import UIKit
import WebKit

final class MemoViewController: UIViewController, WKScriptMessageHandler {
    private let updatePortal =
        "https://cysyforum.muzermat.online/cy-platform/projects/5"
    private let updateProjectAPI =
        "https://cysyforum.muzermat.online/api/backend/cy-platform/projects/5.json"
    private let pairing = PairingManager()
    private var syncServer: LocalSyncServer?
    private var webView: WKWebView!
    private var landscapeLocked = false
    private var lastStoreVersion: Int64 = 0
    private var storeTimer: Timer?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0, green: 0.18, blue: 0.65, alpha: 1)
        configureWebView()
        startSyncServer()
        ReminderManager.shared.requestPermission()
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(applicationDidBecomeActive),
            name: UIApplication.didBecomeActiveNotification,
            object: nil
        )
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        storeTimer = Timer.scheduledTimer(
            withTimeInterval: 1.5,
            repeats: true
        ) { [weak self] _ in
            self?.refreshNativeRecordsIfNeeded()
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        storeTimer?.invalidate()
        storeTimer = nil
    }

    override func viewSafeAreaInsetsDidChange() {
        super.viewSafeAreaInsetsDidChange()
        pushSafeAreaInsets()
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        landscapeLocked
            ? .landscapeRight
            : .portrait
    }

    deinit {
        syncServer?.stop()
        webView?.configuration.userContentController.removeScriptMessageHandler(
            forName: "buaaNative"
        )
        NotificationCenter.default.removeObserver(self)
    }

    private func configureWebView() {
        let controller = WKUserContentController()
        controller.add(self, name: "buaaNative")
        let initialRecords = jsStringLiteral(NativeStore.shared.read())
        let bridgeScript = """
        (function () {
          window.__BUAA_NATIVE_RECORDS__ = \(initialRecords);
          window.__BUAA_DEVICE_INFO__ = "{}";
          function post(action, args) {
            window.webkit.messageHandlers.buaaNative.postMessage({
              action: action,
              args: args || []
            });
          }
          window.AndroidMemo = {
            readRecords: function () {
              return localStorage.getItem("buaa_memo_records_v2")
                || window.__BUAA_NATIVE_RECORDS__
                || "[]";
            },
            writeRecords: function (value) {
              try {
                localStorage.setItem("buaa_memo_records_v2", value);
                window.__BUAA_NATIVE_RECORDS__ = value;
                post("writeRecords", [value]);
                return true;
              } catch (_) { return false; }
            },
            getDeviceInfo: function () {
              return window.__BUAA_DEVICE_INFO__ || "{}";
            },
            requestSync: function () {},
            scheduleReminder: function () {
              post("scheduleReminder", Array.prototype.slice.call(arguments));
            },
            cancelReminder: function (id) { post("cancelReminder", [id]); },
            testReminder: function () {
              post("testReminder", Array.prototype.slice.call(arguments));
            },
            requestReminderSystemPermissions: function () {
              post("requestReminderSystemPermissions");
            },
            checkLatestVersion: function () { post("checkLatestVersion"); },
            openUrl: function (url) { post("openUrl", [url]); },
            setLandscape: function (value) {
              post("setLandscape", [!!value]);
            },
            showToast: function (value) { post("showToast", [value]); }
          };
          window.BUAANativeMergeRecords = function (value) {
            try {
              var records = typeof value === "string"
                ? JSON.parse(value)
                : value;
              var text = JSON.stringify(records || []);
              localStorage.setItem("buaa_memo_records_v2", text);
              window.__BUAA_NATIVE_RECORDS__ = text;
              if (window.BUAAReloadRecords) window.BUAAReloadRecords();
            } catch (_) {}
          };
          window.BUAANativeSetDeviceInfo = function (value) {
            window.__BUAA_DEVICE_INFO__ = String(value || "{}");
          };
        })();
        """
        controller.addUserScript(
            WKUserScript(
                source: bridgeScript,
                injectionTime: .atDocumentStart,
                forMainFrameOnly: true
            )
        )
        let configuration = WKWebViewConfiguration()
        configuration.userContentController = controller
        configuration.websiteDataStore = .default()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true

        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.backgroundColor = view.backgroundColor
        webView.isOpaque = true
        webView.navigationDelegate = self
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        guard let htmlURL = Bundle.main.url(
            forResource: "index",
            withExtension: "html",
            subdirectory: "www"
        ) else {
            showMessage("BUAA浮光界面文件缺失")
            return
        }
        webView.loadFileURL(
            htmlURL,
            allowingReadAccessTo: htmlURL.deletingLastPathComponent()
        )
        lastStoreVersion = NativeStore.shared.version
    }

    private func startSyncServer() {
        let server = LocalSyncServer(pairing: pairing)
        server.onRecordsChanged = { [weak self] records in
            DispatchQueue.main.async {
                guard let self = self, let webView = self.webView else {
                    return
                }
                let literal = self.jsStringLiteral(records)
                webView.evaluateJavaScript(
                    "window.BUAANativeMergeRecords && window.BUAANativeMergeRecords(\(literal));"
                )
            }
        }
        server.start()
        syncServer = server
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.pushDeviceInfo()
        }
    }

    private func pushDeviceInfo() {
        guard let syncServer = syncServer else { return }
        let info: [String: Any] = [
            "ip": NetworkAddress.localIPv4(),
            "port": syncServer.port,
            "name": "BUAA浮光 iOS",
            "device_id": pairing.deviceID,
            "device_name": pairing.deviceName,
            "pairing_code": pairing.pairingCode
        ]
        guard let data = try? JSONSerialization.data(withJSONObject: info),
              let text = String(data: data, encoding: .utf8) else {
            return
        }
        let literal = jsStringLiteral(text)
        webView.evaluateJavaScript(
            "window.BUAANativeSetDeviceInfo && window.BUAANativeSetDeviceInfo(\(literal));"
        )
    }

    private func pushSafeAreaInsets() {
        guard webView != nil else { return }
        let insets = view.safeAreaInsets
        webView.evaluateJavaScript(
            "window.BUAASetSystemInsets && window.BUAASetSystemInsets(\(insets.top),\(insets.bottom),\(insets.left),\(insets.right));"
        )
    }

    private func refreshNativeRecordsIfNeeded() {
        let current = NativeStore.shared.version
        guard current != lastStoreVersion else { return }
        lastStoreVersion = current
        let literal = jsStringLiteral(NativeStore.shared.read())
        webView.evaluateJavaScript(
            "window.BUAANativeMergeRecords && window.BUAANativeMergeRecords(\(literal));"
        )
    }

    @objc private func applicationDidBecomeActive() {
        if syncServer == nil {
            startSyncServer()
        }
        pushDeviceInfo()
    }

    func userContentController(
        _ userContentController: WKUserContentController,
        didReceive message: WKScriptMessage
    ) {
        guard message.name == "buaaNative",
              let body = message.body as? [String: Any],
              let action = body["action"] as? String else {
            return
        }
        let args = body["args"] as? [Any] ?? []
        switch action {
        case "writeRecords":
            guard let value = args.first as? String else { return }
            _ = NativeStore.shared.write(value)
            lastStoreVersion = NativeStore.shared.version
        case "scheduleReminder":
            guard args.count >= 8 else { return }
            let memoID = string(args[0])
            ReminderManager.shared.requestPermission { granted in
                guard granted else {
                    DispatchQueue.main.async {
                        self.showMessage("请在系统设置中允许 BUAA浮光发送通知")
                    }
                    return
                }
                ReminderManager.shared.schedule(
                    memoID: memoID,
                    triggerAt: number(args[1]) / 1000,
                    title: self.string(args[2]),
                    body: self.string(args[3]),
                    soundEnabled: self.bool(args[5])
                )
            }
        case "cancelReminder":
            guard let memoID = args.first as? String else { return }
            ReminderManager.shared.cancel(memoID: memoID)
        case "testReminder":
            ReminderManager.shared.requestPermission { granted in
                guard granted else {
                    DispatchQueue.main.async {
                        self.showMessage("请先允许通知权限，再测试提醒")
                    }
                    return
                }
                ReminderManager.shared.scheduleTest(
                    title: "BUAA浮光测试提醒",
                    body: "锁屏通知与提醒设置已生效。",
                    soundEnabled: args.count > 1 && self.bool(args[1])
                )
            }
        case "requestReminderSystemPermissions":
            ReminderManager.shared.requestPermission()
        case "checkLatestVersion":
            checkLatestVersion()
        case "openUrl":
            guard let raw = args.first as? String,
                  let url = URL(string: raw),
                  ["http", "https"].contains(url.scheme?.lowercased() ?? "") else {
                return
            }
            UIApplication.shared.open(url)
        case "setLandscape":
            setLandscape(args.first.map(bool) ?? false)
        case "showToast":
            showMessage(string(args.first))
        default:
            break
        }
    }

    private func checkLatestVersion() {
        guard let url = URL(string: updateProjectAPI) else {
            returnUpdateResult(["ok": false])
            return
        }
        var request = URLRequest(url: url)
        request.timeoutInterval = 14
        request.setValue("BUAA浮光-iOS/4.1", forHTTPHeaderField: "User-Agent")
        URLSession.shared.dataTask(with: request) { [weak self] data, response, _ in
            guard let self = self else { return }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            if status == 401 || status == 403 {
                self.returnUpdateResult([
                    "ok": false,
                    "auth_required": true
                ])
                return
            }
            guard let data = data,
                  let raw = try? JSONSerialization.jsonObject(with: data),
                  let object = raw as? [String: Any] else {
                self.returnUpdateResult(["ok": false])
                return
            }
            let version =
                object["latest_version"] as? String
                ?? (object["version"] as? String)
                ?? ""
            self.returnUpdateResult([
                "ok": !version.isEmpty,
                "version": version
            ])
        }.resume()
    }

    private func returnUpdateResult(_ object: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: object),
              let text = String(data: data, encoding: .utf8) else {
            return
        }
        DispatchQueue.main.async {
            let literal = self.jsStringLiteral(text)
            self.webView.evaluateJavaScript(
                "window.BUAANativeUpdateResult && window.BUAANativeUpdateResult(\(literal));"
            )
        }
    }

    private func setLandscape(_ enabled: Bool) {
        landscapeLocked = enabled
        if #available(iOS 16.0, *) {
            setNeedsUpdateOfSupportedInterfaceOrientations()
            if let scene = view.window?.windowScene {
                scene.requestGeometryUpdate(
                    .iOS(
                        interfaceOrientations: enabled
                            ? .landscapeRight
                            : .portrait
                    )
                )
            }
        } else {
            UIDevice.current.setValue(
                enabled
                    ? UIInterfaceOrientation.landscapeRight.rawValue
                    : UIInterfaceOrientation.portrait.rawValue,
                forKey: "orientation"
            )
            UIViewController.attemptRotationToDeviceOrientation()
        }
    }

    private func showMessage(_ message: String) {
        guard !message.isEmpty else { return }
        let alert = UIAlertController(
            title: "BUAA浮光",
            message: message,
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "知道了", style: .default))
        present(alert, animated: true)
    }

    private func string(_ value: Any?) -> String {
        value as? String ?? ""
    }

    private func number(_ value: Any?) -> Double {
        (value as? NSNumber)?.doubleValue ?? 0
    }

    private func bool(_ value: Any?) -> Bool {
        (value as? NSNumber)?.boolValue ?? (value as? Bool) ?? false
    }

    private func jsStringLiteral(_ value: String) -> String {
        guard let data = try? JSONSerialization.data(
            withJSONObject: value,
            options: .fragmentsAllowed
        ), let result = String(data: data, encoding: .utf8) else {
            return "\"\""
        }
        return result
    }
}

extension MemoViewController: WKNavigationDelegate {
    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationAction: WKNavigationAction,
        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
    ) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }
        if url.isFileURL || url.scheme == "about" {
            decisionHandler(.allow)
        } else {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
        }
    }

    func webView(
        _ webView: WKWebView,
        didFinish navigation: WKNavigation!
    ) {
        pushSafeAreaInsets()
        pushDeviceInfo()
    }
}
