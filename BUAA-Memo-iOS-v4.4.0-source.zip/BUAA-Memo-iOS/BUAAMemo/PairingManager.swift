import Foundation

final class PairingManager {
    private enum Keys {
        static let code = "buaa_ios_pairing_code"
        static let device = "buaa_ios_device_id"
        static let token = "buaa_ios_sync_token"
    }

    let pairingCode: String
    let deviceID: String
    let syncToken: String
    private var failedAttempts = 0
    private var blockedUntil: TimeInterval = 0

    init(defaults: UserDefaults = .standard) {
        let savedCode = defaults.string(forKey: Keys.code) ?? ""
        let savedDevice = defaults.string(forKey: Keys.device) ?? ""
        let savedToken = defaults.string(forKey: Keys.token) ?? ""
        pairingCode = savedCode.count == 6
            ? savedCode
            : String(format: "%06d", Int.random(in: 0...999_999))
        deviceID = savedDevice.count >= 4
            ? savedDevice
            : String(format: "%04X", Int.random(in: 0...0xFFFF))
        syncToken = savedToken.count >= 24
            ? savedToken
            : PairingManager.randomToken()
        defaults.set(pairingCode, forKey: Keys.code)
        defaults.set(deviceID, forKey: Keys.device)
        defaults.set(syncToken, forKey: Keys.token)
    }

    var deviceName: String { "BUAA-\(deviceID)" }

    func blockedSecondsRemaining() -> Int {
        let remaining = blockedUntil - Date().timeIntervalSince1970
        return remaining > 0 ? Int(ceil(remaining)) : 0
    }

    func attemptPair(_ candidate: String) -> String? {
        let now = Date().timeIntervalSince1970
        if blockedUntil > now { return nil }
        if constantTimeEquals(candidate.trimmingCharacters(in: .whitespacesAndNewlines), pairingCode) {
            failedAttempts = 0
            return syncToken
        }
        failedAttempts += 1
        if failedAttempts >= 5 {
            failedAttempts = 0
            blockedUntil = now + 60
        }
        return nil
    }

    func tokenMatches(_ candidate: String) -> Bool {
        constantTimeEquals(
            candidate.trimmingCharacters(in: .whitespacesAndNewlines),
            syncToken
        )
    }

    private func constantTimeEquals(_ lhs: String, _ rhs: String) -> Bool {
        let left = Array(lhs.utf8)
        let right = Array(rhs.utf8)
        guard left.count == right.count else { return false }
        var difference: UInt8 = 0
        for index in left.indices {
            difference |= left[index] ^ right[index]
        }
        return difference == 0
    }

    private static func randomToken() -> String {
        var bytes = [UInt8](repeating: 0, count: 32)
        for index in bytes.indices {
            bytes[index] = UInt8.random(in: 0...255)
        }
        return Data(bytes).base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }
}
