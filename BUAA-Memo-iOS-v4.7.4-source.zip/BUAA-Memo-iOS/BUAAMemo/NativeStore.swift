import Foundation

final class NativeStore {
    static let shared = NativeStore()

    private let lock = NSLock()
    private let fileURL: URL
    private var versionValue = Int64(Date().timeIntervalSince1970 * 1000)

    private init() {
        let root = FileManager.default.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        )[0].appendingPathComponent("BUAAMemo", isDirectory: true)
        try? FileManager.default.createDirectory(
            at: root,
            withIntermediateDirectories: true
        )
        fileURL = root.appendingPathComponent("records.json")
    }

    func read() -> String {
        lock.lock()
        defer { lock.unlock() }
        guard let data = try? Data(contentsOf: fileURL),
              let text = String(data: data, encoding: .utf8) else {
            return "[]"
        }
        return text
    }

    @discardableResult
    func write(_ content: String) -> Bool {
        lock.lock()
        defer { lock.unlock() }
        guard let data = content.data(using: .utf8) else { return false }
        do {
            try data.write(to: fileURL, options: .atomic)
            versionValue = Int64(Date().timeIntervalSince1970 * 1000)
            return true
        } catch {
            return false
        }
    }

    var version: Int64 {
        lock.lock()
        defer { lock.unlock() }
        let modified = (try? fileURL.resourceValues(
            forKeys: [.contentModificationDateKey]
        ).contentModificationDate?.timeIntervalSince1970) ?? 0
        return versionValue &+ Int64(modified * 1000)
    }
}
