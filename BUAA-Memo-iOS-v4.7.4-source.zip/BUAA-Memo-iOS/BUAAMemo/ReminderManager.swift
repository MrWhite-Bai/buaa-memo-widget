import Foundation
import UserNotifications

final class ReminderManager: NSObject, UNUserNotificationCenterDelegate {
    static let shared = ReminderManager()

    private override init() {
        super.init()
        UNUserNotificationCenter.current().delegate = self
    }

    func requestPermission(completion: ((Bool) -> Void)? = nil) {
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
            DispatchQueue.main.async {
                completion?(granted)
            }
        }
    }

    func schedule(
        memoID: String,
        triggerAt: TimeInterval,
        title: String,
        body: String,
        soundEnabled: Bool
    ) {
        let delay = triggerAt - Date().timeIntervalSince1970
        guard !memoID.isEmpty, delay > 0 else {
            cancel(memoID: memoID)
            return
        }
        let content = UNMutableNotificationContent()
        content.title = "BUAA浮光提醒"
        content.subtitle = title
        content.body = body
        content.sound = soundEnabled
            ? UNNotificationSound(
                named: UNNotificationSoundName("water_drop_twice.wav")
            )
            : nil
        content.userInfo = ["memo_id": memoID]
        content.threadIdentifier = "buaa-memo-reminders"
        if #available(iOS 15.0, *) {
            content.interruptionLevel = .timeSensitive
        }
        let trigger = UNTimeIntervalNotificationTrigger(
            timeInterval: max(1, delay),
            repeats: false
        )
        let request = UNNotificationRequest(
            identifier: reminderIdentifier(memoID),
            content: content,
            trigger: trigger
        )
        UNUserNotificationCenter.current().add(request)
    }

    func cancel(memoID: String) {
        guard !memoID.isEmpty else { return }
        UNUserNotificationCenter.current().removePendingNotificationRequests(
            withIdentifiers: [reminderIdentifier(memoID)]
        )
        UNUserNotificationCenter.current().removeDeliveredNotifications(
            withIdentifiers: [reminderIdentifier(memoID)]
        )
    }

    func scheduleTest(
        title: String,
        body: String,
        soundEnabled: Bool
    ) {
        schedule(
            memoID: "__buaa_ios_reminder_test__",
            triggerAt: Date().timeIntervalSince1970 + 3,
            title: title,
            body: body,
            soundEnabled: soundEnabled
        )
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler:
            @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        completionHandler([.banner, .list, .sound])
    }

    private func reminderIdentifier(_ memoID: String) -> String {
        "buaa-memo-reminder-\(memoID)"
    }
}
