#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""BUAA 备忘倒计时 - a small, dependency-free Windows desktop memo widget."""

from __future__ import annotations

import ctypes
import calendar as calendar_module
import json
import math
import os
import shutil
import secrets
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
import tkinter as tk


APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
IMAGE_DIR = DATA_DIR / "images"
DATA_FILE = DATA_DIR / "memos.json"
CONVERT_SCRIPT = APP_DIR / "tools" / "convert_image.ps1"
ICON_FILE = APP_DIR / "assets" / "buaa.ico"
WEB_CONTROL_HTML = APP_DIR / "web_control.html"
OFFLINE_MOBILE_JS = APP_DIR / "offline_mobile.js"
CHANGELOG_FILE = APP_DIR / "changelog.json"
VENDOR_DIR = APP_DIR / "vendor"

if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))
if VENDOR_DIR.is_dir():
    sys.path.insert(0, str(VENDOR_DIR))

from wechat_bridge import MemoApiError, MemoWebBridge, MemoWebServer, draw_qr_on_canvas
from updater import (
    UpdateError,
    apply_patch,
    download_verified,
    fetch_manifest,
    is_newer,
    schedule_restart,
)

FONT = "Microsoft YaHei UI"
NUMBER_FONT = "Segoe UI Semibold"

BG = "#EDF3F9"
SURFACE = "#FFFFFF"
NAVY = "#0A3B75"
BLUE = "#1E66D0"
BLUE_DARK = "#144EAA"
BLUE_SOFT = "#EAF2FF"
TEXT = "#172033"
MUTED = "#68758A"
BORDER = "#D9E2ED"
DANGER = "#C94141"
DANGER_SOFT = "#FDEEEE"
WARNING = "#B8650B"
WARNING_SOFT = "#FFF3E3"
SUCCESS = "#247A55"
SUCCESS_SOFT = "#EAF7F1"
MUTEX_HANDLE = None
FALLBACK_VERSION = "1.8.0"
UPDATE_MANIFEST_URL = (
    "https://api.github.com/repos/MrWhite-Bai/"
    "buaa-memo-widget/contents/update-manifest.json?ref=main"
)
DOWNLOAD_PAGE_URL = "https://github.com/MrWhite-Bai/buaa-memo-widget"
FALLBACK_CHANGELOG = {
    "current_version": FALLBACK_VERSION,
    "entries": [
        {
            "version": FALLBACK_VERSION,
            "date": "2026-10-20",
            "title": "扫码获取版本",
            "changes": ["新增电脑版和手机版下载二维码。"],
        }
    ],
}


def make_dpi_aware() -> None:
    if os.name != "nt":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def focus_existing_instance() -> bool:
    """Create a single-instance mutex, or focus the window that already exists."""
    global MUTEX_HANDLE
    if os.name != "nt":
        return True
    try:
        kernel32 = ctypes.windll.kernel32
        MUTEX_HANDLE = kernel32.CreateMutexW(
            None,
            False,
            "Local\\BUAA_Memo_Widget_SingleInstance",
        )
        if kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
            user32 = ctypes.windll.user32
            handle = user32.FindWindowW(None, "BUAA 备忘倒计时")
            if handle:
                user32.ShowWindow(handle, 9)  # SW_RESTORE
                user32.SetForegroundWindow(handle)
                return False
            # A stale background process must not prevent a fresh widget from
            # opening. If no real top-level window exists, continue normally.
    except Exception:
        pass
    return True


def format_duration(seconds: int) -> str:
    seconds = max(0, int(seconds))
    days, remainder = divmod(seconds, 86_400)
    hours, remainder = divmod(remainder, 3_600)
    minutes, secs = divmod(remainder, 60)
    if days:
        return f"{days:02d} 天 {hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def parse_deadline(value: str) -> datetime:
    return datetime.fromisoformat(value)


def now_revision() -> int:
    return int(time.time() * 1000)


def parse_revision(record: dict) -> int:
    try:
        value = int(record.get("rev", 0))
        if value > 0:
            return value
    except (TypeError, ValueError):
        pass
    for field in ("updated_at", "created_at"):
        raw = record.get(field)
        if not raw:
            continue
        try:
            return int(datetime.fromisoformat(str(raw)).timestamp() * 1000)
        except (TypeError, ValueError, OSError):
            pass
    return 0


def load_changelog() -> dict:
    try:
        with CHANGELOG_FILE.open("r", encoding="utf-8") as handle:
            loaded = json.load(handle)
        if not isinstance(loaded, dict):
            raise ValueError("更新日志格式不正确")
        entries = loaded.get("entries")
        if not isinstance(entries, list) or not entries:
            raise ValueError("更新日志为空")
        normalized = []
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            changes = entry.get("changes")
            if not isinstance(changes, list):
                changes = []
            normalized.append(
                {
                    "version": str(entry.get("version", "")).strip(),
                    "date": str(entry.get("date", "")).strip(),
                    "title": str(entry.get("title", "版本更新")).strip(),
                    "changes": [str(change) for change in changes if str(change).strip()],
                }
            )
        normalized = [entry for entry in normalized if entry["version"]]
        if not normalized:
            raise ValueError("更新日志没有有效记录")
        current_version = str(
            loaded.get("current_version") or normalized[0]["version"]
        ).strip()
        return {"current_version": current_version, "entries": normalized}
    except Exception:
        return json.loads(json.dumps(FALLBACK_CHANGELOG, ensure_ascii=False))


def deadline_state(value: str) -> tuple[str, str, str, str]:
    """Return countdown text, primary color, status text, soft color."""
    try:
        deadline = parse_deadline(value)
    except (TypeError, ValueError):
        return "时间格式错误", DANGER, "需修正", DANGER_SOFT

    seconds = int((deadline - datetime.now()).total_seconds())
    if seconds <= 0:
        return "已到期", DANGER, "已到期", DANGER_SOFT
    if seconds <= 86_400:
        return format_duration(seconds), WARNING, "24 小时内", WARNING_SOFT
    return format_duration(seconds), BLUE, "进行中", BLUE_SOFT


def load_preview(path: Path, max_width: int, max_height: int) -> tk.PhotoImage:
    image = tk.PhotoImage(file=str(path))
    factor = max(
        1,
        math.ceil(image.width() / max_width),
        math.ceil(image.height() / max_height),
    )
    if factor > 1:
        image = image.subsample(factor, factor)
    return image


def bind_hover(widget: tk.Widget, normal: str, hover: str) -> None:
    widget.bind("<Enter>", lambda _event: widget.configure(bg=hover))
    widget.bind("<Leave>", lambda _event: widget.configure(bg=normal))


class DatePickerPopup(tk.Toplevel):
    WEEKDAYS = ("一", "二", "三", "四", "五", "六", "日")

    def __init__(self, owner: "AddMemoDialog", date_var: tk.StringVar, on_select) -> None:
        super().__init__(owner)
        self.owner = owner
        self.date_var = date_var
        self.on_select = on_select
        self.selected_date = self._parse_selected_date()
        self.view_year = self.selected_date.year
        self.view_month = self.selected_date.month

        self.title("选择日期 · BUAA")
        self.configure(bg="#CBD9E9")
        self.resizable(False, False)
        self.transient(owner)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.bind("<Escape>", lambda _event: self.close())
        self._build_ui()
        self._render_month()
        self._position()
        self.lift()
        self.after(80, self.focus_force)

    def _parse_selected_date(self):
        try:
            return datetime.strptime(self.date_var.get().strip(), "%Y-%m-%d").date()
        except ValueError:
            return datetime.now().date()

    def _build_ui(self) -> None:
        shell = tk.Frame(self, bg="#CBD9E9")
        shell.pack(fill="both", expand=True, padx=1, pady=1)
        panel = tk.Frame(shell, bg=SURFACE)
        panel.pack(fill="both", expand=True)

        header = tk.Frame(panel, bg=SURFACE)
        header.pack(fill="x", padx=14, pady=(12, 5))

        self._nav_button(header, "«", lambda: self._change_year(-1)).pack(side="left")
        self._nav_button(header, "‹", lambda: self._change_month(-1)).pack(
            side="left", padx=(4, 0)
        )
        self.month_label = tk.Label(
            header,
            text="",
            bg=SURFACE,
            fg=TEXT,
            font=(FONT, 12, "bold"),
        )
        self.month_label.pack(side="left", expand=True)
        self._nav_button(header, "›", lambda: self._change_month(1)).pack(side="left")
        self._nav_button(header, "»", lambda: self._change_year(1)).pack(
            side="left", padx=(4, 0)
        )
        close = tk.Button(
            header,
            text="×",
            command=self.close,
            bg=SURFACE,
            fg=MUTED,
            activebackground="#F1F5FA",
            activeforeground=TEXT,
            font=(FONT, 12),
            relief="flat",
            bd=0,
            padx=4,
            cursor="hand2",
        )
        close.pack(side="right", padx=(5, 0))

        weekday_row = tk.Frame(panel, bg="#F4F7FB")
        weekday_row.pack(fill="x", padx=12, pady=(2, 3))
        for index, name in enumerate(self.WEEKDAYS):
            weekday_row.grid_columnconfigure(index, weight=1)
            tk.Label(
                weekday_row,
                text=name,
                bg="#F4F7FB",
                fg=MUTED,
                font=(FONT, 8, "bold"),
                pady=5,
            ).grid(row=0, column=index, sticky="nsew")

        self.days_frame = tk.Frame(panel, bg=SURFACE)
        self.days_frame.pack(fill="both", expand=True, padx=12, pady=(2, 4))
        for index in range(7):
            self.days_frame.grid_columnconfigure(index, weight=1)

        footer = tk.Frame(panel, bg="#F7F9FC")
        footer.pack(fill="x", padx=14, pady=(4, 12))
        today_btn = tk.Button(
            footer,
            text="回到今天",
            command=lambda: self._choose_date(datetime.now().date()),
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            activebackground="#DDEBFF",
            activeforeground=BLUE_DARK,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=12,
            pady=5,
            cursor="hand2",
        )
        today_btn.pack(side="left")
        cancel_btn = tk.Button(
            footer,
            text="取消",
            command=self.close,
            bg="#E9EEF5",
            fg=MUTED,
            activebackground="#DEE6F0",
            activeforeground=TEXT,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=12,
            pady=5,
            cursor="hand2",
        )
        cancel_btn.pack(side="right")

    def _nav_button(self, parent: tk.Widget, text: str, command) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg="#EEF4FB",
            fg=BLUE_DARK,
            activebackground=BLUE_SOFT,
            activeforeground=BLUE_DARK,
            font=(FONT, 10, "bold"),
            relief="flat",
            bd=0,
            width=2,
            pady=3,
            cursor="hand2",
        )

    def _position(self) -> None:
        self.owner.update_idletasks()
        width, height = 356, 404
        x = self.owner.winfo_rootx() + (self.owner.winfo_width() - width) // 2
        y = self.owner.winfo_rooty() + 118
        x = max(15, min(x, self.winfo_screenwidth() - width - 15))
        y = max(15, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")

    def _change_month(self, delta: int) -> None:
        month_index = self.view_year * 12 + (self.view_month - 1) + delta
        self.view_year, month_zero = divmod(month_index, 12)
        self.view_month = month_zero + 1
        self._render_month()

    def _change_year(self, delta: int) -> None:
        self.view_year += delta
        self._render_month()

    def _render_month(self) -> None:
        self.month_label.configure(text=f"{self.view_year} 年 {self.view_month} 月")
        for child in self.days_frame.winfo_children():
            child.destroy()

        today = datetime.now().date()
        selected = self._parse_selected_date()
        weeks = calendar_module.Calendar(firstweekday=0).monthdayscalendar(
            self.view_year, self.view_month
        )
        while len(weeks) < 6:
            weeks.append([0] * 7)

        for row_index, week in enumerate(weeks[:6]):
            self.days_frame.grid_rowconfigure(row_index, weight=1)
            for column, day in enumerate(week):
                if day == 0:
                    tk.Label(
                        self.days_frame,
                        text="",
                        bg=SURFACE,
                    ).grid(row=row_index, column=column, sticky="nsew", padx=1, pady=1)
                    continue

                date_value = datetime(self.view_year, self.view_month, day).date()
                is_selected = date_value == selected
                is_today = date_value == today
                is_past = date_value < today

                if is_selected:
                    bg, fg = BLUE, "white"
                elif is_today:
                    bg, fg = BLUE_SOFT, BLUE_DARK
                elif is_past:
                    bg, fg = SURFACE, "#B8C1CD"
                else:
                    bg, fg = SURFACE, TEXT

                button = tk.Button(
                    self.days_frame,
                    text=str(day),
                    command=lambda value=date_value: self._choose_date(value),
                    bg=bg,
                    fg=fg,
                    activebackground=BLUE_SOFT,
                    activeforeground=BLUE_DARK,
                    disabledforeground="#C5CDD8",
                    font=(NUMBER_FONT, 9, "bold" if is_selected or is_today else "normal"),
                    relief="flat",
                    bd=0,
                    state="disabled" if is_past else "normal",
                    cursor="hand2" if not is_past else "arrow",
                )
                button.grid(
                    row=row_index,
                    column=column,
                    sticky="nsew",
                    padx=1,
                    pady=1,
                )

    def _choose_date(self, value) -> None:
        self.date_var.set(value.strftime("%Y-%m-%d"))
        self.on_select(value)
        self.close()

    def close(self) -> None:
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()


class AddMemoDialog(tk.Toplevel):
    def __init__(self, owner: "BUAAmemo", on_save) -> None:
        super().__init__(owner.root)
        self.owner = owner
        self.on_save = on_save
        self.selected_image: Path | None = None
        self.preview_photo: tk.PhotoImage | None = None
        self.saved = False

        self.title("新建事项 · BUAA")
        self.configure(bg="#F7F9FC")
        self.resizable(False, False)
        self.transient(owner.root)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.cancel)

        width, height = 430, 680
        owner.root.update_idletasks()
        x = owner.root.winfo_rootx() + (owner.root.winfo_width() - width) // 2
        y = owner.root.winfo_rooty() + (owner.root.winfo_height() - height) // 2
        x = max(20, min(x, self.winfo_screenwidth() - width - 20))
        y = max(20, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")

        default_deadline = (datetime.now() + timedelta(days=1)).replace(
            hour=18, minute=0, second=0, microsecond=0
        )
        self.date_var = tk.StringVar(value=default_deadline.strftime("%Y-%m-%d"))
        self.image_name_var = tk.StringVar(value="未选择图片")
        self.hour_var = tk.StringVar(value=default_deadline.strftime("%H"))
        self.minute_var = tk.StringVar(value=default_deadline.strftime("%M"))
        self.calendar_popup: DatePickerPopup | None = None

        self._build_ui()
        self.bind("<Escape>", lambda _event: self.cancel())
        self.bind("<Control-Return>", lambda _event: self.save())
        self.after(60, self.title_entry.focus_set)

    def _build_ui(self) -> None:
        top = tk.Frame(self, bg=NAVY, height=82)
        top.pack(fill="x")
        top.pack_propagate(False)
        tk.Label(
            top,
            text="新建事项",
            bg=NAVY,
            fg="white",
            font=(FONT, 18, "bold"),
        ).pack(anchor="w", padx=24, pady=(17, 0))
        tk.Label(
            top,
            text="设置截止时间，剩下的交给倒计时",
            bg=NAVY,
            fg="#C8DAF4",
            font=(FONT, 9),
        ).pack(anchor="w", padx=24, pady=(2, 0))

        body = tk.Frame(self, bg="#F7F9FC")
        body.pack(fill="both", expand=True, padx=22, pady=16)

        self._field_label(body, "事项名称")
        self.title_entry = tk.Entry(
            body,
            font=(FONT, 11),
            bg="white",
            fg=TEXT,
            insertbackground=BLUE,
            relief="flat",
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=BLUE,
        )
        self.title_entry.pack(fill="x", ipady=8, pady=(5, 12))

        self._field_label(body, "截止时间")
        date_row = tk.Frame(body, bg="#F7F9FC")
        date_row.pack(fill="x", pady=(5, 8))
        self.date_entry = tk.Entry(
            date_row,
            textvariable=self.date_var,
            width=14,
            font=(NUMBER_FONT, 10),
            bg="white",
            fg=TEXT,
            insertbackground=BLUE,
            relief="flat",
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=BLUE,
        )
        self.date_entry.pack(side="left", ipady=7)
        tk.Label(
            date_row,
            text="  日期  ",
            bg="#F7F9FC",
            fg=MUTED,
            font=(FONT, 8),
        ).pack(side="left")
        calendar_btn = tk.Button(
            date_row,
            text="打开月历",
            command=self.open_calendar,
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            activebackground="#DDEBFF",
            activeforeground=BLUE_DARK,
            font=(FONT, 9, "bold"),
            relief="flat",
            bd=0,
            padx=12,
            pady=7,
            cursor="hand2",
        )
        calendar_btn.pack(side="left", padx=(8, 0))

        time_row = tk.Frame(body, bg="#F7F9FC")
        time_row.pack(fill="x", pady=(0, 6))
        tk.Label(
            time_row,
            text="时间",
            bg="#F7F9FC",
            fg=TEXT,
            font=(FONT, 9, "bold"),
        ).pack(side="left", padx=(0, 12))
        self.hour_spin = self._time_spinbox(time_row, self.hour_var, 23)
        self.hour_spin.pack(side="left", ipady=4)
        tk.Label(
            time_row,
            text=" : ",
            bg="#F7F9FC",
            fg=TEXT,
            font=(NUMBER_FONT, 11, "bold"),
        ).pack(side="left")
        self.minute_spin = self._time_spinbox(time_row, self.minute_var, 59)
        self.minute_spin.pack(side="left", ipady=4)
        tk.Label(
            time_row,
            text="    可直接输入或点箭头调整",
            bg="#F7F9FC",
            fg=MUTED,
            font=(FONT, 8),
        ).pack(side="left")

        quick_row = tk.Frame(body, bg="#F7F9FC")
        quick_row.pack(fill="x", pady=(0, 12))
        self._quick_button(quick_row, "10 分钟后", 0).pack(side="left", padx=(0, 6))
        self._quick_button(quick_row, "明天 18:00", 1).pack(side="left", padx=(0, 6))
        self._quick_button(quick_row, "3 天后", 2).pack(side="left", padx=(0, 6))
        self._quick_button(quick_row, "1 周后", 3).pack(side="left")

        self._field_label(body, "备注（可选）")
        self.note_text = tk.Text(
            body,
            height=3,
            font=(FONT, 10),
            bg="white",
            fg=TEXT,
            insertbackground=BLUE,
            relief="flat",
            wrap="word",
            padx=8,
            pady=7,
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=BLUE,
        )
        self.note_text.pack(fill="x", pady=(5, 12))

        self._field_label(body, "图片（可选）")
        image_panel = tk.Frame(
            body,
            bg="#F1F5FA",
            height=86,
            highlightthickness=1,
            highlightbackground="#E3EAF3",
        )
        image_panel.pack(fill="x", pady=(5, 0))
        image_panel.pack_propagate(False)
        self.image_preview = tk.Label(
            image_panel,
            text="可添加截图或参考图\n支持 PNG / JPG / BMP / GIF",
            bg="#F1F5FA",
            fg=MUTED,
            font=(FONT, 8),
            justify="center",
        )
        self.image_preview.pack(side="left", fill="both", expand=True)
        image_actions = tk.Frame(image_panel, bg="#F1F5FA")
        image_actions.pack(side="right", padx=10)
        self.choose_image_btn = tk.Button(
            image_actions,
            text="选择图片",
            command=self.choose_image,
            bg="white",
            fg=BLUE,
            activebackground=BLUE_SOFT,
            activeforeground=BLUE_DARK,
            font=(FONT, 9),
            relief="flat",
            bd=0,
            padx=12,
            pady=6,
            cursor="hand2",
        )
        self.choose_image_btn.pack()
        self.remove_image_btn = tk.Button(
            image_actions,
            text="移除图片",
            command=self.remove_image,
            bg="#F1F5FA",
            fg=MUTED,
            activebackground="#F1F5FA",
            activeforeground=DANGER,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            cursor="hand2",
            state="disabled",
        )
        self.remove_image_btn.pack(pady=(4, 0))

        footer = tk.Frame(self, bg="#F7F9FC")
        footer.pack(fill="x", padx=22, pady=(0, 18))
        cancel_btn = tk.Button(
            footer,
            text="取消",
            command=self.cancel,
            bg="#E9EEF5",
            fg=MUTED,
            activebackground="#DEE6F0",
            activeforeground=TEXT,
            font=(FONT, 10),
            relief="flat",
            bd=0,
            padx=20,
            pady=9,
            cursor="hand2",
        )
        cancel_btn.pack(side="left")
        save_btn = tk.Button(
            footer,
            text="保存事项",
            command=self.save,
            bg=BLUE,
            fg="white",
            activebackground=BLUE_DARK,
            activeforeground="white",
            font=(FONT, 10, "bold"),
            relief="flat",
            bd=0,
            padx=24,
            pady=9,
            cursor="hand2",
        )
        save_btn.pack(side="right")
        bind_hover(save_btn, BLUE, BLUE_DARK)
        bind_hover(cancel_btn, "#E9EEF5", "#DEE6F0")

    def _field_label(self, parent: tk.Widget, text: str) -> None:
        tk.Label(
            parent,
            text=text,
            bg="#F7F9FC",
            fg=TEXT,
            font=(FONT, 9, "bold"),
        ).pack(anchor="w")

    def _quick_button(self, parent: tk.Widget, text: str, preset: int) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=lambda: self.set_preset(preset),
            bg="#EAF1FA",
            fg=BLUE_DARK,
            activebackground=BLUE_SOFT,
            activeforeground=BLUE_DARK,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=9,
            pady=4,
            cursor="hand2",
        )

    def _time_spinbox(
        self,
        parent: tk.Widget,
        variable: tk.StringVar,
        maximum: int,
    ) -> tk.Spinbox:
        return tk.Spinbox(
            parent,
            from_=0,
            to=maximum,
            increment=1,
            wrap=True,
            format="%02.0f",
            textvariable=variable,
            width=4,
            justify="center",
            font=(NUMBER_FONT, 11),
            bg="white",
            fg=TEXT,
            insertbackground=BLUE,
            buttonbackground="#EAF1FA",
            relief="flat",
            bd=0,
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=BLUE,
        )

    def open_calendar(self) -> None:
        if self.calendar_popup and self.calendar_popup.winfo_exists():
            self.calendar_popup.lift()
            return
        self.calendar_popup = DatePickerPopup(
            self,
            self.date_var,
            self._date_chosen,
        )
        self.calendar_popup.bind(
            "<Destroy>",
            self._on_calendar_destroy,
            add="+",
        )

    def _on_calendar_destroy(self, event) -> None:
        if event.widget is self.calendar_popup:
            self.calendar_popup = None

    def _date_chosen(self, _value) -> None:
        self.after(20, self.hour_spin.focus_set)

    def set_preset(self, preset: int) -> None:
        now = datetime.now()
        if preset == 0:
            target = (now + timedelta(minutes=10)).replace(second=0, microsecond=0)
        elif preset == 1:
            target = (now + timedelta(days=1)).replace(
                hour=18, minute=0, second=0, microsecond=0
            )
        elif preset == 2:
            target = (now + timedelta(days=3)).replace(
                hour=18, minute=0, second=0, microsecond=0
            )
        else:
            target = (now + timedelta(days=7)).replace(
                hour=18, minute=0, second=0, microsecond=0
            )
        self.date_var.set(target.strftime("%Y-%m-%d"))
        self.hour_var.set(target.strftime("%H"))
        self.minute_var.set(target.strftime("%M"))

    def choose_image(self) -> None:
        source = filedialog.askopenfilename(
            parent=self,
            title="选择一张图片",
            filetypes=[
                ("图片", "*.png *.jpg *.jpeg *.bmp *.gif"),
                ("所有文件", "*.*"),
            ],
        )
        if not source:
            return

        source_path = Path(source)
        if not source_path.is_file():
            messagebox.showerror("无法读取图片", "选择的文件不存在。", parent=self)
            return

        IMAGE_DIR.mkdir(parents=True, exist_ok=True)
        destination = IMAGE_DIR / f"img_{uuid.uuid4().hex}.png"
        try:
            self.owner.convert_image(source_path, destination, 900, 600)
            photo = load_preview(destination, 220, 72)
        except Exception as exc:
            if destination.exists():
                destination.unlink(missing_ok=True)
            messagebox.showerror(
                "图片添加失败",
                f"无法读取这张图片。\n\n{exc}",
                parent=self,
            )
            return

        self.remove_image(delete_file=True, refresh=False)
        self.selected_image = destination
        self.preview_photo = photo
        self.image_preview.configure(image=photo, text="", bg="#E7EEF7")
        self.image_name_var.set(source_path.name)
        self.remove_image_btn.configure(state="normal")

    def remove_image(self, delete_file: bool = True, refresh: bool = True) -> None:
        if delete_file and self.selected_image and self.selected_image.exists():
            try:
                self.selected_image.unlink()
            except OSError:
                pass
        self.selected_image = None
        self.preview_photo = None
        self.remove_image_btn.configure(state="disabled")
        if refresh:
            self.image_preview.configure(
                image="",
                text="可添加截图或参考图\n支持 PNG / JPG / BMP / GIF",
                bg="#F1F5FA",
            )
            self.image_name_var.set("未选择图片")

    def save(self) -> None:
        title = self.title_entry.get().strip()
        if not title:
            messagebox.showwarning("还差一步", "请填写事项名称。", parent=self)
            self.title_entry.focus_set()
            return

        date_text = self.date_var.get().strip()
        try:
            selected_day = datetime.strptime(date_text, "%Y-%m-%d").date()
            hour = int(self.hour_var.get().strip())
            minute = int(self.minute_var.get().strip())
            if not 0 <= hour <= 23 or not 0 <= minute <= 59:
                raise ValueError
            deadline = datetime.combine(selected_day, datetime.min.time()).replace(
                hour=hour,
                minute=minute,
            )
        except (TypeError, ValueError):
            messagebox.showwarning(
                "时间格式不正确",
                "日期请填写为 2026-10-20，小时请选择 0–23，分钟请选择 0–59。",
                parent=self,
            )
            return

        if deadline <= datetime.now():
            messagebox.showwarning(
                "截止时间已过",
                "请选择一个晚于当前时间的截止时间。",
                parent=self,
            )
            return

        self.date_var.set(deadline.strftime("%Y-%m-%d"))
        self.hour_var.set(deadline.strftime("%H"))
        self.minute_var.set(deadline.strftime("%M"))

        image_rel = None
        if self.selected_image and self.selected_image.exists():
            image_rel = self.selected_image.relative_to(APP_DIR).as_posix()

        item = {
            "id": uuid.uuid4().hex,
            "title": title,
            "note": self.note_text.get("1.0", "end").strip(),
            "deadline": deadline.isoformat(timespec="seconds"),
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "image": image_rel,
        }
        self.saved = True
        self.grab_release()
        self.destroy()
        self.on_save(item)

    def cancel(self) -> None:
        if not self.saved:
            self.remove_image(delete_file=True, refresh=False)
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()


class WeChatControlWindow(tk.Toplevel):
    def __init__(self, app: "BUAAmemo", url: str) -> None:
        super().__init__(app.root)
        self.app = app
        self.url = url
        self.title("微信控制 · BUAA")
        self.configure(bg=BG)
        self.resizable(False, False)
        self.transient(app.root)
        self.protocol("WM_DELETE_WINDOW", self.close)

        width, height = 430, 650
        app.root.update_idletasks()
        x = app.root.winfo_rootx() + (app.root.winfo_width() - width) // 2
        y = app.root.winfo_rooty() + (app.root.winfo_height() - height) // 2
        x = max(20, min(x, self.winfo_screenwidth() - width - 20))
        y = max(20, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")

        header = tk.Frame(self, bg=NAVY, height=88)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header,
            text="微信控制",
            bg=NAVY,
            fg="white",
            font=(FONT, 19, "bold"),
        ).pack(anchor="w", padx=24, pady=(17, 0))
        tk.Label(
            header,
            text="用微信扫一扫，手机上也能管理和同步事项",
            bg=NAVY,
            fg="#C8DAF4",
            font=(FONT, 9),
        ).pack(anchor="w", padx=24, pady=(3, 0))

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=24, pady=(14, 0))

        qr_card = tk.Frame(
            body,
            bg="white",
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        qr_card.pack()
        self.qr_canvas = tk.Canvas(
            qr_card,
            width=218,
            height=218,
            bg="white",
            bd=0,
            highlightthickness=0,
        )
        self.qr_canvas.pack(padx=11, pady=11)
        try:
            draw_qr_on_canvas(self.qr_canvas, url, 218, NAVY)
        except Exception as exc:
            self.qr_canvas.create_text(
                109,
                109,
                text=f"二维码生成失败\n{exc}",
                fill=DANGER,
                font=(FONT, 9),
                justify="center",
                width=210,
            )

        tk.Label(
            body,
            text="用微信“扫一扫”打开手机控制页",
            bg=BG,
            fg=TEXT,
            font=(FONT, 11, "bold"),
        ).pack(pady=(13, 3))

        url_row = tk.Frame(body, bg=BG)
        url_row.pack(fill="x", pady=(4, 0))
        self.url_label = tk.Label(
            url_row,
            text=url,
            bg="#E2EBF6",
            fg="#405674",
            font=(NUMBER_FONT, 7),
            padx=9,
            pady=6,
            anchor="w",
            justify="left",
            wraplength=318,
        )
        self.url_label.pack(side="left", fill="x", expand=True)
        self.copy_btn = tk.Button(
            url_row,
            text="复制",
            command=self.copy_url,
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            activebackground="#DDEBFF",
            activeforeground=BLUE_DARK,
            font=(FONT, 8, "bold"),
            relief="flat",
            bd=0,
            padx=10,
            pady=6,
            cursor="hand2",
        )
        self.copy_btn.pack(side="right", padx=(7, 0))

        status = tk.Frame(body, bg="#EAF7F1", padx=11, pady=7)
        status.pack(fill="x", pady=(13, 0))
        tk.Label(
            status,
            text="●",
            bg="#EAF7F1",
            fg=SUCCESS,
            font=(FONT, 9),
        ).pack(side="left")
        tk.Label(
            status,
            text="控制服务运行中 · 仅同一 Wi‑Fi 可访问",
            bg="#EAF7F1",
            fg=SUCCESS,
            font=(FONT, 8),
        ).pack(side="left", padx=(5, 0))

        help_box = tk.Frame(body, bg="#F8FAFD")
        help_box.pack(fill="x", pady=(12, 0))
        for line in (
            "1. 手机和电脑需要连接同一个 Wi‑Fi。",
            "2. 下载离线手机版后，电脑关机时也能继续记录，联网后自动合并。",
            "3. 若手机打不开，请允许 Python 通过 Windows 专用网络防火墙。",
        ):
            tk.Label(
                help_box,
                text=line,
                bg="#F8FAFD",
                fg=MUTED,
                font=(FONT, 8),
                anchor="w",
                justify="left",
                wraplength=375,
            ).pack(fill="x", padx=12, pady=2)

        close_btn = tk.Button(
            body,
            text="关闭",
            command=self.close,
            bg="#E9EEF5",
            fg=MUTED,
            activebackground="#DEE6F0",
            activeforeground=TEXT,
            font=(FONT, 9),
            relief="flat",
            bd=0,
            padx=22,
            pady=8,
            cursor="hand2",
        )
        close_btn.pack(pady=(10, 8))
        self.bind("<Escape>", lambda _event: self.close())

    def copy_url(self) -> None:
        self.clipboard_clear()
        self.clipboard_append(self.url)
        self.copy_btn.configure(text="已复制")
        self.after(1400, lambda: self.copy_btn.configure(text="复制"))

    def close(self) -> None:
        if self.app.web_window is self:
            self.app.web_window = None
        self.destroy()


class DownloadQrWindow(tk.Toplevel):
    def __init__(
        self,
        app: "BUAAmemo",
        desktop_url: str,
        mobile_url: str,
    ) -> None:
        super().__init__(app.root)
        self.app = app
        self.desktop_url = desktop_url
        self.mobile_url = mobile_url
        self.title("扫码获取版本 · BUAA")
        self.configure(bg=BG)
        self.resizable(False, False)
        self.transient(app.root)
        self.protocol("WM_DELETE_WINDOW", self.close)

        width, height = 640, 570
        app.root.update_idletasks()
        x = app.root.winfo_rootx() + (app.root.winfo_width() - width) // 2
        y = app.root.winfo_rooty() + (app.root.winfo_height() - height) // 2
        x = max(20, min(x, self.winfo_screenwidth() - width - 20))
        y = max(20, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")

        header = tk.Frame(self, bg=NAVY, height=94)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header,
            text="扫码获取版本",
            bg=NAVY,
            fg="white",
            font=(FONT, 19, "bold"),
        ).pack(anchor="w", padx=24, pady=(16, 0))
        tk.Label(
            header,
            text="电脑版和手机版分别扫码获取",
            bg=NAVY,
            fg="#C8DAF4",
            font=(FONT, 9),
        ).pack(anchor="w", padx=24, pady=(3, 0))

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=20, pady=16)
        body.grid_columnconfigure(0, weight=1)
        body.grid_columnconfigure(1, weight=1)
        self._build_card(
            body,
            column=0,
            title="电脑版",
            subtitle="Windows 完整版",
            description="扫码打开 GitHub 下载页，下载后解压运行。",
            url=desktop_url,
        )
        self._build_card(
            body,
            column=1,
            title="手机版",
            subtitle="手机离线 HTML",
            description="手机与电脑连接同一 Wi-Fi 时扫码下载。",
            url=mobile_url,
        )

        tk.Label(
            body,
            text="手机版下载后请用手机浏览器打开并保留文件；电脑版无需安装 Python。",
            bg=BG,
            fg=MUTED,
            font=(FONT, 8),
            wraplength=560,
            justify="center",
        ).grid(row=1, column=0, columnspan=2, pady=(12, 0))

        close_btn = tk.Button(
            body,
            text="关闭",
            command=self.close,
            bg="#E9EEF5",
            fg=MUTED,
            activebackground="#DEE6F0",
            activeforeground=TEXT,
            font=(FONT, 9),
            relief="flat",
            bd=0,
            padx=22,
            pady=7,
            cursor="hand2",
        )
        close_btn.grid(row=2, column=0, columnspan=2, pady=(12, 0))
        self.bind("<Escape>", lambda _event: self.close())

    def _build_card(
        self,
        parent: tk.Widget,
        column: int,
        title: str,
        subtitle: str,
        description: str,
        url: str,
    ) -> None:
        card = tk.Frame(
            parent,
            bg=SURFACE,
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        card.grid(
            row=0,
            column=column,
            sticky="nsew",
            padx=(4 if column == 0 else 8, 8 if column == 0 else 4),
        )
        tk.Label(
            card,
            text=title,
            bg=SURFACE,
            fg=NAVY,
            font=(FONT, 13, "bold"),
        ).pack(pady=(13, 0))
        tk.Label(
            card,
            text=subtitle,
            bg=SURFACE,
            fg=BLUE,
            font=(FONT, 8),
        ).pack(pady=(1, 7))

        canvas = tk.Canvas(
            card,
            width=218,
            height=218,
            bg="white",
            highlightthickness=0,
        )
        canvas.pack()
        try:
            draw_qr_on_canvas(canvas, url, 218, NAVY)
        except Exception as exc:
            canvas.create_text(
                109,
                109,
                text=f"二维码生成失败\n{exc}",
                fill=DANGER,
                font=(FONT, 9),
                justify="center",
                width=190,
            )
        tk.Label(
            card,
            text=description,
            bg=SURFACE,
            fg=MUTED,
            font=(FONT, 8),
            justify="center",
            wraplength=245,
        ).pack(pady=(9, 5))
        url_label = tk.Label(
            card,
            text=url,
            bg="#F2F6FB",
            fg="#52677F",
            font=(NUMBER_FONT, 7),
            padx=6,
            pady=4,
            wraplength=250,
            justify="left",
        )
        url_label.pack(fill="x", padx=14)
        copy_btn = tk.Button(
            card,
            text="复制地址",
            command=lambda: self.copy_url(url),
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            activebackground="#DDEBFF",
            activeforeground=BLUE_DARK,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=10,
            pady=4,
            cursor="hand2",
        )
        copy_btn.pack(pady=(6, 13))

    def copy_url(self, url: str) -> None:
        self.clipboard_clear()
        self.clipboard_append(url)

    def close(self) -> None:
        if self.app.download_window is self:
            self.app.download_window = None
        self.destroy()


class ChangelogWindow(tk.Toplevel):
    def __init__(self, app: "BUAAmemo", changelog: dict) -> None:
        super().__init__(app.root)
        self.app = app
        self.title("版本更新日志 · BUAA")
        self.configure(bg=BG)
        self.resizable(True, True)
        self.minsize(400, 420)
        self.transient(app.root)

        width, height = 470, 640
        app.root.update_idletasks()
        x = app.root.winfo_rootx() + (app.root.winfo_width() - width) // 2
        y = app.root.winfo_rooty() + (app.root.winfo_height() - height) // 2
        x = max(20, min(x, self.winfo_screenwidth() - width - 20))
        y = max(20, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")

        header = tk.Frame(self, bg=NAVY, height=102)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header,
            text="版本更新日志",
            bg=NAVY,
            fg="white",
            font=(FONT, 19, "bold"),
        ).pack(anchor="w", padx=24, pady=(17, 0))
        tk.Label(
            header,
            text=f"BUAA 备忘倒计时 · 当前版本 v{changelog['current_version']}",
            bg=NAVY,
            fg="#C8DAF4",
            font=(FONT, 9),
        ).pack(anchor="w", padx=24, pady=(3, 0))

        shell = tk.Frame(self, bg=BG)
        shell.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(shell, bg=BG, bd=0, highlightthickness=0)
        scrollbar = ttk.Scrollbar(
            shell,
            orient="vertical",
            command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.inner = tk.Frame(self.canvas, bg=BG)
        self.inner_window = self.canvas.create_window(
            (0, 0),
            window=self.inner,
            anchor="nw",
        )
        self.inner.bind(
            "<Configure>",
            lambda _event: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            ),
        )
        self.canvas.bind(
            "<Configure>",
            lambda event: self.canvas.itemconfigure(
                self.inner_window,
                width=event.width,
            ),
        )

        for index, entry in enumerate(changelog["entries"]):
            self._render_entry(entry, is_latest=index == 0)

        footer = tk.Frame(self, bg="#E5EDF7", height=32)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)
        tk.Label(
            footer,
            text=f"共 {len(changelog['entries'])} 个版本记录",
            bg="#E5EDF7",
            fg="#55708F",
            font=(FONT, 8),
        ).pack(side="left", padx=20)
        close_btn = tk.Button(
            footer,
            text="关闭",
            command=self.close,
            bg="#DCE7F4",
            fg="#405674",
            activebackground="#CEDAEA",
            activeforeground=TEXT,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=14,
            pady=3,
            cursor="hand2",
        )
        close_btn.pack(side="right", padx=16, pady=4)

        self.bind("<MouseWheel>", self._on_mousewheel, add="+")
        self.bind("<Escape>", lambda _event: self.close())

    def _render_entry(self, entry: dict, is_latest: bool) -> None:
        card = tk.Frame(
            self.inner,
            bg=SURFACE,
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        card.pack(fill="x", padx=20, pady=(14 if is_latest else 0, 10))

        header = tk.Frame(card, bg=SURFACE)
        header.pack(fill="x", padx=15, pady=(13, 0))
        version_label = tk.Label(
            header,
            text=f"v{entry.get('version', '')}",
            bg=BLUE if is_latest else BLUE_SOFT,
            fg="white" if is_latest else BLUE_DARK,
            font=(NUMBER_FONT, 9, "bold"),
            padx=9,
            pady=3,
        )
        version_label.pack(side="left")
        if is_latest:
            tk.Label(
                header,
                text="当前版本",
                bg=SUCCESS_SOFT,
                fg=SUCCESS,
                font=(FONT, 7, "bold"),
                padx=7,
                pady=3,
            ).pack(side="left", padx=(7, 0))
        tk.Label(
            header,
            text=entry.get("date", ""),
            bg=SURFACE,
            fg=MUTED,
            font=(NUMBER_FONT, 8),
        ).pack(side="right")

        tk.Label(
            card,
            text=entry.get("title", "版本更新"),
            bg=SURFACE,
            fg=TEXT,
            font=(FONT, 12, "bold"),
            anchor="w",
            justify="left",
        ).pack(fill="x", padx=15, pady=(10, 4))

        for change in entry.get("changes", []):
            tk.Label(
                card,
                text=f"•  {change}",
                bg=SURFACE,
                fg="#48576C",
                font=(FONT, 9),
                anchor="w",
                justify="left",
                wraplength=385,
            ).pack(fill="x", padx=15, pady=2)

        tk.Frame(card, bg=SURFACE, height=11).pack(fill="x")

    def _on_mousewheel(self, event) -> None:
        try:
            widget = self.winfo_containing(event.x_root, event.y_root)
        except (KeyError, tk.TclError):
            return
        current = widget
        while current is not None:
            if current == self.canvas:
                delta = -1 * int(event.delta / 120) if event.delta else 0
                if delta:
                    self.canvas.yview_scroll(delta, "units")
                return
            current = getattr(current, "master", None)

    def close(self) -> None:
        if self.app.changelog_window is self:
            self.app.changelog_window = None
        self.destroy()


class HistoryWindow(tk.Toplevel):
    def __init__(self, app: "BUAAmemo") -> None:
        super().__init__(app.root)
        self.app = app
        self.title("历史事项 · BUAA")
        self.configure(bg=BG)
        self.resizable(True, True)
        self.minsize(400, 430)
        self.transient(app.root)

        width, height = 470, 620
        app.root.update_idletasks()
        x = app.root.winfo_rootx() + (app.root.winfo_width() - width) // 2
        y = app.root.winfo_rooty() + (app.root.winfo_height() - height) // 2
        x = max(20, min(x, self.winfo_screenwidth() - width - 20))
        y = max(20, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")

        header = tk.Frame(self, bg="#324A68", height=100)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header,
            text="历史事项",
            bg="#324A68",
            fg="white",
            font=(FONT, 19, "bold"),
        ).pack(anchor="w", padx=24, pady=(16, 0))
        self.subtitle = tk.Label(
            header,
            text="已过期事项仅支持删除，不可修改",
            bg="#324A68",
            fg="#CAD6E5",
            font=(FONT, 9),
        )
        self.subtitle.pack(anchor="w", padx=24, pady=(3, 0))

        shell = tk.Frame(self, bg=BG)
        shell.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(shell, bg=BG, bd=0, highlightthickness=0)
        scrollbar = ttk.Scrollbar(
            shell,
            orient="vertical",
            command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.inner = tk.Frame(self.canvas, bg=BG)
        self.inner_window = self.canvas.create_window(
            (0, 0),
            window=self.inner,
            anchor="nw",
        )
        self.inner.bind(
            "<Configure>",
            lambda _event: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            ),
        )
        self.canvas.bind(
            "<Configure>",
            lambda event: self.canvas.itemconfigure(
                self.inner_window,
                width=event.width,
            ),
        )

        footer = tk.Frame(self, bg="#E5EDF7", height=32)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)
        self.footer_label = tk.Label(
            footer,
            text="0 项历史事项",
            bg="#E5EDF7",
            fg="#55708F",
            font=(FONT, 8),
        )
        self.footer_label.pack(side="left", padx=20)
        close_btn = tk.Button(
            footer,
            text="关闭",
            command=self.close,
            bg="#DCE7F4",
            fg="#405674",
            activebackground="#CEDAEA",
            activeforeground=TEXT,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=14,
            pady=3,
            cursor="hand2",
        )
        close_btn.pack(side="right", padx=16, pady=4)

        self.bind("<MouseWheel>", self._on_mousewheel, add="+")
        self.bind("<Escape>", lambda _event: self.close())
        self.refresh()

    def refresh(self) -> None:
        for child in self.inner.winfo_children():
            child.destroy()
        items = self.app.history_memos()
        self.footer_label.configure(text=f"{len(items)} 项历史事项")
        self.subtitle.configure(text="已过期事项仅支持删除，不可修改")
        if not items:
            tk.Label(
                self.inner,
                text="暂无历史事项",
                bg=BG,
                fg=MUTED,
                font=(FONT, 13, "bold"),
            ).pack(pady=(100, 5))
            tk.Label(
                self.inner,
                text="事项到期后会自动移动到历史事项。",
                bg=BG,
                fg="#8290A3",
                font=(FONT, 9),
            ).pack()
            return

        for item in items:
            self._render_item(item)
        self.inner.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _render_item(self, memo: dict) -> None:
        card = tk.Frame(
            self.inner,
            bg=SURFACE,
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        card.pack(fill="x", padx=20, pady=(14, 0))

        accent = tk.Frame(card, bg="#9AA8BA", width=4)
        accent.pack(side="left", fill="y")
        body = tk.Frame(card, bg=SURFACE)
        body.pack(side="left", fill="both", expand=True, padx=14, pady=12)

        top = tk.Frame(body, bg=SURFACE)
        top.pack(fill="x")
        tk.Label(
            top,
            text=str(memo.get("title", "未命名事项")),
            bg=SURFACE,
            fg=TEXT,
            font=(FONT, 11, "bold"),
            anchor="w",
            justify="left",
            wraplength=300,
        ).pack(side="left", fill="x", expand=True)
        delete_btn = tk.Button(
            top,
            text="删除",
            command=lambda item=memo: self.app.delete_memo(item),
            bg=SURFACE,
            fg=DANGER,
            activebackground=DANGER_SOFT,
            activeforeground=DANGER,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=5,
            pady=1,
            cursor="hand2",
        )
        delete_btn.pack(side="right", anchor="n", padx=(8, 0))

        note = str(memo.get("note", "")).strip()
        if note:
            tk.Label(
                body,
                text=note,
                bg=SURFACE,
                fg=MUTED,
                font=(FONT, 8),
                anchor="w",
                justify="left",
                wraplength=345,
            ).pack(fill="x", pady=(5, 0))

        deadline_text = "未知"
        expired_text = "已过期"
        try:
            deadline = parse_deadline(memo.get("deadline", ""))
            deadline_text = deadline.strftime("%Y-%m-%d  %H:%M")
            expired_seconds = max(
                0, int((datetime.now() - deadline).total_seconds())
            )
            expired_text = f"已过期 {format_duration(expired_seconds)}"
        except (TypeError, ValueError):
            pass

        meta = tk.Frame(body, bg=SURFACE)
        meta.pack(fill="x", pady=(10, 0))
        tk.Label(
            meta,
            text=f"终止时间  {deadline_text}",
            bg=SURFACE,
            fg="#53647B",
            font=(NUMBER_FONT, 9),
        ).pack(side="left")
        tk.Label(
            meta,
            text=expired_text,
            bg="#F0F3F7",
            fg="#6E7E93",
            font=(FONT, 8),
            padx=8,
            pady=2,
        ).pack(side="right")

    def _on_mousewheel(self, event) -> None:
        try:
            widget = self.winfo_containing(event.x_root, event.y_root)
        except (KeyError, tk.TclError):
            return
        current = widget
        while current is not None:
            if current == self.canvas:
                delta = -1 * int(event.delta / 120) if event.delta else 0
                if delta:
                    self.canvas.yview_scroll(delta, "units")
                return
            current = getattr(current, "master", None)

    def close(self) -> None:
        if self.app.history_window is self:
            self.app.history_window = None
        self.destroy()


class BUAAmemo:
    def __init__(self) -> None:
        make_dpi_aware()
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        IMAGE_DIR.mkdir(parents=True, exist_ok=True)

        self.data = self._load_data()
        self.memos: list[dict] = self.data.get("memos", [])
        self.tombstones: list[dict] = self.data.get("tombstones", [])
        self.settings: dict = self.data.get("settings", {})
        self.topmost = bool(self.settings.get("topmost", True))
        self.countdown_labels: dict[str, tk.Label] = {}
        self.status_labels: dict[str, tk.Label] = {}
        self.accent_bars: dict[str, tk.Frame] = {}
        self.image_refs: dict[str, tk.PhotoImage] = {}
        self.dialog: AddMemoDialog | None = None
        self.download_window: DownloadQrWindow | None = None
        self.history_window: HistoryWindow | None = None
        self.changelog_window: ChangelogWindow | None = None
        self.changelog = load_changelog()
        self.update_check_running = False
        self._tick_job = None

        self.root = tk.Tk()
        self.root.title("BUAA 备忘倒计时")
        self.root.configure(bg=BG)
        self.root.minsize(420, 560)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.attributes("-topmost", self.topmost)
        if ICON_FILE.exists():
            try:
                self.root.iconbitmap(default=str(ICON_FILE))
            except tk.TclError:
                pass

        self.web_server: MemoWebServer | None = None
        self.web_window: WeChatControlWindow | None = None
        self.web_bridge = MemoWebBridge(self.root, self.handle_web_command)

        self._set_window_position()
        self._build_ui()
        self.render_memos()
        self.tick()
        try:
            self.ensure_web_server()
        except Exception:
            pass

    def _load_data(self) -> dict:
        if not DATA_FILE.exists():
            return {"version": 1, "settings": {}, "memos": [], "tombstones": []}
        try:
            with DATA_FILE.open("r", encoding="utf-8") as handle:
                loaded = json.load(handle)
            if not isinstance(loaded, dict):
                raise ValueError("数据文件结构不正确")
            if not isinstance(loaded.get("memos", []), list):
                loaded["memos"] = []
            if not isinstance(loaded.get("tombstones", []), list):
                loaded["tombstones"] = []
            if not isinstance(loaded.get("settings", {}), dict):
                loaded["settings"] = {}
            for memo in loaded.get("memos", []):
                if not isinstance(memo, dict):
                    continue
                memo.setdefault("deleted", False)
                memo.setdefault("rev", parse_revision(memo))
                memo.setdefault(
                    "updated_at",
                    memo.get("created_at")
                    or datetime.now().isoformat(timespec="seconds"),
                )
            for tombstone in loaded.get("tombstones", []):
                if isinstance(tombstone, dict):
                    tombstone["deleted"] = True
                    tombstone.setdefault("rev", parse_revision(tombstone))
            return loaded
        except Exception:
            backup = DATA_FILE.with_suffix(".json.bak")
            try:
                shutil.copy2(DATA_FILE, backup)
            except OSError:
                pass
            return {"version": 1, "settings": {}, "memos": [], "tombstones": []}

    def _save_data(self) -> None:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.data["version"] = 1
        self.data["settings"] = self.settings
        self.data["memos"] = self.memos
        self.data["tombstones"] = self.tombstones
        temp_file = DATA_FILE.with_suffix(".json.tmp")
        with temp_file.open("w", encoding="utf-8") as handle:
            json.dump(self.data, handle, ensure_ascii=False, indent=2)
        temp_file.replace(DATA_FILE)

    def _set_window_position(self) -> None:
        width, height = 440, 730
        x = int(self.settings.get("x", self.root.winfo_screenwidth() - width - 30))
        y = int(self.settings.get("y", 72))
        max_x = max(0, self.root.winfo_screenwidth() - width)
        max_y = max(0, self.root.winfo_screenheight() - height - 40)
        x = max(0, min(x, max_x))
        y = max(0, min(y, max_y))
        self.root.geometry(f"{width}x{height}+{x}+{y}")

    def _build_ui(self) -> None:
        self._build_header()

        content = tk.Frame(self.root, bg=BG)
        content.pack(fill="both", expand=True)

        summary = tk.Frame(content, bg=BG)
        summary.pack(fill="x", padx=22, pady=(14, 9))
        tk.Label(
            summary,
            text="事项清单",
            bg=BG,
            fg=TEXT,
            font=(FONT, 13, "bold"),
        ).pack(side="left")
        self.count_label = tk.Label(
            summary,
            text="0 项",
            bg="#DCE9FA",
            fg=BLUE_DARK,
            font=(FONT, 8, "bold"),
            padx=9,
            pady=2,
        )
        self.count_label.pack(side="left", padx=(8, 0))
        self.history_btn = tk.Button(
            summary,
            text="历史事项 0",
            command=self.open_history,
            bg="#EEF3F9",
            fg="#55708F",
            activebackground="#E2EBF6",
            activeforeground=BLUE_DARK,
            font=(FONT, 8, "bold"),
            relief="flat",
            bd=0,
            padx=10,
            pady=3,
            cursor="hand2",
        )
        self.history_btn.pack(side="left", padx=(8, 0))
        self.urgent_label = tk.Label(
            summary,
            text="",
            bg=BG,
            fg=WARNING,
            font=(FONT, 8),
        )
        self.urgent_label.pack(side="right")

        list_shell = tk.Frame(content, bg=BG)
        list_shell.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(
            list_shell,
            bg=BG,
            bd=0,
            highlightthickness=0,
        )
        self.scrollbar = ttk.Scrollbar(
            list_shell,
            orient="vertical",
            command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.list_frame = tk.Frame(self.canvas, bg=BG)
        self.list_window = self.canvas.create_window(
            (0, 0), window=self.list_frame, anchor="nw"
        )
        self.list_frame.bind(
            "<Configure>",
            lambda _event: self.canvas.configure(scrollregion=self.canvas.bbox("all")),
        )
        self.canvas.bind(
            "<Configure>",
            lambda event: self.canvas.itemconfigure(self.list_window, width=event.width),
        )
        self.root.bind_all("<MouseWheel>", self._on_mousewheel, add="+")

        footer = tk.Frame(self.root, bg="#E5EDF7", height=30)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)
        self.save_status_label = tk.Label(
            footer,
            text="●  本机自动保存",
            bg="#E5EDF7",
            fg="#55708F",
            font=(FONT, 8),
        )
        self.save_status_label.pack(side="left", padx=22)
        self.clock_label = tk.Label(
            footer,
            text="",
            bg="#E5EDF7",
            fg="#55708F",
            font=(NUMBER_FONT, 8),
        )
        self.clock_label.pack(side="right", padx=22)
        self.changelog_btn = tk.Button(
            footer,
            text=f"v{self.changelog['current_version']} · 更新日志",
            command=self.open_changelog,
            bg="#E5EDF7",
            fg="#55708F",
            activebackground="#D7E3F1",
            activeforeground=BLUE_DARK,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=6,
            pady=0,
            cursor="hand2",
        )
        self.changelog_btn.pack(side="right", padx=(0, 0))
        self.update_btn = tk.Button(
            footer,
            text="检查更新",
            command=self.check_for_updates,
            bg="#E5EDF7",
            fg="#55708F",
            activebackground="#D7E3F1",
            activeforeground=BLUE_DARK,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=6,
            pady=0,
            cursor="hand2",
        )
        self.update_btn.pack(side="right")

    def _build_header(self) -> None:
        header = tk.Frame(self.root, bg=NAVY, height=161)
        header.pack(fill="x")
        header.pack_propagate(False)

        top_row = tk.Frame(header, bg=NAVY)
        top_row.pack(fill="x", padx=24, pady=(14, 0))

        brand = tk.Frame(top_row, bg=NAVY)
        brand.pack(side="left")
        tk.Label(
            brand,
            text="BUAA",
            bg=NAVY,
            fg="white",
            font=(NUMBER_FONT, 28, "bold"),
        ).pack(anchor="w")
        tk.Label(
            brand,
            text="BEIHANG UNIVERSITY  ·  MEMO",
            bg=NAVY,
            fg="#B9D1F0",
            font=(NUMBER_FONT, 7),
        ).pack(anchor="w", pady=(0, 0))

        actions = tk.Frame(top_row, bg=NAVY)
        actions.pack(side="right", pady=(7, 0))

        self.download_btn = tk.Button(
            actions,
            text="扫码下载",
            command=self.open_download_qr,
            bg="#1D5CA8",
            fg="white",
            activebackground="#266DBC",
            activeforeground="white",
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=7,
            pady=5,
            cursor="hand2",
        )
        self.download_btn.pack(side="left", padx=(0, 6))

        self.web_btn = tk.Button(
            actions,
            text="微信控制",
            command=self.open_web_control,
            bg="#1D5CA8",
            fg="white",
            activebackground="#266DBC",
            activeforeground="white",
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=9,
            pady=5,
            cursor="hand2",
        )
        self.web_btn.pack(side="left", padx=(0, 6))

        self.pin_btn = tk.Button(
            actions,
            text="●  已置顶",
            command=self.toggle_topmost,
            bg="#164C8F",
            fg="white",
            activebackground="#1E5AA4",
            activeforeground="white",
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=10,
            pady=5,
            cursor="hand2",
        )
        self.pin_btn.pack(side="left")

        tk.Label(
            header,
            text="把每一个截止时间，变成看得见的进度。",
            bg=NAVY,
            fg="#C8DAF4",
            font=(FONT, 9),
        ).pack(anchor="w", padx=24, pady=(3, 0))

        add_btn = tk.Button(
            header,
            text="＋  新建事项",
            command=self.open_add_dialog,
            bg="white",
            fg=BLUE_DARK,
            activebackground=BLUE_SOFT,
            activeforeground=BLUE_DARK,
            font=(FONT, 10, "bold"),
            relief="flat",
            bd=0,
            pady=8,
            cursor="hand2",
        )
        add_btn.pack(fill="x", padx=24, pady=(10, 13))
        bind_hover(add_btn, "white", BLUE_SOFT)

    def _on_mousewheel(self, event) -> None:
        try:
            widget = self.root.winfo_containing(event.x_root, event.y_root)
        except (KeyError, tk.TclError):
            widget = None
        if widget is None:
            return
        current = widget
        while current is not None:
            if current == self.canvas:
                delta = -1 * int(event.delta / 120) if event.delta else 0
                if delta:
                    self.canvas.yview_scroll(delta, "units")
                return
            current = getattr(current, "master", None)

    def toggle_topmost(self) -> None:
        self.topmost = not self.topmost
        self.root.attributes("-topmost", self.topmost)
        self.settings["topmost"] = self.topmost
        if self.topmost:
            self.pin_btn.configure(text="●  已置顶", bg="#164C8F")
        else:
            self.pin_btn.configure(text="○  置顶", bg="#0E447F")
        self._save_data()

    def ensure_web_server(self) -> MemoWebServer:
        if self.web_server is not None and self.web_server.running:
            return self.web_server

        token = str(self.settings.get("web_token", "")).strip()
        if len(token) < 16:
            token = secrets.token_urlsafe(18)
            self.settings["web_token"] = token

        try:
            preferred_port = int(self.settings.get("web_port", 8765))
        except (TypeError, ValueError):
            preferred_port = 8765

        server = MemoWebServer(
            self.web_bridge,
            token,
            WEB_CONTROL_HTML,
            OFFLINE_MOBILE_JS,
            UPDATE_MANIFEST_URL,
            preferred_port,
        )
        server.start()
        self.web_server = server
        self.settings["web_port"] = server.port
        self._save_data()
        self.save_status_label.configure(text="●  自动保存 · 微信控制已开启")
        self.web_btn.configure(text="● 微信控制", bg="#1B6B57")
        return server

    def open_web_control(self) -> None:
        if self.web_window is not None and self.web_window.winfo_exists():
            self.web_window.lift()
            self.web_window.focus_force()
            return
        try:
            server = self.ensure_web_server()
        except Exception as exc:
            messagebox.showerror(
                "微信控制启动失败",
                f"无法启动手机控制页。\n\n{exc}",
                parent=self.root,
            )
            return
        self.web_window = WeChatControlWindow(self, server.url)

    def open_download_qr(self) -> None:
        if self.download_window is not None and self.download_window.winfo_exists():
            self.download_window.lift()
            self.download_window.focus_force()
            return
        try:
            server = self.ensure_web_server()
        except Exception as exc:
            messagebox.showerror(
                "二维码生成失败",
                f"无法启动手机版下载服务。\n\n{exc}",
                parent=self.root,
            )
            return
        mobile_url = f"{server.url}offline"
        self.download_window = DownloadQrWindow(
            self,
            DOWNLOAD_PAGE_URL,
            mobile_url,
        )

    def open_changelog(self) -> None:
        self.changelog = load_changelog()
        self.changelog_btn.configure(
            text=f"v{self.changelog['current_version']} · 更新日志"
        )
        if self.changelog_window is not None and self.changelog_window.winfo_exists():
            self.changelog_window.destroy()
            self.changelog_window = None
        self.changelog_window = ChangelogWindow(self, self.changelog)

    def history_memos(self) -> list[dict]:
        now = datetime.now()
        items = []
        for memo in self.memos:
            try:
                deadline = parse_deadline(memo.get("deadline", ""))
            except (TypeError, ValueError):
                continue
            if deadline <= now:
                items.append(memo)
        items.sort(
            key=lambda memo: memo.get("deadline", ""),
            reverse=True,
        )
        return items

    def open_history(self) -> None:
        if self.history_window is not None and self.history_window.winfo_exists():
            self.history_window.refresh()
            self.history_window.lift()
            self.history_window.focus_force()
            return
        self.history_window = HistoryWindow(self)

    def _reset_update_button(self) -> None:
        self.update_check_running = False
        self.update_btn.configure(text="检查更新", state="normal")

    def check_for_updates(self) -> None:
        if self.update_check_running:
            return
        self.update_check_running = True
        self.update_btn.configure(text="检查中…", state="disabled")
        url = str(
            self.settings.get("update_manifest_url") or UPDATE_MANIFEST_URL
        )
        threading.Thread(
            target=self._check_update_worker,
            args=(url,),
            daemon=True,
        ).start()

    def _check_update_worker(self, url: str) -> None:
        try:
            manifest = fetch_manifest(url)
        except Exception as exc:
            self.root.after(0, lambda: self._update_check_failed(str(exc)))
            return
        self.root.after(0, lambda: self._handle_update_manifest(manifest))

    def _update_check_failed(self, message: str) -> None:
        self._reset_update_button()
        messagebox.showerror(
            "检查更新失败",
            f"暂时无法获取更新信息。\n\n{message}",
            parent=self.root,
        )

    def _handle_update_manifest(self, manifest: dict) -> None:
        current_version = self.changelog.get("current_version", "0.0.0")
        remote_version = str(manifest.get("version", "0.0.0"))
        if not is_newer(remote_version, current_version):
            self._reset_update_button()
            messagebox.showinfo(
                "检查更新",
                f"当前已经是最新版本 v{current_version}。",
                parent=self.root,
            )
            return

        desktop = manifest.get("desktop")
        if not isinstance(desktop, dict):
            self._reset_update_button()
            messagebox.showerror(
                "更新信息不完整",
                "更新清单中没有桌面版升级包。",
                parent=self.root,
            )
            return
        patch_url = str(desktop.get("patch_url", "")).strip()
        sha256 = str(desktop.get("sha256", "")).strip()
        if not patch_url or not sha256:
            self._reset_update_button()
            messagebox.showerror(
                "更新信息不完整",
                "更新清单缺少下载地址或校验值。",
                parent=self.root,
            )
            return

        notes = manifest.get("notes", [])
        note_text = "\n".join(
            f"• {item}" for item in notes if str(item).strip()
        )
        message = (
            f"发现新版本 v{remote_version}\n"
            f"当前版本 v{current_version}\n\n"
            f"{note_text}\n\n"
            "是否现在下载并安装？备忘录数据不会被覆盖。"
        ).strip()
        if not messagebox.askyesno("发现新版本", message, parent=self.root):
            self._reset_update_button()
            return

        self.update_btn.configure(text="下载中…")
        threading.Thread(
            target=self._download_update_worker,
            args=(manifest,),
            daemon=True,
        ).start()

    def _download_update_worker(self, manifest: dict) -> None:
        try:
            desktop = manifest["desktop"]
            version = str(manifest["version"])
            target = (
                DATA_DIR
                / "updates"
                / f"BUAA-Memo-{version}-patch.zip"
            )
            download_verified(
                str(desktop["patch_url"]),
                target,
                str(desktop["sha256"]),
            )
        except Exception as exc:
            self.root.after(
                0,
                lambda: self._update_download_failed(str(exc)),
            )
            return
        self.root.after(
            0,
            lambda: self._install_downloaded_update(target, version),
        )

    def _update_download_failed(self, message: str) -> None:
        self._reset_update_button()
        messagebox.showerror(
            "更新下载失败",
            f"没有安装更新。\n\n{message}",
            parent=self.root,
        )

    def _install_downloaded_update(self, patch_path: Path, version: str) -> None:
        try:
            count = apply_patch(patch_path, APP_DIR)
        except Exception as exc:
            self._reset_update_button()
            messagebox.showerror(
                "更新安装失败",
                f"已保留原有版本。\n\n{exc}",
                parent=self.root,
            )
            return

        messagebox.showinfo(
            "更新完成",
            f"已安装 v{version}（共更新 {count} 个文件）。\n"
            "插件即将自动重启。",
            parent=self.root,
        )
        try:
            schedule_restart(APP_DIR)
        except Exception as exc:
            messagebox.showwarning(
                "请手动重启",
                f"文件已更新，但自动重启失败：{exc}\n请关闭后重新打开插件。",
                parent=self.root,
            )
        self.close()

    def handle_web_command(self, action: str, payload: dict):
        if action == "version":
            return {"version": self.changelog.get("current_version", "0.0.0")}
        if action == "list":
            return {"memos": [dict(memo) for memo in self.memos]}
        if action == "all_records":
            return {"records": self.all_sync_records()}
        if action == "sync":
            return {"records": self.sync_records_from_phone(payload.get("records", []))}
        if action == "save":
            return {"memo": self.save_memo_from_web(payload)}
        if action == "delete":
            return self.delete_memo_from_web(payload)
        raise MemoApiError("未知的手机端操作。")

    def all_sync_records(self) -> list[dict]:
        by_id: dict[str, dict] = {}
        for record in [*self.memos, *self.tombstones]:
            if not isinstance(record, dict):
                continue
            memo_id = str(record.get("id", "")).strip()
            if not memo_id:
                continue
            normalized = dict(record)
            normalized["id"] = memo_id
            normalized["rev"] = parse_revision(normalized)
            normalized["deleted"] = bool(normalized.get("deleted", False))
            previous = by_id.get(memo_id)
            if previous is None or normalized["rev"] >= parse_revision(previous):
                by_id[memo_id] = normalized
        return list(by_id.values())

    def sync_records_from_phone(self, incoming: list) -> list[dict]:
        if not isinstance(incoming, list):
            raise MemoApiError("同步记录格式不正确。")
        if len(incoming) > 5000:
            raise MemoApiError("同步记录数量过多。")

        by_id = {
            record["id"]: dict(record)
            for record in self.all_sync_records()
        }
        removed_images: list[str] = []

        for raw in incoming:
            if not isinstance(raw, dict):
                continue
            memo_id = str(raw.get("id", "")).strip()
            if not memo_id:
                continue
            try:
                revision = int(raw.get("rev", 0))
            except (TypeError, ValueError):
                continue
            if revision <= 0:
                continue

            previous = by_id.get(memo_id)
            if previous is not None and revision <= parse_revision(previous):
                continue

            if bool(raw.get("deleted", False)):
                if previous and previous.get("image"):
                    removed_images.append(str(previous["image"]))
                by_id[memo_id] = {
                    "id": memo_id,
                    "deleted": True,
                    "rev": revision,
                    "updated_at": str(raw.get("updated_at") or "")
                    or datetime.now().isoformat(timespec="seconds"),
                }
                continue

            title = str(raw.get("title", "")).strip()
            note = str(raw.get("note", "")).strip()
            deadline_text = str(raw.get("deadline", "")).strip()
            if not title or len(title) > 80 or len(note) > 1000:
                raise MemoApiError("手机端有事项内容不完整。")
            try:
                deadline = datetime.fromisoformat(deadline_text)
                if deadline.tzinfo is not None:
                    deadline = deadline.astimezone().replace(tzinfo=None)
            except ValueError as exc:
                raise MemoApiError("手机端有事项时间格式不正确。") from exc

            image_value = previous.get("image") if previous is not None else None
            by_id[memo_id] = {
                "id": memo_id,
                "title": title,
                "note": note,
                "deadline": deadline.isoformat(timespec="seconds"),
                "created_at": str(raw.get("created_at") or "")
                or (
                    previous.get("created_at")
                    if previous
                    else datetime.now().isoformat(timespec="seconds")
                ),
                "image": image_value,
                "deleted": False,
                "rev": revision,
                "updated_at": str(raw.get("updated_at") or "")
                or datetime.now().isoformat(timespec="seconds"),
            }

        active: list[dict] = []
        tombstones: list[dict] = []
        for record in by_id.values():
            if record.get("deleted"):
                tombstones.append(
                    {
                        "id": record["id"],
                        "deleted": True,
                        "rev": parse_revision(record),
                        "updated_at": record.get("updated_at", ""),
                    }
                )
            else:
                active.append(record)

        self.memos = active
        self.tombstones = tombstones
        self._save_data()
        self.render_memos()

        for image_rel in set(removed_images):
            image_path = APP_DIR / image_rel
            try:
                if image_path.is_file() and IMAGE_DIR in image_path.resolve().parents:
                    image_path.unlink()
            except OSError:
                pass
        return self.all_sync_records()

    def save_memo_from_web(self, payload: dict) -> dict:
        title = str(payload.get("title", "")).strip()
        note = str(payload.get("note", "")).strip()
        deadline_text = str(payload.get("deadline", "")).strip()
        memo_id = str(payload.get("id") or "").strip()

        if not title:
            raise MemoApiError("请填写事项名称。")
        if len(title) > 80:
            raise MemoApiError("事项名称最多 80 个字。")
        if len(note) > 1000:
            raise MemoApiError("备注最多 1000 个字。")
        try:
            deadline = datetime.fromisoformat(deadline_text)
            if deadline.tzinfo is not None:
                deadline = deadline.astimezone().replace(tzinfo=None)
        except ValueError as exc:
            raise MemoApiError("终止时间格式不正确。") from exc
        if deadline <= datetime.now():
            raise MemoApiError("终止时间需要晚于现在。")

        if memo_id:
            target = next(
                (memo for memo in self.memos if str(memo.get("id")) == memo_id),
                None,
            )
            if target is None:
                raise MemoApiError("要编辑的事项已经不存在。")
            target["title"] = title
            target["note"] = note
            target["deadline"] = deadline.isoformat(timespec="seconds")
            target["deleted"] = False
            target["rev"] = max(now_revision(), parse_revision(target) + 1)
            target["updated_at"] = datetime.now().isoformat(timespec="seconds")
        else:
            target = {
                "id": uuid.uuid4().hex,
                "title": title,
                "note": note,
                "deadline": deadline.isoformat(timespec="seconds"),
                "created_at": datetime.now().isoformat(timespec="seconds"),
                "image": None,
                "deleted": False,
                "rev": now_revision(),
                "updated_at": datetime.now().isoformat(timespec="seconds"),
            }
            self.memos.append(target)

        self._save_data()
        self.render_memos()
        if not memo_id:
            self.canvas.yview_moveto(0)
        return dict(target)

    def delete_memo_from_web(self, payload: dict) -> dict:
        memo_id = str(payload.get("id") or "").strip()
        target = next(
            (memo for memo in self.memos if str(memo.get("id")) == memo_id),
            None,
        )
        if target is None:
            raise MemoApiError("要删除的事项已经不存在。")

        image_rel = target.get("image")
        revision = max(now_revision(), parse_revision(target) + 1)
        self.tombstones.append(
            {
                "id": memo_id,
                "deleted": True,
                "rev": revision,
                "updated_at": datetime.now().isoformat(timespec="seconds"),
            }
        )
        self.memos = [
            memo for memo in self.memos if str(memo.get("id")) != memo_id
        ]
        self._save_data()
        if image_rel:
            image_path = APP_DIR / str(image_rel)
            try:
                if image_path.is_file() and IMAGE_DIR in image_path.resolve().parents:
                    image_path.unlink()
            except OSError:
                pass
        self.render_memos()
        return {"id": memo_id}

    def open_add_dialog(self) -> None:
        if self.dialog and self.dialog.winfo_exists():
            self.dialog.lift()
            self.dialog.focus_force()
            return
        self.dialog = AddMemoDialog(self, self.add_memo)

    def add_memo(self, item: dict) -> None:
        item["deleted"] = False
        item["rev"] = now_revision()
        item["updated_at"] = datetime.now().isoformat(timespec="seconds")
        self.memos.append(item)
        self._save_data()
        self.render_memos()
        self.canvas.yview_moveto(0)

    def delete_memo(self, item: dict) -> None:
        confirmed = messagebox.askyesno(
            "删除事项",
            f"确定删除「{item.get('title', '未命名事项')}」吗？",
            parent=self.root,
        )
        if not confirmed:
            return
        image_rel = item.get("image")
        revision = max(now_revision(), parse_revision(item) + 1)
        self.tombstones.append(
            {
                "id": str(item.get("id", "")),
                "deleted": True,
                "rev": revision,
                "updated_at": datetime.now().isoformat(timespec="seconds"),
            }
        )
        self.memos = [memo for memo in self.memos if memo.get("id") != item.get("id")]
        self._save_data()
        if image_rel:
            image_path = APP_DIR / image_rel
            try:
                if image_path.is_file() and IMAGE_DIR in image_path.resolve().parents:
                    image_path.unlink()
            except OSError:
                pass
        self.render_memos()

    def _clear_list(self) -> None:
        for child in self.list_frame.winfo_children():
            child.destroy()
        self.countdown_labels.clear()
        self.status_labels.clear()
        self.accent_bars.clear()
        self.image_refs.clear()

    def render_memos(self) -> None:
        self._clear_list()
        urgent = 0
        now = datetime.now()
        active_items: list[dict] = []
        history_count = 0

        for memo in self.memos:
            try:
                deadline = parse_deadline(memo.get("deadline", ""))
                if deadline > now:
                    active_items.append(memo)
                    if (deadline - now).total_seconds() <= 86_400:
                        urgent += 1
                else:
                    history_count += 1
            except (TypeError, ValueError):
                pass

        active_items.sort(key=lambda memo: memo.get("deadline", ""))
        self.memos.sort(key=lambda memo: memo.get("deadline", ""))

        self.count_label.configure(text=f"{len(active_items)} 项")
        self.history_btn.configure(text=f"历史事项 {history_count}")
        if urgent:
            self.urgent_label.configure(text=f"{urgent} 项 24 小时内截止")
        elif active_items:
            self.urgent_label.configure(text=f"{len(active_items)} 项进行中")
        else:
            self.urgent_label.configure(text="")

        if not active_items:
            self._render_empty_state(history_count)
        else:
            for index, memo in enumerate(active_items):
                self._render_card(memo, index)

        self.list_frame.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        if self.history_window is not None and self.history_window.winfo_exists():
            self.history_window.refresh()

    def _render_empty_state(self, history_count: int = 0) -> None:
        empty = tk.Frame(self.list_frame, bg=BG)
        empty.pack(fill="both", expand=True, padx=24, pady=(38, 20))

        icon = tk.Canvas(
            empty,
            width=78,
            height=78,
            bg=BG,
            highlightthickness=0,
        )
        icon.pack()
        icon.create_oval(4, 4, 74, 74, fill="white", outline="#D6E4F5", width=2)
        icon.create_oval(24, 24, 54, 54, outline=BLUE, width=3)
        icon.create_line(39, 39, 39, 30, fill=BLUE, width=3, capstyle="round")
        icon.create_line(39, 39, 47, 43, fill=BLUE, width=3, capstyle="round")
        icon.create_oval(35, 35, 43, 43, fill=BLUE, outline=BLUE)

        tk.Label(
            empty,
            text="没有进行中的事项" if history_count else "还没有事项",
            bg=BG,
            fg=TEXT,
            font=(FONT, 15, "bold"),
        ).pack(pady=(14, 4))
        tk.Label(
            empty,
            text=(
                f"已有 {history_count} 项事项到期，\n已移入历史事项。"
                if history_count
                else "把下一个目标记下来，\n时间会替你安静地倒计时。"
            ),
            bg=BG,
            fg=MUTED,
            font=(FONT, 9),
            justify="center",
        ).pack()
        add_empty_btn = tk.Button(
            empty,
            text="＋  添加第一条事项",
            command=self.open_add_dialog,
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            activebackground="#DCEAFF",
            activeforeground=BLUE_DARK,
            font=(FONT, 9, "bold"),
            relief="flat",
            bd=0,
            padx=16,
            pady=7,
            cursor="hand2",
        )
        add_empty_btn.pack(pady=(18, 0))
        bind_hover(add_empty_btn, BLUE_SOFT, "#DCEAFF")
        if history_count:
            history_empty_btn = tk.Button(
                empty,
                text=f"查看历史事项 {history_count}",
                command=self.open_history,
                bg="#EEF3F9",
                fg="#55708F",
                activebackground="#E2EBF6",
                activeforeground=BLUE_DARK,
                font=(FONT, 9),
                relief="flat",
                bd=0,
                padx=14,
                pady=6,
                cursor="hand2",
            )
            history_empty_btn.pack(pady=(9, 0))
            bind_hover(history_empty_btn, "#EEF3F9", "#E2EBF6")

    def _render_card(self, memo: dict, index: int) -> None:
        memo_id = str(memo.get("id", index))
        card = tk.Frame(
            self.list_frame,
            bg=SURFACE,
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        card.pack(fill="x", padx=(20, 20), pady=(0, 10))

        accent = tk.Frame(card, bg=BLUE, width=4)
        accent.pack(side="left", fill="y")
        self.accent_bars[memo_id] = accent

        body = tk.Frame(card, bg=SURFACE)
        body.pack(side="left", fill="both", expand=True, padx=14, pady=12)

        title_row = tk.Frame(body, bg=SURFACE)
        title_row.pack(fill="x")
        title = str(memo.get("title", "未命名事项"))
        tk.Label(
            title_row,
            text=title,
            bg=SURFACE,
            fg=TEXT,
            font=(FONT, 11, "bold"),
            anchor="w",
            justify="left",
            wraplength=300,
        ).pack(side="left", fill="x", expand=True)
        delete_btn = tk.Button(
            title_row,
            text="删除",
            command=lambda item=memo: self.delete_memo(item),
            bg=SURFACE,
            fg="#B45B5B",
            activebackground=DANGER_SOFT,
            activeforeground=DANGER,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=4,
            pady=1,
            cursor="hand2",
        )
        delete_btn.pack(side="right", anchor="n", padx=(8, 0))

        note = str(memo.get("note", "")).strip()
        if note:
            tk.Label(
                body,
                text=note,
                bg=SURFACE,
                fg=MUTED,
                font=(FONT, 8),
                anchor="w",
                justify="left",
                wraplength=342,
            ).pack(fill="x", pady=(5, 0))

        image_rel = memo.get("image")
        if image_rel:
            image_path = APP_DIR / str(image_rel)
            if image_path.is_file():
                try:
                    photo = load_preview(image_path, 350, 150)
                    self.image_refs[memo_id] = photo
                    image_box = tk.Frame(body, bg="#F0F4FA")
                    image_box.pack(fill="x", pady=(9, 0))
                    image_label = tk.Label(
                        image_box,
                        image=photo,
                        bg="#F0F4FA",
                        bd=0,
                        cursor="hand2",
                    )
                    image_label.pack(pady=3)
                    image_label.bind(
                        "<Button-1>",
                        lambda _event, path=image_path, label=title: self.show_image(
                            path, label
                        ),
                    )
                except tk.TclError:
                    pass

        time_box = tk.Frame(body, bg=SURFACE)
        time_box.pack(fill="x", pady=(10, 0))
        time_box.grid_columnconfigure(1, weight=1)

        tk.Label(
            time_box,
            text="剩余时间",
            bg=SURFACE,
            fg=MUTED,
            font=(FONT, 8),
            width=6,
            anchor="w",
        ).grid(row=0, column=0, sticky="w")
        countdown_label = tk.Label(
            time_box,
            text="—",
            bg=SURFACE,
            fg=BLUE,
            font=(NUMBER_FONT, 15, "bold"),
            anchor="w",
        )
        countdown_label.grid(row=0, column=1, sticky="w")
        status_label = tk.Label(
            time_box,
            text="进行中",
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            font=(FONT, 7, "bold"),
            padx=7,
            pady=2,
        )
        status_label.grid(row=0, column=2, sticky="e")
        self.countdown_labels[memo_id] = countdown_label
        self.status_labels[memo_id] = status_label

        deadline_text = "—"
        try:
            deadline_text = parse_deadline(memo.get("deadline", "")).strftime(
                "%Y-%m-%d  %H:%M"
            )
        except (TypeError, ValueError):
            pass
        tk.Label(
            time_box,
            text="终止时间",
            bg=SURFACE,
            fg=MUTED,
            font=(FONT, 8),
            width=6,
            anchor="w",
        ).grid(row=1, column=0, sticky="w", pady=(5, 0))
        tk.Label(
            time_box,
            text=deadline_text,
            bg=SURFACE,
            fg="#45556B",
            font=(NUMBER_FONT, 9),
            anchor="w",
        ).grid(row=1, column=1, columnspan=2, sticky="w", pady=(5, 0))

        self._update_card_time(memo_id, memo)

    def _update_card_time(self, memo_id: str, memo: dict) -> None:
        text, color, status, soft_color = deadline_state(memo.get("deadline", ""))
        countdown = self.countdown_labels.get(memo_id)
        badge = self.status_labels.get(memo_id)
        accent = self.accent_bars.get(memo_id)
        if countdown and countdown.winfo_exists():
            countdown.configure(text=text, fg=color)
        if badge and badge.winfo_exists():
            badge.configure(
                text=status,
                bg=soft_color,
                fg=color,
            )
        if accent and accent.winfo_exists():
            accent.configure(bg=color)

    def tick(self) -> None:
        now = datetime.now()
        needs_rerender = False
        for memo in self.memos:
            memo_id = str(memo.get("id", ""))
            if memo_id in self.countdown_labels:
                try:
                    if parse_deadline(memo.get("deadline", "")) <= now:
                        needs_rerender = True
                        continue
                except (TypeError, ValueError):
                    pass
                self._update_card_time(memo_id, memo)
        if needs_rerender:
            self.render_memos()
        self.clock_label.configure(text=now.strftime("%H:%M:%S"))
        self._tick_job = self.root.after(1000, self.tick)

    def show_image(self, path: Path, title: str) -> None:
        viewer = tk.Toplevel(self.root)
        viewer.title(f"{title} · 图片")
        viewer.configure(bg="#101A29")
        viewer.transient(self.root)
        try:
            photo = load_preview(
                path,
                max(400, self.root.winfo_screenwidth() - 240),
                max(300, self.root.winfo_screenheight() - 220),
            )
        except tk.TclError as exc:
            messagebox.showerror("无法打开图片", str(exc), parent=viewer)
            viewer.destroy()
            return

        label = tk.Label(viewer, image=photo, bg="#101A29", bd=0)
        label.image = photo
        label.pack(padx=12, pady=12)
        viewer.bind("<Escape>", lambda _event: viewer.destroy())
        label.bind("<Button-1>", lambda _event: viewer.destroy())
        viewer.update_idletasks()
        width = min(photo.width() + 24, self.root.winfo_screenwidth() - 80)
        height = min(photo.height() + 24, self.root.winfo_screenheight() - 100)
        x = self.root.winfo_rootx() + (self.root.winfo_width() - width) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - height) // 2
        viewer.geometry(f"{width}x{height}+{max(0, x)}+{max(0, y)}")

    def convert_image(
        self,
        source: Path,
        destination: Path,
        max_width: int,
        max_height: int,
    ) -> None:
        powershell = shutil.which("powershell.exe") or shutil.which("powershell")
        if powershell is None or not CONVERT_SCRIPT.exists():
            if source.suffix.lower() in {".png", ".gif"}:
                shutil.copy2(source, destination)
                return
            raise RuntimeError("找不到 Windows 图片转换组件。")

        command = [
            powershell,
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(CONVERT_SCRIPT),
            "-Source",
            str(source),
            "-Destination",
            str(destination),
            "-MaxWidth",
            str(max_width),
            "-MaxHeight",
            str(max_height),
        ]
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=45,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if completed.returncode != 0 or not destination.exists():
            detail = (completed.stderr or completed.stdout or "").strip()
            raise RuntimeError(detail or "图片转换失败。")

    def close(self) -> None:
        self.root.update_idletasks()
        self.settings["x"] = self.root.winfo_x()
        self.settings["y"] = self.root.winfo_y()
        self.settings["topmost"] = self.topmost
        self._save_data()
        self.web_bridge.stop()
        if self.web_server is not None:
            try:
                self.web_server.stop()
            except Exception:
                pass
        if self._tick_job:
            try:
                self.root.after_cancel(self._tick_job)
            except tk.TclError:
                pass
        self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()


def main() -> None:
    if os.name != "nt":
        print("BUAA 备忘插件当前按 Windows 桌面环境设计。", file=sys.stderr)
    if not focus_existing_instance():
        return
    app = BUAAmemo()
    app.run()


if __name__ == "__main__":
    main()
