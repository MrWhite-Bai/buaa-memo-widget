import Darwin
import Foundation

enum FriendDiscovery {
    static let magic = "BUAA_MEMO_DISCOVER_V1"

    static func discover(timeout: TimeInterval = 1.4) -> [[String: Any]] {
        let fd = socket(AF_INET, SOCK_DGRAM, 0)
        guard fd >= 0 else { return [] }
        defer { close(fd) }

        var enabled: Int32 = 1
        setsockopt(
            fd,
            SOL_SOCKET,
            SO_BROADCAST,
            &enabled,
            socklen_t(MemoryLayout<Int32>.size)
        )
        var receiveTimeout = timeval(tv_sec: 0, tv_usec: 250_000)
        setsockopt(
            fd,
            SOL_SOCKET,
            SO_RCVTIMEO,
            &receiveTimeout,
            socklen_t(MemoryLayout<timeval>.size)
        )

        let request = Data(magic.utf8)
        for broadcast in broadcastAddresses() {
            var target = sockaddr_in()
            target.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
            target.sin_family = sa_family_t(AF_INET)
            target.sin_port = in_port_t(8791).bigEndian
            target.sin_addr = broadcast
            request.withUnsafeBytes { rawBuffer in
                guard let base = rawBuffer.baseAddress else { return }
                withUnsafePointer(to: &target) { pointer in
                    pointer.withMemoryRebound(
                        to: sockaddr.self,
                        capacity: 1
                    ) {
                        _ = sendto(
                            fd,
                            base,
                            rawBuffer.count,
                            0,
                            $0,
                            socklen_t(MemoryLayout<sockaddr_in>.size)
                        )
                    }
                }
            }
        }

        var peers: [String: [String: Any]] = [:]
        let deadline = Date().addingTimeInterval(timeout)
        var remote = sockaddr_in()
        while Date() < deadline {
            var buffer = [UInt8](repeating: 0, count: 2048)
            var remoteLength = socklen_t(MemoryLayout<sockaddr_in>.size)
            let count = buffer.withUnsafeMutableBytes { bytes in
                withUnsafeMutablePointer(to: &remote) { pointer in
                    pointer.withMemoryRebound(
                        to: sockaddr.self,
                        capacity: 1
                    ) {
                        recvfrom(
                            fd,
                            bytes.baseAddress,
                            bytes.count,
                            0,
                            $0,
                            &remoteLength
                        )
                    }
                }
            }
            if count <= 0 { continue }
            let raw = String(
                data: Data(buffer[0..<count]),
                encoding: .utf8
            )?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let prefix = "BUAA_MEMO_SERVER_V3:"
            guard raw.hasPrefix(prefix),
                  let data = String(raw.dropFirst(prefix.count)).data(
                      using: .utf8
                  ),
                  let object = try? JSONSerialization.jsonObject(with: data),
                  var peer = object as? [String: Any] else {
                continue
            }
            var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            let addressLength = socklen_t(remote.sin_len)
            withUnsafePointer(to: &remote) { pointer in
                pointer.withMemoryRebound(
                    to: sockaddr.self,
                    capacity: 1
                ) {
                    _ = getnameinfo(
                        $0,
                        addressLength,
                        &host,
                        socklen_t(host.count),
                        nil,
                        0,
                        NI_NUMERICHOST
                    )
                }
            }
            peer["ip"] = String(cString: host)
            if let friendCode = peer["friend_code"] as? String {
                peers[friendCode] = peer
            }
        }
        return Array(peers.values)
    }

    private static func broadcastAddresses() -> [in_addr] {
        var values: Set<UInt32> = [UInt32(INADDR_BROADCAST)]
        var interfaces: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&interfaces) == 0 else {
            return [in_addr(s_addr: INADDR_BROADCAST)]
        }
        defer { freeifaddrs(interfaces) }
        var pointer = interfaces
        while let current = pointer {
            let item = current.pointee
            if let addressPointer = item.ifa_addr,
               let maskPointer = item.ifa_netmask,
               addressPointer.pointee.sa_family == UInt8(AF_INET),
               maskPointer.pointee.sa_family == UInt8(AF_INET) {
                let address = UnsafeRawPointer(addressPointer)
                    .assumingMemoryBound(to: sockaddr_in.self)
                    .pointee
                let mask = UnsafeRawPointer(maskPointer)
                    .assumingMemoryBound(to: sockaddr_in.self)
                    .pointee
                let ipHost = UInt32(bigEndian: address.sin_addr.s_addr)
                let maskHost = UInt32(bigEndian: mask.sin_addr.s_addr)
                if ipHost != 0 && maskHost != 0 {
                    values.insert((ipHost | ~maskHost).bigEndian)
                }
            }
            pointer = item.ifa_next
        }
        return values.map { in_addr(s_addr: $0) }
    }
}
