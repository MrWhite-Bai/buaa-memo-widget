#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
TEAM_ID="${DEVELOPMENT_TEAM:-}"

if [[ -z "$TEAM_ID" ]]; then
  echo "请先设置 Apple Developer Team ID，例如："
  echo "DEVELOPMENT_TEAM=ABCDE12345 ./build_ios_ipa.sh"
  exit 1
fi

mkdir -p "$ROOT/build"

xcodebuild \
  -project "$ROOT/BUAAMemo.xcodeproj" \
  -scheme BUAAMemo \
  -configuration Release \
  -destination "generic/platform=iOS" \
  -archivePath "$ROOT/build/BUAA浮光.xcarchive" \
  DEVELOPMENT_TEAM="$TEAM_ID" \
  CODE_SIGN_STYLE=Automatic \
  archive

cat > "$ROOT/build/ExportOptions.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>method</key>
  <string>development</string>
  <key>signingStyle</key>
  <string>automatic</string>
  <key>teamID</key>
  <string>$TEAM_ID</string>
</dict>
</plist>
EOF

xcodebuild \
  -exportArchive \
  -archivePath "$ROOT/build/BUAA浮光.xcarchive" \
  -exportOptionsPlist "$ROOT/build/ExportOptions.plist" \
  -exportPath "$ROOT/build/ipa"

echo "IPA 输出目录：$ROOT/build/ipa"
