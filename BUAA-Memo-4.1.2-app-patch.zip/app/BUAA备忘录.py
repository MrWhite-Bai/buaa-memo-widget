#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""BUAA浮光 - a small, dependency-free Windows desktop memo widget."""

from __future__ import annotations

import ctypes
import calendar as calendar_module
import base64
import http.client
import json
import math
import os
import re
import shutil
import secrets
import socket
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
import webbrowser
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk
import tkinter as tk


APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
IMAGE_DIR = DATA_DIR / "images"
DATA_FILE = DATA_DIR / "memos.json"
CONVERT_SCRIPT = APP_DIR / "tools" / "convert_image.ps1"
ICON_FILE = APP_DIR / "assets" / "buaa.ico"
BUNDLED_LAUNCHER = APP_DIR / "assets" / "BUAA浮光.exe"
ANDROID_APK_FILE = APP_DIR / "assets" / "BUAA-Memo-Android-v4.1.2.apk"
WATER_SINK_FILE = APP_DIR / "assets" / "water_sink.wav"
STARRY_HEADER_FILE = APP_DIR / "assets" / "starry-texture-v2.png"
MONET_RIVER_FILE = APP_DIR / "assets" / "river-material-v3-strip.png"
MONET_RIVER_ALT_FILE = (
    APP_DIR / "assets" / "river-material-v3-strip-alt.png"
)
DESKTOP_RIVER_BACKGROUND_FILE = (
    APP_DIR / "assets" / "river-desktop-material-v3.png"
)
CHANGELOG_FILE = APP_DIR / "changelog.json"
VENDOR_DIR = APP_DIR / "vendor"

if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))
if VENDOR_DIR.is_dir():
    sys.path.insert(0, str(VENDOR_DIR))

from wechat_bridge import (
    MemoApiError,
    MemoWebBridge,
    MemoWebServer,
    draw_qr_on_canvas,
)
from updater import (
    UpdateError,
    apply_patch,
    download_verified,
    fetch_manifest,
    fetch_text_url,
    is_newer,
    schedule_restart,
)

FONT = "Microsoft YaHei UI"
NUMBER_FONT = "Segoe UI Semibold"

BG = "#E6F2F8"
SURFACE = "#F9FCFD"
NAVY = "#2D6685"
BLUE = "#4C87AD"
BLUE_DARK = "#275E7D"
BLUE_SOFT = "#E2F1F7"
TEXT = "#203746"
MUTED = "#667E8D"
BORDER = "#C7DDE7"
DANGER = "#B95B63"
DANGER_SOFT = "#F8E9EA"
WARNING = "#A66F32"
WARNING_SOFT = "#FAF0DF"
SUCCESS = "#397F73"
SUCCESS_SOFT = "#E4F2EE"
MUTEX_HANDLE = None
FALLBACK_VERSION = "4.1.2"
CLOUD_SYNC_URL = (
    "https://buaa-memo-sync-d1g43mqwr3af89959.api.tcloudbasegateway.com"
    "/v1/rdb/rest/rpc/sync_memos"
)
CLOUD_PUBLISHABLE_KEY = (
    "eyJhbGciOiJSUzI1NiIsImtpZCI6IjRiNzlmMjU0LTdmNTgtNGI5My04ODgxLTMz"
    "Mzg1MjY0ZGY4ZCJ9.eyJpc3MiOiJodHRwczovL2J1YWEtbWVtby1zeW5jLWQxZzQz"
    "bXF3cjNhZjg5OTU5LmFwLXNoYW5naGFpLnRjYi1hcGkudGVuY2VudGNsb3VkYXBp"
    "LmNvbSIsInN1YiI6ImFub24iLCJhdWQiOiJidWFhLW1lbW8tc3luYy1kMWc0M21x"
    "d3IzYWY4OTk1OSIsImV4cCI6NDA5NjE2Njc5OCwiaWF0IjoxNzkyNDgzNTk4LCJu"
    "b25jZSI6IkhPNkxzMUhGUzVXQTZFY0NfZzNhUXciLCJhdF9oYXNoIjoiSE82THMx"
    "SEZTNVdBNkVjQ19nM2FRdyIsIm5hbWUiOiJBbm9ueW1vdXMiLCJzY29wZSI6ImFu"
    "b255bW91cyIsInByb2plY3RfaWQiOiJidWFhLW1lbW8tc3luYy1kMWc0M21xd3Iz"
    "YWY4OTk1OSIsIm1ldGEiOnsicGxhdGZvcm0iOiJQdWJsaXNoYWJsZUtleSJ9LCJy"
    "b2xlIjoiYW5vbiIsImlzX2Fub255bW91cyI6dHJ1ZSwiYXBwX21ldGFkYXRhIjp7"
    "InByb3ZpZGVyIjoiYW5vbnltb3VzIiwicHJvdmlkZXJzIjpbImFub255bW91cyJd"
    "fSwidXNlcl9tZXRhZGF0YSI6eyJuYW1lIjoiQW5vbnltb3VzIn0sInVzZXJfdHlw"
    "ZSI6IiIsImNsaWVudF90eXBlIjoiY2xpZW50X3VzZXIiLCJpc19zeXN0ZW1fYWRt"
    "aW4iOmZhbHNlfQ.Zw1yXez9wAXxpg4-vkfvTTb_2DFG8orblYaeKETNuqefXu9COr"
    "24lqdZCKSfezumOF8vnaxaQ7ceY1ZMgLAE8gX2BSjRu2UltZGS-cX7aJnwJNdrz"
    "HprGmBI8i0VEu9lgBQnP1IJrf3Y3-n706SzuiXEoMKNeKBU2itA2lkZROjkn5nmE"
    "KT8OY_PxA4MOqFK-2LVH6Arz_1jqEy64m_VpZN8x_M_004RQ8_yUfKi1hH_ZB-pK"
    "mG6T1iR2GNQ73sWDF-yAcAgh9mtr_IZGHYaWBTvnd8rzLG0FTClRdI42bSAI8USD"
    "nTWHwc5JH4kKAWtOC9i63XcGh48MDLShlCMHA"
)
CLOUD_MOBILE_URL = (
    "https://buaa-memo-mobile-buaa-memo-sync-d1g43mqwr3af89959"
    ".webapps.tcloudbase.com/"
)
PHONE_SYNC_DISCOVERY_PORT = 8791
PHONE_SYNC_MAGIC = b"BUAA_MEMO_DISCOVER_V1"
HISTORY_GRACE = timedelta(hours=24)


class PhoneAuthError(RuntimeError):
    pass
UPDATE_PORTAL_URL = (
    "https://cysyforum.muzermat.online/cy-platform/projects/5"
)
UPDATE_MANIFEST_URL = UPDATE_PORTAL_URL
LIVE_UPDATE_MANIFEST_URLS = (
    "https://raw.githubusercontent.com/MrWhite-Bai/"
    "buaa-memo-widget/main/update-manifest.json",
    "https://cdn.jsdelivr.net/gh/MrWhite-Bai/"
    "buaa-memo-widget@main/update-manifest.json",
)
MOBILE_DOWNLOAD_URL = UPDATE_PORTAL_URL


def fetch_platform_version() -> str:
    html = fetch_text_url(UPDATE_PORTAL_URL, timeout=15.0)
    release_match = re.search(
        r'class=["\'][^"\']*\brelease-version\b[^"\']*["\'][^>]*>'
        r"\s*v?(\d+\.\d+\.\d+)",
        html,
        flags=re.IGNORECASE,
    )
    if release_match:
        return release_match.group(1)
    current_match = re.search(
        r"当前版本[\s\S]{0,1600}?v?(\d+\.\d+\.\d+)",
        html,
        flags=re.IGNORECASE,
    )
    return current_match.group(1) if current_match else ""


FALLBACK_CHANGELOG = {
    "current_version": FALLBACK_VERSION,
    "entries": [
        {
            "version": FALLBACK_VERSION,
            "date": "2026-10-21",
            "title": "连续江面视觉与 24 小时归档",
            "changes": [
                "手机版和电脑版改为连续的星夜、江面一体化界面。",
                "事项到期后保留 24 小时，再自动进入历史事项。",
                "到期后 24 小时内仍可手动完成任务。",
                "原有事项、分组、图片、提醒和同步数据保持不变。",
            ],
        }
    ],
}


def make_dpi_aware() -> None:
    if os.name != "nt":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def focus_existing_instance() -> bool:
    """Create a single-instance mutex, or focus the window that already exists."""
    global MUTEX_HANDLE
    if os.name != "nt":
        return True
    try:
        kernel32 = ctypes.windll.kernel32
        MUTEX_HANDLE = kernel32.CreateMutexW(
            None,
            False,
            "Local\\BUAA_Memo_Widget_SingleInstance",
        )
        if kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
            user32 = ctypes.windll.user32
            for window_title in ("BUAA浮光", "BUAA 备忘倒计时"):
                handle = user32.FindWindowW(None, window_title)
                if handle:
                    user32.ShowWindow(handle, 9)  # SW_RESTORE
                    user32.SetForegroundWindow(handle)
                    return False
            # A stale background process must not prevent a fresh widget from
            # opening. If no real top-level window exists, continue normally.
    except Exception:
        pass
    return True


def ensure_branded_launcher() -> None:
    """Install the new branded launcher when applying an in-app patch."""
    if os.name != "nt" or not BUNDLED_LAUNCHER.is_file():
        return
    target = APP_DIR.parent / "BUAA浮光.exe"
    if target.is_file():
        return
    try:
        shutil.copy2(BUNDLED_LAUNCHER, target)
    except OSError:
        pass


def format_duration(seconds: int) -> str:
    seconds = max(0, int(seconds))
    days, remainder = divmod(seconds, 86_400)
    hours, remainder = divmod(remainder, 3_600)
    minutes, secs = divmod(remainder, 60)
    if days:
        return f"{days:02d} 天 {hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def blend_hex_color(start: str, end: str, amount: float) -> str:
    amount = max(0.0, min(1.0, float(amount)))
    try:
        start_rgb = tuple(
            int(start.lstrip("#")[index : index + 2], 16)
            for index in (0, 2, 4)
        )
        end_rgb = tuple(
            int(end.lstrip("#")[index : index + 2], 16)
            for index in (0, 2, 4)
        )
    except (TypeError, ValueError):
        return start
    blended = tuple(
        round(left + (right - left) * amount)
        for left, right in zip(start_rgb, end_rgb)
    )
    return "#{:02X}{:02X}{:02X}".format(*blended)


def parse_deadline(value: str) -> datetime:
    return datetime.fromisoformat(value)


def parse_picker_datetime(
    date_text: str,
    hour_text: str,
    minute_text: str,
) -> datetime:
    selected_day = datetime.strptime(date_text.strip(), "%Y-%m-%d").date()
    hour = int(str(hour_text).strip())
    minute = int(str(minute_text).strip())
    if not 0 <= hour <= 23 or not 0 <= minute <= 59:
        raise ValueError
    return datetime.combine(selected_day, datetime.min.time()).replace(
        hour=hour,
        minute=minute,
    )


def now_revision() -> int:
    return int(time.time() * 1000)


def parse_revision(record: dict) -> int:
    try:
        value = int(record.get("rev", 0))
        if value > 0:
            return value
    except (TypeError, ValueError):
        pass
    for field in ("updated_at", "created_at"):
        raw = record.get(field)
        if not raw:
            continue
        try:
            return int(datetime.fromisoformat(str(raw)).timestamp() * 1000)
        except (TypeError, ValueError, OSError):
            pass
    return 0


def load_changelog() -> dict:
    try:
        with CHANGELOG_FILE.open("r", encoding="utf-8") as handle:
            loaded = json.load(handle)
        if not isinstance(loaded, dict):
            raise ValueError("更新日志格式不正确")
        entries = loaded.get("entries")
        if not isinstance(entries, list) or not entries:
            raise ValueError("更新日志为空")
        normalized = []
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            changes = entry.get("changes")
            if not isinstance(changes, list):
                changes = []
            normalized.append(
                {
                    "version": str(entry.get("version", "")).strip(),
                    "date": str(entry.get("date", "")).strip(),
                    "title": str(entry.get("title", "版本更新")).strip(),
                    "changes": [str(change) for change in changes if str(change).strip()],
                }
            )
        normalized = [entry for entry in normalized if entry["version"]]
        if not normalized:
            raise ValueError("更新日志没有有效记录")
        current_version = str(
            loaded.get("current_version") or normalized[0]["version"]
        ).strip()
        return {"current_version": current_version, "entries": normalized}
    except Exception:
        return json.loads(json.dumps(FALLBACK_CHANGELOG, ensure_ascii=False))


def deadline_state(value: str) -> tuple[str, str, str, str]:
    """Return countdown text, primary color, status text, soft color."""
    try:
        deadline = parse_deadline(value)
    except (TypeError, ValueError):
        return "时间格式错误", DANGER, "需修正", DANGER_SOFT

    seconds = int((deadline - datetime.now()).total_seconds())
    if seconds <= 0:
        archive_seconds = int(
            (deadline + HISTORY_GRACE - datetime.now()).total_seconds()
        )
        if archive_seconds > 0:
            return (
                f"已到期 · {format_duration(archive_seconds)} 后归档",
                WARNING,
                "待归档",
                WARNING_SOFT,
            )
        return "已到期", DANGER, "已到期", DANGER_SOFT
    if seconds <= 86_400:
        return format_duration(seconds), WARNING, "24 小时内", WARNING_SOFT
    return format_duration(seconds), BLUE, "进行中", BLUE_SOFT


def memo_is_event(memo: dict) -> bool:
    return str(memo.get("item_type", "task")) == "event"


def record_is_group(record: dict) -> bool:
    return str(record.get("record_kind", "")) == "group"


def memo_is_completed(memo: dict) -> bool:
    return bool(memo.get("completed")) or bool(memo.get("completed_at"))


def memo_history_due(memo: dict, now: datetime | None = None) -> bool:
    if memo_is_completed(memo):
        return True
    try:
        deadline = parse_deadline(memo.get("deadline", ""))
    except (TypeError, ValueError):
        return False
    return deadline + HISTORY_GRACE <= (now or datetime.now())


def memo_time_state(memo: dict) -> tuple[str, str, str, str]:
    """Return countdown, color, status and soft background for a memo."""
    try:
        deadline = parse_deadline(memo.get("deadline", ""))
    except (TypeError, ValueError):
        return "时间格式错误", DANGER, "需修正", DANGER_SOFT

    seconds = int((deadline - datetime.now()).total_seconds())
    if seconds <= 0:
        archive_seconds = int(
            (deadline + HISTORY_GRACE - datetime.now()).total_seconds()
        )
        if archive_seconds > 0:
            return (
                f"{'已结束' if memo_is_event(memo) else '已到期'} · "
                f"{format_duration(archive_seconds)} 后归档",
                WARNING,
                "待归档",
                WARNING_SOFT,
            )
        return "已结束", DANGER, "已结束", DANGER_SOFT

    if memo_is_event(memo):
        try:
            start_at = parse_deadline(memo.get("start_at", ""))
        except (TypeError, ValueError):
            start_at = None
        if start_at is not None and datetime.now() < start_at:
            return format_duration(seconds), BLUE, "待开始", BLUE_SOFT
        if seconds <= 86_400:
            return format_duration(seconds), WARNING, "进行中", WARNING_SOFT
        return format_duration(seconds), BLUE, "进行中", BLUE_SOFT

    if seconds <= 86_400:
        return format_duration(seconds), WARNING, "24 小时内", WARNING_SOFT
    return format_duration(seconds), BLUE, "进行中", BLUE_SOFT


def load_preview(path: Path, max_width: int, max_height: int) -> tk.PhotoImage:
    image = tk.PhotoImage(file=str(path))
    factor = max(
        1,
        math.ceil(image.width() / max_width),
        math.ceil(image.height() / max_height),
    )
    if factor > 1:
        image = image.subsample(factor, factor)
    return image


def load_preview_from_data(
    data_url: str,
    max_width: int,
    max_height: int,
) -> tk.PhotoImage:
    if not data_url.startswith("data:image/") or "," not in data_url:
        raise ValueError("图片数据格式不正确")
    encoded = data_url.split(",", 1)[1]
    base64.b64decode(encoded, validate=True)
    image = tk.PhotoImage(data=encoded)
    factor = max(
        1,
        math.ceil(image.width() / max_width),
        math.ceil(image.height() / max_height),
    )
    if factor > 1:
        image = image.subsample(factor, factor)
    return image


def bind_hover(widget: tk.Widget, normal: str, hover: str) -> None:
    widget.bind("<Enter>", lambda _event: widget.configure(bg=hover))
    widget.bind("<Leave>", lambda _event: widget.configure(bg=normal))


class DatePickerPopup(tk.Toplevel):
    WEEKDAYS = ("一", "二", "三", "四", "五", "六", "日")

    def __init__(self, owner: "AddMemoDialog", date_var: tk.StringVar, on_select) -> None:
        super().__init__(owner)
        self.owner = owner
        self.date_var = date_var
        self.on_select = on_select
        self.selected_date = self._parse_selected_date()
        self.view_year = self.selected_date.year
        self.view_month = self.selected_date.month

        self.title("选择日期 · BUAA浮光")
        self.configure(bg="#CBD9E9")
        self.resizable(False, False)
        self.transient(owner)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.bind("<Escape>", lambda _event: self.close())
        self._build_ui()
        self._render_month()
        self._position()
        self.lift()
        self.after(80, self.focus_force)

    def _parse_selected_date(self):
        try:
            return datetime.strptime(self.date_var.get().strip(), "%Y-%m-%d").date()
        except ValueError:
            return datetime.now().date()

    def _build_ui(self) -> None:
        shell = tk.Frame(self, bg="#CBD9E9")
        shell.pack(fill="both", expand=True, padx=1, pady=1)
        panel = tk.Frame(shell, bg=SURFACE)
        panel.pack(fill="both", expand=True)

        header = tk.Frame(panel, bg=SURFACE)
        header.pack(fill="x", padx=14, pady=(12, 5))

        self._nav_button(header, "«", lambda: self._change_year(-1)).pack(side="left")
        self._nav_button(header, "‹", lambda: self._change_month(-1)).pack(
            side="left", padx=(4, 0)
        )
        self.month_label = tk.Label(
            header,
            text="",
            bg=SURFACE,
            fg=TEXT,
            font=(FONT, 12, "bold"),
        )
        self.month_label.pack(side="left", expand=True)
        self._nav_button(header, "›", lambda: self._change_month(1)).pack(side="left")
        self._nav_button(header, "»", lambda: self._change_year(1)).pack(
            side="left", padx=(4, 0)
        )
        close = tk.Button(
            header,
            text="×",
            command=self.close,
            bg=SURFACE,
            fg=MUTED,
            activebackground="#F1F5FA",
            activeforeground=TEXT,
            font=(FONT, 12),
            relief="flat",
            bd=0,
            padx=4,
            cursor="hand2",
        )
        close.pack(side="right", padx=(5, 0))

        weekday_row = tk.Frame(panel, bg="#F4F7FB")
        weekday_row.pack(fill="x", padx=12, pady=(2, 3))
        for index, name in enumerate(self.WEEKDAYS):
            weekday_row.grid_columnconfigure(index, weight=1)
            tk.Label(
                weekday_row,
                text=name,
                bg="#F4F7FB",
                fg=MUTED,
                font=(FONT, 8, "bold"),
                pady=5,
            ).grid(row=0, column=index, sticky="nsew")

        self.days_frame = tk.Frame(panel, bg=SURFACE)
        self.days_frame.pack(fill="both", expand=True, padx=12, pady=(2, 4))
        for index in range(7):
            self.days_frame.grid_columnconfigure(index, weight=1)

        footer = tk.Frame(panel, bg="#F7F9FC")
        footer.pack(fill="x", padx=14, pady=(4, 12))
        today_btn = tk.Button(
            footer,
            text="回到今天",
            command=lambda: self._choose_date(datetime.now().date()),
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            activebackground="#DDEBFF",
            activeforeground=BLUE_DARK,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=12,
            pady=5,
            cursor="hand2",
        )
        today_btn.pack(side="left")
        cancel_btn = tk.Button(
            footer,
            text="取消",
            command=self.close,
            bg="#E9EEF5",
            fg=MUTED,
            activebackground="#DEE6F0",
            activeforeground=TEXT,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=12,
            pady=5,
            cursor="hand2",
        )
        cancel_btn.pack(side="right")

    def _nav_button(self, parent: tk.Widget, text: str, command) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg="#EEF4FB",
            fg=BLUE_DARK,
            activebackground=BLUE_SOFT,
            activeforeground=BLUE_DARK,
            font=(FONT, 10, "bold"),
            relief="flat",
            bd=0,
            width=2,
            pady=3,
            cursor="hand2",
        )

    def _position(self) -> None:
        self.owner.update_idletasks()
        width, height = 356, 404
        x = self.owner.winfo_rootx() + (self.owner.winfo_width() - width) // 2
        y = self.owner.winfo_rooty() + 118
        x = max(15, min(x, self.winfo_screenwidth() - width - 15))
        y = max(15, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")

    def _change_month(self, delta: int) -> None:
        month_index = self.view_year * 12 + (self.view_month - 1) + delta
        self.view_year, month_zero = divmod(month_index, 12)
        self.view_month = month_zero + 1
        self._render_month()

    def _change_year(self, delta: int) -> None:
        self.view_year += delta
        self._render_month()

    def _render_month(self) -> None:
        self.month_label.configure(text=f"{self.view_year} 年 {self.view_month} 月")
        for child in self.days_frame.winfo_children():
            child.destroy()

        today = datetime.now().date()
        selected = self._parse_selected_date()
        weeks = calendar_module.Calendar(firstweekday=0).monthdayscalendar(
            self.view_year, self.view_month
        )
        while len(weeks) < 6:
            weeks.append([0] * 7)

        for row_index, week in enumerate(weeks[:6]):
            self.days_frame.grid_rowconfigure(row_index, weight=1)
            for column, day in enumerate(week):
                if day == 0:
                    tk.Label(
                        self.days_frame,
                        text="",
                        bg=SURFACE,
                    ).grid(row=row_index, column=column, sticky="nsew", padx=1, pady=1)
                    continue

                date_value = datetime(self.view_year, self.view_month, day).date()
                is_selected = date_value == selected
                is_today = date_value == today
                is_past = date_value < today

                if is_selected:
                    bg, fg = BLUE, "white"
                elif is_today:
                    bg, fg = BLUE_SOFT, BLUE_DARK
                elif is_past:
                    bg, fg = SURFACE, "#B8C1CD"
                else:
                    bg, fg = SURFACE, TEXT

                button = tk.Button(
                    self.days_frame,
                    text=str(day),
                    command=lambda value=date_value: self._choose_date(value),
                    bg=bg,
                    fg=fg,
                    activebackground=BLUE_SOFT,
                    activeforeground=BLUE_DARK,
                    disabledforeground="#C5CDD8",
                    font=(NUMBER_FONT, 9, "bold" if is_selected or is_today else "normal"),
                    relief="flat",
                    bd=0,
                    state="disabled" if is_past else "normal",
                    cursor="hand2" if not is_past else "arrow",
                )
                button.grid(
                    row=row_index,
                    column=column,
                    sticky="nsew",
                    padx=1,
                    pady=1,
                )

    def _choose_date(self, value) -> None:
        self.date_var.set(value.strftime("%Y-%m-%d"))
        self.on_select(value)
        self.close()

    def close(self) -> None:
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()


class GroupDialog(tk.Toplevel):
    def __init__(
        self,
        owner: "BUAAmemo",
        on_save,
        group: dict | None = None,
    ) -> None:
        super().__init__(owner.root)
        self.owner = owner
        self.on_save = on_save
        self.group = group
        self.title(
            "编辑分组 · BUAA浮光" if group else "新建分组 · BUAA浮光"
        )
        self.configure(bg="#F7F9FC")
        self.resizable(False, False)
        self.transient(owner.root)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.close)

        width, height = 460, 650
        owner.root.update_idletasks()
        x = owner.root.winfo_rootx() + (owner.root.winfo_width() - width) // 2
        y = owner.root.winfo_rooty() + (owner.root.winfo_height() - height) // 2
        x = max(20, min(x, self.winfo_screenwidth() - width - 20))
        y = max(20, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")

        top = tk.Frame(self, bg=NAVY, height=78)
        top.pack(fill="x")
        top.pack_propagate(False)
        tk.Label(
            top,
            text="编辑分组" if group else "新建分组",
            bg=NAVY,
            fg="white",
            font=(FONT, 18, "bold"),
        ).pack(anchor="w", padx=24, pady=(15, 0))
        tk.Label(
            top,
            text="命名、简介，并选择要加入的事项",
            bg=NAVY,
            fg="#C8DAF4",
            font=(FONT, 9),
        ).pack(anchor="w", padx=24, pady=(2, 0))

        body = tk.Frame(self, bg="#F7F9FC")
        body.pack(fill="both", expand=True, padx=22, pady=14)
        tk.Label(
            body,
            text="分组名称",
            bg="#F7F9FC",
            fg=TEXT,
            font=(FONT, 9, "bold"),
        ).pack(anchor="w")
        self.name_entry = tk.Entry(
            body,
            font=(FONT, 11),
            bg="white",
            fg=TEXT,
            insertbackground=BLUE,
            relief="flat",
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=BLUE,
        )
        self.name_entry.pack(fill="x", ipady=8, pady=(5, 12))
        if group:
            self.name_entry.insert(0, str(group.get("title", "")))

        tk.Label(
            body,
            text="分组简介",
            bg="#F7F9FC",
            fg=TEXT,
            font=(FONT, 9, "bold"),
        ).pack(anchor="w")
        self.intro_text = tk.Text(
            body,
            height=3,
            font=(FONT, 10),
            bg="white",
            fg=TEXT,
            insertbackground=BLUE,
            relief="flat",
            wrap="word",
            padx=8,
            pady=7,
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=BLUE,
        )
        self.intro_text.pack(fill="x", pady=(5, 12))
        if group:
            self.intro_text.insert("1.0", str(group.get("note", "")))

        tk.Label(
            body,
            text="添加已有事项",
            bg="#F7F9FC",
            fg=TEXT,
            font=(FONT, 9, "bold"),
        ).pack(anchor="w")
        tk.Label(
            body,
            text="按住 Ctrl 可多选；取消选择会移出分组，不会删除事项。",
            bg="#F7F9FC",
            fg=MUTED,
            font=(FONT, 8),
        ).pack(anchor="w", pady=(3, 6))
        list_shell = tk.Frame(body, bg="white")
        list_shell.pack(fill="both", expand=True)
        scrollbar = ttk.Scrollbar(list_shell, orient="vertical")
        self.memo_list = tk.Listbox(
            list_shell,
            selectmode="multiple",
            exportselection=False,
            font=(FONT, 9),
            bg="white",
            fg=TEXT,
            selectbackground=BLUE,
            selectforeground="white",
            relief="flat",
            highlightthickness=1,
            highlightbackground=BORDER,
            yscrollcommand=scrollbar.set,
        )
        scrollbar.configure(command=self.memo_list.yview)
        scrollbar.pack(side="right", fill="y")
        self.memo_list.pack(side="left", fill="both", expand=True)
        self.memo_ids: list[str] = []
        selected_group_id = str(group.get("id", "")) if group else ""
        memos = sorted(
            owner.memo_records(),
            key=lambda memo: str(memo.get("title", "")).casefold(),
        )
        for index, memo in enumerate(memos):
            memo_id = str(memo.get("id", ""))
            self.memo_ids.append(memo_id)
            kind = (
                "已完成"
                if memo_is_completed(memo)
                else "事件"
                if memo_is_event(memo)
                else "任务"
            )
            self.memo_list.insert(
                "end",
                f"{memo.get('title', '未命名事项')}  ·  {kind}",
            )
            if selected_group_id and str(memo.get("group_id", "")) == selected_group_id:
                self.memo_list.selection_set(index)
        if not memos:
            self.memo_list.insert("end", "目前没有可添加的事项")
            self.memo_list.configure(state="disabled")

        footer = tk.Frame(self, bg="#F7F9FC")
        footer.pack(fill="x", padx=22, pady=(0, 16))
        cancel = tk.Button(
            footer,
            text="取消",
            command=self.close,
            bg="#E9EEF5",
            fg=MUTED,
            activebackground="#DEE6F0",
            activeforeground=TEXT,
            font=(FONT, 10),
            relief="flat",
            bd=0,
            padx=20,
            pady=9,
        )
        cancel.pack(side="left")
        save = tk.Button(
            footer,
            text="保存分组",
            command=self.save,
            bg=BLUE,
            fg="white",
            activebackground=BLUE_DARK,
            activeforeground="white",
            font=(FONT, 10, "bold"),
            relief="flat",
            bd=0,
            padx=24,
            pady=9,
        )
        save.pack(side="right")
        bind_hover(save, BLUE, BLUE_DARK)
        self.bind("<Escape>", lambda _event: self.close())
        self.bind("<Control-Return>", lambda _event: self.save())
        self.after(60, self.name_entry.focus_set)

    def save(self) -> None:
        selected = {
            self.memo_ids[index]
            for index in self.memo_list.curselection()
            if 0 <= index < len(self.memo_ids)
        }
        saved = self.on_save(
            self.group,
            self.name_entry.get(),
            self.intro_text.get("1.0", "end").strip(),
            selected,
        )
        if saved:
            self.close()

    def close(self) -> None:
        try:
            self.grab_release()
        except tk.TclError:
            pass
        if self.owner.dialog is self:
            self.owner.dialog = None
        self.destroy()


class GroupDetailWindow(tk.Toplevel):
    def __init__(self, app: "BUAAmemo", group_id: str) -> None:
        super().__init__(app.root)
        self.app = app
        self.group_id = group_id
        self.image_refs: dict[str, tk.PhotoImage] = {}
        self.title("分组事项 · BUAA浮光")
        self.configure(bg=BG)
        self.transient(app.root)
        self.minsize(430, 520)
        width, height = 520, 720
        app.root.update_idletasks()
        x = app.root.winfo_rootx() + (app.root.winfo_width() - width) // 2
        y = app.root.winfo_rooty() + (app.root.winfo_height() - height) // 2
        x = max(20, min(x, self.winfo_screenwidth() - width - 20))
        y = max(20, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")
        self.protocol("WM_DELETE_WINDOW", self.close)

        header = tk.Frame(self, bg=NAVY, height=104)
        header.pack(fill="x")
        header.pack_propagate(False)
        title_row = tk.Frame(header, bg=NAVY)
        title_row.pack(fill="x", padx=20, pady=(14, 0))
        self.heading_label = tk.Label(
            title_row,
            text="分组事项",
            bg=NAVY,
            fg="white",
            font=(FONT, 18, "bold"),
            anchor="w",
        )
        self.heading_label.pack(side="left", fill="x", expand=True)
        edit_btn = tk.Button(
            title_row,
            text="编辑分组",
            command=self.edit_group,
            bg="#1D5CA8",
            fg="white",
            activebackground="#266DBC",
            activeforeground="white",
            font=(FONT, 8, "bold"),
            relief="flat",
            bd=0,
            padx=10,
            pady=4,
            cursor="hand2",
        )
        edit_btn.pack(side="right")
        self.summary_label = tk.Label(
            header,
            text="",
            bg=NAVY,
            fg="#C8DAF4",
            font=(FONT, 9),
            anchor="w",
            justify="left",
            wraplength=470,
        )
        self.summary_label.pack(fill="x", padx=20, pady=(8, 0))

        body_shell = tk.Frame(self, bg=BG)
        body_shell.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(
            body_shell,
            bg=BG,
            bd=0,
            highlightthickness=0,
        )
        scrollbar = ttk.Scrollbar(
            body_shell,
            orient="vertical",
            command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.list_frame = tk.Frame(self.canvas, bg=BG)
        self.list_window = self.canvas.create_window(
            (0, 0),
            window=self.list_frame,
            anchor="nw",
        )
        self.list_frame.bind(
            "<Configure>",
            lambda _event: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            ),
        )
        self.canvas.bind(
            "<Configure>",
            lambda event: self.canvas.itemconfigure(
                self.list_window,
                width=event.width,
            ),
        )
        self.bind("<Escape>", lambda _event: self.close())
        self.bind("<MouseWheel>", self._on_mousewheel, add="+")
        self.refresh()

    def _group(self) -> dict | None:
        return next(
            (
                group
                for group in self.app.group_records()
                if str(group.get("id", "")) == self.group_id
            ),
            None,
        )

    def refresh(self) -> None:
        group = self._group()
        if group is None:
            self.close()
            return
        items = sorted(
            (
                memo
                for memo in self.app.memo_records()
                if str(memo.get("group_id", "")) == self.group_id
            ),
            key=lambda memo: (
                1 if memo_is_completed(memo) else 0,
                str(memo.get("deadline", "")),
            ),
        )
        active_count = sum(
            1
            for memo in items
            if not memo_is_completed(memo)
            and str(memo.get("deadline", ""))
            and memo.get("deadline", "") > datetime.now().isoformat(
                timespec="seconds"
            )
        )
        intro = str(group.get("note", "")).strip()
        summary = f"{intro}\n" if intro else ""
        summary += f"共 {len(items)} 项 · 当前未结束 {active_count} 项"
        self.heading_label.configure(
            text=str(group.get("title", "分组事项"))
        )
        self.summary_label.configure(text=summary)
        for child in self.list_frame.winfo_children():
            child.destroy()
        self.image_refs.clear()

        if not items:
            empty = tk.Frame(self.list_frame, bg=BG)
            empty.pack(fill="both", expand=True, padx=24, pady=70)
            tk.Label(
                empty,
                text="◷",
                bg=BG,
                fg=BLUE,
                font=(NUMBER_FONT, 30, "bold"),
            ).pack()
            tk.Label(
                empty,
                text="这个分组还没有事项",
                bg=BG,
                fg=TEXT,
                font=(FONT, 13, "bold"),
            ).pack(pady=(10, 4))
            tk.Label(
                empty,
                text="可在编辑分组时添加已有事项。",
                bg=BG,
                fg=MUTED,
                font=(FONT, 9),
            ).pack()
        else:
            for memo in items:
                self._render_item(memo)
        self.list_frame.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _item_state(self, memo: dict) -> tuple[str, str]:
        if memo_is_completed(memo):
            return "已完成", SUCCESS
        try:
            deadline = parse_deadline(memo.get("deadline", ""))
        except (TypeError, ValueError):
            return "时间无效", DANGER
        now = datetime.now()
        if deadline <= now:
            return (
                "已结束" if memo_is_event(memo) else "已过期",
                DANGER,
            )
        if memo_is_event(memo):
            try:
                if now < parse_deadline(memo.get("start_at", "")):
                    return "待开始", BLUE
            except (TypeError, ValueError):
                pass
        if deadline - now <= timedelta(days=1):
            return "24 小时内", WARNING
        return "进行中", BLUE

    def _render_item(self, memo: dict) -> None:
        memo_id = str(memo.get("id", ""))
        state_text, state_color = self._item_state(memo)
        card = tk.Frame(
            self.list_frame,
            bg=SURFACE,
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        card.pack(fill="x", padx=18, pady=(0, 10))
        body = tk.Frame(card, bg=SURFACE)
        body.pack(fill="both", expand=True, padx=14, pady=12)
        head = tk.Frame(body, bg=SURFACE)
        head.pack(fill="x")
        tk.Label(
            head,
            text=str(memo.get("title", "未命名事项")),
            bg=SURFACE,
            fg=TEXT,
            font=(FONT, 11, "bold"),
            anchor="w",
            justify="left",
            wraplength=380,
        ).pack(side="left", fill="x", expand=True)
        tk.Label(
            head,
            text=state_text,
            bg="#EEF3F9",
            fg=state_color,
            font=(FONT, 8, "bold"),
            padx=8,
            pady=2,
        ).pack(side="right")

        note = str(memo.get("note", "")).strip()
        if note:
            tk.Label(
                body,
                text=note,
                bg=SURFACE,
                fg=MUTED,
                font=(FONT, 8),
                anchor="w",
                justify="left",
                wraplength=450,
            ).pack(fill="x", pady=(7, 0))

        details = tk.Frame(body, bg=SURFACE)
        details.pack(fill="x", pady=(9, 0))
        details.grid_columnconfigure(1, weight=1)
        row = 0

        def add_detail(label: str, value: str, color: str = "#45556B") -> None:
            nonlocal row
            tk.Label(
                details,
                text=label,
                bg=SURFACE,
                fg=MUTED,
                font=(FONT, 8),
                width=8,
                anchor="w",
            ).grid(row=row, column=0, sticky="nw", pady=2)
            tk.Label(
                details,
                text=value,
                bg=SURFACE,
                fg=color,
                font=(FONT, 8),
                anchor="w",
                justify="left",
                wraplength=370,
            ).grid(row=row, column=1, sticky="w", pady=2)
            row += 1

        add_detail(
            "事项类型",
            "事件型" if memo_is_event(memo) else "任务型",
        )
        add_detail("当前状态", state_text, state_color)
        if not memo_is_completed(memo):
            try:
                seconds = int(
                    (
                        parse_deadline(memo.get("deadline", ""))
                        - datetime.now()
                    ).total_seconds()
                )
                if seconds > 0:
                    add_detail("剩余时间", format_duration(seconds), state_color)
            except (TypeError, ValueError):
                pass
        if memo_is_event(memo):
            try:
                start_text = parse_deadline(
                    memo.get("start_at", "")
                ).strftime("%Y-%m-%d  %H:%M")
            except (TypeError, ValueError):
                start_text = "未知"
            add_detail("开始时间", start_text)
        try:
            deadline_text = parse_deadline(
                memo.get("deadline", "")
            ).strftime("%Y-%m-%d  %H:%M")
        except (TypeError, ValueError):
            deadline_text = "未知"
        add_detail(
            "结束时间" if memo_is_event(memo) else "终止时间",
            deadline_text,
        )
        if memo.get("completed_at"):
            try:
                completed_text = parse_deadline(
                    memo.get("completed_at", "")
                ).strftime("%Y-%m-%d  %H:%M")
            except (TypeError, ValueError):
                completed_text = "未知"
            add_detail("完成时间", completed_text, SUCCESS)

        image_data = memo.get("image_data")
        image_rel = memo.get("image")
        image_path = APP_DIR / str(image_rel) if image_rel else None
        photo = None
        try:
            if image_data:
                photo = load_preview_from_data(str(image_data), 440, 170)
            elif image_path and image_path.is_file():
                photo = load_preview(image_path, 440, 170)
        except (OSError, ValueError, tk.TclError):
            pass
        if photo is not None:
            self.image_refs[memo_id] = photo
            image_label = tk.Label(
                body,
                image=photo,
                bg="#EEF3F9",
                bd=0,
                cursor="hand2",
            )
            image_label.pack(fill="x", pady=(9, 0))
            image_label.bind(
                "<Button-1>",
                lambda _event, path=image_path, data=image_data, title=str(
                    memo.get("title", "事项图片")
                ): self.app.show_image(path, title, data),
            )

    def edit_group(self) -> None:
        group = self._group()
        if group is not None:
            self.app.open_group_dialog(group)

    def _on_mousewheel(self, event) -> None:
        delta = -1 * int(event.delta / 120) if event.delta else 0
        if delta:
            self.canvas.yview_scroll(delta, "units")

    def close(self) -> None:
        if self.app.group_detail_window is self:
            self.app.group_detail_window = None
        self.destroy()


class AddMemoDialog(tk.Toplevel):
    def __init__(self, owner: "BUAAmemo", on_save) -> None:
        super().__init__(owner.root)
        self.owner = owner
        self.on_save = on_save
        self.selected_image: Path | None = None
        self.preview_photo: tk.PhotoImage | None = None
        self.saved = False

        self.title("新建事项 · BUAA浮光")
        self.configure(bg="#F7F9FC")
        self.resizable(False, False)
        self.transient(owner.root)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.cancel)

        width, height = 430, 720
        owner.root.update_idletasks()
        x = owner.root.winfo_rootx() + (owner.root.winfo_width() - width) // 2
        y = owner.root.winfo_rooty() + (owner.root.winfo_height() - height) // 2
        x = max(20, min(x, self.winfo_screenwidth() - width - 20))
        y = max(20, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")

        default_deadline = (datetime.now() + timedelta(days=1)).replace(
            hour=18, minute=0, second=0, microsecond=0
        )
        default_start = (datetime.now() + timedelta(hours=1)).replace(
            second=0, microsecond=0
        )
        default_event_end = default_start + timedelta(hours=2)
        self.item_type = "task"
        self.date_var = tk.StringVar(value=default_deadline.strftime("%Y-%m-%d"))
        self.start_date_var = tk.StringVar(
            value=default_start.strftime("%Y-%m-%d")
        )
        self.image_name_var = tk.StringVar(value="未选择图片")
        self.group_options: dict[str, str | None] = {"不分组": None}
        for group in owner.group_records():
            title = str(group.get("title", "")).strip()
            if title:
                self.group_options[title] = str(group.get("id", ""))
        self.group_var = tk.StringVar(value="不分组")
        self.hour_var = tk.StringVar(value=default_deadline.strftime("%H"))
        self.minute_var = tk.StringVar(value=default_deadline.strftime("%M"))
        self.start_hour_var = tk.StringVar(value=default_start.strftime("%H"))
        self.start_minute_var = tk.StringVar(value=default_start.strftime("%M"))
        self.event_end_var = tk.StringVar(
            value=default_event_end.strftime("%Y-%m-%d")
        )
        self.event_end_hour_var = tk.StringVar(
            value=default_event_end.strftime("%H")
        )
        self.event_end_minute_var = tk.StringVar(
            value=default_event_end.strftime("%M")
        )
        self.calendar_popup: DatePickerPopup | None = None

        self._build_ui()
        self.bind("<Escape>", lambda _event: self.cancel())
        self.bind("<Control-Return>", lambda _event: self.save())
        self.after(60, self.title_entry.focus_set)

    def _build_ui(self) -> None:
        top = tk.Frame(self, bg=NAVY, height=82)
        top.pack(fill="x")
        top.pack_propagate(False)
        tk.Label(
            top,
            text="新建事项",
            bg=NAVY,
            fg="white",
            font=(FONT, 18, "bold"),
        ).pack(anchor="w", padx=24, pady=(17, 0))
        tk.Label(
            top,
            text="任务看截止，事件看起止",
            bg=NAVY,
            fg="#C8DAF4",
            font=(FONT, 9),
        ).pack(anchor="w", padx=24, pady=(2, 0))

        body_shell = tk.Frame(self, bg="#F7F9FC")
        body_shell.pack(fill="both", expand=True)
        self.body_canvas = tk.Canvas(
            body_shell,
            bg="#F7F9FC",
            bd=0,
            highlightthickness=0,
        )
        body_scrollbar = ttk.Scrollbar(
            body_shell,
            orient="vertical",
            command=self.body_canvas.yview,
        )
        self.body_canvas.configure(yscrollcommand=body_scrollbar.set)
        body_scrollbar.pack(side="right", fill="y")
        self.body_canvas.pack(side="left", fill="both", expand=True)
        body_container = tk.Frame(self.body_canvas, bg="#F7F9FC")
        self.body_window = self.body_canvas.create_window(
            (0, 0),
            window=body_container,
            anchor="nw",
        )
        body = tk.Frame(body_container, bg="#F7F9FC")
        body.pack(fill="x", padx=22, pady=16)
        body_container.bind(
            "<Configure>",
            lambda _event: self.body_canvas.configure(
                scrollregion=self.body_canvas.bbox("all")
            ),
        )
        self.body_canvas.bind(
            "<Configure>",
            lambda event: self.body_canvas.itemconfigure(
                self.body_window,
                width=event.width,
            ),
        )

        self._field_label(body, "事项名称")
        self.title_entry = tk.Entry(
            body,
            font=(FONT, 11),
            bg="white",
            fg=TEXT,
            insertbackground=BLUE,
            relief="flat",
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=BLUE,
        )
        self.title_entry.pack(fill="x", ipady=8, pady=(5, 12))

        self._field_label(body, "事项类型")
        type_row = tk.Frame(body, bg="#F7F9FC")
        type_row.pack(fill="x", pady=(5, 0))
        self.task_type_btn = self._type_button(
            type_row,
            "任务型",
            "有截止时间，可提前完成",
            lambda: self.set_item_type("task"),
        )
        self.task_type_btn.pack(side="left", fill="x", expand=True, padx=(0, 5))
        self.event_type_btn = self._type_button(
            type_row,
            "事件型",
            "有开始和结束时间",
            lambda: self.set_item_type("event"),
        )
        self.event_type_btn.pack(side="left", fill="x", expand=True, padx=(5, 0))

        self.type_fields = tk.Frame(body, bg="#F7F9FC")
        self.type_fields.pack(fill="x")
        self.task_frame = tk.Frame(self.type_fields, bg="#F7F9FC")
        self.task_frame.pack(fill="x", pady=(12, 0))
        self._field_label(self.task_frame, "截止时间")
        date_row = tk.Frame(self.task_frame, bg="#F7F9FC")
        date_row.pack(fill="x", pady=(5, 7))
        self.date_entry = self._date_entry(date_row, self.date_var)
        self.date_entry.pack(side="left", ipady=7)
        tk.Label(
            date_row,
            text="  日期  ",
            bg="#F7F9FC",
            fg=MUTED,
            font=(FONT, 8),
        ).pack(side="left")
        self._calendar_button(
            date_row,
            self.date_var,
            self._deadline_date_chosen,
        ).pack(side="left", padx=(8, 0))

        time_row = tk.Frame(self.task_frame, bg="#F7F9FC")
        time_row.pack(fill="x", pady=(0, 6))
        tk.Label(
            time_row,
            text="时间",
            bg="#F7F9FC",
            fg=TEXT,
            font=(FONT, 9, "bold"),
        ).pack(side="left", padx=(0, 12))
        self.hour_spin = self._time_spinbox(time_row, self.hour_var, 23)
        self.hour_spin.pack(side="left", ipady=4)
        tk.Label(
            time_row,
            text=" : ",
            bg="#F7F9FC",
            fg=TEXT,
            font=(NUMBER_FONT, 11, "bold"),
        ).pack(side="left")
        self.minute_spin = self._time_spinbox(time_row, self.minute_var, 59)
        self.minute_spin.pack(side="left", ipady=4)
        tk.Label(
            time_row,
            text="    可直接输入或点箭头调整",
            bg="#F7F9FC",
            fg=MUTED,
            font=(FONT, 8),
        ).pack(side="left")

        quick_row = tk.Frame(self.task_frame, bg="#F7F9FC")
        quick_row.pack(fill="x", pady=(0, 12))
        self._quick_button(quick_row, "10 分钟后", 0).pack(side="left", padx=(0, 6))
        self._quick_button(quick_row, "明天 18:00", 1).pack(side="left", padx=(0, 6))
        self._quick_button(quick_row, "3 天后", 2).pack(side="left", padx=(0, 6))
        self._quick_button(quick_row, "1 周后", 3).pack(side="left")

        self.event_frame = tk.Frame(self.type_fields, bg="#F7F9FC")
        self._field_label(self.event_frame, "开始时间")
        start_date_row = tk.Frame(self.event_frame, bg="#F7F9FC")
        start_date_row.pack(fill="x", pady=(5, 5))
        self.start_date_entry = self._date_entry(
            start_date_row,
            self.start_date_var,
        )
        self.start_date_entry.pack(side="left", ipady=7)
        self._calendar_button(
            start_date_row,
            self.start_date_var,
            self._start_date_chosen,
        ).pack(side="left", padx=(8, 0))
        start_time_row = tk.Frame(self.event_frame, bg="#F7F9FC")
        start_time_row.pack(fill="x", pady=(0, 10))
        self._time_row(
            start_time_row,
            self.start_hour_var,
            self.start_minute_var,
        )

        self._field_label(self.event_frame, "结束时间")
        end_date_row = tk.Frame(self.event_frame, bg="#F7F9FC")
        end_date_row.pack(fill="x", pady=(5, 5))
        self.event_end_entry = self._date_entry(
            end_date_row,
            self.event_end_var,
        )
        self.event_end_entry.pack(side="left", ipady=7)
        self._calendar_button(
            end_date_row,
            self.event_end_var,
            self._event_end_date_chosen,
        ).pack(side="left", padx=(8, 0))
        event_end_time_row = tk.Frame(self.event_frame, bg="#F7F9FC")
        event_end_time_row.pack(fill="x", pady=(0, 7))
        self._time_row(
            event_end_time_row,
            self.event_end_hour_var,
            self.event_end_minute_var,
        )
        tk.Label(
            self.event_frame,
            text="事件没有“完成”按钮，结束时间到达后自动进入历史事项。",
            bg="#F7F9FC",
            fg=MUTED,
            font=(FONT, 8),
            anchor="w",
        ).pack(fill="x", pady=(2, 12))

        self._field_label(body, "所属分组（可选）")
        group_row = tk.Frame(body, bg="#F7F9FC")
        group_row.pack(fill="x", pady=(5, 12))
        self.group_menu = tk.OptionMenu(
            group_row,
            self.group_var,
            *self.group_options.keys(),
        )
        self.group_menu.configure(
            font=(FONT, 9),
            bg="white",
            fg=TEXT,
            activebackground=BLUE_SOFT,
            activeforeground=BLUE_DARK,
            relief="flat",
            highlightthickness=1,
            highlightbackground=BORDER,
            anchor="w",
            padx=8,
        )
        self.group_menu.pack(side="left", fill="x", expand=True)
        tk.Label(
            group_row,
            text="不加入分组也可以正常保存",
            bg="#F7F9FC",
            fg=MUTED,
            font=(FONT, 8),
        ).pack(side="left", padx=(10, 0))

        self._field_label(body, "备注（可选）")
        self.note_text = tk.Text(
            body,
            height=3,
            font=(FONT, 10),
            bg="white",
            fg=TEXT,
            insertbackground=BLUE,
            relief="flat",
            wrap="word",
            padx=8,
            pady=7,
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=BLUE,
        )
        self.note_text.pack(fill="x", pady=(5, 12))

        self._field_label(body, "图片（可选）")
        image_panel = tk.Frame(
            body,
            bg="#F1F5FA",
            height=86,
            highlightthickness=1,
            highlightbackground="#E3EAF3",
        )
        image_panel.pack(fill="x", pady=(5, 0))
        image_panel.pack_propagate(False)
        self.image_preview = tk.Label(
            image_panel,
            text="可添加截图或参考图\n支持 PNG / JPG / BMP / GIF",
            bg="#F1F5FA",
            fg=MUTED,
            font=(FONT, 8),
            justify="center",
        )
        self.image_preview.pack(side="left", fill="both", expand=True)
        image_actions = tk.Frame(image_panel, bg="#F1F5FA")
        image_actions.pack(side="right", padx=10)
        self.choose_image_btn = tk.Button(
            image_actions,
            text="选择图片",
            command=self.choose_image,
            bg="white",
            fg=BLUE,
            activebackground=BLUE_SOFT,
            activeforeground=BLUE_DARK,
            font=(FONT, 9),
            relief="flat",
            bd=0,
            padx=12,
            pady=6,
            cursor="hand2",
        )
        self.choose_image_btn.pack()
        self.remove_image_btn = tk.Button(
            image_actions,
            text="移除图片",
            command=self.remove_image,
            bg="#F1F5FA",
            fg=MUTED,
            activebackground="#F1F5FA",
            activeforeground=DANGER,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            cursor="hand2",
            state="disabled",
        )
        self.remove_image_btn.pack(pady=(4, 0))

        footer = tk.Frame(self, bg="#F7F9FC")
        footer.pack(fill="x", padx=22, pady=(0, 18))
        cancel_btn = tk.Button(
            footer,
            text="取消",
            command=self.cancel,
            bg="#E9EEF5",
            fg=MUTED,
            activebackground="#DEE6F0",
            activeforeground=TEXT,
            font=(FONT, 10),
            relief="flat",
            bd=0,
            padx=20,
            pady=9,
            cursor="hand2",
        )
        cancel_btn.pack(side="left")
        save_btn = tk.Button(
            footer,
            text="保存事项",
            command=self.save,
            bg=BLUE,
            fg="white",
            activebackground=BLUE_DARK,
            activeforeground="white",
            font=(FONT, 10, "bold"),
            relief="flat",
            bd=0,
            padx=24,
            pady=9,
            cursor="hand2",
        )
        save_btn.pack(side="right")
        bind_hover(save_btn, BLUE, BLUE_DARK)
        bind_hover(cancel_btn, "#E9EEF5", "#DEE6F0")
        self.bind("<MouseWheel>", self._on_body_wheel, add="+")
        self.set_item_type("task")

    def _on_body_wheel(self, event) -> None:
        first, last = self.body_canvas.yview()
        if first <= 0 and last >= 1:
            return
        delta = -1 * int(event.delta / 120) if event.delta else 0
        if delta:
            self.body_canvas.yview_scroll(delta, "units")

    def _field_label(self, parent: tk.Widget, text: str) -> None:
        tk.Label(
            parent,
            text=text,
            bg="#F7F9FC",
            fg=TEXT,
            font=(FONT, 9, "bold"),
        ).pack(anchor="w")

    def _quick_button(self, parent: tk.Widget, text: str, preset: int) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=lambda: self.set_preset(preset),
            bg="#EAF1FA",
            fg=BLUE_DARK,
            activebackground=BLUE_SOFT,
            activeforeground=BLUE_DARK,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=9,
            pady=4,
            cursor="hand2",
        )

    def _type_button(
        self,
        parent: tk.Widget,
        title: str,
        hint: str,
        command,
    ) -> tk.Button:
        return tk.Button(
            parent,
            text=f"{title}\n{hint}",
            command=command,
            bg="#EAF1FA",
            fg=BLUE_DARK,
            activebackground=BLUE_SOFT,
            activeforeground=BLUE_DARK,
            font=(FONT, 8, "bold"),
            justify="left",
            anchor="w",
            relief="flat",
            bd=0,
            padx=12,
            pady=7,
            cursor="hand2",
        )

    def _date_entry(
        self,
        parent: tk.Widget,
        variable: tk.StringVar,
    ) -> tk.Entry:
        return tk.Entry(
            parent,
            textvariable=variable,
            width=14,
            font=(NUMBER_FONT, 10),
            bg="white",
            fg=TEXT,
            insertbackground=BLUE,
            relief="flat",
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=BLUE,
        )

    def _calendar_button(
        self,
        parent: tk.Widget,
        date_var: tk.StringVar,
        on_select,
    ) -> tk.Button:
        return tk.Button(
            parent,
            text="打开月历",
            command=lambda: self.open_calendar(date_var, on_select),
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            activebackground="#DDEBFF",
            activeforeground=BLUE_DARK,
            font=(FONT, 9, "bold"),
            relief="flat",
            bd=0,
            padx=12,
            pady=7,
            cursor="hand2",
        )

    def _time_row(
        self,
        parent: tk.Widget,
        hour_var: tk.StringVar,
        minute_var: tk.StringVar,
    ) -> None:
        tk.Label(
            parent,
            text="时间",
            bg="#F7F9FC",
            fg=TEXT,
            font=(FONT, 9, "bold"),
        ).pack(side="left", padx=(0, 12))
        self._time_spinbox(parent, hour_var, 23).pack(side="left", ipady=4)
        tk.Label(
            parent,
            text=" : ",
            bg="#F7F9FC",
            fg=TEXT,
            font=(NUMBER_FONT, 11, "bold"),
        ).pack(side="left")
        self._time_spinbox(parent, minute_var, 59).pack(side="left", ipady=4)
        tk.Label(
            parent,
            text="    可直接输入或点箭头调整",
            bg="#F7F9FC",
            fg=MUTED,
            font=(FONT, 8),
        ).pack(side="left")

    def set_item_type(self, item_type: str) -> None:
        self.item_type = "event" if item_type == "event" else "task"
        selected = {
            "bg": BLUE,
            "fg": "white",
            "activebackground": BLUE_DARK,
            "activeforeground": "white",
        }
        normal = {
            "bg": "#EAF1FA",
            "fg": BLUE_DARK,
            "activebackground": BLUE_SOFT,
            "activeforeground": BLUE_DARK,
        }
        self.task_type_btn.configure(
            **(selected if self.item_type == "task" else normal)
        )
        self.event_type_btn.configure(
            **(selected if self.item_type == "event" else normal)
        )
        if self.item_type == "event":
            self.task_frame.pack_forget()
            self.event_frame.pack(fill="x", pady=(12, 0))
        else:
            self.event_frame.pack_forget()
            self.task_frame.pack(fill="x", pady=(12, 0))

    def _time_spinbox(
        self,
        parent: tk.Widget,
        variable: tk.StringVar,
        maximum: int,
    ) -> tk.Spinbox:
        return tk.Spinbox(
            parent,
            from_=0,
            to=maximum,
            increment=1,
            wrap=True,
            format="%02.0f",
            textvariable=variable,
            width=4,
            justify="center",
            font=(NUMBER_FONT, 11),
            bg="white",
            fg=TEXT,
            insertbackground=BLUE,
            buttonbackground="#EAF1FA",
            relief="flat",
            bd=0,
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=BLUE,
        )

    def open_calendar(
        self,
        date_var: tk.StringVar | None = None,
        on_select=None,
    ) -> None:
        date_var = date_var or self.date_var
        on_select = on_select or self._deadline_date_chosen
        if self.calendar_popup and self.calendar_popup.winfo_exists():
            if getattr(self, "calendar_target_var", None) == date_var:
                self.calendar_popup.lift()
                return
            self.calendar_popup.destroy()
        self.calendar_target_var = date_var
        self.calendar_popup = DatePickerPopup(
            self,
            date_var,
            on_select,
        )
        self.calendar_popup.bind(
            "<Destroy>",
            self._on_calendar_destroy,
            add="+",
        )

    def _on_calendar_destroy(self, event) -> None:
        if event.widget is self.calendar_popup:
            self.calendar_popup = None

    def _deadline_date_chosen(self, _value) -> None:
        self.after(20, self.hour_spin.focus_set)

    def _start_date_chosen(self, _value) -> None:
        self.after(20, self.start_date_entry.focus_set)

    def _event_end_date_chosen(self, _value) -> None:
        self.after(20, self.event_end_entry.focus_set)

    def set_preset(self, preset: int) -> None:
        now = datetime.now()
        if preset == 0:
            target = (now + timedelta(minutes=10)).replace(second=0, microsecond=0)
        elif preset == 1:
            target = (now + timedelta(days=1)).replace(
                hour=18, minute=0, second=0, microsecond=0
            )
        elif preset == 2:
            target = (now + timedelta(days=3)).replace(
                hour=18, minute=0, second=0, microsecond=0
            )
        else:
            target = (now + timedelta(days=7)).replace(
                hour=18, minute=0, second=0, microsecond=0
            )
        self.date_var.set(target.strftime("%Y-%m-%d"))
        self.hour_var.set(target.strftime("%H"))
        self.minute_var.set(target.strftime("%M"))

    def choose_image(self) -> None:
        source = filedialog.askopenfilename(
            parent=self,
            title="选择一张图片",
            filetypes=[
                ("图片", "*.png *.jpg *.jpeg *.bmp *.gif"),
                ("所有文件", "*.*"),
            ],
        )
        if not source:
            return

        source_path = Path(source)
        if not source_path.is_file():
            messagebox.showerror("无法读取图片", "选择的文件不存在。", parent=self)
            return

        IMAGE_DIR.mkdir(parents=True, exist_ok=True)
        destination = IMAGE_DIR / f"img_{uuid.uuid4().hex}.png"
        try:
            self.owner.convert_image(source_path, destination, 900, 600)
            photo = load_preview(destination, 220, 72)
        except Exception as exc:
            if destination.exists():
                destination.unlink(missing_ok=True)
            messagebox.showerror(
                "图片添加失败",
                f"无法读取这张图片。\n\n{exc}",
                parent=self,
            )
            return

        self.remove_image(delete_file=True, refresh=False)
        self.selected_image = destination
        self.preview_photo = photo
        self.image_preview.configure(image=photo, text="", bg="#E7EEF7")
        self.image_name_var.set(source_path.name)
        self.remove_image_btn.configure(state="normal")

    def remove_image(self, delete_file: bool = True, refresh: bool = True) -> None:
        if delete_file and self.selected_image and self.selected_image.exists():
            try:
                self.selected_image.unlink()
            except OSError:
                pass
        self.selected_image = None
        self.preview_photo = None
        self.remove_image_btn.configure(state="disabled")
        if refresh:
            self.image_preview.configure(
                image="",
                text="可添加截图或参考图\n支持 PNG / JPG / BMP / GIF",
                bg="#F1F5FA",
            )
            self.image_name_var.set("未选择图片")

    def save(self) -> None:
        title = self.title_entry.get().strip()
        if not title:
            messagebox.showwarning("还差一步", "请填写事项名称。", parent=self)
            self.title_entry.focus_set()
            return

        start_at = None
        try:
            if self.item_type == "event":
                start_at = parse_picker_datetime(
                    self.start_date_var.get(),
                    self.start_hour_var.get(),
                    self.start_minute_var.get(),
                )
                deadline = parse_picker_datetime(
                    self.event_end_var.get(),
                    self.event_end_hour_var.get(),
                    self.event_end_minute_var.get(),
                )
            else:
                deadline = parse_picker_datetime(
                    self.date_var.get(),
                    self.hour_var.get(),
                    self.minute_var.get(),
                )
        except (TypeError, ValueError):
            messagebox.showwarning(
                "时间格式不正确",
                "日期请填写为 2026-10-20，小时请选择 0–23，分钟请选择 0–59。",
                parent=self,
            )
            return

        if self.item_type == "event":
            if start_at is None or start_at >= deadline:
                messagebox.showwarning(
                    "时间顺序不正确",
                    "事件开始时间需要早于结束时间。",
                    parent=self,
                )
                return
            if deadline <= datetime.now():
                messagebox.showwarning(
                    "结束时间已过",
                    "请选择一个晚于当前时间的事件结束时间。",
                    parent=self,
                )
                return
            self.start_date_var.set(start_at.strftime("%Y-%m-%d"))
            self.start_hour_var.set(start_at.strftime("%H"))
            self.start_minute_var.set(start_at.strftime("%M"))
            self.event_end_var.set(deadline.strftime("%Y-%m-%d"))
            self.event_end_hour_var.set(deadline.strftime("%H"))
            self.event_end_minute_var.set(deadline.strftime("%M"))
        else:
            if deadline <= datetime.now():
                messagebox.showwarning(
                    "截止时间已过",
                    "请选择一个晚于当前时间的截止时间。",
                    parent=self,
                )
                return
            self.date_var.set(deadline.strftime("%Y-%m-%d"))
            self.hour_var.set(deadline.strftime("%H"))
            self.minute_var.set(deadline.strftime("%M"))

        image_rel = None
        if self.selected_image and self.selected_image.exists():
            image_rel = self.selected_image.relative_to(APP_DIR).as_posix()

        item = {
            "id": uuid.uuid4().hex,
            "title": title,
            "note": self.note_text.get("1.0", "end").strip(),
            "item_type": self.item_type,
            "start_at": (
                start_at.isoformat(timespec="seconds")
                if start_at is not None
                else None
            ),
            "deadline": deadline.isoformat(timespec="seconds"),
            "group_id": self.group_options.get(self.group_var.get()),
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "image": image_rel,
            "completed": False,
            "completed_at": None,
        }
        self.saved = True
        self.grab_release()
        self.destroy()
        self.on_save(item)

    def cancel(self) -> None:
        if not self.saved:
            self.remove_image(delete_file=True, refresh=False)
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()


class WeChatControlWindow(tk.Toplevel):
    def __init__(self, app: "BUAAmemo", url: str) -> None:
        super().__init__(app.root)
        self.app = app
        self.url = url
        self.title("微信控制 · BUAA浮光")
        self.configure(bg=BG)
        self.resizable(False, False)
        self.transient(app.root)
        self.protocol("WM_DELETE_WINDOW", self.close)

        width, height = 430, 650
        app.root.update_idletasks()
        x = app.root.winfo_rootx() + (app.root.winfo_width() - width) // 2
        y = app.root.winfo_rooty() + (app.root.winfo_height() - height) // 2
        x = max(20, min(x, self.winfo_screenwidth() - width - 20))
        y = max(20, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")

        header = tk.Frame(self, bg=NAVY, height=88)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header,
            text="微信控制",
            bg=NAVY,
            fg="white",
            font=(FONT, 19, "bold"),
        ).pack(anchor="w", padx=24, pady=(17, 0))
        tk.Label(
            header,
            text="用微信扫一扫，手机上也能管理和同步事项",
            bg=NAVY,
            fg="#C8DAF4",
            font=(FONT, 9),
        ).pack(anchor="w", padx=24, pady=(3, 0))

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=24, pady=(14, 0))

        qr_card = tk.Frame(
            body,
            bg="white",
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        qr_card.pack()
        self.qr_canvas = tk.Canvas(
            qr_card,
            width=218,
            height=218,
            bg="white",
            bd=0,
            highlightthickness=0,
        )
        self.qr_canvas.pack(padx=11, pady=11)
        try:
            draw_qr_on_canvas(self.qr_canvas, url, 218, NAVY)
        except Exception as exc:
            self.qr_canvas.create_text(
                109,
                109,
                text=f"二维码生成失败\n{exc}",
                fill=DANGER,
                font=(FONT, 9),
                justify="center",
                width=210,
            )

        tk.Label(
            body,
            text="用微信“扫一扫”打开手机控制页",
            bg=BG,
            fg=TEXT,
            font=(FONT, 11, "bold"),
        ).pack(pady=(13, 3))

        url_row = tk.Frame(body, bg=BG)
        url_row.pack(fill="x", pady=(4, 0))
        self.url_label = tk.Label(
            url_row,
            text=url,
            bg="#E2EBF6",
            fg="#405674",
            font=(NUMBER_FONT, 7),
            padx=9,
            pady=6,
            anchor="w",
            justify="left",
            wraplength=318,
        )
        self.url_label.pack(side="left", fill="x", expand=True)
        self.copy_btn = tk.Button(
            url_row,
            text="复制",
            command=self.copy_url,
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            activebackground="#DDEBFF",
            activeforeground=BLUE_DARK,
            font=(FONT, 8, "bold"),
            relief="flat",
            bd=0,
            padx=10,
            pady=6,
            cursor="hand2",
        )
        self.copy_btn.pack(side="right", padx=(7, 0))

        status = tk.Frame(body, bg="#EAF7F1", padx=11, pady=7)
        status.pack(fill="x", pady=(13, 0))
        tk.Label(
            status,
            text="●",
            bg="#EAF7F1",
            fg=SUCCESS,
            font=(FONT, 9),
        ).pack(side="left")
        tk.Label(
            status,
            text="控制服务运行中 · 仅同一 Wi‑Fi 可访问",
            bg="#EAF7F1",
            fg=SUCCESS,
            font=(FONT, 8),
        ).pack(side="left", padx=(5, 0))

        help_box = tk.Frame(body, bg="#F8FAFD")
        help_box.pack(fill="x", pady=(12, 0))
        for line in (
            "1. 手机和电脑需要连接同一个 Wi‑Fi。",
            "2. 下载离线手机版后，电脑关机时也能继续记录，联网后自动合并。",
            "3. 若手机打不开，请允许 Python 通过 Windows 专用网络防火墙。",
        ):
            tk.Label(
                help_box,
                text=line,
                bg="#F8FAFD",
                fg=MUTED,
                font=(FONT, 8),
                anchor="w",
                justify="left",
                wraplength=375,
            ).pack(fill="x", padx=12, pady=2)

        close_btn = tk.Button(
            body,
            text="关闭",
            command=self.close,
            bg="#E9EEF5",
            fg=MUTED,
            activebackground="#DEE6F0",
            activeforeground=TEXT,
            font=(FONT, 9),
            relief="flat",
            bd=0,
            padx=22,
            pady=8,
            cursor="hand2",
        )
        close_btn.pack(pady=(10, 8))
        self.bind("<Escape>", lambda _event: self.close())

    def copy_url(self) -> None:
        self.clipboard_clear()
        self.clipboard_append(self.url)
        self.copy_btn.configure(text="已复制")
        self.after(1400, lambda: self.copy_btn.configure(text="复制"))

    def close(self) -> None:
        if self.app.web_window is self:
            self.app.web_window = None
        self.destroy()


class DownloadQrWindow(tk.Toplevel):
    def __init__(
        self,
        app: "BUAAmemo",
        mobile_url: str,
    ) -> None:
        super().__init__(app.root)
        self.app = app
        self.mobile_url = mobile_url
        self.title("手机 Android 版 · BUAA浮光")
        self.configure(bg=BG)
        self.resizable(False, False)
        self.transient(app.root)
        self.protocol("WM_DELETE_WINDOW", self.close)

        width, height = 470, 720
        app.root.update_idletasks()
        x = app.root.winfo_rootx() + (app.root.winfo_width() - width) // 2
        y = app.root.winfo_rooty() + (app.root.winfo_height() - height) // 2
        x = max(20, min(x, self.winfo_screenwidth() - width - 20))
        y = max(20, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")

        header = tk.Frame(self, bg=NAVY, height=94)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header,
            text="手机 Android 版",
            bg=NAVY,
            fg="white",
            font=(FONT, 19, "bold"),
        ).pack(anchor="w", padx=24, pady=(16, 0))
        tk.Label(
            header,
            text="扫码下载 APK，安装后手机可独立运行",
            bg=NAVY,
            fg="#C8DAF4",
            font=(FONT, 9),
        ).pack(anchor="w", padx=24, pady=(3, 0))

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=20, pady=16)
        body.grid_columnconfigure(0, weight=1)
        self._build_card(
            body,
            column=0,
            title="手机 Android 版",
            subtitle="Android APK",
            description="手机联网即可扫码；登录平台后从“版本下载”获取 APK。",
            url=mobile_url,
        )

        tk.Label(
            body,
            text=(
                "下载与同步说明\n"
                "1. 下载手机版不要求与电脑连接同一 Wi-Fi，手机联网扫码即可。\n"
                "2. 扫码后登录平台，在“版本下载”中安装最新版 Android APK。\n"
                "3. 同步数据时，手机与电脑才需要连接同一 Wi-Fi 或手机热点。\n"
                "4. 打开手机 App 并点击“同步”，记下 6 位配对码。\n"
                "5. 点击电脑端底部“同步”，输入配对码。\n"
                "6. 若校园网无法自动发现，再输入手机 App 显示的 IP:端口。"
            ),
            bg=BG,
            fg=MUTED,
            font=(FONT, 8),
            wraplength=560,
            justify="left",
        ).grid(row=1, column=0, pady=(12, 0))

        close_btn = tk.Button(
            body,
            text="关闭",
            command=self.close,
            bg="#E9EEF5",
            fg=MUTED,
            activebackground="#DEE6F0",
            activeforeground=TEXT,
            font=(FONT, 9),
            relief="flat",
            bd=0,
            padx=22,
            pady=7,
            cursor="hand2",
        )
        close_btn.grid(row=2, column=0, pady=(12, 0))
        self.bind("<Escape>", lambda _event: self.close())

    def _build_card(
        self,
        parent: tk.Widget,
        column: int,
        title: str,
        subtitle: str,
        description: str,
        url: str,
    ) -> None:
        card = tk.Frame(
            parent,
            bg=SURFACE,
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        card.grid(
            row=0,
            column=column,
            sticky="nsew",
            padx=(4 if column == 0 else 8, 8 if column == 0 else 4),
        )
        tk.Label(
            card,
            text=title,
            bg=SURFACE,
            fg=NAVY,
            font=(FONT, 13, "bold"),
        ).pack(pady=(13, 0))
        tk.Label(
            card,
            text=subtitle,
            bg=SURFACE,
            fg=BLUE,
            font=(FONT, 8),
        ).pack(pady=(1, 7))

        canvas = tk.Canvas(
            card,
            width=218,
            height=218,
            bg="white",
            highlightthickness=0,
        )
        canvas.pack()
        try:
            draw_qr_on_canvas(canvas, url, 218, NAVY)
        except Exception as exc:
            canvas.create_text(
                109,
                109,
                text=f"二维码生成失败\n{exc}",
                fill=DANGER,
                font=(FONT, 9),
                justify="center",
                width=190,
            )
        tk.Label(
            card,
            text=description,
            bg=SURFACE,
            fg=MUTED,
            font=(FONT, 8),
            justify="center",
            wraplength=245,
        ).pack(pady=(9, 5))
        url_label = tk.Label(
            card,
            text=url,
            bg="#F2F6FB",
            fg="#52677F",
            font=(NUMBER_FONT, 7),
            padx=6,
            pady=4,
            wraplength=250,
            justify="left",
        )
        url_label.pack(fill="x", padx=14)
        copy_btn = tk.Button(
            card,
            text="复制地址",
            command=lambda: self.copy_url(url),
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            activebackground="#DDEBFF",
            activeforeground=BLUE_DARK,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=10,
            pady=4,
            cursor="hand2",
        )
        copy_btn.pack(pady=(6, 13))

    def copy_url(self, url: str) -> None:
        self.clipboard_clear()
        self.clipboard_append(url)

    def close(self) -> None:
        if self.app.download_window is self:
            self.app.download_window = None
        self.destroy()


class ChangelogWindow(tk.Toplevel):
    def __init__(self, app: "BUAAmemo", changelog: dict) -> None:
        super().__init__(app.root)
        self.app = app
        self.title("版本更新日志 · BUAA浮光")
        self.configure(bg=BG)
        self.resizable(True, True)
        self.minsize(400, 420)
        self.transient(app.root)

        width, height = 470, 640
        app.root.update_idletasks()
        x = app.root.winfo_rootx() + (app.root.winfo_width() - width) // 2
        y = app.root.winfo_rooty() + (app.root.winfo_height() - height) // 2
        x = max(20, min(x, self.winfo_screenwidth() - width - 20))
        y = max(20, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")

        header = tk.Frame(self, bg=NAVY, height=102)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header,
            text="版本更新日志",
            bg=NAVY,
            fg="white",
            font=(FONT, 19, "bold"),
        ).pack(anchor="w", padx=24, pady=(17, 0))
        tk.Label(
            header,
            text=f"BUAA浮光 · 当前版本 v{changelog['current_version']}",
            bg=NAVY,
            fg="#C8DAF4",
            font=(FONT, 9),
        ).pack(anchor="w", padx=24, pady=(3, 0))

        shell = tk.Frame(self, bg=BG)
        shell.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(shell, bg=BG, bd=0, highlightthickness=0)
        scrollbar = ttk.Scrollbar(
            shell,
            orient="vertical",
            command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.inner = tk.Frame(self.canvas, bg=BG)
        self.inner_window = self.canvas.create_window(
            (0, 0),
            window=self.inner,
            anchor="nw",
        )
        self.inner.bind(
            "<Configure>",
            lambda _event: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            ),
        )
        self.canvas.bind(
            "<Configure>",
            lambda event: self.canvas.itemconfigure(
                self.inner_window,
                width=event.width,
            ),
        )

        for index, entry in enumerate(changelog["entries"]):
            self._render_entry(entry, is_latest=index == 0)

        footer = tk.Frame(self, bg="#E5EDF7", height=32)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)
        tk.Label(
            footer,
            text=f"共 {len(changelog['entries'])} 个版本记录",
            bg="#E5EDF7",
            fg="#55708F",
            font=(FONT, 8),
        ).pack(side="left", padx=20)
        close_btn = tk.Button(
            footer,
            text="关闭",
            command=self.close,
            bg="#DCE7F4",
            fg="#405674",
            activebackground="#CEDAEA",
            activeforeground=TEXT,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=14,
            pady=3,
            cursor="hand2",
        )
        close_btn.pack(side="right", padx=16, pady=4)

        self.bind("<MouseWheel>", self._on_mousewheel, add="+")
        self.bind("<Escape>", lambda _event: self.close())

    def _render_entry(self, entry: dict, is_latest: bool) -> None:
        card = tk.Frame(
            self.inner,
            bg=SURFACE,
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        card.pack(fill="x", padx=20, pady=(14 if is_latest else 0, 10))

        header = tk.Frame(card, bg=SURFACE)
        header.pack(fill="x", padx=15, pady=(13, 0))
        version_label = tk.Label(
            header,
            text=f"v{entry.get('version', '')}",
            bg=BLUE if is_latest else BLUE_SOFT,
            fg="white" if is_latest else BLUE_DARK,
            font=(NUMBER_FONT, 9, "bold"),
            padx=9,
            pady=3,
        )
        version_label.pack(side="left")
        if is_latest:
            tk.Label(
                header,
                text="当前版本",
                bg=SUCCESS_SOFT,
                fg=SUCCESS,
                font=(FONT, 7, "bold"),
                padx=7,
                pady=3,
            ).pack(side="left", padx=(7, 0))
        tk.Label(
            header,
            text=entry.get("date", ""),
            bg=SURFACE,
            fg=MUTED,
            font=(NUMBER_FONT, 8),
        ).pack(side="right")

        tk.Label(
            card,
            text=entry.get("title", "版本更新"),
            bg=SURFACE,
            fg=TEXT,
            font=(FONT, 12, "bold"),
            anchor="w",
            justify="left",
        ).pack(fill="x", padx=15, pady=(10, 4))

        for change in entry.get("changes", []):
            tk.Label(
                card,
                text=f"•  {change}",
                bg=SURFACE,
                fg="#48576C",
                font=(FONT, 9),
                anchor="w",
                justify="left",
                wraplength=385,
            ).pack(fill="x", padx=15, pady=2)

        tk.Frame(card, bg=SURFACE, height=11).pack(fill="x")

    def _on_mousewheel(self, event) -> None:
        try:
            widget = self.winfo_containing(event.x_root, event.y_root)
        except (KeyError, tk.TclError):
            return
        current = widget
        while current is not None:
            if current == self.canvas:
                delta = -1 * int(event.delta / 120) if event.delta else 0
                if delta:
                    self.canvas.yview_scroll(delta, "units")
                return
            current = getattr(current, "master", None)

    def close(self) -> None:
        if self.app.changelog_window is self:
            self.app.changelog_window = None
        self.destroy()


class HistoryWindow(tk.Toplevel):
    def __init__(self, app: "BUAAmemo") -> None:
        super().__init__(app.root)
        self.app = app
        self.title("历史事项 · BUAA浮光")
        self.configure(bg=BG)
        self.resizable(True, True)
        self.minsize(400, 430)
        self.transient(app.root)

        width, height = 470, 620
        app.root.update_idletasks()
        x = app.root.winfo_rootx() + (app.root.winfo_width() - width) // 2
        y = app.root.winfo_rooty() + (app.root.winfo_height() - height) // 2
        x = max(20, min(x, self.winfo_screenwidth() - width - 20))
        y = max(20, min(y, self.winfo_screenheight() - height - 40))
        self.geometry(f"{width}x{height}+{x}+{y}")

        header = tk.Frame(self, bg="#324A68", height=100)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header,
            text="历史事项",
            bg="#324A68",
            fg="white",
            font=(FONT, 19, "bold"),
        ).pack(anchor="w", padx=24, pady=(16, 0))
        self.subtitle = tk.Label(
            header,
            text="已完成或已结束事项仅支持删除，不可修改",
            bg="#324A68",
            fg="#CAD6E5",
            font=(FONT, 9),
        )
        self.subtitle.pack(anchor="w", padx=24, pady=(3, 0))

        shell = tk.Frame(self, bg=BG)
        shell.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(shell, bg=BG, bd=0, highlightthickness=0)
        scrollbar = ttk.Scrollbar(
            shell,
            orient="vertical",
            command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.inner = tk.Frame(self.canvas, bg=BG)
        self.inner_window = self.canvas.create_window(
            (0, 0),
            window=self.inner,
            anchor="nw",
        )
        self.inner.bind(
            "<Configure>",
            lambda _event: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            ),
        )
        self.canvas.bind(
            "<Configure>",
            lambda event: self.canvas.itemconfigure(
                self.inner_window,
                width=event.width,
            ),
        )

        footer = tk.Frame(self, bg="#E5EDF7", height=32)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)
        self.footer_label = tk.Label(
            footer,
            text="0 项历史事项",
            bg="#E5EDF7",
            fg="#55708F",
            font=(FONT, 8),
        )
        self.footer_label.pack(side="left", padx=20)
        close_btn = tk.Button(
            footer,
            text="关闭",
            command=self.close,
            bg="#DCE7F4",
            fg="#405674",
            activebackground="#CEDAEA",
            activeforeground=TEXT,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=14,
            pady=3,
            cursor="hand2",
        )
        close_btn.pack(side="right", padx=16, pady=4)

        self.bind("<MouseWheel>", self._on_mousewheel, add="+")
        self.bind("<Escape>", lambda _event: self.close())
        self.refresh()

    def refresh(self) -> None:
        for child in self.inner.winfo_children():
            child.destroy()
        items = self.app.history_memos()
        self.footer_label.configure(text=f"{len(items)} 项历史事项")
        self.subtitle.configure(text="已完成或已结束事项仅支持删除，不可修改")
        if not items:
            tk.Label(
                self.inner,
                text="暂无历史事项",
                bg=BG,
                fg=MUTED,
                font=(FONT, 13, "bold"),
            ).pack(pady=(100, 5))
            tk.Label(
                self.inner,
                text="任务完成或事件结束后会自动移动到历史事项。",
                bg=BG,
                fg="#8290A3",
                font=(FONT, 9),
            ).pack()
            return

        for item in items:
            self._render_item(item)
        self.inner.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _render_item(self, memo: dict) -> None:
        card = tk.Frame(
            self.inner,
            bg=SURFACE,
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        card.pack(fill="x", padx=20, pady=(14, 0))

        accent = tk.Frame(card, bg="#9AA8BA", width=4)
        accent.pack(side="left", fill="y")
        body = tk.Frame(card, bg=SURFACE)
        body.pack(side="left", fill="both", expand=True, padx=14, pady=12)

        top = tk.Frame(body, bg=SURFACE)
        top.pack(fill="x")
        tk.Label(
            top,
            text=str(memo.get("title", "未命名事项")),
            bg=SURFACE,
            fg=TEXT,
            font=(FONT, 11, "bold"),
            anchor="w",
            justify="left",
            wraplength=300,
        ).pack(side="left", fill="x", expand=True)
        delete_btn = tk.Button(
            top,
            text="删除",
            command=lambda item=memo: self.app.delete_memo(item),
            bg=SURFACE,
            fg=DANGER,
            activebackground=DANGER_SOFT,
            activeforeground=DANGER,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=5,
            pady=1,
            cursor="hand2",
        )
        delete_btn.pack(side="right", anchor="n", padx=(8, 0))

        note = str(memo.get("note", "")).strip()
        if note:
            tk.Label(
                body,
                text=note,
                bg=SURFACE,
                fg=MUTED,
                font=(FONT, 8),
                anchor="w",
                justify="left",
                wraplength=345,
            ).pack(fill="x", pady=(5, 0))

        is_event = memo_is_event(memo)
        completed = memo_is_completed(memo)
        deadline_text = "未知"
        start_text = "未知"
        completed_text = ""
        try:
            deadline = parse_deadline(memo.get("deadline", ""))
            deadline_text = deadline.strftime("%Y-%m-%d  %H:%M")
        except (TypeError, ValueError):
            pass
        if is_event:
            try:
                start_text = parse_deadline(memo.get("start_at", "")).strftime(
                    "%Y-%m-%d  %H:%M"
                )
            except (TypeError, ValueError):
                pass
        elif completed:
            try:
                completed_text = parse_deadline(
                    memo.get("completed_at", "")
                ).strftime("%Y-%m-%d  %H:%M:%S")
            except (TypeError, ValueError):
                completed_text = "未知"

        meta = tk.Frame(body, bg=SURFACE)
        meta.pack(fill="x", pady=(10, 0))
        if is_event:
            info_text = (
                f"事件  ·  开始  {start_text}\n"
                f"         结束  {deadline_text}"
            )
            status_text = "事件 · 已结束"
            status_bg = "#F0F3F7"
            status_fg = "#6E7E93"
        elif completed:
            info_text = (
                f"任务  ·  截止  {deadline_text}\n"
                f"         完成  {completed_text}"
            )
            status_text = "任务 · 已完成"
            status_bg = SUCCESS_SOFT
            status_fg = SUCCESS
        else:
            info_text = f"任务  ·  截止  {deadline_text}"
            status_text = "任务 · 已过期"
            status_bg = "#F0F3F7"
            status_fg = "#6E7E93"
        tk.Label(
            meta,
            text=info_text,
            bg=SURFACE,
            fg="#53647B",
            font=(NUMBER_FONT, 9),
            justify="left",
            anchor="w",
        ).pack(side="left", fill="x", expand=True)
        tk.Label(
            meta,
            text=status_text,
            bg=status_bg,
            fg=status_fg,
            font=(FONT, 8, "bold"),
            padx=8,
            pady=2,
        ).pack(side="right", anchor="n", padx=(8, 0))

    def _on_mousewheel(self, event) -> None:
        try:
            widget = self.winfo_containing(event.x_root, event.y_root)
        except (KeyError, tk.TclError):
            return
        current = widget
        while current is not None:
            if current == self.canvas:
                delta = -1 * int(event.delta / 120) if event.delta else 0
                if delta:
                    self.canvas.yview_scroll(delta, "units")
                return
            current = getattr(current, "master", None)

    def close(self) -> None:
        if self.app.history_window is self:
            self.app.history_window = None
        self.destroy()


class WeekScheduleWindow(tk.Toplevel):
    """A Monday-to-Sunday timetable for active events and tasks."""

    HOUR_HEIGHT = 52
    AXIS_WIDTH = 66
    TASK_WIDTH = 88
    TASK_HEIGHT = 36
    WEEKDAYS = ("周一", "周二", "周三", "周四", "周五", "周六", "周日")

    def __init__(self, app: "BUAAmemo") -> None:
        super().__init__(app.root)
        self.app = app
        self.week_start = self._monday(datetime.now())
        self._refresh_job = None
        self.title("本周事项表 · BUAA浮光")
        self.configure(bg=BG)
        self.minsize(1040, 560)
        try:
            self.attributes("-topmost", app.topmost)
        except tk.TclError:
            pass

        width = min(1380, max(1040, self.winfo_screenwidth() - 100))
        height = min(860, max(620, self.winfo_screenheight() - 100))
        app.root.update_idletasks()
        x = app.root.winfo_rootx() + (app.root.winfo_width() - width) // 2
        y = app.root.winfo_rooty() + (app.root.winfo_height() - height) // 2
        x = max(20, min(x, self.winfo_screenwidth() - width - 20))
        y = max(20, min(y, self.winfo_screenheight() - height - 60))
        self.geometry(f"{width}x{height}+{x}+{y}")

        header = tk.Frame(self, bg="#183D66", height=98)
        header.pack(fill="x")
        header.pack_propagate(False)
        title_box = tk.Frame(header, bg="#183D66")
        title_box.pack(side="left", padx=24, pady=(14, 0))
        tk.Label(
            title_box,
            text="本周事项表",
            bg="#183D66",
            fg="white",
            font=(FONT, 19, "bold"),
        ).pack(anchor="w")
        self.range_label = tk.Label(
            title_box,
            text="",
            bg="#183D66",
            fg="#C7D9EF",
            font=(NUMBER_FONT, 10),
        )
        self.range_label.pack(anchor="w", pady=(3, 0))

        controls = tk.Frame(header, bg="#183D66")
        controls.pack(side="right", padx=24, pady=(24, 0))
        self._control_button(controls, "‹  上一周", lambda: self.shift_week(-7)).pack(
            side="left",
            padx=(0, 7),
        )
        self._control_button(
            controls,
            "本周",
            self.show_current_week,
            primary=True,
        ).pack(side="left", padx=(0, 7))
        self._control_button(controls, "下一周  ›", lambda: self.shift_week(7)).pack(
            side="left"
        )

        legend = tk.Frame(self, bg="#EEF4FB", height=35)
        legend.pack(fill="x")
        legend.pack_propagate(False)
        self._legend_item(legend, "#D7E8FF", "事件", "矩形高度 = 持续时间")
        self._legend_item(legend, "#E3F6EC", "任务", "固定小块，水平中线 = 截止时间")
        tk.Label(
            legend,
            text="点击色块可查看详情",
            bg="#EEF4FB",
            fg="#6B7C92",
            font=(FONT, 8),
        ).pack(side="right", padx=18)

        board = tk.Frame(self, bg=SURFACE)
        board.pack(fill="both", expand=True)
        self.header_canvas = tk.Canvas(
            board,
            height=58,
            bg=SURFACE,
            bd=0,
            highlightthickness=0,
        )
        self.header_canvas.pack(fill="x")

        body = tk.Frame(board, bg=SURFACE)
        body.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(
            body,
            bg=SURFACE,
            bd=0,
            highlightthickness=0,
        )
        scrollbar = ttk.Scrollbar(
            body,
            orient="vertical",
            command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        footer = tk.Frame(self, bg="#E8EFF8", height=32)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)
        self.summary_label = tk.Label(
            footer,
            text="",
            bg="#E8EFF8",
            fg="#55708F",
            font=(FONT, 9, "bold"),
        )
        self.summary_label.pack(side="left", padx=18)
        close_btn = tk.Button(
            footer,
            text="关闭",
            command=self.close,
            bg="#DCE7F4",
            fg="#405674",
            activebackground="#CEDAEA",
            activeforeground=TEXT,
            font=(FONT, 9),
            relief="flat",
            bd=0,
            padx=14,
            pady=3,
            cursor="hand2",
        )
        close_btn.pack(side="right", padx=14, pady=4)

        self.canvas.bind("<Configure>", lambda _event: self._draw())
        self.bind("<MouseWheel>", self._on_mousewheel, add="+")
        self.bind("<Escape>", lambda _event: self.close())
        self.after(80, self._initial_view)
        self._schedule_refresh()

    def _control_button(
        self,
        parent: tk.Widget,
        text: str,
        command,
        primary: bool = False,
    ) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg="#2C67A8" if primary else "#295786",
            fg="white",
            activebackground="#3576BC" if primary else "#35699D",
            activeforeground="white",
            font=(FONT, 9, "bold" if primary else "normal"),
            relief="flat",
            bd=0,
            padx=12,
            pady=6,
            cursor="hand2",
        )

    def _legend_item(
        self,
        parent: tk.Widget,
        color: str,
        title: str,
        detail: str,
    ) -> None:
        box = tk.Frame(parent, bg="#EEF4FB")
        box.pack(side="left", padx=(18, 8))
        swatch = tk.Canvas(
            box,
            width=18,
            height=16,
            bg="#EEF4FB",
            bd=0,
            highlightthickness=0,
        )
        swatch.pack(side="left", padx=(0, 6))
        swatch.create_rectangle(
            2,
            2,
            16,
            14,
            fill=color,
            outline=BLUE if title == "事件" else SUCCESS,
        )
        tk.Label(
            box,
            text=title,
            bg="#EEF4FB",
            fg=TEXT,
            font=(FONT, 8, "bold"),
        ).pack(side="left")
        tk.Label(
            box,
            text=detail,
            bg="#EEF4FB",
            fg=MUTED,
            font=(FONT, 8),
        ).pack(side="left", padx=(5, 0))

    @staticmethod
    def _monday(value: datetime) -> datetime:
        start = value - timedelta(days=value.weekday())
        return start.replace(hour=0, minute=0, second=0, microsecond=0)

    def _schedule_refresh(self) -> None:
        self._refresh_job = self.after(30_000, self._auto_refresh)

    def _auto_refresh(self) -> None:
        if not self.winfo_exists():
            return
        self.refresh()
        self._schedule_refresh()

    def shift_week(self, days: int) -> None:
        self.week_start += timedelta(days=days)
        self.refresh()
        self.canvas.yview_moveto(7 / 24)

    def show_current_week(self) -> None:
        self.week_start = self._monday(datetime.now())
        self.refresh()
        self.after(30, self._scroll_to_relevant_time)

    def _initial_view(self) -> None:
        self.refresh()
        self.after(60, self._scroll_to_relevant_time)

    def _scroll_to_relevant_time(self) -> None:
        if not self.winfo_exists() or not self.canvas.winfo_height():
            return
        now = datetime.now()
        current_week = self.week_start == self._monday(now)
        hour = now.hour if current_week else 8
        target = max(0, (hour - 2) * self.HOUR_HEIGHT)
        self.canvas.yview_moveto(target / (24 * self.HOUR_HEIGHT))

    def refresh(self) -> None:
        if not self.winfo_exists():
            return
        end = self.week_start + timedelta(days=6)
        self.range_label.configure(
            text=(
                f"{self.week_start.strftime('%Y年%m月%d日')}  —  "
                f"{end.strftime('%m月%d日')}"
            )
        )
        self._draw()

    def _event_segments(self) -> list[list[dict]]:
        now = datetime.now()
        days = [self.week_start + timedelta(days=index) for index in range(7)]
        segments: list[list[dict]] = [[] for _ in range(7)]
        for memo in self.app.memo_records():
            if memo_is_completed(memo) or not memo_is_event(memo):
                continue
            try:
                event_start = parse_deadline(memo.get("start_at", ""))
                event_end = parse_deadline(memo.get("deadline", ""))
            except (TypeError, ValueError):
                continue
            if event_end <= now:
                continue
            for index, day_start in enumerate(days):
                day_end = day_start + timedelta(days=1)
                overlap_start = max(event_start, day_start)
                overlap_end = min(event_end, day_end)
                if overlap_end <= overlap_start:
                    continue
                segments[index].append(
                    {
                        "memo": memo,
                        "start": overlap_start,
                        "end": overlap_end,
                        "continued": event_start < day_start,
                    }
                )
        return segments

    def _task_items(self) -> list[list[dict]]:
        now = datetime.now()
        week_end = self.week_start + timedelta(days=7)
        tasks: list[list[dict]] = [[] for _ in range(7)]
        for memo in self.app.memo_records():
            if memo_is_completed(memo) or memo_is_event(memo):
                continue
            try:
                deadline = parse_deadline(memo.get("deadline", ""))
            except (TypeError, ValueError):
                continue
            if deadline <= now or not (self.week_start <= deadline < week_end):
                continue
            index = (deadline.date() - self.week_start.date()).days
            if 0 <= index < 7:
                tasks[index].append({"memo": memo, "deadline": deadline})
        return tasks

    @staticmethod
    def _assign_lanes(segments: list[dict]) -> None:
        segments.sort(key=lambda item: (item["start"], item["end"]))
        clusters: list[list[dict]] = []
        cluster_end: datetime | None = None
        for segment in segments:
            if not clusters or cluster_end is None or segment["start"] >= cluster_end:
                clusters.append([])
                cluster_end = segment["end"]
            clusters[-1].append(segment)
            cluster_end = max(cluster_end, segment["end"])

        for cluster in clusters:
            lane_ends: list[datetime] = []
            for segment in cluster:
                lane = next(
                    (
                        index
                        for index, lane_end in enumerate(lane_ends)
                        if lane_end <= segment["start"]
                    ),
                    None,
                )
                if lane is None:
                    lane = len(lane_ends)
                    lane_ends.append(segment["end"])
                else:
                    lane_ends[lane] = segment["end"]
                segment["lane"] = lane
            count = max(1, len(lane_ends))
            for segment in cluster:
                segment["lane_count"] = count

    def _draw(self) -> None:
        if not self.winfo_exists():
            return
        width = max(760, self.canvas.winfo_width())
        hour_height = self.HOUR_HEIGHT
        total_height = 24 * hour_height
        axis_width = self.AXIS_WIDTH
        day_width = max(84, (width - axis_width) / 7)
        self.canvas.delete("all")
        self.header_canvas.delete("all")
        self.header_canvas.configure(width=width)
        self.canvas.configure(scrollregion=(0, 0, width, total_height))

        today = datetime.now().date()
        event_segments = self._event_segments()
        task_items = self._task_items()
        event_count = len(
            {
                str(segment["memo"].get("id"))
                for day in event_segments
                for segment in day
            }
        )
        task_count = len(
            {
                str(item["memo"].get("id"))
                for day in task_items
                for item in day
            }
        )
        self.summary_label.configure(
            text=(
                f"本周 {event_count} 个事件 · {task_count} 个任务"
                "　｜　仅显示仍在进行中的事项"
            )
        )

        for index, weekday in enumerate(self.WEEKDAYS):
            x1 = axis_width + index * day_width
            x2 = x1 + day_width
            date = (self.week_start + timedelta(days=index)).date()
            is_today = date == today
            self.header_canvas.create_rectangle(
                x1,
                0,
                x2,
                58,
                fill="#EAF3FF" if is_today else SURFACE,
                outline="",
            )
            self.header_canvas.create_text(
                (x1 + x2) / 2,
                18,
                text=weekday,
                fill=BLUE_DARK if is_today else TEXT,
                font=(FONT, 11, "bold"),
            )
            self.header_canvas.create_text(
                (x1 + x2) / 2,
                38,
                text=date.strftime("%m/%d"),
                fill=BLUE if is_today else MUTED,
                font=(NUMBER_FONT, 10),
            )
            if is_today:
                self.header_canvas.create_rectangle(
                    x1 + 4,
                    52,
                    x2 - 4,
                    55,
                    fill=BLUE,
                    outline="",
                )
        for index in range(8):
            x = axis_width + index * day_width
            self.header_canvas.create_line(
                x,
                0,
                x,
                58,
                fill="#AFC1D6",
                width=2,
            )
        self.header_canvas.create_line(
            0,
            57,
            width,
            57,
            fill=BORDER,
        )
        self.header_canvas.create_text(
            axis_width / 2,
            26,
            text="时间",
            fill=MUTED,
            font=(FONT, 9, "bold"),
        )

        self.canvas.create_rectangle(
            0,
            0,
            axis_width,
            total_height,
            fill="#F7FAFE",
            outline="",
        )
        for index in range(7):
            x1 = axis_width + index * day_width
            x2 = x1 + day_width
            date = (self.week_start + timedelta(days=index)).date()
            fill = "#F9FBFE" if index >= 5 else SURFACE
            if date == today:
                fill = "#F4F9FF"
            self.canvas.create_rectangle(
                x1,
                0,
                x2,
                total_height,
                fill=fill,
                outline="",
            )

        for hour in range(25):
            y = hour * hour_height
            strong = hour in {0, 6, 12, 18, 24}
            self.canvas.create_line(
                axis_width,
                y,
                width,
                y,
                fill="#CDD9E7" if strong else "#E8EEF6",
                width=2 if strong else 1,
            )
            if hour < 24:
                self.canvas.create_line(
                    axis_width,
                    y + hour_height / 2,
                    width,
                    y + hour_height / 2,
                    fill="#F0F4F9",
                    dash=(2, 4),
                )
            if hour % 2 == 0 or hour == 24:
                label = "24:00" if hour == 24 else f"{hour:02d}:00"
                self.canvas.create_text(
                    axis_width - 9,
                    y,
                    text=label,
                    anchor="e",
                    fill="#6D7D91" if strong else "#8A98AA",
                    font=(NUMBER_FONT, 9, "bold" if strong else "normal"),
                )

        for index in range(8):
            x = axis_width + index * day_width
            self.canvas.create_line(
                x,
                0,
                x,
                total_height,
                fill="#AFC1D6",
                width=2,
            )

        self._draw_events(event_segments, axis_width, day_width, hour_height)
        self._draw_tasks(task_items, axis_width, day_width, hour_height)
        self._draw_now_line(axis_width, day_width, hour_height, total_height)

    def _draw_events(
        self,
        event_segments: list[list[dict]],
        axis_width: int,
        day_width: float,
        hour_height: int,
    ) -> None:
        for index, segments in enumerate(event_segments):
            if not segments:
                continue
            self._assign_lanes(segments)
            day_x = axis_width + index * day_width
            event_width = max(32, day_width - 12)
            for segment in segments:
                lane_count = max(1, int(segment.get("lane_count", 1)))
                lane = int(segment.get("lane", 0))
                lane_width = event_width / lane_count
                x1 = day_x + 6 + lane * lane_width
                x2 = x1 + max(14, lane_width - 3)
                start_minutes = (
                    segment["start"] - self.week_start
                ).total_seconds() / 60 - index * 24 * 60
                end_minutes = (
                    segment["end"] - self.week_start
                ).total_seconds() / 60 - index * 24 * 60
                y1 = max(0, start_minutes * hour_height / 60)
                y2 = min(24 * hour_height, end_minutes * hour_height / 60)
                if y2 - y1 < 2:
                    y2 = y1 + 2
                memo = segment["memo"]
                tag = f"memo-{memo.get('id')}"
                item = self.canvas.create_rectangle(
                    x1,
                    y1,
                    x2,
                    y2,
                    fill="#D7E8FF",
                    outline="#6E9ED9",
                    width=1,
                    tags=(tag,),
                )
                text_item = None
                height = y2 - y1
                rect_width = x2 - x1
                if height >= 24 and rect_width >= 34:
                    title = str(memo.get("title", "未命名事项"))
                    if segment.get("continued"):
                        title = "↳ " + title
                    font_size = 10 if rect_width >= 46 else 9
                    if height < 42:
                        max_chars = max(3, int(rect_width / (font_size * 1.05)))
                        if len(title) > max_chars:
                            title = title[:max_chars] + "…"
                    text_item = self.canvas.create_text(
                        x1 + 4,
                        y1 + 2,
                        text=title,
                        anchor="nw",
                        width=max(28, rect_width - 8),
                        fill="#174A8C",
                        font=(FONT, font_size, "bold"),
                        tags=(tag,),
                    )
                self._bind_memo_tag(tag, memo, item, text_item)

    def _draw_tasks(
        self,
        task_items: list[list[dict]],
        axis_width: int,
        day_width: float,
        hour_height: int,
    ) -> None:
        for index, tasks in enumerate(task_items):
            if not tasks:
                continue
            tasks.sort(key=lambda item: item["deadline"])
            day_x = axis_width + index * day_width
            task_x = day_x + (day_width - self.TASK_WIDTH) / 2
            for task in tasks:
                deadline = task["deadline"]
                memo = task["memo"]
                minutes = (
                    deadline.hour * 60 + deadline.minute + deadline.second / 60
                )
                center_y = minutes * hour_height / 60
                self.canvas.create_line(
                    day_x + 10,
                    center_y,
                    day_x + day_width - 10,
                    center_y,
                    fill="#9ACDB4",
                    dash=(3, 4),
                )
                x1 = task_x
                y1 = center_y - self.TASK_HEIGHT / 2
                rect = self.canvas.create_rectangle(
                    x1,
                    y1,
                    x1 + self.TASK_WIDTH,
                    y1 + self.TASK_HEIGHT,
                    fill="#E3F6EC",
                    outline=SUCCESS,
                    width=2,
                    tags=(f"memo-{memo.get('id')}",),
                )
                title = str(memo.get("title", "任务"))
                short = title if len(title) <= 6 else title[:6] + "…"
                text = self.canvas.create_text(
                    x1 + self.TASK_WIDTH / 2,
                    center_y,
                    text=short,
                    fill="#176344",
                    font=(FONT, 10, "bold"),
                    width=self.TASK_WIDTH - 8,
                    tags=(f"memo-{memo.get('id')}",),
                )
                self._bind_memo_tag(
                    f"memo-{memo.get('id')}",
                    memo,
                    rect,
                    text,
                )

    def _draw_now_line(
        self,
        axis_width: int,
        day_width: float,
        hour_height: int,
        total_height: int,
    ) -> None:
        now = datetime.now()
        today = now.date()
        index = (today - self.week_start.date()).days
        if not 0 <= index < 7:
            return
        x1 = axis_width + index * day_width + 3
        x2 = axis_width + (index + 1) * day_width - 3
        y = (now.hour * 60 + now.minute + now.second / 60) * hour_height / 60
        if 0 <= y <= total_height:
            self.canvas.create_line(
                x1,
                y,
                x2,
                y,
                fill="#D64A4A",
                width=2,
            )
            self.canvas.create_oval(
                x1 - 3,
                y - 3,
                x1 + 3,
                y + 3,
                fill="#D64A4A",
                outline="",
            )

    def _bind_memo_tag(
        self,
        tag: str,
        memo: dict,
        item,
        text_item,
    ) -> None:
        self.canvas.tag_bind(
            tag,
            "<Button-1>",
            lambda _event, current=memo: self.show_memo_detail(current),
        )
        for canvas_item in (item, text_item):
            if canvas_item is not None:
                self.canvas.tag_bind(
                    canvas_item,
                    "<Enter>",
                    lambda _event: self.canvas.configure(cursor="hand2"),
                )
                self.canvas.tag_bind(
                    canvas_item,
                    "<Leave>",
                    lambda _event: self.canvas.configure(cursor=""),
                )

    def show_memo_detail(self, memo: dict) -> None:
        title = str(memo.get("title", "未命名事项"))
        note = str(memo.get("note", "")).strip()
        if memo_is_event(memo):
            try:
                start_text = parse_deadline(memo.get("start_at", "")).strftime(
                    "%Y-%m-%d  %H:%M"
                )
                end_text = parse_deadline(memo.get("deadline", "")).strftime(
                    "%Y-%m-%d  %H:%M"
                )
            except (TypeError, ValueError):
                start_text = end_text = "未知"
            message = (
                f"事件型事项\n\n开始时间：{start_text}\n结束时间：{end_text}"
            )
        else:
            try:
                deadline_text = parse_deadline(
                    memo.get("deadline", "")
                ).strftime("%Y-%m-%d  %H:%M")
            except (TypeError, ValueError):
                deadline_text = "未知"
            message = f"任务型事项\n\n截止时间：{deadline_text}"
        if note:
            message += f"\n\n备注：\n{note}"
        messagebox.showinfo(title, message, parent=self)

    def _on_mousewheel(self, event) -> None:
        first, last = self.canvas.yview()
        if first <= 0 and last >= 1:
            return
        delta = -1 * int(event.delta / 120) if event.delta else 0
        if delta:
            self.canvas.yview_scroll(delta, "units")

    def close(self) -> None:
        if self._refresh_job:
            try:
                self.after_cancel(self._refresh_job)
            except tk.TclError:
                pass
            self._refresh_job = None
        if self.app.schedule_window is self:
            self.app.schedule_window = None
        self.destroy()


class BUAAmemo:
    def __init__(self) -> None:
        make_dpi_aware()
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        IMAGE_DIR.mkdir(parents=True, exist_ok=True)

        self.data = self._load_data()
        self.memos: list[dict] = self.data.get("memos", [])
        self.tombstones: list[dict] = self.data.get("tombstones", [])
        self.settings: dict = self.data.get("settings", {})
        self.cloud_vault_key = str(
            self.settings.get("cloud_vault_key", "")
        ).strip()
        if len(self.cloud_vault_key) < 20:
            self.cloud_vault_key = secrets.token_urlsafe(24)
            self.settings["cloud_vault_key"] = self.cloud_vault_key
        try:
            self.cloud_cursor = int(self.settings.get("cloud_cursor", 0))
        except (TypeError, ValueError):
            self.cloud_cursor = 0
        try:
            self.cloud_last_push_rev = int(
                self.settings.get("cloud_last_push_rev", 0)
            )
        except (TypeError, ValueError):
            self.cloud_last_push_rev = 0
        self.cloud_sync_enabled = False
        self.cloud_sync_running = False
        self.cloud_sync_again = False
        self.cloud_sync_ok = False
        self._cloud_sync_job = None
        self.phone_sync_enabled = True
        self.phone_sync_running = False
        self.phone_sync_ok = False
        self.phone_sync_host = str(
            self.settings.get("phone_sync_host", "")
        ).strip()
        self.phone_sync_token = str(
            self.settings.get("phone_sync_token", "")
        ).strip()
        self.phone_sync_device_id = str(
            self.settings.get("phone_sync_device_id", "")
        ).strip()
        self.phone_client_id = str(
            self.settings.get("phone_client_id", "")
        ).strip()
        if len(self.phone_client_id) < 8:
            self.phone_client_id = secrets.token_hex(8)
            self.settings["phone_client_id"] = self.phone_client_id
        try:
            self.phone_sync_port = int(
                self.settings.get("phone_sync_port", 8790)
            )
        except (TypeError, ValueError):
            self.phone_sync_port = 8790
        self._phone_sync_job = None
        self.topmost = bool(self.settings.get("topmost", True))
        self.countdown_labels: dict[str, tk.Label] = {}
        self.status_labels: dict[str, tk.Label] = {}
        self.accent_bars: dict[str, tk.Frame] = {}
        self.memo_cards: dict[str, tk.Frame] = {}
        self.completing_ids: set[str] = set()
        self.image_refs: dict[str, tk.PhotoImage] = {}
        self.dialog: tk.Toplevel | None = None
        self.download_window: DownloadQrWindow | None = None
        self.history_window: HistoryWindow | None = None
        self.schedule_window: WeekScheduleWindow | None = None
        self.group_detail_window: GroupDetailWindow | None = None
        self.changelog_window: ChangelogWindow | None = None
        self.changelog = load_changelog()
        self.update_check_running = False
        self.live_update_available = False
        self.live_update_status = "checking"
        self.latest_remote_version = ""
        self.live_update_check_running = False
        self._live_update_job = None
        self._tick_job = None
        self._header_art_phase = 0.0
        self._header_art_job = None
        self._header_art_item = None
        self._river_art_phase = 0.0
        self._river_art_job = None
        self._desktop_web_bridge: MemoWebBridge | None = None
        self._desktop_web_server: MemoWebServer | None = None
        self._desktop_web_process: subprocess.Popen | None = None
        self._desktop_web_started_at = 0.0
        self._desktop_web_seen_window = False
        self.current_page = "memos"

        self.root = tk.Tk()
        self.root.title("BUAA浮光")
        self.root.configure(bg=BG)
        self.root.minsize(420, 560)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.attributes("-topmost", self.topmost)
        if ICON_FILE.exists():
            try:
                self.root.iconbitmap(default=str(ICON_FILE))
            except tk.TclError:
                pass

        self._set_window_position()
        self._build_ui()
        self._save_data()
        self.render_memos()
        self.tick()
        self.root.after(1200, self._start_phone_sync)
        self.root.after(1600, self._start_live_update_monitor)
        self.root.after(140, self.render_memos)

    def _load_data(self) -> dict:
        if not DATA_FILE.exists():
            return {"version": 1, "settings": {}, "memos": [], "tombstones": []}
        try:
            with DATA_FILE.open("r", encoding="utf-8") as handle:
                loaded = json.load(handle)
            if not isinstance(loaded, dict):
                raise ValueError("数据文件结构不正确")
            if not isinstance(loaded.get("memos", []), list):
                loaded["memos"] = []
            if not isinstance(loaded.get("tombstones", []), list):
                loaded["tombstones"] = []
            if not isinstance(loaded.get("settings", {}), dict):
                loaded["settings"] = {}
            for memo in loaded.get("memos", []):
                if not isinstance(memo, dict):
                    continue
                memo.setdefault("deleted", False)
                memo.setdefault("rev", parse_revision(memo))
                if record_is_group(memo):
                    memo.setdefault("title", "未命名分组")
                    memo.setdefault("note", "")
                    memo.setdefault(
                        "updated_at",
                        memo.get("created_at")
                        or datetime.now().isoformat(timespec="seconds"),
                    )
                    continue
                memo.setdefault(
                    "item_type",
                    "event" if memo.get("start_at") else "task",
                )
                if memo.get("item_type") not in {"task", "event"}:
                    memo["item_type"] = "task"
                if memo["item_type"] == "task":
                    memo["completed_at"] = memo.get("completed_at") or None
                else:
                    memo["completed_at"] = None
                memo["completed"] = bool(
                    memo.get("completed") or memo.get("completed_at")
                )
                memo.setdefault(
                    "updated_at",
                    memo.get("created_at")
                    or datetime.now().isoformat(timespec="seconds"),
                )
            for tombstone in loaded.get("tombstones", []):
                if isinstance(tombstone, dict):
                    tombstone["deleted"] = True
                    tombstone.setdefault("rev", parse_revision(tombstone))
            return loaded
        except Exception:
            backup = DATA_FILE.with_suffix(".json.bak")
            try:
                shutil.copy2(DATA_FILE, backup)
            except OSError:
                pass
            return {"version": 1, "settings": {}, "memos": [], "tombstones": []}

    def _save_data(self) -> None:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.data["version"] = 1
        self.data["settings"] = self.settings
        self.data["memos"] = self.memos
        self.data["tombstones"] = self.tombstones
        temp_file = DATA_FILE.with_suffix(".json.tmp")
        with temp_file.open("w", encoding="utf-8") as handle:
            json.dump(self.data, handle, ensure_ascii=False, indent=2)
        temp_file.replace(DATA_FILE)

    def _set_window_position(self) -> None:
        width, height = 440, 730
        x = int(self.settings.get("x", self.root.winfo_screenwidth() - width - 30))
        y = int(self.settings.get("y", 72))
        max_x = max(0, self.root.winfo_screenwidth() - width)
        max_y = max(0, self.root.winfo_screenheight() - height - 40)
        x = max(0, min(x, max_x))
        y = max(0, min(y, max_y))
        self.root.geometry(f"{width}x{height}+{x}+{y}")

    def _build_ui(self) -> None:
        self._build_header()

        self.water_banner = tk.Canvas(
            self.root,
            height=88,
            bg="#9BC6D5",
            bd=0,
            highlightthickness=0,
        )
        self.water_banner.pack(fill="x")
        self._build_river_banner()

        page_nav = tk.Frame(
            self.root,
            bg="#F7FAFE",
            highlightthickness=1,
            highlightbackground="#DCE6F2",
        )
        page_nav.pack(fill="x")
        self.memos_nav_btn = tk.Button(
            page_nav,
            text="事项主页",
            command=lambda: self.show_page("memos"),
            bg=BLUE,
            fg="white",
            activebackground=BLUE_DARK,
            activeforeground="white",
            font=(FONT, 9, "bold"),
            relief="flat",
            bd=0,
            padx=20,
            pady=7,
            cursor="hand2",
        )
        self.memos_nav_btn.pack(side="left", padx=(20, 6), pady=7)
        self.groups_nav_btn = tk.Button(
            page_nav,
            text="分组",
            command=lambda: self.show_page("groups"),
            bg="#EAF1FA",
            fg=BLUE_DARK,
            activebackground=BLUE_SOFT,
            activeforeground=BLUE_DARK,
            font=(FONT, 9, "bold"),
            relief="flat",
            bd=0,
            padx=24,
            pady=7,
            cursor="hand2",
        )
        self.groups_nav_btn.pack(side="left", pady=7)

        self.page_host = tk.Frame(self.root, bg=BG)
        self.page_host.pack(fill="both", expand=True)
        self.memos_page = tk.Frame(self.page_host, bg=BG)
        self.groups_page = tk.Frame(self.page_host, bg=BG)
        self.memos_page.pack(fill="both", expand=True)
        content = self.memos_page

        summary = tk.Frame(content, bg=BG)
        summary.pack(fill="x", padx=22, pady=(14, 9))
        tk.Label(
            summary,
            text="事项清单",
            bg=BG,
            fg=TEXT,
            font=(FONT, 13, "bold"),
        ).pack(side="left")
        self.count_label = tk.Label(
            summary,
            text="0 项",
            bg="#DCE9FA",
            fg=BLUE_DARK,
            font=(FONT, 8, "bold"),
            padx=9,
            pady=2,
        )
        self.count_label.pack(side="left", padx=(8, 0))
        self.history_btn = tk.Button(
            summary,
            text="历史事项 0",
            command=self.open_history,
            bg="#EEF3F9",
            fg="#55708F",
            activebackground="#E2EBF6",
            activeforeground=BLUE_DARK,
            font=(FONT, 8, "bold"),
            relief="flat",
            bd=0,
            padx=10,
            pady=3,
            cursor="hand2",
        )
        self.history_btn.pack(side="left", padx=(8, 0))
        self.schedule_btn = tk.Button(
            summary,
            text="▦  周视图",
            command=self.open_schedule,
            bg="#DDEEFF",
            fg=BLUE_DARK,
            activebackground="#CDE4FF",
            activeforeground=BLUE_DARK,
            font=(FONT, 8, "bold"),
            relief="flat",
            bd=0,
            padx=9,
            pady=3,
            cursor="hand2",
        )
        self.schedule_btn.pack(side="left", padx=(7, 0))
        self.urgent_label = tk.Label(
            summary,
            text="",
            bg=BG,
            fg=WARNING,
            font=(FONT, 8),
        )
        self.urgent_label.pack(side="right")

        version_bar = tk.Frame(
            content,
            bg="#F7FAFE",
            highlightthickness=1,
            highlightbackground="#D7E3F1",
        )
        version_bar.pack(fill="x", padx=20, pady=(0, 10))

        version_left = tk.Frame(version_bar, bg="#F7FAFE")
        version_left.pack(side="left", padx=12, pady=7)
        tk.Label(
            version_left,
            text="版本与更新",
            bg="#F7FAFE",
            fg="#405674",
            font=(FONT, 9, "bold"),
        ).pack(side="left")
        self.version_badge = tk.Label(
            version_left,
            text=f"v{self.changelog['current_version']}",
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            font=(NUMBER_FONT, 8, "bold"),
            padx=7,
            pady=2,
        )
        self.version_badge.pack(side="left", padx=(8, 0))

        self.update_btn = tk.Button(
            version_bar,
            text="↻  正在检查",
            command=self.check_for_updates,
            bg=BLUE,
            fg="white",
            activebackground=BLUE_DARK,
            activeforeground="white",
            font=(FONT, 9, "bold"),
            relief="flat",
            bd=0,
            padx=13,
            pady=6,
            cursor="hand2",
        )
        self.update_btn.pack(side="right", padx=(0, 10), pady=6)
        self.changelog_btn = tk.Button(
            version_bar,
            text="查看更新日志  ›",
            command=self.open_changelog,
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            activebackground="#DDEBFF",
            activeforeground=BLUE_DARK,
            font=(FONT, 9, "bold"),
            relief="flat",
            bd=0,
            padx=12,
            pady=6,
            cursor="hand2",
        )
        self.changelog_btn.pack(side="right", padx=(0, 7), pady=6)

        list_shell = tk.Frame(content, bg=BG)
        list_shell.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(
            list_shell,
            bg=BG,
            bd=0,
            highlightthickness=0,
        )
        self.scrollbar = ttk.Scrollbar(
            list_shell,
            orient="vertical",
            command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self._main_canvas_bg_photo = None
        if DESKTOP_RIVER_BACKGROUND_FILE.is_file():
            try:
                self._main_canvas_bg_photo = tk.PhotoImage(
                    file=str(DESKTOP_RIVER_BACKGROUND_FILE)
                )
                self.canvas.create_image(
                    0,
                    0,
                    image=self._main_canvas_bg_photo,
                    anchor="nw",
                    tags=("main-river-art",),
                )
            except tk.TclError:
                self._main_canvas_bg_photo = None
        self.memo_canvas_items: dict[str, int] = {}
        self.memo_canvas_widgets: list[tk.Widget] = []
        self.canvas.bind("<Configure>", self._resize_memo_canvas_items)
        self.root.bind_all("<MouseWheel>", self._on_mousewheel, add="+")

        self._build_groups_page()

        footer = tk.Frame(self.root, bg="#E5EDF7", height=30)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)
        self.save_status_label = tk.Label(
            footer,
            text="●  本机自动保存",
            bg="#E5EDF7",
            fg="#55708F",
            font=(FONT, 8),
        )
        self.save_status_label.pack(side="left", padx=22)
        self.sync_now_btn = tk.Button(
            footer,
            text="同步",
            command=self._on_sync_status_click,
            bg="#006BFF",
            fg="white",
            activebackground="#0057D9",
            activeforeground="white",
            font=(FONT, 9, "bold"),
            relief="flat",
            bd=0,
            padx=13,
            pady=3,
            cursor="hand2",
        )
        self.sync_now_btn.pack(side="left", padx=(0, 8))
        self.cloud_status_label = tk.Label(
            footer,
            text="查找手机",
            bg="#E5EDF7",
            fg="#55708F",
            font=(FONT, 8, "bold"),
        )
        self.cloud_status_label.pack(side="left", padx=(0, 12))
        self.clock_label = tk.Label(
            footer,
            text="",
            bg="#E5EDF7",
            fg="#55708F",
            font=(NUMBER_FONT, 8),
        )
        self.clock_label.pack(side="right", padx=22)

    def _build_groups_page(self) -> None:
        summary = tk.Frame(self.groups_page, bg=BG)
        summary.pack(fill="x", padx=22, pady=(14, 8))
        tk.Label(
            summary,
            text="事项分组",
            bg=BG,
            fg=TEXT,
            font=(FONT, 13, "bold"),
        ).pack(side="left")
        self.groups_count_label = tk.Label(
            summary,
            text="0 组",
            bg="#DCE9FA",
            fg=BLUE_DARK,
            font=(FONT, 8, "bold"),
            padx=9,
            pady=2,
        )
        self.groups_count_label.pack(side="left", padx=(8, 0))
        new_group_btn = tk.Button(
            summary,
            text="＋  新建分组",
            command=lambda: self.open_group_dialog(),
            bg=BLUE,
            fg="white",
            activebackground=BLUE_DARK,
            activeforeground="white",
            font=(FONT, 8, "bold"),
            relief="flat",
            bd=0,
            padx=12,
            pady=5,
            cursor="hand2",
        )
        new_group_btn.pack(side="right")
        bind_hover(new_group_btn, BLUE, BLUE_DARK)

        tk.Label(
            self.groups_page,
            text="分组只用于整理事项，不会改变截止时间或完成状态。",
            bg=BG,
            fg=MUTED,
            font=(FONT, 8),
            anchor="w",
        ).pack(fill="x", padx=23, pady=(0, 10))

        group_shell = tk.Frame(self.groups_page, bg=BG)
        group_shell.pack(fill="both", expand=True)
        self.groups_canvas = tk.Canvas(
            group_shell,
            bg=BG,
            bd=0,
            highlightthickness=0,
        )
        group_scrollbar = ttk.Scrollbar(
            group_shell,
            orient="vertical",
            command=self.groups_canvas.yview,
        )
        self.groups_canvas.configure(yscrollcommand=group_scrollbar.set)
        group_scrollbar.pack(side="right", fill="y")
        self.groups_canvas.pack(side="left", fill="both", expand=True)
        self.groups_list_frame = tk.Frame(self.groups_canvas, bg=BG)
        self.groups_list_window = self.groups_canvas.create_window(
            (0, 0),
            window=self.groups_list_frame,
            anchor="nw",
        )
        self.groups_list_frame.bind(
            "<Configure>",
            lambda _event: self.groups_canvas.configure(
                scrollregion=self.groups_canvas.bbox("all")
            ),
        )
        self.groups_canvas.bind(
            "<Configure>",
            lambda event: self.groups_canvas.itemconfigure(
                self.groups_list_window,
                width=event.width,
            ),
        )
        self.render_groups()

    def show_page(self, page: str) -> None:
        selected = "groups" if page == "groups" else "memos"
        self.current_page = selected
        self.memos_page.pack_forget()
        self.groups_page.pack_forget()
        if selected == "groups":
            self.groups_page.pack(fill="both", expand=True)
            self.render_groups()
            self.groups_nav_btn.configure(bg=BLUE, fg="white")
            self.memos_nav_btn.configure(bg="#EAF1FA", fg=BLUE_DARK)
        else:
            self.memos_page.pack(fill="both", expand=True)
            self.memos_nav_btn.configure(bg=BLUE, fg="white")
            self.groups_nav_btn.configure(bg="#EAF1FA", fg=BLUE_DARK)

    def _clear_group_list(self) -> None:
        for child in self.groups_list_frame.winfo_children():
            child.destroy()

    def render_groups(self) -> None:
        if not hasattr(self, "groups_list_frame"):
            return
        self._clear_group_list()
        groups = self.group_records()
        self.groups_count_label.configure(text=f"{len(groups)} 组")
        if not groups:
            empty = tk.Frame(self.groups_list_frame, bg=BG)
            empty.pack(fill="both", expand=True, padx=24, pady=(55, 20))
            tk.Label(
                empty,
                text="▦",
                bg=BG,
                fg=BLUE,
                font=(NUMBER_FONT, 30, "bold"),
            ).pack()
            tk.Label(
                empty,
                text="还没有分组",
                bg=BG,
                fg=TEXT,
                font=(FONT, 14, "bold"),
            ).pack(pady=(10, 4))
            tk.Label(
                empty,
                text="新建分组后，可把已有事项加入其中。",
                bg=BG,
                fg=MUTED,
                font=(FONT, 9),
            ).pack()
            create_btn = tk.Button(
                empty,
                text="＋  新建第一个分组",
                command=lambda: self.open_group_dialog(),
                bg=BLUE_SOFT,
                fg=BLUE_DARK,
                activebackground="#DDEBFF",
                activeforeground=BLUE_DARK,
                font=(FONT, 9, "bold"),
                relief="flat",
                bd=0,
                padx=16,
                pady=7,
                cursor="hand2",
            )
            create_btn.pack(pady=(18, 0))
            bind_hover(create_btn, BLUE_SOFT, "#DDEBFF")
        else:
            for group in groups:
                self._render_group_card(group)
        self.groups_list_frame.update_idletasks()
        self.groups_canvas.configure(
            scrollregion=self.groups_canvas.bbox("all")
        )

    def _render_group_card(self, group: dict) -> None:
        group_id = str(group.get("id", ""))
        items = [
            memo
            for memo in self.memo_records()
            if str(memo.get("group_id", "")) == group_id
        ]
        card = tk.Frame(
            self.groups_list_frame,
            bg=SURFACE,
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        card.pack(fill="x", padx=20, pady=(0, 10))
        body = tk.Frame(card, bg=SURFACE)
        body.pack(fill="both", expand=True, padx=15, pady=12)
        head = tk.Frame(body, bg=SURFACE)
        head.pack(fill="x")
        tk.Label(
            head,
            text=str(group.get("title", "未命名分组")),
            bg=SURFACE,
            fg=TEXT,
            font=(FONT, 12, "bold"),
            anchor="w",
        ).pack(side="left", fill="x", expand=True)
        tk.Label(
            head,
            text=f"{len(items)} 项",
            bg="#E6F2FF",
            fg="#155AB4",
            font=(FONT, 8, "bold"),
            padx=8,
            pady=2,
        ).pack(side="left", padx=(8, 0))
        intro = str(group.get("note", "")).strip()
        if intro:
            tk.Label(
                body,
                text=intro,
                bg=SURFACE,
                fg=MUTED,
                font=(FONT, 8),
                anchor="w",
                justify="left",
                wraplength=340,
            ).pack(fill="x", pady=(7, 0))
        item_box = tk.Frame(body, bg=SURFACE)
        item_box.pack(fill="x", pady=(9, 0))
        if items:
            for memo in items[:6]:
                kind = (
                    "已完成"
                    if memo_is_completed(memo)
                    else "事件"
                    if memo_is_event(memo)
                    else "任务"
                )
                tk.Label(
                    item_box,
                    text=f"•  {memo.get('title', '未命名事项')}  ·  {kind}",
                    bg=SURFACE,
                    fg="#425B79",
                    font=(FONT, 8),
                    anchor="w",
                ).pack(fill="x", pady=1)
            if len(items) > 6:
                tk.Label(
                    item_box,
                    text=f"还有 {len(items) - 6} 项",
                    bg=SURFACE,
                    fg=MUTED,
                    font=(FONT, 8),
                    anchor="w",
                ).pack(fill="x", pady=(2, 0))
        else:
            tk.Label(
                item_box,
                text="暂无事项，可编辑分组后添加。",
                bg=SURFACE,
                fg=MUTED,
                font=(FONT, 8),
                anchor="w",
            ).pack(fill="x")
        actions = tk.Frame(body, bg=SURFACE)
        actions.pack(fill="x", pady=(10, 0))
        view_btn = tk.Button(
            actions,
            text="查看组内事项",
            command=lambda value=group: self.open_group_detail(value),
            bg="#155DCC",
            fg="white",
            activebackground="#0F4EB4",
            activeforeground="white",
            font=(FONT, 8, "bold"),
            relief="flat",
            bd=0,
            padx=11,
            pady=4,
            cursor="hand2",
        )
        view_btn.pack(side="left")
        edit_btn = tk.Button(
            actions,
            text="编辑分组",
            command=lambda value=group: self.open_group_dialog(value),
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            activebackground="#DDEBFF",
            activeforeground=BLUE_DARK,
            font=(FONT, 8, "bold"),
            relief="flat",
            bd=0,
            padx=11,
            pady=4,
            cursor="hand2",
        )
        edit_btn.pack(side="right")
        delete_btn = tk.Button(
            actions,
            text="删除分组",
            command=lambda value=group: self.delete_group(value),
            bg=DANGER_SOFT,
            fg=DANGER,
            activebackground="#F9DCDC",
            activeforeground=DANGER,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=10,
            pady=4,
            cursor="hand2",
        )
        delete_btn.pack(side="right", padx=(0, 7))

    def open_group_dialog(self, group: dict | None = None) -> None:
        if self.dialog and self.dialog.winfo_exists():
            self.dialog.destroy()
            self.dialog = None
        self.dialog = GroupDialog(self, self.save_group, group)

    def open_group_detail(self, group: dict) -> None:
        group_id = str(group.get("id", ""))
        if (
            self.group_detail_window is not None
            and self.group_detail_window.winfo_exists()
        ):
            if self.group_detail_window.group_id == group_id:
                self.group_detail_window.refresh()
                self.group_detail_window.lift()
                self.group_detail_window.focus_force()
                return
            self.group_detail_window.destroy()
        self.group_detail_window = GroupDetailWindow(self, group_id)

    def save_group(
        self,
        group: dict | None,
        title: str,
        intro: str,
        selected_memo_ids: set[str],
    ) -> bool:
        normalized_title = title.strip()
        if not normalized_title:
            messagebox.showerror("无法保存分组", "请填写分组名称。", parent=self.root)
            return False
        if len(normalized_title) > 40:
            messagebox.showerror(
                "无法保存分组",
                "分组名称最多 40 个字。",
                parent=self.root,
            )
            return False
        if len(intro) > 500:
            messagebox.showerror(
                "无法保存分组",
                "分组简介最多 500 个字。",
                parent=self.root,
            )
            return False
        duplicate = next(
            (
                record
                for record in self.group_records()
                if record is not group
                and str(record.get("title", "")).casefold()
                == normalized_title.casefold()
            ),
            None,
        )
        if duplicate is not None:
            messagebox.showerror(
                "无法保存分组",
                "已经有同名分组，请换一个名称。",
                parent=self.root,
            )
            return False

        now = datetime.now().isoformat(timespec="seconds")
        if group is None:
            group = {
                "id": uuid.uuid4().hex,
                "record_kind": "group",
                "title": normalized_title,
                "note": intro.strip(),
                "created_at": now,
                "updated_at": now,
                "rev": now_revision(),
                "deleted": False,
            }
            self.memos.append(group)
        else:
            group["title"] = normalized_title
            group["note"] = intro.strip()
            group["rev"] = max(now_revision(), parse_revision(group) + 1)
            group["updated_at"] = now

        group_id = str(group.get("id", ""))
        for memo in self.memo_records():
            memo_id = str(memo.get("id", ""))
            should_belong = memo_id in selected_memo_ids
            current_group = str(memo.get("group_id", "")).strip()
            if should_belong and current_group != group_id:
                memo["group_id"] = group_id
                memo["rev"] = max(now_revision(), parse_revision(memo) + 1)
                memo["updated_at"] = now
            elif not should_belong and current_group == group_id:
                memo["group_id"] = None
                memo["rev"] = max(now_revision(), parse_revision(memo) + 1)
                memo["updated_at"] = now
        self._save_data()
        self.render_memos()
        self.render_groups()
        self._queue_cloud_sync()
        return True

    def delete_group(self, group: dict) -> None:
        group_id = str(group.get("id", ""))
        if not messagebox.askyesno(
            "删除分组",
            f"确定删除分组「{group.get('title', '未命名分组')}」吗？\n\n"
            "组内事项不会被删除，只会变成未分组。",
            parent=self.root,
        ):
            return
        if (
            self.group_detail_window is not None
            and self.group_detail_window.group_id == group_id
        ):
            self.group_detail_window.close()
        now = datetime.now().isoformat(timespec="seconds")
        revision = max(now_revision(), parse_revision(group) + 1)
        self.tombstones.append(
            {
                "id": group_id,
                "deleted": True,
                "rev": revision,
                "updated_at": now,
            }
        )
        self.memos = [
            record
            for record in self.memos
            if str(record.get("id", "")) != group_id
        ]
        for memo in self.memo_records():
            if str(memo.get("group_id", "")) == group_id:
                memo["group_id"] = None
                memo["rev"] = max(now_revision(), parse_revision(memo) + 1)
                memo["updated_at"] = now
        self._save_data()
        self.render_memos()
        self.render_groups()
        self._queue_cloud_sync()

    def _build_header(self) -> None:
        header = tk.Canvas(
            self.root,
            bg=NAVY,
            height=161,
            bd=0,
            highlightthickness=0,
        )
        header.pack(fill="x")
        self.header = header
        self._header_art_photo = None
        if STARRY_HEADER_FILE.is_file():
            try:
                source = tk.PhotoImage(file=str(STARRY_HEADER_FILE))
                self._header_art_photo = source.subsample(2, 2)
                self._header_art_item = header.create_image(
                    220,
                    80,
                    image=self._header_art_photo,
                    anchor="center",
                    tags=("header-art",),
                )
            except tk.TclError:
                self._header_art_photo = None

        self._header_brand_text = header.create_text(
            24,
            18,
            text="BUAA浮光",
            fill="#FFF8DF",
            font=(FONT, 27, "bold"),
            anchor="nw",
            tags=("header-copy",),
        )
        self._header_brand_subtitle = header.create_text(
            25,
            55,
            text="BEIHANG UNIVERSITY  ·  FUGUANG",
            fill="#D6E5FF",
            font=(NUMBER_FONT, 7),
            anchor="nw",
            tags=("header-copy",),
        )
        self._header_tagline = header.create_text(
            24,
            75,
            text="浮光跃金，静影沉璧",
            fill="#F1E8CB",
            font=(FONT, 10),
            anchor="nw",
            tags=("header-copy",),
        )

        self.download_btn = tk.Button(
            header,
            text="手机APP",
            command=self.open_download_qr,
            bg="#0B4CCB",
            fg="white",
            activebackground="#1760D8",
            activeforeground="white",
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=7,
            pady=5,
            cursor="hand2",
        )
        self._download_btn_item = header.create_window(
            0,
            27,
            window=self.download_btn,
            anchor="ne",
            tags=("header-action",),
        )

        self.pin_btn = tk.Button(
            header,
            text="●  已置顶",
            command=self.toggle_topmost,
            bg="#073C9D",
            fg="white",
            activebackground="#1252B8",
            activeforeground="white",
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=10,
            pady=5,
            cursor="hand2",
        )

        add_btn = tk.Button(
            header,
            text="＋  新建事项",
            command=self.open_add_dialog,
            bg="#FFFDF6",
            fg="#003DA7",
            activebackground="#E8F0FF",
            activeforeground="#00327F",
            font=(FONT, 10, "bold"),
            relief="flat",
            bd=0,
            pady=8,
            cursor="hand2",
        )
        self._add_btn_item = header.create_window(
            220,
            136,
            window=add_btn,
            anchor="center",
            tags=("header-action",),
        )
        bind_hover(add_btn, "#FFFDF6", "#E8F0FF")

        self._pin_btn_item = header.create_window(
            0,
            27,
            window=self.pin_btn,
            anchor="ne",
            tags=("header-action",),
        )

        def layout_header(event=None) -> None:
            width = max(320, event.width if event else header.winfo_width())
            header.coords(self._download_btn_item, width - 24, 27)
            header.coords(self._pin_btn_item, width - 92, 27)
            header.coords(self._add_btn_item, width / 2, 136)
            header.itemconfigure(
                self._add_btn_item,
                width=max(240, width - 48),
                height=36,
            )
            if self._header_art_item is not None:
                header.coords(self._header_art_item, width / 2, 80)

        header.bind("<Configure>", layout_header)
        self.root.after(80, layout_header)
        self.root.after(90, self._animate_header_art)

    def _build_river_banner(self) -> None:
        canvas = self.water_banner
        self._river_art_photos: list[tk.PhotoImage] = []
        self._river_art_items: list[int] = []
        for art_file in (MONET_RIVER_FILE, MONET_RIVER_ALT_FILE):
            if not art_file.is_file():
                continue
            try:
                source = tk.PhotoImage(file=str(art_file))
                photo = source.subsample(2, 2)
                self._river_art_photos.append(photo)
                self._river_art_items.append(
                    canvas.create_image(
                        0,
                        44,
                        image=photo,
                        anchor="center",
                    )
                )
            except tk.TclError:
                continue

        if not self._river_art_items:
            canvas.create_rectangle(
                0,
                0,
                1000,
                88,
                fill="#8EBDD0",
                outline="",
            )
        canvas.create_rectangle(
            0,
            0,
            1000,
            88,
            fill="#B8DCE6",
            outline="",
            stipple="gray25",
            tags=("river-veil",),
        )
        canvas.create_line(
            0,
            1,
            1000,
            1,
            fill="#6F9FB4",
            width=2,
            tags=("river-edge",),
        )
        canvas.bind(
            "<Configure>",
            lambda _event: self._draw_river_banner(0),
        )
        self.root.after(110, self._animate_river_art)

    def _draw_river_banner(self, offset: float) -> None:
        canvas = self.water_banner
        if not canvas.winfo_exists():
            return
        width = max(1, canvas.winfo_width())
        height = max(1, canvas.winfo_height())
        for index, item in enumerate(self._river_art_items):
            direction = -1 if index % 2 == 0 else 1
            canvas.coords(
                item,
                width / 2 + direction * offset,
                height / 2,
            )
        canvas.coords("river-veil", 0, 0, width, height)
        canvas.coords("river-edge", 0, 1, width, 1)

    def _animate_river_art(self) -> None:
        if not self.root.winfo_exists():
            return
        self._river_art_phase += 0.025
        offset = math.sin(self._river_art_phase) * 10
        self._draw_river_banner(offset)
        self._river_art_job = self.root.after(80, self._animate_river_art)

    def _animate_header_art(self) -> None:
        if not self.root.winfo_exists():
            return
        self._header_art_phase += 0.018
        if self._header_art_item is not None:
            width = max(1, self.header.winfo_width())
            self.header.coords(
                self._header_art_item,
                width / 2 + math.sin(self._header_art_phase) * 7,
                80,
            )
        self._header_art_job = self.root.after(
            100,
            self._animate_header_art,
        )

    def _on_mousewheel(self, event) -> None:
        try:
            widget = self.root.winfo_containing(event.x_root, event.y_root)
        except (KeyError, tk.TclError):
            widget = None
        if widget is None:
            return
        canvas = (
            self.groups_canvas
            if self.current_page == "groups"
            else self.canvas
        )
        current = widget
        while current is not None:
            if current == canvas:
                delta = -1 * int(event.delta / 120) if event.delta else 0
                if delta:
                    canvas.yview_scroll(delta, "units")
                return
            current = getattr(current, "master", None)

    def toggle_topmost(self) -> None:
        self.topmost = not self.topmost
        self.root.attributes("-topmost", self.topmost)
        self.settings["topmost"] = self.topmost
        if self.topmost:
            self.pin_btn.configure(text="●  已置顶", bg="#164C8F")
        else:
            self.pin_btn.configure(text="○  置顶", bg="#0E447F")
        self._save_data()

    def open_download_qr(self) -> None:
        if self.download_window is not None and self.download_window.winfo_exists():
            self.download_window.lift()
            self.download_window.focus_force()
            return
        if not ANDROID_APK_FILE.is_file():
            messagebox.showerror(
                "Android 安装包缺失",
                "没有找到手机 Android 安装包，请重新下载完整版插件。",
                parent=self.root,
            )
            return
        self.download_window = DownloadQrWindow(
            self,
            MOBILE_DOWNLOAD_URL,
        )

    def open_changelog(self) -> None:
        self.changelog = load_changelog()
        self.version_badge.configure(
            text=f"v{self.changelog['current_version']}"
        )
        if self.changelog_window is not None and self.changelog_window.winfo_exists():
            self.changelog_window.destroy()
            self.changelog_window = None
        self.changelog_window = ChangelogWindow(self, self.changelog)

    def group_records(self) -> list[dict]:
        return sorted(
            (
                record
                for record in self.memos
                if not record.get("deleted") and record_is_group(record)
            ),
            key=lambda record: str(record.get("title", "")).casefold(),
        )

    def memo_records(self) -> list[dict]:
        return [
            record
            for record in self.memos
            if not record.get("deleted") and not record_is_group(record)
        ]

    def group_title(self, group_id: str) -> str:
        target = next(
            (
                group
                for group in self.group_records()
                if str(group.get("id", "")) == str(group_id)
            ),
            None,
        )
        return str(target.get("title", "")) if target else ""

    def history_memos(self) -> list[dict]:
        now = datetime.now()
        items = [
            memo
            for memo in self.memo_records()
            if memo_history_due(memo, now)
        ]

        def history_key(memo: dict) -> str:
            return str(
                memo.get("completed_at")
                or memo.get("deadline")
                or memo.get("updated_at")
                or ""
            )

        items.sort(key=history_key, reverse=True)
        return items

    def open_history(self) -> None:
        if self.history_window is not None and self.history_window.winfo_exists():
            self.history_window.refresh()
            self.history_window.lift()
            self.history_window.focus_force()
            return
        self.history_window = HistoryWindow(self)

    def open_schedule(self) -> None:
        existing_window = self.schedule_window
        if existing_window is not None:
            try:
                window_exists = existing_window.winfo_exists()
            except tk.TclError:
                window_exists = False
            if window_exists:
                existing_window.refresh()
                existing_window.lift()
                existing_window.focus_force()
                return
            self.schedule_window = None
        if (
            self.group_detail_window is not None
            and self.group_detail_window.winfo_exists()
        ):
            self.group_detail_window.refresh()
        elif self.group_detail_window is not None:
            self.group_detail_window = None
        if hasattr(self, "groups_list_frame"):
            self.render_groups()
        self.schedule_window = WeekScheduleWindow(self)
        self.schedule_window.lift()
        self.schedule_window.focus_force()

    def _reset_update_button(self) -> None:
        self.update_check_running = False
        self._apply_update_button_state()

    def _apply_update_button_state(self) -> None:
        if self.live_update_available:
            self.update_btn.configure(
                text=f"●  可以更新 v{self.latest_remote_version}",
                bg="#F07A1A",
                fg="white",
                activebackground="#D96108",
                activeforeground="white",
                state="normal",
            )
            return
        if self.live_update_status == "latest":
            self.update_btn.configure(
                text=f"✓  已是最新版 v{self.latest_remote_version}",
                bg="#23845A",
                fg="white",
                activebackground="#1B6C49",
                activeforeground="white",
                state="normal",
            )
            return
        if self.live_update_status == "failed":
            self.update_btn.configure(
                text="!  检查失败，点此重试",
                bg=DANGER,
                fg="white",
                activebackground="#A93232",
                activeforeground="white",
                state="normal",
            )
            return
        self.update_btn.configure(
            text=(
                "↻  正在检查"
                if self.live_update_status == "checking"
                else "↻  检查更新"
            ),
            bg=BLUE,
            fg="white",
            activebackground=BLUE_DARK,
            activeforeground="white",
            state="normal",
        )

    def _start_live_update_monitor(self) -> None:
        self._poll_live_update()

    def _poll_live_update(self) -> None:
        if self._live_update_job:
            try:
                self.root.after_cancel(self._live_update_job)
            except tk.TclError:
                pass
        self._live_update_job = self.root.after(
            60000,
            self._poll_live_update,
        )
        if self.live_update_check_running:
            return
        if not self.live_update_available:
            self.live_update_status = "checking"
            self._apply_update_button_state()
        self.live_update_check_running = True
        threading.Thread(
            target=self._live_update_worker,
            daemon=True,
        ).start()

    def _live_update_worker(self) -> None:
        remote_version = ""
        try:
            remote_version = fetch_platform_version()
        except Exception:
            pass
        manifest = None
        if not remote_version:
            for url in LIVE_UPDATE_MANIFEST_URLS:
                try:
                    manifest = fetch_manifest(url)
                    break
                except Exception:
                    continue
        if remote_version:
            current_version = str(
                self.changelog.get("current_version", "0.0.0")
            )
            available = is_newer(remote_version, current_version)
            self.root.after(
                0,
                lambda: self._apply_live_update_result(
                    remote_version,
                    available,
                ),
            )
        else:
            self.root.after(
                0,
                lambda: self._apply_live_update_failure(),
            )
        self.root.after(
            0,
            lambda: setattr(self, "live_update_check_running", False),
        )

    def _apply_live_update_result(
        self,
        remote_version: str,
        available: bool,
    ) -> None:
        self.latest_remote_version = remote_version
        self.live_update_available = available
        self.live_update_status = "available" if available else "latest"
        self._apply_update_button_state()

    def _apply_live_update_failure(self) -> None:
        self.live_update_available = False
        self.live_update_status = "failed"
        self._apply_update_button_state()

    def check_for_updates(self) -> None:
        if self.update_check_running:
            return
        update_hint = (
            f"已检测到新版本 v{self.latest_remote_version}。\n\n"
            if self.live_update_available
            else (
                f"当前已是最新版 v{self.latest_remote_version}。\n\n"
                if self.live_update_status == "latest"
                else (
                    "暂时无法读取国内平台的版本信息，"
                    "可以打开平台手动检查。\n\n"
                    if self.live_update_status == "failed"
                    else "正在读取国内平台版本信息，也可以直接打开平台。\n\n"
                )
            )
        )
        proceed = messagebox.askokcancel(
            "检查更新",
            f"{update_hint}更新由“学业支持中心开源平台”提供。\n\n"
            "未登录时会先跳转到平台登录页；登录后在项目页面的"
            "“版本下载”中获取最新版。\n\n"
            "插件不会保存或上传你的平台账号和密码。\n\n"
            "是否打开更新页面？",
            parent=self.root,
        )
        if not proceed:
            return
        try:
            opened = webbrowser.open(UPDATE_PORTAL_URL, new=2)
        except Exception as exc:
            messagebox.showerror(
                "无法打开更新页面",
                f"请手动访问：\n{UPDATE_PORTAL_URL}\n\n{exc}",
                parent=self.root,
            )
            return
        if not opened:
            messagebox.showerror(
                "无法打开更新页面",
                f"请使用浏览器访问：\n{UPDATE_PORTAL_URL}",
                parent=self.root,
            )

    def _check_update_worker(self, url: str) -> None:
        try:
            manifest = fetch_manifest(url)
        except Exception as exc:
            self.root.after(0, lambda: self._update_check_failed(str(exc)))
            return
        self.root.after(0, lambda: self._handle_update_manifest(manifest))

    def _update_check_failed(self, message: str) -> None:
        self._reset_update_button()
        messagebox.showerror(
            "检查更新失败",
            f"暂时无法获取更新信息。\n\n{message}",
            parent=self.root,
        )

    def _handle_update_manifest(self, manifest: dict) -> None:
        current_version = self.changelog.get("current_version", "0.0.0")
        remote_version = str(manifest.get("version", "0.0.0"))
        if not is_newer(remote_version, current_version):
            self._reset_update_button()
            messagebox.showinfo(
                "检查更新",
                f"当前已经是最新版本 v{current_version}。",
                parent=self.root,
            )
            return

        desktop = manifest.get("desktop")
        if not isinstance(desktop, dict):
            self._reset_update_button()
            messagebox.showerror(
                "更新信息不完整",
                "更新清单中没有桌面版升级包。",
                parent=self.root,
            )
            return
        patch_url = str(desktop.get("patch_url", "")).strip()
        sha256 = str(desktop.get("sha256", "")).strip()
        if not patch_url or not sha256:
            self._reset_update_button()
            messagebox.showerror(
                "更新信息不完整",
                "更新清单缺少下载地址或校验值。",
                parent=self.root,
            )
            return

        notes = manifest.get("notes", [])
        note_text = "\n".join(
            f"• {item}" for item in notes if str(item).strip()
        )
        message = (
            f"发现新版本 v{remote_version}\n"
            f"当前版本 v{current_version}\n\n"
            f"{note_text}\n\n"
            "是否现在下载并安装？备忘录数据不会被覆盖。"
        ).strip()
        if not messagebox.askyesno("发现新版本", message, parent=self.root):
            self._reset_update_button()
            return

        self.update_btn.configure(text="下载中…")
        threading.Thread(
            target=self._download_update_worker,
            args=(manifest,),
            daemon=True,
        ).start()

    def _download_update_worker(self, manifest: dict) -> None:
        try:
            desktop = manifest["desktop"]
            version = str(manifest["version"])
            target = (
                DATA_DIR
                / "updates"
                / f"BUAA-Memo-{version}-patch.zip"
            )
            download_verified(
                str(desktop["patch_url"]),
                target,
                str(desktop["sha256"]),
            )
        except Exception as exc:
            self.root.after(
                0,
                lambda: self._update_download_failed(str(exc)),
            )
            return
        self.root.after(
            0,
            lambda: self._install_downloaded_update(target, version),
        )

    def _update_download_failed(self, message: str) -> None:
        self._reset_update_button()
        messagebox.showerror(
            "更新下载失败",
            f"没有安装更新。\n\n{message}",
            parent=self.root,
        )

    def _install_downloaded_update(self, patch_path: Path, version: str) -> None:
        try:
            count = apply_patch(patch_path, APP_DIR)
        except Exception as exc:
            self._reset_update_button()
            messagebox.showerror(
                "更新安装失败",
                f"已保留原有版本。\n\n{exc}",
                parent=self.root,
            )
            return

        messagebox.showinfo(
            "更新完成",
            f"已安装 v{version}（共更新 {count} 个文件）。\n"
            "插件即将自动重启。",
            parent=self.root,
        )
        try:
            schedule_restart(APP_DIR)
        except Exception as exc:
            messagebox.showwarning(
                "请手动重启",
                f"文件已更新，但自动重启失败：{exc}\n请关闭后重新打开插件。",
                parent=self.root,
            )
        self.close()

    def _on_sync_status_click(self) -> None:
        if self.phone_sync_running:
            return
        if self.phone_sync_token:
            self._queue_phone_sync(0)
            return
        code = simpledialog.askstring(
            "手机配对",
            "打开手机 App，点击“同步”查看同步教程。\n"
            "请输入教程中显示的 6 位配对码：",
            parent=self.root,
        )
        if not code:
            return
        address = simpledialog.askstring(
            "手机地址（可选）",
            "能自动发现手机时可留空。\n"
            "校园网无法自动发现时，请输入手机教程中显示的 IP:端口。",
            initialvalue=self.phone_sync_host,
            parent=self.root,
        )
        host = ""
        port = 8790
        if address:
            raw = address.strip().replace("http://", "").replace("https://", "")
            raw = raw.split("/", 1)[0]
            host = raw
            if ":" in raw:
                host, port_text = raw.rsplit(":", 1)
                try:
                    port = int(port_text)
                except ValueError:
                    port = 8790
            if host:
                self.phone_sync_host = host
                self.phone_sync_port = port
                self.settings["phone_sync_host"] = host
                self.settings["phone_sync_port"] = port
                self._save_data()
        self._start_phone_pairing(code.strip(), host, port)

    def _queue_phone_sync(self, delay_ms: int = 800) -> None:
        if not self.phone_sync_enabled:
            return
        if self.phone_sync_running:
            return
        if self._phone_sync_job:
            try:
                self.root.after_cancel(self._phone_sync_job)
            except tk.TclError:
                pass
        self._phone_sync_job = self.root.after(
            delay_ms,
            self._start_phone_sync,
        )

    def _start_phone_sync(self) -> None:
        if (
            not self.phone_sync_enabled
            or self.phone_sync_running
            or not self.root.winfo_exists()
        ):
            return
        self.phone_sync_running = True
        records = self._sync_records_for_phone()
        threading.Thread(
            target=self._phone_sync_worker,
            args=(records,),
            daemon=True,
        ).start()

    def _start_phone_pairing(
        self,
        code: str,
        host: str,
        port: int,
    ) -> None:
        if (
            not self.phone_sync_enabled
            or self.phone_sync_running
            or not self.root.winfo_exists()
        ):
            return
        self.phone_sync_running = True
        records = self._sync_records_for_phone()
        threading.Thread(
            target=self._phone_pair_worker,
            args=(code, host, port, records),
            daemon=True,
        ).start()

    def _sync_records_for_phone(self) -> list[dict]:
        records = []
        for record in self.all_sync_records():
            copy = dict(record)
            image_rel = str(copy.get("image") or "").strip()
            if image_rel and not copy.get("image_data"):
                image_path = APP_DIR / image_rel
                try:
                    if image_path.is_file():
                        size = image_path.stat().st_size
                        if size <= 2 * 1024 * 1024:
                            encoded = base64.b64encode(
                                image_path.read_bytes()
                            ).decode("ascii")
                            mime = (
                                "image/gif"
                                if image_path.suffix.lower() == ".gif"
                                else "image/png"
                            )
                            copy["image_data"] = f"data:{mime};base64,{encoded}"
                except OSError:
                    pass
            records.append(copy)
        return records

    def _discover_phone_servers(self) -> list[tuple[str, int, str]]:
        discovery = None
        found: dict[tuple[str, int], str] = {}
        try:
            discovery = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            discovery.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            discovery.settimeout(2.0)
            for target in ("255.255.255.255", "<broadcast>"):
                try:
                    discovery.sendto(
                        PHONE_SYNC_MAGIC,
                        (target, PHONE_SYNC_DISCOVERY_PORT),
                    )
                except OSError:
                    continue
            while True:
                try:
                    payload, address = discovery.recvfrom(256)
                except socket.timeout:
                    break
                text = payload.decode("utf-8", errors="ignore").strip()
                device_id = ""
                port = 8790
                if text.startswith("BUAA_MEMO_SERVER_V2:"):
                    parts = text.split(":")
                    if len(parts) >= 3:
                        try:
                            port = int(parts[1])
                        except ValueError:
                            port = 8790
                        device_id = parts[2]
                elif text.startswith("BUAA_MEMO_SERVER_V1:"):
                    try:
                        port = int(text.split(":", 1)[1])
                    except ValueError:
                        port = 8790
                else:
                    continue
                found[(address[0], port)] = device_id
            return [
                (host, port, device_id)
                for (host, port), device_id in found.items()
            ]
        except OSError:
            return []
        finally:
            if discovery is not None:
                try:
                    discovery.close()
                except Exception:
                    pass

    @staticmethod
    def _post_phone_pair(
        host: str,
        port: int,
        code: str,
        client_id: str,
    ) -> dict:
        body = json.dumps(
            {"code": code, "client_id": client_id},
            ensure_ascii=False,
        ).encode("utf-8")
        connection = http.client.HTTPConnection(host, port, timeout=5)
        try:
            connection.request(
                "POST",
                "/pair",
                body=body,
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
            )
            response = connection.getresponse()
            raw = response.read()
            if response.status != 200:
                try:
                    detail = json.loads(raw.decode("utf-8")).get("error", "")
                except Exception:
                    detail = ""
                raise RuntimeError(
                    detail or f"配对失败 HTTP {response.status}"
                )
            parsed = json.loads(raw.decode("utf-8"))
            if not parsed.get("token"):
                raise RuntimeError("手机没有返回同步令牌")
            return parsed
        finally:
            connection.close()

    @staticmethod
    def _post_phone_sync(
        host: str,
        port: int,
        records: list[dict],
        token: str,
    ) -> dict:
        body = json.dumps(
            {"records": records},
            ensure_ascii=False,
        ).encode("utf-8")
        connection = http.client.HTTPConnection(host, port, timeout=5)
        try:
            connection.request(
                "POST",
                "/sync",
                body=body,
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "X-Buaa-Token": token,
                },
            )
            response = connection.getresponse()
            raw = response.read()
            if response.status == 401:
                raise PhoneAuthError("配对令牌已失效")
            if response.status != 200:
                try:
                    detail = json.loads(raw.decode("utf-8")).get("error", "")
                except Exception:
                    detail = ""
                raise RuntimeError(
                    detail or f"同步失败 HTTP {response.status}"
                )
            parsed = json.loads(raw.decode("utf-8"))
            if not isinstance(parsed, dict):
                raise RuntimeError("手机返回格式不正确")
            if not isinstance(parsed.get("records"), list):
                raise RuntimeError("手机返回记录格式不正确")
            return parsed
        finally:
            connection.close()

    def _phone_sync_worker(self, records: list[dict]) -> None:
        result = None
        error = ""
        host = self.phone_sync_host
        port = self.phone_sync_port
        token = self.phone_sync_token
        device_id = self.phone_sync_device_id
        auth_failed = False
        try:
            if not token:
                discovered = self._discover_phone_servers()
                if discovered:
                    host, port, device_id = discovered[0]
                    error = "needs_pairing"
                else:
                    raise RuntimeError("没有发现手机同步服务")
            else:
                candidates = (
                    [(host, port, device_id)]
                    if host
                    else self._discover_phone_servers()
                )
                if device_id:
                    matching = [
                        item
                        for item in candidates
                        if not item[2] or item[2] == device_id
                    ]
                    if matching:
                        candidates = matching
                last_error = None
                for candidate_host, candidate_port, candidate_device in candidates:
                    try:
                        result = self._post_phone_sync(
                            candidate_host,
                            candidate_port,
                            records,
                            token,
                        )
                        host = candidate_host
                        port = candidate_port
                        device_id = candidate_device or device_id
                        error = ""
                        break
                    except PhoneAuthError:
                        auth_failed = True
                        raise
                    except Exception as exc:
                        last_error = exc
                if result is None and last_error is not None:
                    raise last_error
                if result is None:
                    raise RuntimeError("没有发现手机同步服务")
        except PhoneAuthError as exc:
            auth_failed = True
            error = str(exc)
        except Exception as exc:
            error = str(exc)
        try:
            self.root.after(
                0,
                lambda: self._finish_phone_sync(
                    result,
                    error,
                    host,
                    port,
                    token,
                    device_id,
                    auth_failed,
                ),
            )
        except tk.TclError:
            pass

    def _phone_pair_worker(
        self,
        code: str,
        host: str,
        port: int,
        records: list[dict],
    ) -> None:
        result = None
        error = ""
        token = ""
        device_id = ""
        try:
            candidates = (
                [(host, port, "")]
                if host
                else self._discover_phone_servers()
            )
            if not candidates:
                raise RuntimeError("没有发现手机同步服务")
            last_error = None
            for candidate_host, candidate_port, candidate_device in candidates:
                try:
                    paired = self._post_phone_pair(
                        candidate_host,
                        candidate_port,
                        code,
                        self.phone_client_id,
                    )
                    token = str(paired.get("token", ""))
                    device_id = str(paired.get("device_id", ""))
                    result = self._post_phone_sync(
                        candidate_host,
                        candidate_port,
                        records,
                        token,
                    )
                    host = candidate_host
                    port = candidate_port
                    break
                except Exception as exc:
                    last_error = exc
            if result is None:
                if last_error is not None:
                    raise last_error
                raise RuntimeError("配对失败")
        except Exception as exc:
            error = str(exc)
        try:
            self.root.after(
                0,
                lambda: self._finish_phone_sync(
                    result,
                    error,
                    host,
                    port,
                    token,
                    device_id,
                    False,
                ),
            )
        except tk.TclError:
            pass

    def _finish_phone_sync(
        self,
        result,
        error: str,
        host: str,
        port: int,
        token: str,
        device_id: str,
        auth_failed: bool,
    ) -> None:
        self.phone_sync_running = False
        if not self.phone_sync_enabled or not self.root.winfo_exists():
            return

        if not error and isinstance(result, dict):
            records = result.get("records", [])
            try:
                self.phone_sync_host = host
                self.phone_sync_port = port
                self.phone_sync_token = token
                self.phone_sync_device_id = device_id
                self.settings["phone_sync_host"] = host
                self.settings["phone_sync_port"] = port
                self.settings["phone_sync_token"] = token
                self.settings["phone_sync_device_id"] = device_id
                self.sync_records_from_phone(records)
                self.phone_sync_ok = True
                self.cloud_status_label.configure(
                    text="已连接",
                    fg=SUCCESS,
                )
                delay = 5_000
            except Exception as exc:
                error = str(exc)

        if error:
            self.phone_sync_ok = False
            if auth_failed:
                self.phone_sync_token = ""
                self.phone_sync_device_id = ""
                self.settings["phone_sync_token"] = ""
                self.settings["phone_sync_device_id"] = ""
                status_text = "配对失效"
            elif error == "needs_pairing":
                status_text = "需要配对"
            elif "配对" in error or "尝试次数" in error or "令牌" in error:
                status_text = "配对失败"
            else:
                status_text = "等待手机"
            self.cloud_status_label.configure(text=status_text, fg=WARNING)
            if auth_failed:
                messagebox.showwarning(
                    "同步配对失效",
                    "手机的同步令牌已失效。\n请点击“同步”，重新输入手机显示的配对码。",
                    parent=self.root,
                )
            elif status_text == "配对失败":
                messagebox.showwarning(
                    "同步配对失败",
                    error,
                    parent=self.root,
                )
            delay = 15_000

        self._phone_sync_job = self.root.after(
            delay,
            self._start_phone_sync,
        )

    def _start_cloud_sync(self) -> None:
        if (
            not self.cloud_sync_enabled
            or self.cloud_sync_running
            or not self.root.winfo_exists()
        ):
            if self.cloud_sync_running:
                self.cloud_sync_again = True
            return
        self.cloud_sync_running = True
        records = [dict(record) for record in self.all_sync_records()]
        outgoing = [
            record
            for record in records
            if parse_revision(record) > self.cloud_last_push_rev
        ]
        outgoing_max = max(
            (parse_revision(record) for record in outgoing),
            default=0,
        )
        threading.Thread(
            target=self._cloud_sync_worker,
            args=(outgoing, outgoing_max),
            daemon=True,
        ).start()

    def _cloud_sync_worker(
        self,
        records: list[dict],
        outgoing_max: int,
    ) -> None:
        result = None
        error = ""
        body = json.dumps(
            {
                "p_vault_key": self.cloud_vault_key,
                "p_since": self.cloud_cursor,
                "p_records": records,
            },
            ensure_ascii=False,
        ).encode("utf-8")
        request = urllib.request.Request(
            CLOUD_SYNC_URL,
            data=body,
            method="POST",
            headers={
                "Authorization": f"Bearer {CLOUD_PUBLISHABLE_KEY}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
        )
        opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({}),
            urllib.request.HTTPSHandler(
                context=ssl.create_default_context()
            ),
        )
        try:
            with opener.open(request, timeout=18) as response:
                result = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            try:
                detail = exc.read().decode("utf-8", errors="replace")
            except Exception:
                detail = ""
            error = f"HTTP {exc.code}: {detail[:240]}"
        except Exception as exc:
            error = str(exc)
        try:
            self.root.after(
                0,
                lambda: self._finish_cloud_sync(
                    result,
                    error,
                    outgoing_max,
                ),
            )
        except tk.TclError:
            pass

    def _finish_cloud_sync(
        self,
        result,
        error: str,
        outgoing_max: int,
    ) -> None:
        self.cloud_sync_running = False
        if not self.cloud_sync_enabled or not self.root.winfo_exists():
            return

        cloud_records = (
            result.get("records", [])
            if isinstance(result, dict)
            else []
        )
        if not error and isinstance(cloud_records, list):
            if outgoing_max > self.cloud_last_push_rev:
                self.cloud_last_push_rev = outgoing_max
                self.settings["cloud_last_push_rev"] = outgoing_max
            try:
                cursor = int(result.get("cursor", self.cloud_cursor))
            except (TypeError, ValueError):
                cursor = self.cloud_cursor
            if cursor >= self.cloud_cursor:
                self.cloud_cursor = cursor
                self.settings["cloud_cursor"] = cursor
            try:
                self.sync_records_from_phone(cloud_records)
            except Exception as exc:
                error = f"同步数据合并失败：{exc}"

        if error:
            self.cloud_sync_ok = False
            self.cloud_status_label.configure(
                text="云同步待连接",
                fg=WARNING,
            )
            delay = 600_000
        else:
            self.cloud_sync_ok = True
            self.cloud_status_label.configure(
                text="云同步已连接 · 点击刷新",
                fg=SUCCESS,
            )
            delay = 300_000

        if self.cloud_sync_again:
            self.cloud_sync_again = False
            delay = 500
        self._cloud_sync_job = self.root.after(
            delay,
            self._start_cloud_sync,
        )

    def _queue_cloud_sync(self, delay: int = 800) -> None:
        if not self.cloud_sync_enabled:
            self._queue_phone_sync(delay)
            return
        if self.cloud_sync_running:
            self.cloud_sync_again = True
            return
        if self._cloud_sync_job:
            try:
                self.root.after_cancel(self._cloud_sync_job)
            except tk.TclError:
                pass
        self._cloud_sync_job = self.root.after(
            delay,
            self._start_cloud_sync,
        )

    def handle_web_command(self, action: str, payload: dict):
        if action == "version":
            return {"version": self.changelog.get("current_version", "0.0.0")}
        if action == "list":
            return {"memos": [dict(memo) for memo in self.memos]}
        if action == "all_records":
            return {"records": self.all_sync_records()}
        if action == "sync":
            return {"records": self.sync_records_from_phone(payload.get("records", []))}
        if action == "save":
            return {"memo": self.save_memo_from_web(payload)}
        if action == "complete":
            return {"memo": self.complete_memo_from_web(payload)}
        if action == "delete":
            return self.delete_memo_from_web(payload)
        raise MemoApiError("未知的手机端操作。")

    def all_sync_records(self) -> list[dict]:
        by_id: dict[str, dict] = {}
        for record in [*self.memos, *self.tombstones]:
            if not isinstance(record, dict):
                continue
            memo_id = str(record.get("id", "")).strip()
            if not memo_id:
                continue
            normalized = dict(record)
            normalized["id"] = memo_id
            normalized["rev"] = parse_revision(normalized)
            normalized["deleted"] = bool(normalized.get("deleted", False))
            if not normalized["deleted"] and not record_is_group(normalized):
                normalized.setdefault(
                    "item_type",
                    "event" if normalized.get("start_at") else "task",
                )
                normalized["completed"] = bool(
                    normalized.get("completed")
                    or normalized.get("completed_at")
                )
            previous = by_id.get(memo_id)
            if previous is None or normalized["rev"] >= parse_revision(previous):
                by_id[memo_id] = normalized
        return list(by_id.values())

    def sync_records_from_phone(self, incoming: list) -> list[dict]:
        if not isinstance(incoming, list):
            raise MemoApiError("同步记录格式不正确。")
        if len(incoming) > 5000:
            raise MemoApiError("同步记录数量过多。")

        by_id = {
            record["id"]: dict(record)
            for record in self.all_sync_records()
        }
        removed_images: list[str] = []

        for raw in incoming:
            if not isinstance(raw, dict):
                continue
            memo_id = str(raw.get("id", "")).strip()
            if not memo_id:
                continue
            try:
                revision = int(raw.get("rev", 0))
            except (TypeError, ValueError):
                continue
            if revision <= 0:
                continue

            previous = by_id.get(memo_id)
            if previous is not None and revision <= parse_revision(previous):
                continue

            if bool(raw.get("deleted", False)):
                if previous and previous.get("image"):
                    removed_images.append(str(previous["image"]))
                by_id[memo_id] = {
                    "id": memo_id,
                    "deleted": True,
                    "rev": revision,
                    "updated_at": str(raw.get("updated_at") or "")
                    or datetime.now().isoformat(timespec="seconds"),
                }
                continue

            if record_is_group(raw):
                group_title = str(raw.get("title", "")).strip()
                group_intro = str(raw.get("note", "")).strip()
                if not group_title or len(group_title) > 40 or len(group_intro) > 500:
                    raise MemoApiError("手机端有分组内容不完整。")
                by_id[memo_id] = {
                    "id": memo_id,
                    "record_kind": "group",
                    "title": group_title,
                    "note": group_intro,
                    "created_at": str(raw.get("created_at") or "")
                    or (
                        previous.get("created_at")
                        if previous
                        else datetime.now().isoformat(timespec="seconds")
                    ),
                    "deleted": False,
                    "rev": revision,
                    "updated_at": str(raw.get("updated_at") or "")
                    or datetime.now().isoformat(timespec="seconds"),
                }
                continue

            title = str(raw.get("title", "")).strip()
            note = str(raw.get("note", "")).strip()
            deadline_text = str(raw.get("deadline", "")).strip()
            item_type = str(
                raw.get("item_type")
                or (
                    previous.get("item_type")
                    if previous is not None
                    else "task"
                )
            ).strip()
            if item_type not in {"task", "event"}:
                item_type = "task"
            if not title or len(title) > 80 or len(note) > 1000:
                raise MemoApiError("手机端有事项内容不完整。")
            try:
                deadline = datetime.fromisoformat(deadline_text)
                if deadline.tzinfo is not None:
                    deadline = deadline.astimezone().replace(tzinfo=None)
            except ValueError as exc:
                raise MemoApiError("手机端有事项时间格式不正确。") from exc

            start_at = None
            if item_type == "event":
                start_text = str(raw.get("start_at") or "").strip()
                if not start_text and previous is not None:
                    start_text = str(previous.get("start_at") or "").strip()
                try:
                    start_at = datetime.fromisoformat(start_text)
                    if start_at.tzinfo is not None:
                        start_at = start_at.astimezone().replace(tzinfo=None)
                except ValueError as exc:
                    raise MemoApiError("手机端事件缺少开始时间。") from exc
                if start_at >= deadline:
                    raise MemoApiError("手机端事件的开始时间需要早于结束时间。")

            completed_at_value = raw.get("completed_at")
            if "completed_at" not in raw and previous is not None:
                completed_at_value = previous.get("completed_at")
            completed_at = (
                str(completed_at_value).strip()
                if completed_at_value
                else None
            )
            completed = bool(raw.get("completed")) or bool(completed_at)
            if item_type == "event":
                completed = False
                completed_at = None
            elif completed and not completed_at:
                completed_at = datetime.now().isoformat(timespec="seconds")

            image_value = previous.get("image") if previous is not None else None
            if "image_data" in raw:
                image_data_value = raw.get("image_data")
            else:
                image_data_value = (
                    previous.get("image_data") if previous is not None else None
                )
            reminder_enabled_value = raw.get("reminder_enabled")
            if "reminder_enabled" not in raw and previous is not None:
                reminder_enabled_value = previous.get("reminder_enabled")
            reminder_minutes_value = raw.get("reminder_minutes")
            if "reminder_minutes" not in raw and previous is not None:
                reminder_minutes_value = previous.get("reminder_minutes")
            reminder_modes_value = raw.get("reminder_modes")
            if "reminder_modes" not in raw and previous is not None:
                reminder_modes_value = previous.get("reminder_modes")
            reminder_volume_value = raw.get("reminder_volume")
            if "reminder_volume" not in raw and previous is not None:
                reminder_volume_value = previous.get("reminder_volume")
            reminder_at_value = raw.get("reminder_at")
            if "reminder_at" not in raw and previous is not None:
                reminder_at_value = previous.get("reminder_at")
            try:
                reminder_minutes = max(1, int(reminder_minutes_value or 15))
            except (TypeError, ValueError):
                reminder_minutes = 15
            try:
                reminder_volume = max(
                    10,
                    min(100, int(reminder_volume_value or 100)),
                )
            except (TypeError, ValueError):
                reminder_volume = 100
            by_id[memo_id] = {
                "id": memo_id,
                "title": title,
                "note": note,
                "item_type": item_type,
                "start_at": (
                    start_at.isoformat(timespec="seconds")
                    if start_at is not None
                    else None
                ),
                "deadline": deadline.isoformat(timespec="seconds"),
                "completed": completed,
                "completed_at": completed_at,
                "created_at": str(raw.get("created_at") or "")
                or (
                    previous.get("created_at")
                    if previous
                    else datetime.now().isoformat(timespec="seconds")
                ),
                "image": image_value,
                "image_data": image_data_value,
                "reminder_enabled": bool(reminder_enabled_value),
                "reminder_minutes": reminder_minutes,
                "reminder_modes": (
                    [
                        str(mode)
                        for mode in reminder_modes_value
                        if str(mode) in {
                            "notification",
                            "sound",
                            "vibration",
                        }
                    ]
                    if isinstance(reminder_modes_value, list)
                    else []
                ),
                "reminder_volume": reminder_volume,
                "reminder_at": (
                    str(reminder_at_value)
                    if reminder_at_value
                    else None
                ),
                "group_id": (
                    str(raw.get("group_id") or "").strip()
                    or (
                        str(previous.get("group_id") or "").strip()
                        if previous is not None
                        else ""
                    )
                    or None
                ),
                "deleted": False,
                "rev": revision,
                "updated_at": str(raw.get("updated_at") or "")
                or datetime.now().isoformat(timespec="seconds"),
            }

        active: list[dict] = []
        tombstones: list[dict] = []
        for record in by_id.values():
            if record.get("deleted"):
                tombstones.append(
                    {
                        "id": record["id"],
                        "deleted": True,
                        "rev": parse_revision(record),
                        "updated_at": record.get("updated_at", ""),
                    }
                )
            else:
                active.append(record)

        self.memos = active
        self.tombstones = tombstones
        self._save_data()
        self.render_memos()

        for image_rel in set(removed_images):
            image_path = APP_DIR / image_rel
            try:
                if image_path.is_file() and IMAGE_DIR in image_path.resolve().parents:
                    image_path.unlink()
            except OSError:
                pass
        return self.all_sync_records()

    def save_memo_from_web(self, payload: dict) -> dict:
        title = str(payload.get("title", "")).strip()
        note = str(payload.get("note", "")).strip()
        deadline_text = str(payload.get("deadline", "")).strip()
        memo_id = str(payload.get("id") or "").strip()
        item_type = str(payload.get("item_type") or "task").strip()
        if item_type not in {"task", "event"}:
            raise MemoApiError("事项类型不正确。")

        if not title:
            raise MemoApiError("请填写事项名称。")
        if len(title) > 80:
            raise MemoApiError("事项名称最多 80 个字。")
        if len(note) > 1000:
            raise MemoApiError("备注最多 1000 个字。")
        try:
            deadline = datetime.fromisoformat(deadline_text)
            if deadline.tzinfo is not None:
                deadline = deadline.astimezone().replace(tzinfo=None)
        except ValueError as exc:
            raise MemoApiError("结束时间格式不正确。") from exc
        if deadline <= datetime.now():
            raise MemoApiError("结束时间需要晚于现在。")

        start_at = None
        if item_type == "event":
            start_text = str(payload.get("start_at", "")).strip()
            try:
                start_at = datetime.fromisoformat(start_text)
                if start_at.tzinfo is not None:
                    start_at = start_at.astimezone().replace(tzinfo=None)
            except ValueError as exc:
                raise MemoApiError("事件开始时间格式不正确。") from exc
            if start_at >= deadline:
                raise MemoApiError("事件开始时间需要早于结束时间。")
        group_id = str(payload.get("group_id") or "").strip() or None
        if group_id and not any(
            str(group.get("id", "")) == group_id
            for group in self.group_records()
        ):
            group_id = None

        if memo_id:
            target = next(
                (memo for memo in self.memos if str(memo.get("id")) == memo_id),
                None,
            )
            if target is None:
                raise MemoApiError("要编辑的事项已经不存在。")
            target["title"] = title
            target["note"] = note
            target["item_type"] = item_type
            target["group_id"] = group_id
            target["start_at"] = (
                start_at.isoformat(timespec="seconds")
                if start_at is not None
                else None
            )
            target["deadline"] = deadline.isoformat(timespec="seconds")
            if item_type == "event":
                target["completed"] = False
                target["completed_at"] = None
            target["deleted"] = False
            target["rev"] = max(now_revision(), parse_revision(target) + 1)
            target["updated_at"] = datetime.now().isoformat(timespec="seconds")
        else:
            target = {
                "id": uuid.uuid4().hex,
                "title": title,
                "note": note,
                "item_type": item_type,
                "group_id": group_id,
                "start_at": (
                    start_at.isoformat(timespec="seconds")
                    if start_at is not None
                    else None
                ),
                "deadline": deadline.isoformat(timespec="seconds"),
                "completed": False,
                "completed_at": None,
                "created_at": datetime.now().isoformat(timespec="seconds"),
                "image": None,
                "deleted": False,
                "rev": now_revision(),
                "updated_at": datetime.now().isoformat(timespec="seconds"),
            }
            self.memos.append(target)

        self._save_data()
        self.render_memos()
        if not memo_id:
            self.canvas.yview_moveto(0)
        self._queue_cloud_sync()
        return dict(target)

    def complete_memo_from_web(self, payload: dict) -> dict:
        memo_id = str(payload.get("id") or "").strip()
        target = next(
            (memo for memo in self.memos if str(memo.get("id")) == memo_id),
            None,
        )
        if target is None:
            raise MemoApiError("要完成的任务已经不存在。")
        if memo_is_event(target):
            raise MemoApiError("事件型事项没有“完成”按钮。")
        if memo_is_completed(target):
            return dict(target)
        try:
            parse_deadline(target.get("deadline", ""))
        except (TypeError, ValueError) as exc:
            raise MemoApiError("任务截止时间格式不正确。") from exc

        now = datetime.now()
        target["completed"] = True
        target["completed_at"] = now.isoformat(timespec="seconds")
        target["rev"] = max(now_revision(), parse_revision(target) + 1)
        target["updated_at"] = now.isoformat(timespec="seconds")
        self._save_data()
        self.render_memos()
        self._queue_cloud_sync()
        return dict(target)

    def delete_memo_from_web(self, payload: dict) -> dict:
        memo_id = str(payload.get("id") or "").strip()
        target = next(
            (memo for memo in self.memos if str(memo.get("id")) == memo_id),
            None,
        )
        if target is None:
            raise MemoApiError("要删除的事项已经不存在。")

        image_rel = target.get("image")
        revision = max(now_revision(), parse_revision(target) + 1)
        self.tombstones.append(
            {
                "id": memo_id,
                "deleted": True,
                "rev": revision,
                "updated_at": datetime.now().isoformat(timespec="seconds"),
            }
        )
        self.memos = [
            memo for memo in self.memos if str(memo.get("id")) != memo_id
        ]
        self._save_data()
        if image_rel:
            image_path = APP_DIR / str(image_rel)
            try:
                if image_path.is_file() and IMAGE_DIR in image_path.resolve().parents:
                    image_path.unlink()
            except OSError:
                pass
        self.render_memos()
        self._queue_cloud_sync()
        return {"id": memo_id}

    def open_add_dialog(self) -> None:
        if self.dialog and self.dialog.winfo_exists():
            self.dialog.lift()
            self.dialog.focus_force()
            return
        self.dialog = AddMemoDialog(self, self.add_memo)

    def add_memo(self, item: dict) -> None:
        item["deleted"] = False
        item["rev"] = now_revision()
        item["updated_at"] = datetime.now().isoformat(timespec="seconds")
        self.memos.append(item)
        self._save_data()
        self.render_memos()
        self.canvas.yview_moveto(0)
        self._queue_cloud_sync()

    def _play_water_sink_sound(self) -> None:
        if os.name != "nt" or not WATER_SINK_FILE.is_file():
            return
        try:
            import winsound

            winsound.PlaySound(
                str(WATER_SINK_FILE),
                winsound.SND_FILENAME
                | winsound.SND_ASYNC
                | winsound.SND_NODEFAULT,
            )
        except Exception:
            pass

    def _start_water_ripples(self, content_y: float) -> None:
        if not self.canvas.winfo_exists():
            return
        try:
            canvas_y = content_y - self.canvas.canvasy(0)
        except tk.TclError:
            return
        center_x = max(40, self.canvas.winfo_width() / 2)

        for index in range(3):
            self.root.after(
                index * 90,
                self._spawn_water_ripple,
                center_x,
                canvas_y,
            )

    def _spawn_water_ripple(
        self,
        center_x: float,
        canvas_y: float,
    ) -> None:
        if not self.canvas.winfo_exists():
            return
        item = self.canvas.create_oval(
            center_x - 12,
            canvas_y - 4,
            center_x + 12,
            canvas_y + 4,
            outline="#79AAC3",
            width=2,
        )
        self.canvas.tag_raise(item)
        steps = 18

        def grow(step: int) -> None:
            if not self.canvas.winfo_exists():
                return
            progress = step / steps
            radius = 12 + 72 * progress
            vertical = 4 + 15 * progress
            self.canvas.coords(
                item,
                center_x - radius,
                canvas_y - vertical,
                center_x + radius,
                canvas_y + vertical,
            )
            self.canvas.itemconfigure(
                item,
                outline=blend_hex_color(
                    "#79AAC3",
                    BG,
                    progress * 0.78,
                ),
                width=max(1, round(2 - progress)),
            )
            if step < steps:
                self.root.after(34, grow, step + 1)
            else:
                self.canvas.delete(item)

        grow(0)

    def _animate_card_sinking(
        self,
        card: tk.Frame | None,
        on_complete,
        memo_id: str = "",
    ) -> None:
        if card is None or not card.winfo_exists():
            on_complete()
            return
        self._play_water_sink_sound()
        canvas_item = self.memo_canvas_items.get(memo_id)
        try:
            if canvas_item is not None:
                bbox = self.canvas.bbox(canvas_item)
                if bbox is None:
                    raise tk.TclError("card item is not visible")
                start_x, start_y, end_x, end_y = bbox
                start_width = max(160, end_x - start_x)
                start_height = max(80, end_y - start_y)
            else:
                start_x = card.winfo_x()
                start_y = card.winfo_y()
                start_width = max(160, card.winfo_width())
                start_height = max(80, card.winfo_height())
        except tk.TclError:
            on_complete()
            return

        original_colors: dict[tk.Widget, str] = {}
        widgets = [card]
        pending = list(card.winfo_children())
        while pending:
            widget = pending.pop()
            widgets.append(widget)
            pending.extend(widget.winfo_children())
        for widget in widgets:
            try:
                original_colors[widget] = str(widget.cget("bg"))
            except tk.TclError:
                continue

        self._start_water_ripples(start_y + start_height * 0.72)
        steps = 24

        def animate(step: int) -> None:
            if not card.winfo_exists():
                on_complete()
                return
            progress = min(1.0, step / steps)
            eased = progress * progress * (3 - 2 * progress)
            width = max(140, round(start_width * (1 - 0.14 * eased)))
            x = round(start_x + (start_width - width) / 2)
            y = round(start_y + 92 * eased)
            height = max(64, round(start_height * (1 - 0.08 * eased)))
            if canvas_item is not None:
                self.canvas.coords(canvas_item, x, y)
                self.canvas.itemconfigure(
                    canvas_item,
                    width=width,
                    height=height,
                )
            else:
                card.place(
                    x=x,
                    y=y,
                    width=width,
                    height=height,
                )
            for widget, original in original_colors.items():
                try:
                    widget.configure(
                        bg=blend_hex_color(
                            original,
                            "#B8DBE9",
                            min(0.92, eased * 1.1),
                        )
                    )
                except tk.TclError:
                    continue
            if step < steps:
                self.root.after(32, animate, step + 1)
            else:
                if canvas_item is not None:
                    try:
                        self.canvas.delete(canvas_item)
                    except tk.TclError:
                        pass
                try:
                    card.destroy()
                except tk.TclError:
                    pass
                on_complete()

        self.root.after(32, animate, 1)

    def complete_memo(self, item: dict) -> None:
        memo_id = str(item.get("id", ""))
        if (
            memo_is_event(item)
            or memo_is_completed(item)
            or memo_id in self.completing_ids
        ):
            return
        try:
            parse_deadline(item.get("deadline", ""))
        except (TypeError, ValueError):
            messagebox.showerror(
                "无法完成任务",
                "这个任务的截止时间格式不正确。",
                parent=self.root,
            )
            return

        completed_at = datetime.now()
        confirmed = messagebox.askyesno(
            "完成任务",
            f"将「{item.get('title', '未命名事项')}」标记为已完成？\n\n"
            f"完成时间：{completed_at.strftime('%Y-%m-%d  %H:%M:%S')}",
            parent=self.root,
        )
        if not confirmed:
            return

        self.completing_ids.add(memo_id)
        card = self.memo_cards.get(memo_id)
        item["completed"] = True
        item["completed_at"] = completed_at.isoformat(timespec="seconds")
        item["rev"] = max(now_revision(), parse_revision(item) + 1)
        item["updated_at"] = completed_at.isoformat(timespec="seconds")
        # Persist first: the sinking effect must never gate completion or sync.
        self._save_data()
        self._queue_cloud_sync()

        def finish_completion() -> None:
            self.completing_ids.discard(memo_id)
            self.render_memos()

        self._animate_card_sinking(card, finish_completion, memo_id)

    def delete_memo(self, item: dict) -> None:
        confirmed = messagebox.askyesno(
            "删除事项",
            f"确定删除「{item.get('title', '未命名事项')}」吗？",
            parent=self.root,
        )
        if not confirmed:
            return
        image_rel = item.get("image")
        revision = max(now_revision(), parse_revision(item) + 1)
        self.tombstones.append(
            {
                "id": str(item.get("id", "")),
                "deleted": True,
                "rev": revision,
                "updated_at": datetime.now().isoformat(timespec="seconds"),
            }
        )
        self.memos = [memo for memo in self.memos if memo.get("id") != item.get("id")]
        self._save_data()
        if image_rel:
            image_path = APP_DIR / image_rel
            try:
                if image_path.is_file() and IMAGE_DIR in image_path.resolve().parents:
                    image_path.unlink()
            except OSError:
                pass
        self.render_memos()
        self._queue_cloud_sync()

    def _clear_list(self) -> None:
        for widget in self.memo_canvas_widgets:
            try:
                widget.destroy()
            except tk.TclError:
                pass
        self.memo_canvas_widgets.clear()
        for item in self.memo_canvas_items.values():
            try:
                self.canvas.delete(item)
            except tk.TclError:
                pass
        self.memo_canvas_items.clear()
        self.countdown_labels.clear()
        self.status_labels.clear()
        self.accent_bars.clear()
        self.memo_cards.clear()
        self.image_refs.clear()

    def render_memos(self) -> None:
        self._clear_list()
        urgent = 0
        now = datetime.now()
        active_items: list[dict] = []
        history_count = 0

        for memo in self.memo_records():
            if memo_history_due(memo, now):
                history_count += 1
                continue
            try:
                deadline = parse_deadline(memo.get("deadline", ""))
                active_items.append(memo)
                seconds = (deadline - now).total_seconds()
                if 0 < seconds <= 86_400:
                    urgent += 1
            except (TypeError, ValueError):
                pass

        active_items.sort(key=lambda memo: memo.get("deadline", ""))
        self.memos.sort(
            key=lambda memo: (
                1 if record_is_group(memo) else 0,
                str(memo.get("deadline", "")),
            )
        )

        self.count_label.configure(text=f"{len(active_items)} 项")
        self.history_btn.configure(text=f"历史事项 {history_count}")
        if urgent:
            self.urgent_label.configure(text=f"{urgent} 项 24 小时内截止")
        elif active_items:
            self.urgent_label.configure(text=f"{len(active_items)} 项进行中")
        else:
            self.urgent_label.configure(text="")

        content_y = 8
        if not active_items:
            content_y += self._render_empty_state(history_count, content_y)
        else:
            for index, memo in enumerate(active_items):
                content_y += self._render_card(memo, index, content_y)

        canvas_width = max(320, self.canvas.winfo_width())
        self.canvas.configure(
            scrollregion=(
                0,
                0,
                canvas_width,
                max(content_y + 20, self.canvas.winfo_height()),
            )
        )
        if self.history_window is not None and self.history_window.winfo_exists():
            self.history_window.refresh()
        if self.schedule_window is not None and self.schedule_window.winfo_exists():
            self.schedule_window.refresh()

    def _render_empty_state(
        self,
        history_count: int = 0,
        y: int = 38,
    ) -> int:
        empty = tk.Frame(
            self.canvas,
            bg="#F7FAF8",
            highlightthickness=1,
            highlightbackground="#CCE0E5",
        )
        window = self.canvas.create_window(
            24,
            y,
            window=empty,
            anchor="nw",
            width=max(300, self.canvas.winfo_width() - 48),
            tags=("memo-card", "empty-card"),
        )
        self.memo_canvas_items[f"empty:{id(empty)}"] = window
        self.memo_canvas_widgets.append(empty)

        icon = tk.Canvas(
            empty,
            width=78,
            height=78,
            bg=BG,
            highlightthickness=0,
        )
        icon.pack()
        icon.create_oval(4, 4, 74, 74, fill="white", outline="#D6E4F5", width=2)
        icon.create_oval(24, 24, 54, 54, outline=BLUE, width=3)
        icon.create_line(39, 39, 39, 30, fill=BLUE, width=3, capstyle="round")
        icon.create_line(39, 39, 47, 43, fill=BLUE, width=3, capstyle="round")
        icon.create_oval(35, 35, 43, 43, fill=BLUE, outline=BLUE)

        tk.Label(
            empty,
            text="没有进行中的事项" if history_count else "还没有事项",
            bg=BG,
            fg=TEXT,
            font=(FONT, 15, "bold"),
        ).pack(pady=(14, 4))
        tk.Label(
            empty,
            text=(
                f"已有 {history_count} 项事项到期，\n已移入历史事项。"
                if history_count
                else "把下一个目标记下来，\n时间会替你安静地倒计时。"
            ),
            bg=BG,
            fg=MUTED,
            font=(FONT, 9),
            justify="center",
        ).pack()
        add_empty_btn = tk.Button(
            empty,
            text="＋  添加第一条事项",
            command=self.open_add_dialog,
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            activebackground="#DCEAFF",
            activeforeground=BLUE_DARK,
            font=(FONT, 9, "bold"),
            relief="flat",
            bd=0,
            padx=16,
            pady=7,
            cursor="hand2",
        )
        add_empty_btn.pack(pady=(18, 0))
        bind_hover(add_empty_btn, BLUE_SOFT, "#DCEAFF")
        if history_count:
            history_empty_btn = tk.Button(
                empty,
                text=f"查看历史事项 {history_count}",
                command=self.open_history,
                bg="#EEF3F9",
                fg="#55708F",
                activebackground="#E2EBF6",
                activeforeground=BLUE_DARK,
                font=(FONT, 9),
                relief="flat",
                bd=0,
                padx=14,
                pady=6,
                cursor="hand2",
            )
            history_empty_btn.pack(pady=(9, 0))
            bind_hover(history_empty_btn, "#EEF3F9", "#E2EBF6")
        empty.update_idletasks()
        return max(250, empty.winfo_reqheight() + 20)

    def _render_card(
        self,
        memo: dict,
        index: int,
        y: int,
    ) -> int:
        memo_id = str(memo.get("id", index))
        card = tk.Frame(
            self.canvas,
            bg=SURFACE,
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        window = self.canvas.create_window(
            20,
            y,
            window=card,
            anchor="nw",
            width=max(300, self.canvas.winfo_width() - 40),
            tags=("memo-card", "memo-item"),
        )
        self.memo_canvas_items[memo_id] = window
        self.memo_canvas_widgets.append(card)
        self.memo_cards[memo_id] = card

        accent = tk.Frame(card, bg=BLUE, width=4)
        accent.pack(side="left", fill="y")
        self.accent_bars[memo_id] = accent

        body = tk.Frame(card, bg=SURFACE)
        body.pack(side="left", fill="both", expand=True, padx=14, pady=12)

        title_row = tk.Frame(body, bg=SURFACE)
        title_row.pack(fill="x")
        title = str(memo.get("title", "未命名事项"))
        tk.Label(
            title_row,
            text=title,
            bg=SURFACE,
            fg=TEXT,
            font=(FONT, 11, "bold"),
            anchor="w",
            justify="left",
            wraplength=300,
        ).pack(side="left", fill="x", expand=True)
        if not memo_is_event(memo):
            complete_btn = tk.Button(
                title_row,
                text="✓  完成",
                command=lambda item=memo: self.complete_memo(item),
                bg=SUCCESS_SOFT,
                fg=SUCCESS,
                activebackground="#DDF2E8",
                activeforeground=SUCCESS,
                font=(FONT, 8, "bold"),
                relief="flat",
                bd=0,
                padx=8,
                pady=2,
                cursor="hand2",
            )
            complete_btn.pack(side="right", anchor="n", padx=(6, 2))
        delete_btn = tk.Button(
            title_row,
            text="删除",
            command=lambda item=memo: self.delete_memo(item),
            bg=SURFACE,
            fg="#B45B5B",
            activebackground=DANGER_SOFT,
            activeforeground=DANGER,
            font=(FONT, 8),
            relief="flat",
            bd=0,
            padx=4,
            pady=1,
            cursor="hand2",
        )
        delete_btn.pack(side="right", anchor="n", padx=(8, 0))

        note = str(memo.get("note", "")).strip()
        if note:
            tk.Label(
                body,
                text=note,
                bg=SURFACE,
                fg=MUTED,
                font=(FONT, 8),
                anchor="w",
                justify="left",
                wraplength=342,
            ).pack(fill="x", pady=(5, 0))

        group_name = self.group_title(str(memo.get("group_id", "")))
        if group_name:
            tk.Label(
                body,
                text=f"分组 · {group_name}",
                bg="#E9F1FF",
                fg="#235EAE",
                font=(FONT, 8, "bold"),
                padx=8,
                pady=2,
            ).pack(anchor="w", pady=(7, 0))

        image_data = memo.get("image_data")
        image_rel = memo.get("image")
        image_path = APP_DIR / str(image_rel) if image_rel else None
        photo = None
        try:
            if image_data:
                photo = load_preview_from_data(str(image_data), 350, 150)
            elif image_path and image_path.is_file():
                photo = load_preview(image_path, 350, 150)
        except (OSError, ValueError, tk.TclError):
            photo = None
        if photo is not None:
            self.image_refs[memo_id] = photo
            image_box = tk.Frame(body, bg="#F0F4FA")
            image_box.pack(fill="x", pady=(9, 0))
            image_label = tk.Label(
                image_box,
                image=photo,
                bg="#F0F4FA",
                bd=0,
                cursor="hand2",
            )
            image_label.pack(pady=3)
            image_label.bind(
                "<Button-1>",
                lambda _event, path=image_path, data=image_data, label=title: (
                    self.show_image(path, label, data)
                ),
            )

        time_box = tk.Frame(body, bg=SURFACE)
        time_box.pack(fill="x", pady=(10, 0))
        time_box.grid_columnconfigure(1, weight=1)

        tk.Label(
            time_box,
            text="剩余时间",
            bg=SURFACE,
            fg=MUTED,
            font=(FONT, 8),
            width=6,
            anchor="w",
        ).grid(row=0, column=0, sticky="w")
        countdown_label = tk.Label(
            time_box,
            text="—",
            bg=SURFACE,
            fg=BLUE,
            font=(NUMBER_FONT, 15, "bold"),
            anchor="w",
        )
        countdown_label.grid(row=0, column=1, sticky="w")
        status_label = tk.Label(
            time_box,
            text="进行中",
            bg=BLUE_SOFT,
            fg=BLUE_DARK,
            font=(FONT, 7, "bold"),
            padx=7,
            pady=2,
        )
        status_label.grid(row=0, column=2, sticky="e")
        self.countdown_labels[memo_id] = countdown_label
        self.status_labels[memo_id] = status_label

        next_row = 1
        if memo_is_event(memo):
            start_text = "—"
            try:
                start_text = parse_deadline(memo.get("start_at", "")).strftime(
                    "%Y-%m-%d  %H:%M"
                )
            except (TypeError, ValueError):
                pass
            tk.Label(
                time_box,
                text="开始时间",
                bg=SURFACE,
                fg=MUTED,
                font=(FONT, 8),
                width=6,
                anchor="w",
            ).grid(row=next_row, column=0, sticky="w", pady=(5, 0))
            tk.Label(
                time_box,
                text=start_text,
                bg=SURFACE,
                fg="#45556B",
                font=(NUMBER_FONT, 9),
                anchor="w",
            ).grid(
                row=next_row,
                column=1,
                columnspan=2,
                sticky="w",
                pady=(5, 0),
            )
            next_row += 1

        deadline_text = "—"
        try:
            deadline_text = parse_deadline(memo.get("deadline", "")).strftime(
                "%Y-%m-%d  %H:%M"
            )
        except (TypeError, ValueError):
            pass
        tk.Label(
            time_box,
            text="结束时间" if memo_is_event(memo) else "终止时间",
            bg=SURFACE,
            fg=MUTED,
            font=(FONT, 8),
            width=6,
            anchor="w",
        ).grid(row=next_row, column=0, sticky="w", pady=(5, 0))
        tk.Label(
            time_box,
            text=deadline_text,
            bg=SURFACE,
            fg="#45556B",
            font=(NUMBER_FONT, 9),
            anchor="w",
        ).grid(
            row=next_row,
            column=1,
            columnspan=2,
            sticky="w",
            pady=(5, 0),
        )

        self._update_card_time(memo_id, memo)
        card.update_idletasks()
        return max(112, card.winfo_reqheight() + 10)

    def _resize_memo_canvas_items(self, event) -> None:
        memo_width = max(300, event.width - 40)
        empty_width = max(300, event.width - 48)
        for item in self.canvas.find_withtag("memo-item"):
            self.canvas.itemconfigure(item, width=memo_width)
        for item in self.canvas.find_withtag("empty-card"):
            self.canvas.itemconfigure(item, width=empty_width)

    def _update_card_time(self, memo_id: str, memo: dict) -> None:
        text, color, status, soft_color = memo_time_state(memo)
        countdown = self.countdown_labels.get(memo_id)
        badge = self.status_labels.get(memo_id)
        accent = self.accent_bars.get(memo_id)
        if countdown and countdown.winfo_exists():
            countdown.configure(text=text, fg=color)
        if badge and badge.winfo_exists():
            badge.configure(
                text=f"{'事件' if memo_is_event(memo) else '任务'} · {status}",
                bg=soft_color,
                fg=color,
            )
        if accent and accent.winfo_exists():
            accent.configure(bg=color)

    def tick(self) -> None:
        now = datetime.now()
        needs_rerender = False
        for memo in self.memo_records():
            memo_id = str(memo.get("id", ""))
            if memo_id in self.countdown_labels:
                try:
                    if (
                        parse_deadline(memo.get("deadline", ""))
                        + HISTORY_GRACE
                        <= now
                    ):
                        needs_rerender = True
                        continue
                except (TypeError, ValueError):
                    pass
                self._update_card_time(memo_id, memo)
        if needs_rerender:
            self.render_memos()
        self.clock_label.configure(text=now.strftime("%H:%M:%S"))
        self._tick_job = self.root.after(1000, self.tick)

    def show_image(
        self,
        path: Path | None,
        title: str,
        image_data: str | None = None,
    ) -> None:
        viewer = tk.Toplevel(self.root)
        viewer.title(f"{title} · 图片")
        viewer.configure(bg="#101A29")
        viewer.transient(self.root)
        try:
            max_width = max(400, self.root.winfo_screenwidth() - 240)
            max_height = max(300, self.root.winfo_screenheight() - 220)
            if image_data:
                photo = load_preview_from_data(
                    image_data,
                    max_width,
                    max_height,
                )
            elif path is not None:
                photo = load_preview(path, max_width, max_height)
            else:
                raise ValueError("图片不存在")
        except (OSError, ValueError, tk.TclError) as exc:
            messagebox.showerror("无法打开图片", str(exc), parent=viewer)
            viewer.destroy()
            return

        label = tk.Label(viewer, image=photo, bg="#101A29", bd=0)
        label.image = photo
        label.pack(padx=12, pady=12)
        viewer.bind("<Escape>", lambda _event: viewer.destroy())
        label.bind("<Button-1>", lambda _event: viewer.destroy())
        viewer.update_idletasks()
        width = min(photo.width() + 24, self.root.winfo_screenwidth() - 80)
        height = min(photo.height() + 24, self.root.winfo_screenheight() - 100)
        x = self.root.winfo_rootx() + (self.root.winfo_width() - width) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - height) // 2
        viewer.geometry(f"{width}x{height}+{max(0, x)}+{max(0, y)}")

    def convert_image(
        self,
        source: Path,
        destination: Path,
        max_width: int,
        max_height: int,
    ) -> None:
        powershell = shutil.which("powershell.exe") or shutil.which("powershell")
        if powershell is None or not CONVERT_SCRIPT.exists():
            if source.suffix.lower() in {".png", ".gif"}:
                shutil.copy2(source, destination)
                return
            raise RuntimeError("找不到 Windows 图片转换组件。")

        command = [
            powershell,
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(CONVERT_SCRIPT),
            "-Source",
            str(source),
            "-Destination",
            str(destination),
            "-MaxWidth",
            str(max_width),
            "-MaxHeight",
            str(max_height),
        ]
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=45,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if completed.returncode != 0 or not destination.exists():
            detail = (completed.stderr or completed.stdout or "").strip()
            raise RuntimeError(detail or "图片转换失败。")

    def start_desktop_web_ui(self) -> bool:
        """Run the polished desktop surface inside an Edge app window."""
        edge_candidates = (
            Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
            Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
        )
        edge = next((path for path in edge_candidates if path.is_file()), None)
        if edge is None:
            return False
        try:
            bridge = MemoWebBridge(self.root, self.handle_web_command)
            server = MemoWebServer(
                bridge=bridge,
                token=secrets.token_urlsafe(20),
                html_path=APP_DIR / "web_control.html",
                offline_js_path=APP_DIR / "offline_mobile.js",
                android_apk_path=ANDROID_APK_FILE,
                update_manifest_url=UPDATE_PORTAL_URL,
                preferred_port=8765,
            )
            server.start()
            local_url = (
                f"http://127.0.0.1:{server.port}/t/"
                f"{server.token}/desktop"
            )
            profile_dir = DATA_DIR / "desktop-web-profile"
            profile_dir.mkdir(parents=True, exist_ok=True)
            process = subprocess.Popen(
                [
                    str(edge),
                    f"--app={local_url}",
                    "--window-size=920,840",
                    "--window-position=160,60",
                    f"--user-data-dir={profile_dir}",
                    "--no-first-run",
                    "--disable-default-apps",
                    "--disable-session-crashed-bubble",
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            self._desktop_web_bridge = bridge
            self._desktop_web_server = server
            self._desktop_web_process = process
            self._desktop_web_started_at = time.monotonic()
            self._desktop_web_seen_window = False
            self.root.withdraw()
            self.root.after(1_500, self._watch_desktop_web_lifetime)
            return True
        except Exception:
            if self._desktop_web_server is not None:
                self._desktop_web_server.stop()
            self._desktop_web_server = None
            self._desktop_web_bridge = None
            self.root.deiconify()
            return False

    def _watch_desktop_web_lifetime(self) -> None:
        server = self._desktop_web_server
        if server is None:
            return
        if not server.running or server.httpd is None:
            self.close()
            return
        if getattr(server.httpd, "last_seen", 0.0):
            self._desktop_web_seen_window = True
        elif time.monotonic() - self._desktop_web_started_at > 20:
            # If the app window could not start, retain the proven Tk fallback.
            server.stop()
            self._desktop_web_server = None
            self._desktop_web_bridge = None
            self.root.deiconify()
            return
        if (
            self._desktop_web_seen_window
            and time.monotonic() - float(server.httpd.last_seen) > 180
        ):
            self.close()
            return
        self.root.after(2_000, self._watch_desktop_web_lifetime)

    def close(self) -> None:
        if self._desktop_web_server is not None:
            try:
                self._desktop_web_server.stop()
            except Exception:
                pass
            self._desktop_web_server = None
        if self._desktop_web_bridge is not None:
            self._desktop_web_bridge.stop()
            self._desktop_web_bridge = None
        self.cloud_sync_enabled = False
        self.phone_sync_enabled = False
        if self._phone_sync_job:
            try:
                self.root.after_cancel(self._phone_sync_job)
            except tk.TclError:
                pass
            self._phone_sync_job = None
        if self._cloud_sync_job:
            try:
                self.root.after_cancel(self._cloud_sync_job)
            except tk.TclError:
                pass
            self._cloud_sync_job = None
        self.root.update_idletasks()
        self.settings["x"] = self.root.winfo_x()
        self.settings["y"] = self.root.winfo_y()
        self.settings["topmost"] = self.topmost
        self._save_data()
        if self._live_update_job:
            try:
                self.root.after_cancel(self._live_update_job)
            except tk.TclError:
                pass
            self._live_update_job = None
        if self._tick_job:
            try:
                self.root.after_cancel(self._tick_job)
            except tk.TclError:
                pass
            self._tick_job = None
        for job_name in ("_header_art_job", "_river_art_job"):
            job = getattr(self, job_name, None)
            if job:
                try:
                    self.root.after_cancel(job)
                except tk.TclError:
                    pass
                setattr(self, job_name, None)
        self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()


def main() -> None:
    if os.name != "nt":
        print("BUAA浮光当前按 Windows 桌面环境设计。", file=sys.stderr)
    ensure_branded_launcher()
    if not focus_existing_instance():
        return
    app = BUAAmemo()
    app.start_desktop_web_ui()
    app.run()


if __name__ == "__main__":
    main()
