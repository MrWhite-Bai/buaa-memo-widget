import Darwin
import Foundation
import Network

final class LocalSyncServer {
    private struct Request {
        let method: String
        let path: String
        let headers: [String: String]
        let body: Data
    }

    private let queue = DispatchQueue(label: "com.mrwhitebai.buaamemo.sync")
    private let store = NativeStore.shared
    private let pairing: PairingManager
    private let friendStore = FriendStore.shared
    private var socketFD: Int32 = -1
    private var running = false
    private var discovery: DiscoveryResponder?
    private(set) var port = 8790
    var onRecordsChanged: ((String) -> Void)?

    init(pairing: PairingManager) {
        self.pairing = pairing
    }

    func start() {
        queue.async { [weak self] in
            guard let self = self, !self.running else { return }
            self.running = true
            guard self.openSocket() else {
                self.running = false
                return
            }
            self.discovery = DiscoveryResponder(
                httpPort: self.port,
                deviceID: self.pairing.deviceID,
                friendCode: self.pairing.friendCode,
                deviceName: self.pairing.deviceName
            )
            self.discovery?.start()
            while self.running {
                var address = sockaddr()
                var length = socklen_t(MemoryLayout<sockaddr>.size)
                let client = accept(self.socketFD, &address, &length)
                if client < 0 {
                    if self.running { continue }
                    break
                }
                DispatchQueue.global(qos: .userInitiated).async {
                    self.handle(client: client)
                }
            }
        }
    }

    func stop() {
        running = false
        discovery?.stop()
        discovery = nil
        if socketFD >= 0 {
            shutdown(socketFD, SHUT_RDWR)
            close(socketFD)
            socketFD = -1
        }
    }

    private func openSocket() -> Bool {
        for candidate in 8790..<8800 {
            let fd = socket(AF_INET, SOCK_STREAM, 0)
            if fd < 0 { continue }
            var reuse: Int32 = 1
            setsockopt(
                fd,
                SOL_SOCKET,
                SO_REUSEADDR,
                &reuse,
                socklen_t(MemoryLayout<Int32>.size)
            )
            var address = sockaddr_in()
            address.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
            address.sin_family = sa_family_t(AF_INET)
            address.sin_port = in_port_t(candidate).bigEndian
            address.sin_addr = in_addr(s_addr: INADDR_ANY)
            let bound = withUnsafePointer(to: &address) { pointer in
                pointer.withMemoryRebound(
                    to: sockaddr.self,
                    capacity: 1
                ) {
                    bind(
                        fd,
                        $0,
                        socklen_t(MemoryLayout<sockaddr_in>.size)
                    )
                }
            }
            if bound == 0 && listen(fd, 16) == 0 {
                socketFD = fd
                port = candidate
                return true
            }
            close(fd)
        }
        return false
    }

    private func handle(client: Int32) {
        defer { close(client) }
        var timeout = timeval(tv_sec: 10, tv_usec: 0)
        setsockopt(
            client,
            SOL_SOCKET,
            SO_RCVTIMEO,
            &timeout,
            socklen_t(MemoryLayout<timeval>.size)
        )
        var noSignal: Int32 = 1
        setsockopt(
            client,
            SOL_SOCKET,
            SO_NOSIGPIPE,
            &noSignal,
            socklen_t(MemoryLayout<Int32>.size)
        )
        guard let request = readRequest(client) else { return }
        if request.method == "OPTIONS" {
            send(client, status: 204, object: nil)
            return
        }
        if request.method == "GET" && request.path == "/ping" {
            send(client, status: 200, object: [
                "ok": true,
                "name": "BUAA浮光 iOS",
                "device_id": pairing.deviceID,
                "device_name": pairing.deviceName,
                "ip": NetworkAddress.localIPv4(),
                "port": port,
                "records": recordCount(),
                "pairing_required": true
            ])
            return
        }
        if request.method == "GET" && request.path == "/friend/info" {
            send(client, status: 200, object: [
                "ok": true,
                "friend_code": pairing.friendCode,
                "device_id": pairing.deviceID,
                "device_name": pairing.deviceName,
                "ip": NetworkAddress.localIPv4(),
                "port": port,
                "friend_protocol": 1
            ])
            return
        }
        if request.method == "POST" && request.path == "/friend/request" {
            guard let payload = jsonObject(request.body),
                  let fromID = payload["from_id"] as? String,
                  let requestID = payload["request_id"] as? String,
                  let token = payload["token"] as? String,
                  let publicKey = payload["public_key"] as? String,
                  let address = payload["address"] as? String,
                  !fromID.isEmpty,
                  !requestID.isEmpty,
                  token.count >= 24,
                  !publicKey.isEmpty,
                  !address.isEmpty else {
                send(client, status: 400, object: [
                    "ok": false,
                    "error": "好友请求内容不完整"
                ])
                return
            }
            let createdAt =
                (payload["created_at"] as? NSNumber)?.doubleValue
                ?? Date().timeIntervalSince1970 * 1000
            let now = Date().timeIntervalSince1970 * 1000
            if abs(now - createdAt) > 300_000 {
                send(client, status: 400, object: [
                    "ok": false,
                    "error": "好友请求已过期"
                ])
                return
            }
            let requestObject: [String: Any] = [
                "request_id": requestID,
                "from_id": fromID,
                "from_name": payload["from_name"] as? String ?? "好友",
                "token": token,
                "public_key": publicKey,
                "address": address,
                "created_at": Int64(now)
            ]
            _ = friendStore.addIncomingRequest(requestObject)
            send(client, status: 200, object: [
                "ok": true,
                "pending": true
            ])
            return
        }
        if request.method == "POST" && request.path == "/friend/approve" {
            guard let payload = jsonObject(request.body) else {
                send(client, status: 400, object: ["ok": false])
                return
            }
            let fromID = payload["from_id"] as? String ?? ""
            if friendStore.isFriendLimitReached(fromID) {
                send(client, status: 409, object: [
                    "ok": false,
                    "error": "好友数量已达 20 人上限，请先删除部分好友"
                ])
                return
            }
            let friend = friendStore.approveOutgoing(
                requestID: payload["request_id"] as? String ?? "",
                friendID: fromID,
                token: payload["token"] as? String ?? "",
                publicKey: payload["public_key"] as? String ?? "",
                address: payload["address"] as? String ?? "",
                name: payload["from_name"] as? String ?? "好友"
            )
            guard friend != nil else {
                send(client, status: 401, object: [
                    "ok": false,
                    "error": "好友确认已失效或请求不存在"
                ])
                return
            }
            send(client, status: 200, object: [
                "ok": true,
                "friend_code": pairing.friendCode,
                "device_name": pairing.deviceName,
                "ip": NetworkAddress.localIPv4(),
                "port": port
            ])
            return
        }
        if request.method == "POST" && request.path == "/friend/deny" {
            let payload = jsonObject(request.body)
            let removed = friendStore.denyOutgoing(
                requestID: payload?["request_id"] as? String ?? "",
                friendID: payload?["from_id"] as? String ?? "",
                token: payload?["token"] as? String ?? ""
            )
            send(client, status: removed ? 200 : 401, object: [
                "ok": removed
            ])
            return
        }
        let friendToken = request.headers["x-friend-token"] ?? ""
        let friendID = request.headers["x-friend-id"] ?? ""
        if request.method == "POST" && request.path == "/friend/message" {
            guard friendStore.tokenMatches(
                friendID: friendID,
                token: friendToken
            ), let envelope = jsonObject(request.body) else {
                send(client, status: 401, object: [
                    "ok": false,
                    "error": "好友认证失败"
                ])
                return
            }
            _ = friendStore.addInboxMessage(
                senderID: friendID,
                envelope: envelope
            )
            send(client, status: 200, object: [
                "ok": true,
                "queued": true
            ])
            return
        }
        if request.method == "POST" && request.path == "/friend/remove" {
            guard friendStore.tokenMatches(
                friendID: friendID,
                token: friendToken
            ) else {
                send(client, status: 401, object: [
                    "ok": false,
                    "error": "好友认证失败"
                ])
                return
            }
            friendStore.removeFriend(friendID)
            send(client, status: 200, object: ["ok": true])
            return
        }
        if request.method == "POST" && request.path == "/pair" {
            let payload = jsonObject(request.body)
            let code = payload?["code"] as? String ?? ""
            let token = pairing.attemptPair(code)
            let blocked = pairing.blockedSecondsRemaining()
            if token == nil {
                send(client, status: blocked > 0 ? 429 : 401, object: [
                    "ok": false,
                    "error": blocked > 0
                        ? "尝试次数过多，请稍后再试"
                        : "配对码不正确",
                    "retry_after": blocked
                ])
                return
            }
            send(client, status: 200, object: [
                "ok": true,
                "token": token!,
                "device_id": pairing.deviceID,
                "device_name": pairing.deviceName
            ])
            return
        }
        let providedToken = request.headers["x-buaa-token"] ?? ""
        guard pairing.tokenMatches(providedToken) else {
            send(client, status: 401, object: [
                "ok": false,
                "error": "未授权，请先配对"
            ])
            return
        }
        if request.method == "GET" && request.path == "/records" {
            send(client, status: 200, object: [
                "ok": true,
                "records": recordsArray(),
                "server_time": Int(Date().timeIntervalSince1970 * 1000)
            ])
            return
        }
        if request.method == "POST" && request.path == "/sync" {
            let payload = jsonObject(request.body)
            let incoming = payload?["records"] as? [[String: Any]] ?? []
            let merged = mergeRecords(recordsArray(), incoming)
            if let data = try? JSONSerialization.data(
                withJSONObject: merged,
                options: []
            ), let text = String(data: data, encoding: .utf8) {
                _ = store.write(text)
                onRecordsChanged?(text)
            }
            send(client, status: 200, object: [
                "ok": true,
                "records": merged,
                "server_time": Int(Date().timeIntervalSince1970 * 1000)
            ])
            return
        }
        send(client, status: 404, object: [
            "ok": false,
            "error": "Not found"
        ])
    }

    private func recordsArray() -> [[String: Any]] {
        let data = Data(store.read().utf8)
        return (try? JSONSerialization.jsonObject(with: data))
            as? [[String: Any]] ?? []
    }

    private func recordCount() -> Int {
        recordsArray().count
    }

    private func jsonObject(_ data: Data) -> [String: Any]? {
        (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    }

    private func mergeRecords(
        _ local: [[String: Any]],
        _ incoming: [[String: Any]]
    ) -> [[String: Any]] {
        var byID: [String: [String: Any]] = [:]
        for record in local + incoming {
            guard let id = record["id"] as? String, !id.isEmpty else {
                continue
            }
            let nextRevision = (record["rev"] as? NSNumber)?.int64Value ?? 0
            let previousRevision =
                (byID[id]?["rev"] as? NSNumber)?.int64Value ?? -1
            if previousRevision <= nextRevision {
                byID[id] = record
            }
        }
        return Array(byID.values)
    }

    private func readRequest(_ fd: Int32) -> Request? {
        let separator = Data("\r\n\r\n".utf8)
        var data = Data()
        var headerEnd: Range<Data.Index>?
        while data.count < 1_100_000 {
            var buffer = [UInt8](repeating: 0, count: 8192)
            let count = buffer.withUnsafeMutableBytes {
                recv(fd, $0.baseAddress, $0.count, 0)
            }
            if count <= 0 { break }
            data.append(contentsOf: buffer[0..<count])
            headerEnd = data.range(of: separator)
            if headerEnd != nil { break }
        }
        guard let headerEnd = headerEnd,
              let headerText = String(
                data: data[..<headerEnd.lowerBound],
                encoding: .utf8
              ) else {
            return nil
        }
        let lines = headerText.components(separatedBy: "\r\n")
        guard let requestLine = lines.first else { return nil }
        let parts = requestLine.split(separator: " ")
        guard parts.count >= 2 else { return nil }
        var headers: [String: String] = [:]
        for line in lines.dropFirst() {
            guard let separator = line.firstIndex(of: ":") else { continue }
            let name = line[..<separator]
                .trimmingCharacters(in: .whitespaces)
                .lowercased()
            let value = line[line.index(after: separator)...]
                .trimmingCharacters(in: .whitespaces)
            headers[name] = value
        }
        let contentLength = Int(headers["content-length"] ?? "0") ?? 0
        var body = Data(data[headerEnd.upperBound...])
        while body.count < contentLength {
            var buffer = [UInt8](repeating: 0, count: 8192)
            let count = buffer.withUnsafeMutableBytes {
                recv(fd, $0.baseAddress, $0.count, 0)
            }
            if count <= 0 { break }
            body.append(contentsOf: buffer[0..<count])
        }
        let path = String(parts[1]).split(
            separator: "?",
            maxSplits: 1
        ).first.map(String.init) ?? String(parts[1])
        return Request(
            method: String(parts[0]).uppercased(),
            path: path,
            headers: headers,
            body: body.prefix(contentLength)
        )
    }

    private func send(
        _ fd: Int32,
        status: Int,
        object: [String: Any]?
    ) {
        let body: Data
        if let object = object,
           let data = try? JSONSerialization.data(
               withJSONObject: object,
               options: []
           ) {
            body = data
        } else {
            body = Data()
        }
        let reason: String
        switch status {
        case 200: reason = "OK"
        case 204: reason = "No Content"
        case 400: reason = "Bad Request"
        case 401: reason = "Unauthorized"
        case 202: reason = "Accepted"
        case 404: reason = "Not Found"
        case 429: reason = "Too Many Requests"
        default: reason = "Error"
        }
        let headers = [
            "HTTP/1.1 \(status) \(reason)",
            "Content-Type: application/json; charset=utf-8",
            "Access-Control-Allow-Origin: *",
            "Access-Control-Allow-Headers: Content-Type, X-Buaa-Token, X-Friend-Id, X-Friend-Token",
            "Access-Control-Allow-Methods: GET, POST, OPTIONS",
            "Access-Control-Allow-Private-Network: true",
            "Content-Length: \(body.count)",
            "Connection: close",
            "",
            ""
        ].joined(separator: "\r\n")
        var response = Data(headers.utf8)
        response.append(body)
        response.withUnsafeBytes { rawBuffer in
            guard let base = rawBuffer.baseAddress else { return }
            var offset = 0
            while offset < rawBuffer.count {
                let written = Darwin.send(
                    fd,
                    base.advanced(by: offset),
                    rawBuffer.count - offset,
                    0
                )
                if written <= 0 { break }
                offset += written
            }
        }
    }
}

final class DiscoveryResponder {
    private static let magic = "BUAA_MEMO_DISCOVER_V1"
    private let queue = DispatchQueue(label: "com.mrwhitebai.buaamemo.discovery")
    private let httpPort: Int
    private let deviceID: String
    private var listener: NWListener?

    private let friendCode: String
    private let deviceName: String

    init(
        httpPort: Int,
        deviceID: String,
        friendCode: String,
        deviceName: String
    ) {
        self.httpPort = httpPort
        self.deviceID = deviceID
        self.friendCode = friendCode
        self.deviceName = deviceName
    }

    func start() {
        do {
            let parameters = NWParameters.udp
            parameters.allowLocalEndpointReuse = true
            let listener = try NWListener(using: parameters, on: 8791)
            listener.newConnectionHandler = { [weak self] connection in
                guard let self = self else {
                    connection.cancel()
                    return
                }
                connection.start(queue: self.queue)
                connection.receiveMessage { data, _, _, _ in
                    if let data = data,
                       String(data: data, encoding: .utf8)
                        ?.trimmingCharacters(in: .whitespacesAndNewlines)
                        == DiscoveryResponder.magic {
                        let info: [String: Any] = [
                            "port": self.httpPort,
                            "device_id": self.deviceID,
                            "friend_code": self.friendCode,
                            "device_name": self.deviceName
                        ]
                        let infoData = (
                            try? JSONSerialization.data(
                                withJSONObject: info
                            )
                        ) ?? Data("{}".utf8)
                        var response = Data(
                            "BUAA_MEMO_SERVER_V3:".utf8
                        )
                        response.append(infoData)
                        connection.send(
                            content: response,
                            completion: .contentProcessed { _ in
                                connection.cancel()
                            }
                        )
                    } else {
                        connection.cancel()
                    }
                }
            }
            listener.start(queue: queue)
            self.listener = listener
        } catch {
            listener = nil
        }
    }

    func stop() {
        listener?.cancel()
        listener = nil
    }
}

enum NetworkAddress {
    static func localIPv4() -> String {
        var interfaces: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&interfaces) == 0 else { return "127.0.0.1" }
        defer { freeifaddrs(interfaces) }
        var pointer = interfaces
        while let current = pointer {
            let item = current.pointee
            if item.ifa_addr?.pointee.sa_family == UInt8(AF_INET) {
                let name = String(cString: item.ifa_name)
                if name != "lo0" {
                    var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                    let length = socklen_t(item.ifa_addr.pointee.sa_len)
                    if getnameinfo(
                        item.ifa_addr,
                        length,
                        &host,
                        socklen_t(host.count),
                        nil,
                        0,
                        NI_NUMERICHOST
                    ) == 0 {
                        return String(cString: host)
                    }
                }
            }
            pointer = item.ifa_next
        }
        return "127.0.0.1"
    }
}
