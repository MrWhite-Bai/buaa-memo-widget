from __future__ import annotations

import base64
import hashlib
import ipaddress
import json
import queue
import re
import secrets
import socket
import struct
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


MAX_REQUEST_BODY = 1_000_000


class MemoApiError(Exception):
    pass


class MemoWebBridge:
    """Run web requests on Tk's main thread so the UI and data stay coherent."""

    def __init__(self, root, handler) -> None:
        self.root = root
        self.handler = handler
        self.requests: queue.Queue = queue.Queue()
        self.stopped = False
        self.root.after(120, self._drain)

    def request(self, action: str, payload: dict | None = None, timeout: float = 8.0):
        event = threading.Event()
        result_box: dict = {}
        self.requests.put((action, payload or {}, result_box, event))
        if not event.wait(timeout):
            raise MemoApiError("电脑端响应超时，请确认插件仍在运行。")
        if result_box.get("error"):
            raise MemoApiError(str(result_box["error"]))
        return result_box.get("result")

    def _drain(self) -> None:
        while True:
            try:
                action, payload, result_box, event = self.requests.get_nowait()
            except queue.Empty:
                break
            try:
                result_box["result"] = self.handler(action, payload)
            except Exception as exc:
                result_box["error"] = str(exc) or "操作失败"
            finally:
                event.set()
        if not self.stopped:
            self.root.after(120, self._drain)

    def stop(self) -> None:
        self.stopped = True


class _ThreadingServer(ThreadingHTTPServer):
    allow_reuse_address = False
    daemon_threads = True


class MemoRequestHandler(BaseHTTPRequestHandler):
    server_version = "BUAAMemo/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, _format, *args) -> None:
        pass

    def _client_is_allowed(self) -> bool:
        try:
            address = ipaddress.ip_address(self.client_address[0])
        except ValueError:
            return False
        return address.is_private or address.is_loopback

    def _validate_path(self) -> str | None:
        if not self._client_is_allowed():
            self._send_json(403, {"ok": False, "error": "仅允许局域网设备访问。"})
            return None

        path = urllib.parse.urlsplit(self.path).path
        prefix = f"/t/{self.server.token}"
        if path == prefix:
            self.send_response(302)
            self.send_header("Location", prefix + "/")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return None
        if not (path == prefix + "/" or path.startswith(prefix + "/")):
            self._send_json(404, {"ok": False, "error": "控制页地址无效。"})
            return None
        return path

    def _send_bytes(
        self,
        status: int,
        payload: bytes,
        content_type: str,
    ) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store, max-age=0")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self._send_bytes(status, body, "application/json; charset=utf-8")

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0:
            return {}
        if length > MAX_REQUEST_BODY:
            raise MemoApiError("请求内容过大。")
        raw = self.rfile.read(length)
        try:
            parsed = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise MemoApiError("请求内容格式不正确。") from exc
        if not isinstance(parsed, dict):
            raise MemoApiError("请求内容格式不正确。")
        return parsed

    def _read_exact(self, length: int) -> bytes:
        data = self.rfile.read(length)
        if len(data) != length:
            raise ConnectionError("连接已关闭")
        return data

    def _send_ws_frame(self, opcode: int, payload: bytes) -> None:
        first = 0x80 | opcode
        length = len(payload)
        if length < 126:
            header = bytes((first, length))
        elif length < 65536:
            header = bytes((first, 126)) + struct.pack("!H", length)
        else:
            header = bytes((first, 127)) + struct.pack("!Q", length)
        self.connection.sendall(header + payload)

    def _read_ws_message(self) -> str | None:
        message = bytearray()
        while True:
            header = self._read_exact(2)
            first, second = header[0], header[1]
            final = bool(first & 0x80)
            opcode = first & 0x0F
            masked = bool(second & 0x80)
            length = second & 0x7F
            if length == 126:
                length = struct.unpack("!H", self._read_exact(2))[0]
            elif length == 127:
                length = struct.unpack("!Q", self._read_exact(8))[0]
            if length > 8_000_000:
                raise MemoApiError("同步数据过大。")
            mask = self._read_exact(4) if masked else b""
            payload = self._read_exact(length)
            if masked:
                payload = bytes(
                    byte ^ mask[index % 4] for index, byte in enumerate(payload)
                )
            if opcode == 0x8:
                return None
            if opcode == 0x9:
                self._send_ws_frame(0xA, payload)
                continue
            if opcode in (0x0, 0x1):
                message.extend(payload)
                if final:
                    try:
                        return message.decode("utf-8")
                    except UnicodeDecodeError as exc:
                        raise MemoApiError("同步内容编码不正确。") from exc

    def _handle_websocket(self) -> None:
        if not self._client_is_allowed():
            self._send_json(403, {"ok": False, "error": "仅允许局域网设备访问。"})
            return
        expected = f"/sync/{self.server.token}"
        path = urllib.parse.urlsplit(self.path).path
        if path != expected:
            self._send_json(404, {"ok": False, "error": "同步地址无效。"})
            return
        key = self.headers.get("Sec-WebSocket-Key")
        if not key:
            self._send_json(400, {"ok": False, "error": "WebSocket 握手失败。"})
            return

        accept = base64.b64encode(
            hashlib.sha1(
                (key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("ascii")
            ).digest()
        ).decode("ascii")
        response = (
            "HTTP/1.1 101 Switching Protocols\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Accept: {accept}\r\n\r\n"
        )
        self.wfile.write(response.encode("ascii"))
        self.wfile.flush()
        self.close_connection = True
        self.connection.settimeout(20)

        try:
            message = self._read_ws_message()
            if message is None:
                return
            payload = json.loads(message)
            if not isinstance(payload, dict) or payload.get("type") != "sync":
                raise MemoApiError("同步请求格式不正确。")
            records = payload.get("records", [])
            result = self.server.bridge.request(
                "sync",
                {"records": records},
                timeout=20,
            )
            reply = json.dumps(
                {"type": "synced", "records": result.get("records", [])},
                ensure_ascii=False,
            ).encode("utf-8")
            self._send_ws_frame(0x1, reply)
            self._send_ws_frame(0x8, b"")
        except (OSError, ConnectionError, TimeoutError):
            pass
        except (json.JSONDecodeError, MemoApiError):
            pass

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self) -> None:
        if self.headers.get("Upgrade", "").lower() == "websocket":
            self._handle_websocket()
            return
        path = self._validate_path()
        if path is None:
            return
        prefix = f"/t/{self.server.token}"
        if path in {prefix + "/", prefix}:
            try:
                html = Path(self.server.html_path).read_text(encoding="utf-8")
                version = self.server.bridge.request("version").get(
                    "version", "0.0.0"
                )
                html = html.replace("__BUAA_APP_VERSION__", str(version))
            except (OSError, MemoApiError):
                self._send_json(500, {"ok": False, "error": "控制页文件缺失。"})
                return
            self._send_bytes(200, html.encode("utf-8"), "text/html; charset=utf-8")
            return
        if path == prefix + "/api/memos":
            try:
                result = self.server.bridge.request("list")
                self._send_json(200, {"ok": True, **result})
            except MemoApiError as exc:
                self._send_json(503, {"ok": False, "error": str(exc)})
            return
        if path == prefix + "/offline":
            try:
                html = Path(self.server.html_path).read_text(encoding="utf-8")
                offline_js = Path(self.server.offline_js_path).read_text(
                    encoding="utf-8"
                )
                records = self.server.bridge.request("all_records").get("records", [])
                version = self.server.bridge.request("version").get(
                    "version", "0.0.0"
                )
                host = get_lan_ip()
                bootstrap = {
                    "syncWsUrl": (
                        f"ws://{host}:{self.server.server_port}/sync/"
                        f"{self.server.token}"
                    ),
                    "syncHttpUrl": (
                        f"http://{host}:{self.server.server_port}/t/"
                        f"{self.server.token}/api/sync"
                    ),
                    "seedRecords": records,
                    "mobileVersion": version,
                    "updateManifestUrl": self.server.update_manifest_url,
                }
                config = json.dumps(bootstrap, ensure_ascii=False).replace(
                    "</", "<\\/"
                )
                script = (
                    f"<script>window.BUAA_BOOTSTRAP = {config};</script>\n"
                    f"<script>\n{offline_js}\n</script>"
                )
                html = re.sub(
                    r"<script>[\s\S]*?</script>",
                    lambda _match: script,
                    html,
                    count=1,
                )
                html = html.replace(
                    "备忘倒计时 · 微信控制",
                    "离线手机版 · 本地保存 · 自动同步",
                )
                body = html.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header(
                    "Content-Disposition",
                    'attachment; filename="BUAA-Memo-Offline.html"',
                )
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except (OSError, MemoApiError) as exc:
                self._send_json(500, {"ok": False, "error": str(exc)})
            return
        self._send_json(404, {"ok": False, "error": "接口不存在。"})

    def do_POST(self) -> None:
        path = self._validate_path()
        if path is None:
            return
        prefix = f"/t/{self.server.token}"
        try:
            payload = self._read_json()
            if path == prefix + "/api/memos":
                result = self.server.bridge.request("save", payload)
                self._send_json(200, {"ok": True, **result})
                return
            if path == prefix + "/api/memos/delete":
                result = self.server.bridge.request("delete", payload)
                self._send_json(200, {"ok": True, **result})
                return
            if path == prefix + "/api/memos/complete":
                result = self.server.bridge.request("complete", payload)
                self._send_json(200, {"ok": True, **result})
                return
            if path == prefix + "/api/sync":
                result = self.server.bridge.request(
                    "sync",
                    {"records": payload.get("records", [])},
                    timeout=20,
                )
                self._send_json(200, {"ok": True, **result})
                return
            self._send_json(404, {"ok": False, "error": "接口不存在。"})
        except MemoApiError as exc:
            self._send_json(400, {"ok": False, "error": str(exc)})
        except Exception:
            self._send_json(500, {"ok": False, "error": "电脑端处理失败。"})


class MemoWebServer:
    def __init__(
        self,
        bridge: MemoWebBridge,
        token: str,
        html_path: Path,
        offline_js_path: Path | None = None,
        update_manifest_url: str = "",
        preferred_port: int = 8765,
    ) -> None:
        self.bridge = bridge
        self.token = token
        self.html_path = html_path
        self.offline_js_path = offline_js_path
        self.update_manifest_url = update_manifest_url
        self.preferred_port = preferred_port
        self.httpd: _ThreadingServer | None = None
        self.thread: threading.Thread | None = None
        self.port: int | None = None

    def start(self) -> None:
        if self.running:
            return
        last_error = None
        for port in range(self.preferred_port, self.preferred_port + 20):
            try:
                httpd = _ThreadingServer(("0.0.0.0", port), MemoRequestHandler)
            except OSError as exc:
                last_error = exc
                continue
            httpd.bridge = self.bridge
            httpd.token = self.token
            httpd.html_path = self.html_path
            httpd.offline_js_path = self.offline_js_path
            httpd.update_manifest_url = self.update_manifest_url
            self.httpd = httpd
            self.port = port
            self.thread = threading.Thread(
                target=httpd.serve_forever,
                name="BUAA-Memo-Web",
                daemon=True,
            )
            self.thread.start()
            return
        raise MemoApiError(f"无法启动微信控制服务：{last_error or '端口被占用'}")

    @property
    def running(self) -> bool:
        return self.httpd is not None and self.thread is not None and self.thread.is_alive()

    @property
    def url(self) -> str:
        return f"http://{get_lan_ip()}:{self.port}/t/{self.token}/"

    def stop(self) -> None:
        if self.httpd is not None:
            self.httpd.shutdown()
            self.httpd.server_close()
        self.httpd = None
        self.thread = None


def get_lan_ip() -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        candidate = sock.getsockname()[0]
        if candidate and not candidate.startswith("127."):
            return candidate
    except OSError:
        pass
    finally:
        sock.close()

    try:
        for candidate in socket.gethostbyname_ex(socket.gethostname())[2]:
            if candidate and not candidate.startswith("127."):
                return candidate
    except OSError:
        pass
    return "127.0.0.1"


def draw_qr_on_canvas(canvas, value: str, size: int, color: str) -> None:
    import pyqrcode

    matrix = pyqrcode.create(value, error="M").code
    count = len(matrix)
    module = size / max(1, count)
    canvas.delete("all")
    canvas.create_rectangle(0, 0, size, size, fill="white", outline="")
    for row_index, row in enumerate(matrix):
        column = 0
        while column < count:
            if row[column] != 1:
                column += 1
                continue
            start = column
            while column < count and row[column] == 1:
                column += 1
            left = round(start * module)
            right = round(column * module)
            top = round(row_index * module)
            bottom = round((row_index + 1) * module)
            canvas.create_rectangle(
                left,
                top,
                right,
                bottom,
                fill=color,
                outline=color,
            )
