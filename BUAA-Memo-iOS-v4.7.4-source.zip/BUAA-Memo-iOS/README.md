# BUAA浮光 iOS 工程

该工程使用 Swift、UIKit 与 WKWebView，加载与 Android 版一致的 BUAA浮光界面。

## 功能

- 事项、倒计时、任务/事件、图片、分组、历史事项和周视图。
- 数据保存在 iOS App 沙盒，并镜像到原生记录文件。
- 本地通知提醒，可在 App 关闭后由系统继续触发。
- 局域网同步：iOS App 打开时提供与 Android 版相同的配对码、同步令牌和记录接口。
- 横屏周视图。

## 在 macOS 上构建

1. 安装 Xcode 16 或更高版本。
2. 打开 `BUAAMemo.xcodeproj`。
3. 在 Signing & Capabilities 中选择自己的 Apple Developer Team。
4. 连接 iPhone，或选择模拟器后运行。

也可在终端生成开发签名 IPA：

```bash
chmod +x build_ios_ipa.sh
DEVELOPMENT_TEAM=你的团队ID ./build_ios_ipa.sh
```

真机内测需要 Apple Developer 签名或 TestFlight。Windows 无法生成可安装签名 IPA。

## iOS 限制

- iOS 原生版不能直接安装压缩包中的 IPA，必须使用 Apple 开发者证书签名，
  或通过 macOS 和 Xcode 安装。
- iOS 会在锁屏显示并可能自动点亮本地通知，但第三方 App 无权强制打开屏幕或显示
  Android 式全屏 Intent。
- iOS 不允许 App 自行下载并安装新版本，更新需要通过 TestFlight、App Store
  或 Xcode 覆盖安装。
- 局域网同步仅在 iOS App 处于前台或系统尚未挂起时可用。
