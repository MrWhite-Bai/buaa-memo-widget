(() => {
  "use strict";

  const bootstrap = window.BUAA_BOOTSTRAP || {};
  const STORAGE_KEY = "buaa_memo_records_v2";
  const SYNC_URL_KEY = "buaa_memo_sync_url_v2";
  const CLOUD_VAULT_KEY = "buaa_memo_cloud_vault_v1";
  const CLOUD_CURSOR_KEY = "buaa_memo_cloud_cursor_v1";
  const CLOUD_PUSH_REV_KEY = "buaa_memo_cloud_push_rev_v1";
  const HISTORY_GRACE_MS = 24 * 60 * 60 * 1000;
  const UPDATE_PORTAL_URL =
    "https://cysyforum.muzermat.online/cy-platform/projects/5";
  const DESKTOP_DOWNLOAD_URL =
    bootstrap.desktopDownloadUrl ||
    "https://github.com/MrWhite-Bai/buaa-memo-widget/releases/download/" +
      "v4.1.0/BUAA-Memo-Windows-v4.1.0.zip";
  const CURRENT_MOBILE_VERSION = bootstrap.mobileVersion || "0.0.0";
  const LIVE_UPDATE_MANIFEST_URLS = [
    "https://raw.githubusercontent.com/MrWhite-Bai/" +
      "buaa-memo-widget/main/update-manifest.json",
    "https://cdn.jsdelivr.net/gh/MrWhite-Bai/" +
      "buaa-memo-widget@main/update-manifest.json",
  ].filter(Boolean);

  const listEl = document.getElementById("list");
  const countEl = document.getElementById("count");
  const statusEl = document.getElementById("status");
  const statusText = document.getElementById("statusText");
  const overlay = document.getElementById("overlay");
  const memosPage = document.getElementById("memosPage");
  const groupsPage = document.getElementById("groupsPage");
  const memosTabBtn = document.getElementById("memosTabBtn");
  const groupsTabBtn = document.getElementById("groupsTabBtn");
  const groupCount = document.getElementById("groupCount");
  const groupList = document.getElementById("groupList");
  const newGroupBtn = document.getElementById("newGroupBtn");
  const groupOverlay = document.getElementById("groupOverlay");
  const groupForm = document.getElementById("groupForm");
  const groupFormTitle = document.getElementById("groupFormTitle");
  const groupNameInput = document.getElementById("groupName");
  const groupIntroInput = document.getElementById("groupIntro");
  const groupMemoChoices = document.getElementById("groupMemoChoices");
  const groupCancelBtn = document.getElementById("groupCancelBtn");
  const groupDetailOverlay = document.getElementById("groupDetailOverlay");
  const groupDetailTitle = document.getElementById("groupDetailTitle");
  const groupDetailIntro = document.getElementById("groupDetailIntro");
  const groupDetailList = document.getElementById("groupDetailList");
  const groupDetailCloseBtn = document.getElementById("groupDetailCloseBtn");
  const syncOverlay = document.getElementById("syncOverlay");
  const syncCodeInput = document.getElementById("syncCodeInput");
  const syncBtn = document.getElementById("syncBtn");
  const syncTutorialOverlay = document.getElementById("syncTutorialOverlay");
  const syncGuideAddress = document.getElementById("syncGuideAddress");
  const syncGuideCode = document.getElementById("syncGuideCode");
  const historyBtn = document.getElementById("historyBtn");
  const weekBtn = document.getElementById("weekBtn");
  const versionBtn = document.getElementById("versionBtn");
  const historyOverlay = document.getElementById("historyOverlay");
  const historyList = document.getElementById("historyList");
  const weekOverlay = document.getElementById("weekOverlay");
  const weekHeaderCanvas = document.getElementById("weekHeaderCanvas");
  const weekCanvas = document.getElementById("weekCanvas");
  const weekTitle = document.getElementById("weekTitle");
  const changelogOverlay = document.getElementById("changelogOverlay");
  const changelogList = document.getElementById("changelogList");
  const imageViewerOverlay = document.getElementById("imageViewerOverlay");
  const imageViewerImage = document.getElementById("imageViewerImage");
  const imageInput = document.getElementById("imageInput");
  const imagePreview = document.getElementById("imagePreview");
  const removeImageBtn = document.getElementById("removeImageBtn");
  const form = document.getElementById("memoForm");
  const formTitle = document.getElementById("formTitle");
  const titleInput = document.getElementById("title");
  const memoGroup = document.getElementById("memoGroup");
  const dateInput = document.getElementById("date");
  const timeInput = document.getElementById("time");
  const startDateInput = document.getElementById("startDate");
  const startTimeInput = document.getElementById("startTime");
  const endDateInput = document.getElementById("endDate");
  const endTimeInput = document.getElementById("endTime");
  const taskFields = document.getElementById("taskFields");
  const eventFields = document.getElementById("eventFields");
  const taskTypeBtn = document.getElementById("taskTypeBtn");
  const eventTypeBtn = document.getElementById("eventTypeBtn");
  const reminderEnabled = document.getElementById("reminderEnabled");
  const reminderOptions = document.getElementById("reminderOptions");
  const reminderAmount = document.getElementById("reminderAmount");
  const reminderUnit = document.getElementById("reminderUnit");
  const reminderNotify = document.getElementById("reminderNotify");
  const reminderSound = document.getElementById("reminderSound");
  const reminderVibrate = document.getElementById("reminderVibrate");
  const reminderVolume = document.getElementById("reminderVolume");
  const reminderVolumeValue = document.getElementById("reminderVolumeValue");
  const testReminderBtn = document.getElementById("testReminderBtn");
  const noteInput = document.getElementById("note");
  const toastEl = document.getElementById("toast");
  const checkUpdateBtn = document.getElementById("checkUpdateBtn");
  const layoutSettingsBtn = document.getElementById("layoutSettingsBtn");
  const layoutSettingsOverlay = document.getElementById(
    "layoutSettingsOverlay"
  );
  const layoutSettingsCloseBtn = document.getElementById(
    "layoutSettingsCloseBtn"
  );
  const layoutSettingsDoneBtn = document.getElementById(
    "layoutSettingsDoneBtn"
  );
  const layoutResetBtn = document.getElementById("layoutResetBtn");
  const layoutSafeTop = document.getElementById("layoutSafeTop");
  const layoutSafeBottom = document.getElementById("layoutSafeBottom");
  const layoutTopExtra = document.getElementById("layoutTopExtra");
  const layoutBottomExtra = document.getElementById("layoutBottomExtra");
  const layoutTopExtraValue = document.getElementById(
    "layoutTopExtraValue"
  );
  const layoutBottomExtraValue = document.getElementById(
    "layoutBottomExtraValue"
  );
  const layoutNavMode = document.getElementById("layoutNavMode");
  const layoutFabMode = document.getElementById("layoutFabMode");
  const layoutSystemInfo = document.getElementById("layoutSystemInfo");
  const desktopDownloadPageLink = document.getElementById(
    "desktopDownloadPageLink"
  );
  const directDesktopDownload = document.getElementById("directDesktopDownload");
  const copyDesktopLinkBtn = document.getElementById("copyDesktopLinkBtn");
  const shareDesktopLinkBtn = document.getElementById("shareDesktopLinkBtn");
  const desktopDownloadBtn = document.getElementById("desktopDownloadBtn");
  const desktopDownloadOverlay = document.getElementById(
    "desktopDownloadOverlay"
  );
  const desktopDownloadCloseBtn = document.getElementById(
    "desktopDownloadCloseBtn"
  );
  const nativeBridge = window.AndroidMemo || null;

  document.querySelector(".offline-box")?.remove();

  let records = [];
  let editingId = null;
  let editingGroupId = null;
  let activeGroupDetailId = null;
  let activePage = "memos";
  let editorType = "task";
  let syncing = false;
  let toastTimer = null;
  let editingImageData = null;
  let weekStart = dayStartOf(new Date());
  let changelogEntries = null;
  let renderedHistoryCount = 0;
  let latestRemoteVersion = "";
  let liveUpdateAvailable = false;
  let updateCheckState = "checking";
  let updateDownloadVersion = "";
  let updateDownloadPercent = 0;
  let updateInstallWaiting = false;
  let liveUpdateTimer = null;
  let versionCheckPromise = null;
  let nativeUpdateResolution = null;
  let nativeUpdateTimer = null;
  const LAYOUT_SETTINGS_KEY = "buaa_mobile_layout_v1";
  const DEFAULT_LAYOUT_SETTINGS = Object.freeze({
    safeTop: true,
    safeBottom: true,
    topExtra: 0,
    bottomExtra: 0,
    navMode: "fixed",
    fabMode: "compact",
  });
  let layoutSettings = { ...DEFAULT_LAYOUT_SETTINGS };
  let nativeSystemInsets = {
    top: null,
    bottom: null,
    left: null,
    right: null,
  };
  let syncUrl =
    localStorage.getItem(SYNC_URL_KEY) || bootstrap.syncWsUrl || "";
  if (bootstrap.syncWsUrl && !localStorage.getItem(SYNC_URL_KEY)) {
    localStorage.setItem(SYNC_URL_KEY, bootstrap.syncWsUrl);
  }
  const cloudSyncUrl = bootstrap.cloudSyncUrl || "";
  const cloudPublishableKey = bootstrap.cloudPublishableKey || "";
  let cloudVaultKey =
    localStorage.getItem(CLOUD_VAULT_KEY) || bootstrap.cloudVaultKey || "";
  let recordsStorageKey = cloudVaultKey
    ? `${STORAGE_KEY}:${cloudVaultKey}`
    : STORAGE_KEY;
  let cloudCursor = 0;
  let cloudPushRev = 0;

  function cloudCursorKey() {
    return cloudVaultKey
      ? `${CLOUD_CURSOR_KEY}:${cloudVaultKey}`
      : CLOUD_CURSOR_KEY;
  }

  function cloudPushKey() {
    return cloudVaultKey
      ? `${CLOUD_PUSH_REV_KEY}:${cloudVaultKey}`
      : CLOUD_PUSH_REV_KEY;
  }

  function loadCloudProgress() {
    cloudCursor = Number(localStorage.getItem(cloudCursorKey()) || 0) || 0;
    cloudPushRev =
      Number(localStorage.getItem(cloudPushKey()) || 0) || 0;
  }

  function saveCloudProgress() {
    localStorage.setItem(cloudCursorKey(), String(cloudCursor));
    localStorage.setItem(cloudPushKey(), String(cloudPushRev));
  }

  function resetCloudProgress() {
    cloudCursor = 0;
    cloudPushRev = 0;
    saveCloudProgress();
  }

  function normalizeVaultKey(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    const match = raw.match(/[?&#]vault=([A-Za-z0-9_-]{20,})/);
    return match ? match[1] : raw;
  }

  function switchCloudVault(nextVault) {
    const normalized = normalizeVaultKey(nextVault);
    if (!normalized || normalized === cloudVaultKey) {
      return false;
    }
    const previousVault = cloudVaultKey;
    const unpairedRecords = previousVault
      ? ""
      : localStorage.getItem(STORAGE_KEY) || "";
    cloudVaultKey = normalized;
    recordsStorageKey = `${STORAGE_KEY}:${cloudVaultKey}`;
    if (unpairedRecords && !localStorage.getItem(recordsStorageKey)) {
      localStorage.setItem(recordsStorageKey, unpairedRecords);
    }
    if (previousVault) {
      records = [];
    }
    localStorage.setItem(CLOUD_VAULT_KEY, cloudVaultKey);
    resetCloudProgress();
    return true;
  }

  const hashParams = new URLSearchParams(location.hash.replace(/^#/, ""));
  const searchParams = new URLSearchParams(location.search);
  const searchVault = normalizeVaultKey(searchParams.get("vault"));
  const hashVault = normalizeVaultKey(hashParams.get("vault"));
  const linkedVault = hashVault || searchVault;
  if (linkedVault) {
    switchCloudVault(linkedVault);
    try {
      history.replaceState(null, "", location.pathname);
    } catch {}
  }
  loadCloudProgress();

  function nextRevision(record = null) {
    return Math.max(Date.now(), Number(record?.rev || 0) + 1);
  }

  function mergeRecords(...groups) {
    const byId = new Map();
    for (const group of groups) {
      for (const record of Array.isArray(group) ? group : []) {
        if (!record || !record.id) continue;
        const normalized = {
          ...record,
          id: String(record.id),
          rev: Number(record.rev || 0),
          deleted: Boolean(record.deleted),
        };
        const existing = byId.get(normalized.id);
        if (!existing || normalized.rev >= Number(existing.rev || 0)) {
          byId.set(normalized.id, normalized);
        }
      }
    }
    return [...byId.values()];
  }

  function mondayOf(value) {
    const result = new Date(value);
    result.setHours(0, 0, 0, 0);
    const offset = (result.getDay() + 6) % 7;
    result.setDate(result.getDate() - offset);
    return result;
  }

  function dayStartOf(value) {
    const result = new Date(value);
    result.setHours(0, 0, 0, 0);
    return result;
  }

  function isGroupRecord(record) {
    return record?.record_kind === "group";
  }

  function groupRecords() {
    return records
      .filter(record => !record.deleted && isGroupRecord(record))
      .sort((left, right) =>
        String(left.title || "").localeCompare(String(right.title || ""), "zh-CN")
      );
  }

  function memoRecords() {
    return records.filter(record => !record.deleted && !isGroupRecord(record));
  }

  function groupById(groupId) {
    return records.find(
      record =>
        record.id === groupId &&
        !record.deleted &&
        isGroupRecord(record)
    );
  }

  function isHistorical(record) {
    if (isGroupRecord(record)) return false;
    if (isCompleted(record)) return true;
    const deadline = new Date(record.deadline).getTime();
    return (
      Number.isFinite(deadline) &&
      deadline + HISTORY_GRACE_MS <= Date.now()
    );
  }

  function persist() {
    try {
      if (nativeBridge) {
        const saved = nativeBridge.writeRecords(JSON.stringify(records));
        if (!saved) {
          showToast("Android 本地保存失败");
        }
        if (saved) queueReminderReschedule();
        return saved;
      }
      localStorage.setItem(recordsStorageKey, JSON.stringify(records));
      queueReminderReschedule();
      return true;
    } catch {
      showToast("浏览器未允许本地保存，请更换浏览器打开");
      return false;
    }
  }

  function loadRecords() {
    if (nativeBridge) {
      try {
        const raw = nativeBridge.readRecords();
        const loaded = raw ? JSON.parse(raw) : [];
        records = Array.isArray(loaded) ? loaded : [];
      } catch {
        records = [];
      }
      return;
    }
    let localRecords = [];
    try {
      const raw = localStorage.getItem(recordsStorageKey);
      localRecords = raw ? JSON.parse(raw) : [];
    } catch {
      localRecords = [];
    }
    records = mergeRecords(localRecords, bootstrap.seedRecords || []);
    persist();
  }

  function activeRecords() {
    return records.filter(
      record =>
        !record.deleted &&
        !isGroupRecord(record) &&
        !isHistorical(record)
    );
  }

  function historyRecords() {
    return records
      .filter(
        record =>
          !record.deleted &&
          !isGroupRecord(record) &&
          isHistorical(record)
      )
      .sort((left, right) => {
        const leftTime = new Date(left.completed_at || left.deadline || 0).getTime();
        const rightTime = new Date(right.completed_at || right.deadline || 0).getTime();
        return rightTime - leftTime;
      });
  }

  function localDateValue(date) {
    const pad = value => String(value).padStart(2, "0");
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  }

  function defaultDeadline() {
    const value = new Date(Date.now() + 24 * 60 * 60 * 1000);
    value.setHours(18, 0, 0, 0);
    dateInput.value = localDateValue(value);
    timeInput.value = "18:00";
  }

  function defaultEventTimes() {
    const start = new Date(Date.now() + 60 * 60 * 1000);
    start.setSeconds(0, 0);
    const end = new Date(start.getTime() + 2 * 60 * 60 * 1000);
    startDateInput.value = localDateValue(start);
    startTimeInput.value = `${String(start.getHours()).padStart(2, "0")}:${String(start.getMinutes()).padStart(2, "0")}`;
    endDateInput.value = localDateValue(end);
    endTimeInput.value = `${String(end.getHours()).padStart(2, "0")}:${String(end.getMinutes()).padStart(2, "0")}`;
  }

  function setEditingImage(dataUrl) {
    editingImageData = dataUrl || null;
    if (editingImageData) {
      imagePreview.src = editingImageData;
      imagePreview.style.display = "block";
      removeImageBtn.style.display = "inline-block";
    } else {
      imagePreview.removeAttribute("src");
      imagePreview.style.display = "none";
      removeImageBtn.style.display = "none";
      imageInput.value = "";
    }
  }

  async function compressImageFile(file) {
    const source = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
    const image = await new Promise((resolve, reject) => {
      const element = new Image();
      element.onload = () => resolve(element);
      element.onerror = reject;
      element.src = source;
    });
    const maxWidth = 900;
    const maxHeight = 600;
    const scale = Math.min(
      1,
      maxWidth / image.naturalWidth,
      maxHeight / image.naturalHeight
    );
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/png");
  }

  function isEvent(memo) {
    return memo?.item_type === "event";
  }

  function isCompleted(memo) {
    return Boolean(memo?.completed || memo?.completed_at);
  }

  function formatRemaining(deadlineText) {
    const deadline = new Date(deadlineText).getTime();
    const seconds = Math.floor((deadline - Date.now()) / 1000);
    if (!Number.isFinite(seconds)) return "时间无效";
    if (seconds <= 0) {
      const archiveSeconds = Math.floor(
        (deadline + HISTORY_GRACE_MS - Date.now()) / 1000
      );
      if (archiveSeconds <= 0) return "已归档";
      const archiveHours = Math.floor(archiveSeconds / 3600);
      const archiveMinutes = Math.floor((archiveSeconds % 3600) / 60);
      const archiveSecondsPart = archiveSeconds % 60;
      const pad = value => String(value).padStart(2, "0");
      return `已到期 · ${pad(archiveHours)}:${pad(archiveMinutes)}:${pad(archiveSecondsPart)} 后归档`;
    }
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    const pad = value => String(value).padStart(2, "0");
    return days > 0
      ? `${String(days).padStart(2, "0")} 天 ${pad(hours)}:${pad(minutes)}:${pad(secs)}`
      : `${pad(hours)}:${pad(minutes)}:${pad(secs)}`;
  }

  function statusOf(memo) {
    const seconds = (new Date(memo.deadline).getTime() - Date.now()) / 1000;
    if (seconds <= 0) return ["expired", isEvent(memo) ? "已结束" : "已到期"];
    if (isEvent(memo)) {
      const start = new Date(memo.start_at).getTime();
      if (Number.isFinite(start) && Date.now() < start) {
        return ["pending", "待开始"];
      }
    }
    if (seconds <= 86400) return ["urgent", "进行中"];
    return ["", "进行中"];
  }

  function setEditorType(type) {
    editorType = type === "event" ? "event" : "task";
    const isTask = editorType === "task";
    taskFields.classList.toggle("hidden", !isTask);
    eventFields.classList.toggle("hidden", isTask);
    taskTypeBtn.classList.toggle("active", isTask);
    eventTypeBtn.classList.toggle("active", !isTask);
  }

  function reminderMinutesValue() {
    const amount = Math.max(1, Number(reminderAmount.value) || 1);
    const multiplier = {
      minutes: 1,
      hours: 60,
      days: 1440,
    }[reminderUnit.value] || 1;
    return Math.round(amount * multiplier);
  }

  function reminderModesValue() {
    return [
      reminderNotify.checked ? "notification" : null,
      reminderSound.checked ? "sound" : null,
      reminderVibrate.checked ? "vibration" : null,
    ].filter(Boolean);
  }

  function reminderVolumePercent() {
    return Math.max(
      10,
      Math.min(100, Math.round(Number(reminderVolume.value) || 100))
    );
  }

  function updateReminderVolumeLabel() {
    reminderVolumeValue.textContent = `${reminderVolumePercent()}%`;
  }

  function updateReminderOptionsVisibility() {
    reminderOptions.classList.toggle("hidden", !reminderEnabled.checked);
  }

  function cancelMemoReminder(memo) {
    nativeBridge?.cancelReminder?.(memo.id);
  }

  function scheduleMemoReminder(memo) {
    if (!memo || !nativeBridge?.scheduleReminder) return;
    if (
      isGroupRecord(memo) ||
      !memo.reminder_enabled ||
      memo.deleted ||
      isCompleted(memo) ||
      isHistorical(memo)
    ) {
      cancelMemoReminder(memo);
      return;
    }
    const anchor = new Date(isEvent(memo) ? memo.start_at : memo.deadline);
    const reminderAt = new Date(
      anchor.getTime() - Number(memo.reminder_minutes || 0) * 60000
    );
    if (
      !Number.isFinite(reminderAt.getTime()) ||
      reminderAt.getTime() <= Date.now()
    ) {
      cancelMemoReminder(memo);
      return;
    }
    const modes = Array.isArray(memo.reminder_modes)
      ? memo.reminder_modes
      : [];
    if (!modes.length) {
      cancelMemoReminder(memo);
      return;
    }
    nativeBridge.scheduleReminder(
      memo.id,
      reminderAt.getTime(),
      memo.title || "BUAA浮光提醒",
      memo.note || (isEvent(memo) ? "事件即将开始" : "任务即将截止"),
      modes.includes("notification"),
      modes.includes("sound"),
      modes.includes("vibration"),
      Math.max(0.1, Math.min(1, Number(memo.reminder_volume || 100) / 100))
    );
  }

  function rescheduleAllReminders() {
    for (const memo of records) scheduleMemoReminder(memo);
  }

  function queueReminderReschedule() {
    clearTimeout(queueReminderReschedule.timer);
    queueReminderReschedule.timer = setTimeout(
      rescheduleAllReminders,
      350
    );
  }

  function formatDeadline(deadlineText) {
    const value = new Date(deadlineText);
    const pad = number => String(number).padStart(2, "0");
    return `${value.getFullYear()}-${pad(value.getMonth() + 1)}-${pad(value.getDate())}  ${pad(value.getHours())}:${pad(value.getMinutes())}`;
  }

  function showToast(message) {
    toastEl.textContent = message;
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("show"), 2300);
  }

  function clampLayoutNumber(value, minimum, maximum, fallback = 0) {
    const number = Number(value);
    if (!Number.isFinite(number)) return fallback;
    return Math.max(minimum, Math.min(maximum, Math.round(number)));
  }

  function normalizeLayoutSettings(value) {
    const source = value && typeof value === "object" ? value : {};
    return {
      safeTop: source.safeTop !== false,
      safeBottom: source.safeBottom !== false,
      topExtra: clampLayoutNumber(source.topExtra, 0, 48, 0),
      bottomExtra: clampLayoutNumber(source.bottomExtra, 0, 64, 0),
      navMode: source.navMode === "flow" ? "flow" : "fixed",
      fabMode: ["large", "inline", "compact"].includes(source.fabMode)
        ? source.fabMode
        : "compact",
    };
  }

  function loadLayoutSettings() {
    try {
      layoutSettings = normalizeLayoutSettings(
        JSON.parse(localStorage.getItem(LAYOUT_SETTINGS_KEY) || "{}")
      );
    } catch {
      layoutSettings = { ...DEFAULT_LAYOUT_SETTINGS };
    }
  }

  function saveLayoutSettings() {
    localStorage.setItem(
      LAYOUT_SETTINGS_KEY,
      JSON.stringify(layoutSettings)
    );
  }

  function syncLayoutControls() {
    if (!layoutSafeTop) return;
    layoutSafeTop.checked = layoutSettings.safeTop;
    layoutSafeBottom.checked = layoutSettings.safeBottom;
    layoutTopExtra.value = String(layoutSettings.topExtra);
    layoutBottomExtra.value = String(layoutSettings.bottomExtra);
    layoutTopExtraValue.textContent = `${layoutSettings.topExtra} px`;
    layoutBottomExtraValue.textContent = `${layoutSettings.bottomExtra} px`;
    layoutNavMode.value = layoutSettings.navMode;
    layoutFabMode.value = layoutSettings.fabMode;
  }

  function applyLayoutSettings() {
    const root = document.documentElement;
    if (nativeSystemInsets.top !== null) {
      root.style.setProperty(
        "--native-safe-top",
        `${nativeSystemInsets.top}px`
      );
    }
    if (nativeSystemInsets.bottom !== null) {
      root.style.setProperty(
        "--native-safe-bottom",
        `${nativeSystemInsets.bottom}px`
      );
    }
    if (nativeSystemInsets.left !== null) {
      root.style.setProperty(
        "--native-safe-left",
        `${nativeSystemInsets.left}px`
      );
    }
    if (nativeSystemInsets.right !== null) {
      root.style.setProperty(
        "--native-safe-right",
        `${nativeSystemInsets.right}px`
      );
    }
    root.style.setProperty(
      "--layout-top-extra",
      `${layoutSettings.topExtra}px`
    );
    root.style.setProperty(
      "--layout-bottom-extra",
      `${layoutSettings.bottomExtra}px`
    );
    document.body.classList.toggle(
      "safe-top-off",
      !layoutSettings.safeTop
    );
    document.body.classList.toggle(
      "safe-bottom-off",
      !layoutSettings.safeBottom
    );
    document.body.dataset.navMode = layoutSettings.navMode;
    document.body.dataset.fabMode = layoutSettings.fabMode;
    document.getElementById("addBtn")?.setAttribute(
      "aria-label",
      activePage === "groups" ? "新建分组" : "新建事项"
    );
    if (layoutSystemInfo) {
      const topText =
        nativeSystemInsets.top === null
          ? "浏览器自动值"
          : `${nativeSystemInsets.top} px`;
      const bottomText =
        nativeSystemInsets.bottom === null
          ? "浏览器自动值"
          : `${nativeSystemInsets.bottom} px`;
      layoutSystemInfo.textContent =
        `检测到顶部安全区：${topText}；底部安全区：${bottomText}。` +
        `自动避让${layoutSettings.safeTop ? "已开启" : "已关闭"}（顶部）、` +
        `${layoutSettings.safeBottom ? "已开启" : "已关闭"}（底部）。`;
    }
    syncLayoutControls();
  }

  function updateLayoutSettingsFromControls() {
    layoutSettings = normalizeLayoutSettings({
      safeTop: layoutSafeTop.checked,
      safeBottom: layoutSafeBottom.checked,
      topExtra: layoutTopExtra.value,
      bottomExtra: layoutBottomExtra.value,
      navMode: layoutNavMode.value,
      fabMode: layoutFabMode.value,
    });
    saveLayoutSettings();
    applyLayoutSettings();
  }

  function initLayoutSettings() {
    loadLayoutSettings();
    layoutSettingsBtn?.removeAttribute("hidden");
    layoutSettingsOverlay?.removeAttribute("hidden");
    applyLayoutSettings();
    layoutSettingsBtn?.addEventListener("click", () => {
      syncLayoutControls();
      layoutSettingsOverlay.classList.add("show");
    });
    const close = () => layoutSettingsOverlay.classList.remove("show");
    layoutSettingsCloseBtn?.addEventListener("click", close);
    layoutSettingsDoneBtn?.addEventListener("click", close);
    layoutSettingsOverlay?.addEventListener("click", event => {
      if (event.target === layoutSettingsOverlay) close();
    });
    layoutResetBtn?.addEventListener("click", () => {
      layoutSettings = { ...DEFAULT_LAYOUT_SETTINGS };
      saveLayoutSettings();
      applyLayoutSettings();
      showToast("手机排版已恢复默认");
    });
    for (const control of [
      layoutSafeTop,
      layoutSafeBottom,
      layoutTopExtra,
      layoutBottomExtra,
      layoutNavMode,
      layoutFabMode,
    ]) {
      control?.addEventListener("input", updateLayoutSettingsFromControls);
      control?.addEventListener("change", updateLayoutSettingsFromControls);
    }
  }

  window.BUAASetSystemInsets = (top, bottom, left, right) => {
    nativeSystemInsets = {
      top: Math.max(0, Number(top) || 0),
      bottom: Math.max(0, Number(bottom) || 0),
      left: Math.max(0, Number(left) || 0),
      right: Math.max(0, Number(right) || 0),
    };
    applyLayoutSettings();
  };

  function setConnectionStatus(online) {
    if (nativeBridge) {
      statusEl.classList.remove("offline");
      try {
        const info = JSON.parse(nativeBridge.getDeviceInfo() || "{}");
        statusText.textContent =
          `手机同步已开启 · ${info.ip}:${info.port}`;
      } catch {
        statusText.textContent = "手机同步已开启";
      }
      return;
    }
    statusEl.classList.toggle("offline", !online);
    statusText.textContent = online
      ? "云同步已连接 · 数据已更新"
      : cloudVaultKey
        ? "离线模式 · 数据已保存在本机"
        : "未连接同步 · 点击输入同步码";
  }

  function render() {
    if (activePage === "groups") renderGroups();
    if (
      activeGroupDetailId &&
      groupDetailOverlay.classList.contains("show")
    ) {
      renderGroupDetail();
    }
    const memos = activeRecords();
    memos.sort((left, right) => {
      const leftTime = new Date(left.deadline).getTime();
      const rightTime = new Date(right.deadline).getTime();
      const now = Date.now();
      const leftActive = leftTime > now ? 0 : 1;
      const rightActive = rightTime > now ? 0 : 1;
      return leftActive - rightActive || leftTime - rightTime;
    });

    countEl.textContent = `${memos.length} 项`;
    renderedHistoryCount = historyRecords().length;
    historyBtn.textContent = `历史 ${renderedHistoryCount}`;
    listEl.replaceChildren();

    if (!memos.length) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.innerHTML =
        '<div class="empty-clock">◷</div>还没有事项<br>现在可以先离线记录，联网后自动同步';
      listEl.appendChild(empty);
      return;
    }

    for (const memo of memos) {
      const [stateClass, badgeText] = statusOf(memo);
      const card = document.createElement("article");
      card.className = `card ${stateClass}`.trim();
      card.dataset.id = memo.id;

      const head = document.createElement("div");
      head.className = "card-head";
      const title = document.createElement("h2");
      title.className = "card-title";
      title.textContent = memo.title || "未命名事项";
      const badge = document.createElement("span");
      badge.className = "badge";
      badge.textContent = `${isEvent(memo) ? "事件" : "任务"} · ${badgeText}`;
      head.append(title, badge);
      card.appendChild(head);

      if (memo.note) {
        const note = document.createElement("div");
        note.className = "note";
        note.textContent = memo.note;
        card.appendChild(note);
      }

      const memoGroupRecord = groupById(memo.group_id);
      if (memoGroupRecord) {
        const groupChip = document.createElement("span");
        groupChip.className = "memo-group-chip";
        groupChip.textContent = `分组 · ${memoGroupRecord.title}`;
        card.appendChild(groupChip);
      }

      if (memo.image_data) {
        const image = document.createElement("img");
        image.className = "card-image";
        image.src = memo.image_data;
        image.loading = "lazy";
        image.decoding = "async";
        image.alt = memo.title || "事项图片";
        image.addEventListener("click", () => {
          imageViewerImage.src = memo.image_data;
          imageViewerOverlay.classList.add("show");
        });
        card.appendChild(image);
      }

      const meta = document.createElement("div");
      meta.className = "meta";
      const remainingLabel = document.createElement("span");
      remainingLabel.className = "meta-label";
      remainingLabel.textContent = "剩余时间";
      const remaining = document.createElement("span");
      remaining.className = "remaining";
      remaining.dataset.deadline = memo.deadline;
      remaining.textContent = formatRemaining(memo.deadline);
      let startLabel = null;
      let startValue = null;
      if (isEvent(memo)) {
        startLabel = document.createElement("span");
        startLabel.className = "meta-label";
        startLabel.textContent = "开始时间";
        startValue = document.createElement("span");
        startValue.className = "deadline";
        startValue.textContent = formatDeadline(memo.start_at);
      }
      const deadlineLabel = document.createElement("span");
      deadlineLabel.className = "meta-label";
      deadlineLabel.textContent = isEvent(memo) ? "结束时间" : "终止时间";
      const deadline = document.createElement("span");
      deadline.className = "deadline";
      deadline.textContent = formatDeadline(memo.deadline);
      meta.append(remainingLabel, remaining);
      if (startLabel && startValue) meta.append(startLabel, startValue);
      meta.append(deadlineLabel, deadline);
      card.appendChild(meta);

      const actions = document.createElement("div");
      actions.className = "actions";
      const editButton = document.createElement("button");
      editButton.className = "action-btn";
      editButton.textContent = "编辑";
      editButton.addEventListener("click", () => openEditor(memo.id));
      actions.append(editButton);
      if (!isEvent(memo)) {
        const completeButton = document.createElement("button");
        completeButton.className = "action-btn complete";
        completeButton.textContent = "✓ 完成";
        completeButton.addEventListener("click", () => completeMemo(memo.id));
        actions.append(completeButton);
      }
      const deleteButton = document.createElement("button");
      deleteButton.className = "action-btn delete";
      deleteButton.textContent = "删除";
      deleteButton.addEventListener("click", () => deleteMemo(memo.id));
      actions.append(deleteButton);
      card.appendChild(actions);
      listEl.appendChild(card);
    }
  }

  function refreshMemoGroupOptions(selectedId = "") {
    const current = selectedId || memoGroup.value;
    memoGroup.replaceChildren();
    const none = document.createElement("option");
    none.value = "";
    none.textContent = "不分组";
    memoGroup.appendChild(none);
    for (const group of groupRecords()) {
      const option = document.createElement("option");
      option.value = group.id;
      option.textContent = group.title;
      memoGroup.appendChild(option);
    }
    memoGroup.value = groupById(current) ? current : "";
  }

  function setPage(page) {
    activePage = page === "groups" ? "groups" : "memos";
    memosPage.classList.toggle("active", activePage === "memos");
    groupsPage.classList.toggle("active", activePage === "groups");
    memosTabBtn.classList.toggle("active", activePage === "memos");
    groupsTabBtn.classList.toggle("active", activePage === "groups");
    const addButton = document.getElementById("addBtn");
    addButton.textContent =
      activePage === "groups" ? "＋ 新建分组" : "＋ 新建事项";
    addButton.setAttribute(
      "aria-label",
      activePage === "groups" ? "新建分组" : "新建事项"
    );
    if (activePage === "groups") renderGroups();
  }

  function renderGroups() {
    const groups = groupRecords();
    groupCount.textContent = `${groups.length} 组`;
    groupList.replaceChildren();
    if (!groups.length) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.innerHTML =
        '<div class="empty-clock">▦</div>还没有分组<br>新建分组后，可把已有事项加入其中';
      groupList.appendChild(empty);
      return;
    }
    for (const group of groups) {
      const items = memoRecords()
        .filter(memo => memo.group_id === group.id)
        .sort((left, right) => {
          const leftTime = new Date(left.deadline || 0).getTime();
          const rightTime = new Date(right.deadline || 0).getTime();
          return leftTime - rightTime;
        });
      const card = document.createElement("article");
      card.className = "group-card";

      const head = document.createElement("div");
      head.className = "group-card-head";
      const title = document.createElement("h2");
      title.textContent = group.title || "未命名分组";
      const count = document.createElement("span");
      count.className = "group-count";
      count.textContent = `${items.length} 项`;
      head.append(title, count);
      card.appendChild(head);

      if (group.note) {
        const intro = document.createElement("p");
        intro.className = "group-description";
        intro.textContent = group.note;
        card.appendChild(intro);
      }

      const itemBox = document.createElement("div");
      itemBox.className = "group-items";
      if (!items.length) {
        const text = document.createElement("div");
        text.className = "group-empty-items";
        text.textContent = "暂无事项，可在编辑分组时添加。";
        itemBox.appendChild(text);
      } else {
        for (const memo of items.slice(0, 6)) {
          const line = document.createElement("div");
          line.className = "group-item-line";
          const typeText = isEvent(memo)
            ? "事件"
            : isCompleted(memo)
              ? "已完成"
              : isHistorical(memo)
                ? "历史"
                : "任务";
          line.textContent = `${memo.title || "未命名事项"} · ${typeText}`;
          itemBox.appendChild(line);
        }
        if (items.length > 6) {
          const more = document.createElement("div");
          more.className = "group-empty-items";
          more.textContent = `还有 ${items.length - 6} 项`;
          itemBox.appendChild(more);
        }
      }
      card.appendChild(itemBox);

      const actions = document.createElement("div");
      actions.className = "actions";
      const view = document.createElement("button");
      view.className = "action-btn";
      view.textContent = "查看事项";
      view.addEventListener("click", () => openGroupDetail(group.id));
      const edit = document.createElement("button");
      edit.className = "action-btn";
      edit.textContent = "编辑分组";
      edit.addEventListener("click", () => openGroupEditor(group.id));
      const remove = document.createElement("button");
      remove.className = "action-btn delete";
      remove.textContent = "删除分组";
      remove.addEventListener("click", () => deleteGroup(group.id));
      actions.append(view, edit, remove);
      card.appendChild(actions);
      groupList.appendChild(card);
    }
  }

  function openGroupEditor(groupId = null) {
    editingGroupId = groupId;
    const group = groupId
      ? records.find(
          record =>
            record.id === groupId &&
            !record.deleted &&
            isGroupRecord(record)
        )
      : null;
    groupFormTitle.textContent = group ? "编辑分组" : "新建分组";
    groupNameInput.value = group ? group.title : "";
    groupIntroInput.value = group ? (group.note || "") : "";
    groupMemoChoices.replaceChildren();
    const memos = memoRecords().sort((left, right) =>
      String(left.title || "").localeCompare(String(right.title || ""), "zh-CN")
    );
    if (!memos.length) {
      const empty = document.createElement("div");
      empty.className = "group-empty-items";
      empty.textContent = "目前没有可添加的事项";
      groupMemoChoices.appendChild(empty);
    } else {
      for (const memo of memos) {
        const label = document.createElement("label");
        label.className = "group-choice";
        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.value = memo.id;
        checkbox.checked = Boolean(group && memo.group_id === group.id);
        const text = document.createElement("span");
        text.textContent = memo.title || "未命名事项";
        const meta = document.createElement("span");
        meta.className = "group-choice-meta";
        meta.textContent = isCompleted(memo)
          ? "已完成"
          : isHistorical(memo)
            ? "历史"
            : isEvent(memo)
              ? "事件"
              : "任务";
        label.append(checkbox, text, meta);
        groupMemoChoices.appendChild(label);
      }
    }
    groupOverlay.classList.add("show");
    setTimeout(() => groupNameInput.focus(), 80);
  }

  function closeGroupEditor() {
    groupOverlay.classList.remove("show");
    editingGroupId = null;
  }

  function deleteGroup(groupId) {
    const group = records.find(
      record =>
        record.id === groupId &&
        !record.deleted &&
        isGroupRecord(record)
    );
    if (
      !group ||
      !confirm(
        `确定删除分组「${group.title}」吗？组内事项不会被删除，只会变成未分组。`
      )
    ) {
      return;
    }
    const now = new Date().toISOString();
    group.deleted = true;
    group.rev = nextRevision(group);
    group.updated_at = now;
    for (const memo of memoRecords()) {
      if (memo.group_id !== groupId) continue;
      memo.group_id = null;
      memo.rev = nextRevision(memo);
      memo.updated_at = now;
    }
    persist();
    render();
    renderGroups();
    showToast("分组已删除，组内事项已保留");
    syncNow();
  }

  function groupItemState(memo) {
    if (isCompleted(memo)) return ["已完成", "completed"];
    const deadline = new Date(memo.deadline).getTime();
    if (!Number.isFinite(deadline)) return ["时间无效", "expired"];
    if (deadline <= Date.now()) {
      if (deadline + HISTORY_GRACE_MS > Date.now()) {
        return [
          isEvent(memo) ? "已结束 · 待归档" : "已到期 · 待归档",
          "expired",
        ];
      }
      return ["已归档", "expired"];
    }
    if (isEvent(memo)) {
      const start = new Date(memo.start_at).getTime();
      if (Number.isFinite(start) && Date.now() < start) {
        return ["待开始", ""];
      }
    }
    if (deadline - Date.now() <= 86400000) {
      return ["24 小时内", ""];
    }
    return ["进行中", ""];
  }

  function renderGroupDetail() {
    if (!activeGroupDetailId) return;
    const group = groupById(activeGroupDetailId);
    if (!group) {
      closeGroupDetail();
      return;
    }
    const items = memoRecords()
      .filter(memo => memo.group_id === group.id)
      .sort((left, right) => {
        const leftHistorical = isHistorical(left) ? 1 : 0;
        const rightHistorical = isHistorical(right) ? 1 : 0;
        return (
          leftHistorical - rightHistorical ||
          new Date(left.deadline || 0).getTime() -
            new Date(right.deadline || 0).getTime()
        );
      });
    const activeCount = items.filter(memo => !isHistorical(memo)).length;
    groupDetailTitle.textContent = group.title || "分组事项";
    groupDetailIntro.textContent =
      `${group.note ? `${group.note}\n` : ""}` +
      `共 ${items.length} 项 · ${activeCount} 项未结束`;
    groupDetailList.replaceChildren();
    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.innerHTML =
        '<div class="empty-clock">◷</div>这个分组还没有事项<br>可在编辑分组时添加已有事项';
      groupDetailList.appendChild(empty);
      return;
    }
    for (const memo of items) {
      const [stateText, stateClass] = groupItemState(memo);
      const card = document.createElement("article");
      card.className = "group-detail-card";
      const head = document.createElement("div");
      head.className = "group-detail-head";
      const title = document.createElement("h3");
      title.textContent = memo.title || "未命名事项";
      const state = document.createElement("span");
      state.className = `group-detail-state ${stateClass}`.trim();
      state.textContent = stateText;
      head.append(title, state);
      card.appendChild(head);
      if (memo.note) {
        const note = document.createElement("div");
        note.className = "group-detail-note";
        note.textContent = memo.note;
        card.appendChild(note);
      }
      const meta = document.createElement("div");
      meta.className = "group-detail-meta";
      const addMeta = (label, value) => {
        const key = document.createElement("span");
        key.textContent = label;
        const content = document.createElement("span");
        content.textContent = value;
        meta.append(key, content);
      };
      addMeta("事项类型", isEvent(memo) ? "事件型" : "任务型");
      addMeta("当前状态", stateText);
      if (!isHistorical(memo)) {
        const remaining = document.createElement("span");
        remaining.className = "remaining";
        remaining.dataset.deadline = memo.deadline;
        remaining.textContent = formatRemaining(memo.deadline);
        const remainingLabel = document.createElement("span");
        remainingLabel.textContent = "剩余时间";
        meta.append(remainingLabel, remaining);
      }
      if (isEvent(memo)) {
        addMeta("开始时间", formatDeadline(memo.start_at));
      }
      addMeta(isEvent(memo) ? "结束时间" : "终止时间", formatDeadline(memo.deadline));
      if (memo.completed_at) {
        addMeta("完成时间", formatDeadline(memo.completed_at));
      }
      card.appendChild(meta);
      if (memo.image_data) {
        const image = document.createElement("img");
        image.className = "group-detail-image";
        image.src = memo.image_data;
        image.alt = memo.title || "事项图片";
        image.addEventListener("click", () => {
          imageViewerImage.src = memo.image_data;
          imageViewerOverlay.classList.add("show");
        });
        card.appendChild(image);
      }
      const actions = document.createElement("div");
      actions.className = "group-detail-actions";
      if (!isHistorical(memo)) {
        const edit = document.createElement("button");
        edit.className = "action-btn";
        edit.textContent = "编辑事项";
        edit.addEventListener("click", () => {
          closeGroupDetail();
          openEditor(memo.id);
        });
        actions.appendChild(edit);
      }
      if (actions.childElementCount) card.appendChild(actions);
      groupDetailList.appendChild(card);
    }
  }

  function openGroupDetail(groupId) {
    activeGroupDetailId = groupId;
    groupDetailOverlay.classList.add("show");
    renderGroupDetail();
  }

  function closeGroupDetail() {
    groupDetailOverlay.classList.remove("show");
    activeGroupDetailId = null;
  }

  function updateCountdowns() {
    document.querySelectorAll(".remaining[data-deadline]").forEach(element => {
      element.textContent = formatRemaining(element.dataset.deadline);
    });
    document.querySelectorAll(".card").forEach(card => {
      const memo = records.find(record => record.id === card.dataset.id);
      if (!memo) return;
      const [stateClass, badgeText] = statusOf(memo);
      card.classList.remove("urgent", "expired");
      card.classList.remove("pending");
      if (stateClass) card.classList.add(stateClass);
      const badge = card.querySelector(".badge");
      if (badge) {
        badge.textContent = `${isEvent(memo) ? "事件" : "任务"} · ${badgeText}`;
      }
    });
    if (historyRecords().length !== renderedHistoryCount) {
      render();
    }
  }

  function openEditor(memoId = null) {
    editingId = memoId;
    const memo = memoId
      ? records.find(record => record.id === memoId && !record.deleted)
      : null;
    formTitle.textContent = memo ? "编辑事项" : "新建事项";
    titleInput.value = memo ? memo.title : "";
    noteInput.value = memo ? (memo.note || "") : "";
    refreshMemoGroupOptions(memo?.group_id || "");
    setEditingImage(memo ? memo.image_data : null);
    setEditorType(memo && isEvent(memo) ? "event" : "task");
    const reminderMinutes = Math.max(
      1,
      Number(memo?.reminder_minutes || 15)
    );
    reminderEnabled.checked = Boolean(memo?.reminder_enabled);
    if (reminderMinutes % 1440 === 0) {
      reminderAmount.value = reminderMinutes / 1440;
      reminderUnit.value = "days";
    } else if (reminderMinutes % 60 === 0) {
      reminderAmount.value = reminderMinutes / 60;
      reminderUnit.value = "hours";
    } else {
      reminderAmount.value = reminderMinutes;
      reminderUnit.value = "minutes";
    }
    const modes = Array.isArray(memo?.reminder_modes)
      ? memo.reminder_modes
      : ["notification"];
    reminderNotify.checked = modes.includes("notification");
    reminderSound.checked = modes.includes("sound");
    reminderVibrate.checked = modes.includes("vibration");
    reminderVolume.value = String(
      Math.max(10, Math.min(100, Number(memo?.reminder_volume || 100)))
    );
    updateReminderVolumeLabel();
    updateReminderOptionsVisibility();
    if (memo) {
      const value = new Date(memo.deadline);
      if (isEvent(memo)) {
        const start = new Date(memo.start_at);
        startDateInput.value = localDateValue(start);
        startTimeInput.value = `${String(start.getHours()).padStart(2, "0")}:${String(start.getMinutes()).padStart(2, "0")}`;
        endDateInput.value = localDateValue(value);
        endTimeInput.value = `${String(value.getHours()).padStart(2, "0")}:${String(value.getMinutes()).padStart(2, "0")}`;
      } else {
        dateInput.value = localDateValue(value);
        timeInput.value = `${String(value.getHours()).padStart(2, "0")}:${String(value.getMinutes()).padStart(2, "0")}`;
      }
    } else {
      defaultDeadline();
      defaultEventTimes();
    }
    overlay.classList.add("show");
    setTimeout(() => titleInput.focus(), 80);
  }

  function closeEditor() {
    overlay.classList.remove("show");
    editingId = null;
    setEditingImage(null);
  }

  function deleteMemo(memoId) {
    const memo = records.find(record => record.id === memoId);
    if (!memo || !confirm(`确定删除「${memo.title}」吗？`)) return;
    memo.deleted = true;
    memo.rev = nextRevision(memo);
    memo.updated_at = new Date().toISOString();
    persist();
    render();
    showToast("已删除，联网后同步");
    syncNow();
  }

  let waterAudioContext = null;

  function playWaterSinkSound() {
    try {
      const AudioContextClass =
        window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return;
      if (!waterAudioContext) {
        waterAudioContext = new AudioContextClass();
      }
      const context = waterAudioContext;
      if (context.state === "suspended") {
        context.resume().catch(() => {});
      }
      const now = context.currentTime + 0.015;

      const drop = context.createOscillator();
      const dropGain = context.createGain();
      drop.type = "sine";
      drop.frequency.setValueAtTime(520, now);
      drop.frequency.exponentialRampToValueAtTime(165, now + 0.28);
      dropGain.gain.setValueAtTime(0.0001, now);
      dropGain.gain.exponentialRampToValueAtTime(0.16, now + 0.018);
      dropGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.42);
      drop.connect(dropGain).connect(context.destination);
      drop.start(now);
      drop.stop(now + 0.44);

      const bubble = context.createOscillator();
      const bubbleGain = context.createGain();
      bubble.type = "sine";
      bubble.frequency.setValueAtTime(760, now + 0.12);
      bubble.frequency.exponentialRampToValueAtTime(330, now + 0.34);
      bubbleGain.gain.setValueAtTime(0.0001, now + 0.12);
      bubbleGain.gain.exponentialRampToValueAtTime(0.045, now + 0.15);
      bubbleGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.42);
      bubble.connect(bubbleGain).connect(context.destination);
      bubble.start(now + 0.12);
      bubble.stop(now + 0.44);

      const noiseLength = Math.round(context.sampleRate * 0.38);
      const noiseBuffer = context.createBuffer(
        1,
        noiseLength,
        context.sampleRate
      );
      const noiseData = noiseBuffer.getChannelData(0);
      for (let index = 0; index < noiseLength; index += 1) {
        noiseData[index] = (Math.random() * 2 - 1) * 0.32;
      }
      const noise = context.createBufferSource();
      const filter = context.createBiquadFilter();
      const noiseGain = context.createGain();
      noise.buffer = noiseBuffer;
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(920, now);
      filter.frequency.exponentialRampToValueAtTime(240, now + 0.36);
      noiseGain.gain.setValueAtTime(0.032, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.38);
      noise.connect(filter).connect(noiseGain).connect(context.destination);
      noise.start(now);
    } catch {
      // Sound is optional; completion still works when audio is unavailable.
    }
  }

  function animateMemoSink(card) {
    if (!card) return;
    const rect = card.getBoundingClientRect();
    const ghost = card.cloneNode(true);
    ghost.classList.add("sinking-ghost");
    ghost.removeAttribute("id");
    ghost.setAttribute("aria-hidden", "true");
    ghost.inert = true;
    Object.assign(ghost.style, {
      left: `${rect.left}px`,
      top: `${rect.top}px`,
      width: `${rect.width}px`,
      height: `${rect.height}px`,
    });
    document.body.appendChild(ghost);
    requestAnimationFrame(() => ghost.classList.add("sinking"));
    setTimeout(() => ghost.remove(), 1050);
  }

  function completeMemo(memoId) {
    const memo = records.find(record => record.id === memoId);
    if (
      !memo ||
      isEvent(memo) ||
      isCompleted(memo) ||
      memo.__completing
    ) {
      return;
    }
    if (!confirm(`将「${memo.title}」标记为已完成？`)) return;
    memo.__completing = true;
    const card = Array.from(listEl.querySelectorAll(".card")).find(
      item => item.dataset.id === memoId
    );
    try {
      animateMemoSink(card);
    } catch {
      // Completion must never depend on the visual effect.
    }
    playWaterSinkSound();

    const now = new Date().toISOString();
    memo.completed = true;
    memo.completed_at = now;
    memo.updated_at = now;
    memo.rev = nextRevision(memo);
    delete memo.__completing;
    persist();
    render();
    showToast("任务已完成，如浮光沉入水面");
    syncNow();
  }

  function renderHistory() {
    historyList.replaceChildren();
    const items = historyRecords();
    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.textContent = "暂无历史事项";
      historyList.appendChild(empty);
      return;
    }
    for (const memo of items) {
      const row = document.createElement("article");
      row.className = "history-row";
      const title = document.createElement("h3");
      title.textContent = memo.title || "未命名事项";
      row.appendChild(title);
      const meta = document.createElement("div");
      meta.className = "history-meta";
      if (isEvent(memo)) {
        meta.textContent =
          `事件 · 开始 ${formatDeadline(memo.start_at)} · 结束 ${formatDeadline(memo.deadline)}`;
      } else if (isCompleted(memo)) {
        meta.textContent =
          `任务 · 已完成于 ${memo.completed_at ? formatDeadline(memo.completed_at) : "未知"}\n截止 ${formatDeadline(memo.deadline)}`;
      } else {
        meta.textContent = `任务 · 已过期 ${formatDeadline(memo.deadline)}`;
      }
      row.appendChild(meta);
      if (memo.image_data) {
        const image = document.createElement("img");
        image.className = "card-image";
        image.src = memo.image_data;
        row.appendChild(image);
      }
      const actions = document.createElement("div");
      actions.className = "history-actions";
      const remove = document.createElement("button");
      remove.className = "action-btn delete";
      remove.textContent = "删除";
      remove.addEventListener("click", () => {
        deleteMemo(memo.id);
        renderHistory();
      });
      actions.appendChild(remove);
      row.appendChild(actions);
      historyList.appendChild(row);
    }
  }

  function openHistory() {
    renderHistory();
    historyOverlay.classList.add("show");
  }

  function drawWeekView() {
    const headerContext = weekHeaderCanvas.getContext("2d");
    const context = weekCanvas.getContext("2d");
    const scroller = weekOverlay.querySelector(".week-scroll");
    const width = Math.max(280, Math.floor(scroller?.clientWidth || 340));
    const axisWidth = width < 350 ? 42 : 48;
    const headerHeight = 54;
    const dayWidth = (width - axisWidth) / 3;
    const totalHeight = Math.max(1, Math.floor((scroller?.clientHeight || 576) - 1));
    const hourHeight = totalHeight / 24;
    const pixelRatio = Math.min(3, Math.max(1, window.devicePixelRatio || 1));

    weekHeaderCanvas.style.width = `${width}px`;
    weekHeaderCanvas.style.height = `${headerHeight}px`;
    weekHeaderCanvas.width = Math.round(width * pixelRatio);
    weekHeaderCanvas.height = Math.round(headerHeight * pixelRatio);
    headerContext.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    headerContext.imageSmoothingEnabled = true;
    headerContext.imageSmoothingQuality = "high";

    weekCanvas.style.width = `${width}px`;
    weekCanvas.style.height = `${totalHeight}px`;
    weekCanvas.width = Math.round(width * pixelRatio);
    weekCanvas.height = Math.round(totalHeight * pixelRatio);
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = "high";
    context.fillStyle = "#ffffff";
    context.fillRect(0, 0, width, totalHeight);
    headerContext.fillStyle = "#ffffff";
    headerContext.fillRect(0, 0, width, headerHeight);
    weekTitle.textContent =
      `连续三天 · ${localDateValue(weekStart)} — ${localDateValue(new Date(weekStart.getTime() + 2 * 86400000))}`;

    const weekdays = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"];
    const today = new Date();
    for (let index = 0; index < 3; index++) {
      const date = new Date(weekStart.getTime() + index * 86400000);
      const x = axisWidth + index * dayWidth;
      const isToday = localDateValue(date) === localDateValue(today);
      const dayBackground = isToday ? "#eaf3ff" : "#ffffff";
      context.fillStyle = dayBackground;
      context.fillRect(x, 0, dayWidth, totalHeight);
      headerContext.fillStyle = dayBackground;
      headerContext.fillRect(x, 0, dayWidth, headerHeight);

      headerContext.fillStyle = isToday ? "#1e66d0" : "#172033";
      headerContext.font = "bold 15px sans-serif";
      headerContext.textAlign = "center";
      headerContext.fillText(weekdays[(date.getDay() + 6) % 7], x + dayWidth / 2, 22);
      headerContext.font = "12px sans-serif";
      headerContext.fillText(
        `${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")}`,
        x + dayWidth / 2,
        42
      );

      context.strokeStyle = "#afc1d6";
      context.lineWidth = 2;
      context.beginPath();
      context.moveTo(x, 0);
      context.lineTo(x, totalHeight);
      context.stroke();
      headerContext.strokeStyle = "#afc1d6";
      headerContext.lineWidth = 2;
      headerContext.beginPath();
      headerContext.moveTo(x, 0);
      headerContext.lineTo(x, headerHeight);
      headerContext.stroke();
    }
    context.strokeStyle = "#afc1d6";
    context.beginPath();
    context.moveTo(width - 1, 0);
    context.lineTo(width - 1, totalHeight);
    context.stroke();
    headerContext.strokeStyle = "#afc1d6";
    headerContext.beginPath();
    headerContext.moveTo(width - 1, 0);
    headerContext.lineTo(width - 1, headerHeight);
    headerContext.stroke();

    for (let hour = 0; hour <= 24; hour++) {
      const y = hour * hourHeight;
      context.strokeStyle = hour % 6 === 0 ? "#c4d1e0" : "#e8eef6";
      context.lineWidth = hour % 6 === 0 ? 2 : 1;
      context.beginPath();
      context.moveTo(axisWidth, y);
      context.lineTo(width, y);
      context.stroke();
      const labelInterval = hourHeight < 14 ? 6 : hourHeight < 20 ? 3 : 2;
      if (hour % labelInterval === 0 || hour === 24) {
        context.fillStyle = "#6d7d91";
        context.textAlign = "right";
        context.font = hour % 6 === 0 ? "bold 11px sans-serif" : "11px sans-serif";
        const labelY = hour === 0 ? y + 11 : hour === 24 ? y - 5 : y + 4;
        context.fillText(
          hour === 24 ? "23:59" : `${String(hour).padStart(2, "0")}:00`,
          axisWidth - 7,
          labelY
        );
      }
    }

    const weekEnd = new Date(weekStart.getTime() + 3 * 86400000);
    for (const memo of records.filter(
      item =>
        !item.deleted &&
        !isGroupRecord(item) &&
        !isHistorical(item)
    )) {
      const end = new Date(memo.deadline);
      if (isEvent(memo)) {
        const start = new Date(memo.start_at);
        for (let index = 0; index < 3; index++) {
          const dayStart = new Date(weekStart.getTime() + index * 86400000);
          const dayEnd = new Date(dayStart.getTime() + 86400000);
          const begin = Math.max(start.getTime(), dayStart.getTime());
          const finish = Math.min(end.getTime(), dayEnd.getTime());
          if (finish <= begin) continue;
          const x = axisWidth + index * dayWidth + 4;
          const y = ((begin - dayStart.getTime()) / 3600000) * hourHeight;
          const bottom = ((finish - dayStart.getTime()) / 3600000) * hourHeight;
          context.fillStyle = "#d7e8ff";
          context.strokeStyle = "#6e9ed9";
          context.fillRect(x, y, dayWidth - 8, Math.max(3, bottom - y));
          context.strokeRect(x, y, dayWidth - 8, Math.max(3, bottom - y));
          if (bottom - y >= 22) {
            context.fillStyle = "#174a8c";
            context.textAlign = "left";
            context.font = "bold 11px sans-serif";
            context.fillText(memo.title || "事件", x + 3, y + 14, dayWidth - 14);
          }
        }
      } else if (end >= weekStart && end < weekEnd) {
        const index = Math.floor((end.getTime() - weekStart.getTime()) / 86400000);
        const dayStart = new Date(weekStart.getTime() + index * 86400000);
        const taskWidth = Math.min(60, dayWidth - 10);
        const taskHeight = Math.max(20, Math.min(26, hourHeight));
        const x = axisWidth + index * dayWidth + (dayWidth - taskWidth) / 2;
        const center = ((end.getTime() - dayStart.getTime()) / 3600000) * hourHeight;
        context.fillStyle = "#e3f6ec";
        context.strokeStyle = "#247a55";
        context.fillRect(x, center - taskHeight / 2, taskWidth, taskHeight);
        context.strokeRect(x, center - taskHeight / 2, taskWidth, taskHeight);
        context.fillStyle = "#176344";
        context.textAlign = "center";
        context.font = "bold 11px sans-serif";
        context.fillText(memo.title || "任务", x + taskWidth / 2, center + 4, taskWidth - 8);
      }
    }

    const now = new Date();
    const todayIndex = Math.floor(
      (new Date(localDateValue(now)).getTime() - weekStart.getTime()) / 86400000
    );
    if (todayIndex >= 0 && todayIndex < 3) {
      const y = ((now.getHours() * 60 + now.getMinutes()) / 60) * hourHeight;
      context.strokeStyle = "#d64a4a";
      context.lineWidth = 2;
      context.beginPath();
      context.moveTo(axisWidth + todayIndex * dayWidth + 2, y);
      context.lineTo(axisWidth + (todayIndex + 1) * dayWidth - 2, y);
      context.stroke();
    }
  }

  function openWeekView() {
    nativeBridge?.setLandscape?.(false);
    weekStart = dayStartOf(new Date());
    weekOverlay.classList.add("show");
    setTimeout(() => {
      drawWeekView();
    }, 80);
  }

  function shiftWeek(days) {
    weekStart = new Date(weekStart.getTime() + days * 86400000);
    drawWeekView();
  }

  function closeWeekView() {
    weekOverlay.classList.remove("show");
    nativeBridge?.setLandscape?.(false);
  }

  async function openChangelog() {
    if (!changelogEntries && bootstrap.changelog) {
      changelogEntries = bootstrap.changelog;
    }
    if (!changelogEntries) {
      try {
        const response = await fetch("./changelog.json", { cache: "no-store" });
        if (response.ok) {
          changelogEntries = await response.json();
        }
      } catch {}
    }
    if (!changelogEntries) {
      changelogEntries = {
        current_version: bootstrap.mobileVersion || "3.1.0",
        entries: [],
      };
    }
    versionBtn.textContent = `v${changelogEntries.current_version || "3.1.0"}`;
    changelogList.replaceChildren();
    for (const entry of changelogEntries.entries || []) {
      const card = document.createElement("article");
      card.className = "version-history-entry";
      const head = document.createElement("div");
      head.className = "version-entry-head";
      const title = document.createElement("h3");
      title.textContent = `v${entry.version} · ${entry.title || "版本更新"}`;
      const time = document.createElement("time");
      time.textContent = entry.date || "";
      head.append(title, time);
      const list = document.createElement("ul");
      for (const change of entry.changes || []) {
        const item = document.createElement("li");
        item.textContent = change;
        list.appendChild(item);
      }
      card.append(head, list);
      changelogList.appendChild(card);
    }
    changelogOverlay.classList.add("show");
  }

  form.addEventListener("submit", event => {
    event.preventDefault();
    const title = titleInput.value.trim();
    if (!title) {
      showToast("请填写事项名称");
      return;
    }
    if (
      editorType === "event"
        ? (!startDateInput.value || !startTimeInput.value || !endDateInput.value || !endTimeInput.value)
        : (!dateInput.value || !timeInput.value)
    ) {
      showToast(editorType === "event" ? "请选择事件开始和结束时间" : "请选择截止时间");
      return;
    }
    const deadline = editorType === "event"
      ? `${endDateInput.value}T${endTimeInput.value}:00`
      : `${dateInput.value}T${timeInput.value}:00`;
    const startAt = editorType === "event"
      ? `${startDateInput.value}T${startTimeInput.value}:00`
      : null;
    if (new Date(deadline).getTime() <= Date.now()) {
      showToast("结束时间需要晚于现在");
      return;
    }
    if (
      editorType === "event" &&
      new Date(startAt).getTime() >= new Date(deadline).getTime()
    ) {
      showToast("事件开始时间需要早于结束时间");
      return;
    }
    const reminderMinutes = reminderMinutesValue();
    const reminderModes = reminderModesValue();
    const reminderVolumePercentValue = reminderVolumePercent();
    if (reminderEnabled.checked && !reminderModes.length) {
      showToast("请至少选择一种提醒方式");
      return;
    }
    const reminderAnchor = new Date(
      editorType === "event" ? startAt : deadline
    );
    const reminderAt = new Date(
      reminderAnchor.getTime() - reminderMinutes * 60000
    );
    if (
      reminderEnabled.checked &&
      reminderAt.getTime() <= Date.now()
    ) {
      showToast("提前通知时间已经过去，请缩短提前时间");
      return;
    }
    const selectedGroupId = groupById(memoGroup.value)
      ? memoGroup.value
      : null;

    const now = new Date().toISOString();
    let memo = editingId
      ? records.find(record => record.id === editingId)
      : null;
    if (memo) {
      memo.title = title;
      memo.note = noteInput.value.trim();
      memo.item_type = editorType;
      memo.start_at = startAt;
      memo.deadline = deadline;
      memo.group_id = selectedGroupId;
      memo.reminder_enabled = reminderEnabled.checked;
      memo.reminder_minutes = reminderMinutes;
      memo.reminder_modes = reminderModes;
      memo.reminder_volume = reminderVolumePercentValue;
      memo.reminder_at = reminderEnabled.checked
        ? reminderAt.toISOString()
        : null;
      memo.image_data = editingImageData;
      if (editorType === "event") {
        memo.completed = false;
        memo.completed_at = null;
      }
      memo.deleted = false;
      memo.rev = nextRevision(memo);
      memo.updated_at = now;
    } else {
      memo = {
        id:
          crypto.randomUUID?.() ||
          `m-${Date.now()}-${Math.random().toString(16).slice(2)}`,
        title,
        note: noteInput.value.trim(),
        item_type: editorType,
        start_at: startAt,
        deadline,
        group_id: selectedGroupId,
        completed: false,
        completed_at: null,
        reminder_enabled: reminderEnabled.checked,
        reminder_minutes: reminderMinutes,
        reminder_modes: reminderModes,
        reminder_volume: reminderVolumePercentValue,
        reminder_at: reminderEnabled.checked ? reminderAt.toISOString() : null,
        image_data: editingImageData,
        created_at: now,
        updated_at: now,
        rev: nextRevision(),
        deleted: false,
        image: null,
      };
      records.push(memo);
    }
    persist();
    closeEditor();
    render();
    showToast("已保存到手机，联网后自动同步");
    syncNow();
  });

  groupForm.addEventListener("submit", event => {
    event.preventDefault();
    const name = groupNameInput.value.trim();
    const intro = groupIntroInput.value.trim();
    if (!name) {
      showToast("请填写分组名称");
      return;
    }
    const duplicate = groupRecords().find(
      group =>
        group.id !== editingGroupId &&
        String(group.title || "").trim().toLocaleLowerCase("zh-CN") ===
          name.toLocaleLowerCase("zh-CN")
    );
    if (duplicate) {
      showToast("已经有同名分组，请换一个名称");
      return;
    }

    const now = new Date().toISOString();
    let group = editingGroupId
      ? records.find(
          record =>
            record.id === editingGroupId &&
            !record.deleted &&
            isGroupRecord(record)
        )
      : null;
    if (group) {
      group.title = name;
      group.note = intro;
      group.rev = nextRevision(group);
      group.updated_at = now;
    } else {
      group = {
        id:
          crypto.randomUUID?.() ||
          `g-${Date.now()}-${Math.random().toString(16).slice(2)}`,
        record_kind: "group",
        title: name,
        note: intro,
        created_at: now,
        updated_at: now,
        rev: nextRevision(),
        deleted: false,
      };
      records.push(group);
    }

    const selectedIds = new Set(
      [...groupMemoChoices.querySelectorAll('input[type="checkbox"]:checked')]
        .map(input => input.value)
    );
    for (const memo of memoRecords()) {
      const shouldBelongToGroup = selectedIds.has(memo.id);
      if (shouldBelongToGroup && memo.group_id !== group.id) {
        memo.group_id = group.id;
        memo.rev = nextRevision(memo);
        memo.updated_at = now;
      } else if (!shouldBelongToGroup && memo.group_id === group.id) {
        memo.group_id = null;
        memo.rev = nextRevision(memo);
        memo.updated_at = now;
      }
    }
    persist();
    closeGroupEditor();
    render();
    setPage("groups");
    renderGroups();
    showToast("分组已保存，联网后自动同步");
    syncNow();
  });

  taskTypeBtn.addEventListener("click", () => setEditorType("task"));
  eventTypeBtn.addEventListener("click", () => setEditorType("event"));
  reminderEnabled.addEventListener("change", updateReminderOptionsVisibility);
  reminderVolume.addEventListener("input", updateReminderVolumeLabel);
  testReminderBtn.addEventListener("click", () => {
    const modes = reminderModesValue();
    if (!modes.length) {
      showToast("请至少选择一种提醒方式");
      return;
    }
    if (!nativeBridge?.testReminder) {
      showToast("测试提醒功能需要在 Android App 中使用");
      return;
    }
    nativeBridge.testReminder(
      modes.includes("notification"),
      modes.includes("sound"),
      modes.includes("vibration"),
      reminderVolumePercent() / 100
    );
    showToast("测试提醒将在 3 秒后触发");
  });
  imageInput.addEventListener("change", async () => {
    const file = imageInput.files?.[0];
    if (!file) {
      setEditingImage(null);
      return;
    }
    try {
      setEditingImage(await compressImageFile(file));
    } catch {
      showToast("图片读取失败");
      setEditingImage(null);
    }
  });
  removeImageBtn.addEventListener("click", () => setEditingImage(null));

  function syncViaWebSocket() {
    return new Promise(resolve => {
      if (!syncUrl) {
        resolve(false);
        return;
      }
      let settled = false;
      let socket;
      let timer;
      const finish = ok => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        try {
          socket?.close();
        } catch {}
        resolve(ok);
      };
      try {
        socket = new WebSocket(syncUrl);
      } catch {
        resolve(false);
        return;
      }
      timer = setTimeout(() => finish(false), 4500);
      socket.onopen = () => {
        socket.send(JSON.stringify({ type: "sync", records }));
      };
      socket.onmessage = event => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type !== "synced" || !Array.isArray(payload.records)) {
            finish(false);
            return;
          }
          records = mergeRecords(records, payload.records);
          persist();
          render();
          finish(true);
        } catch {
          finish(false);
        }
      };
      socket.onerror = () => finish(false);
      socket.onclose = () => finish(false);
    });
  }

  async function syncViaCloud() {
    if (!cloudSyncUrl || !cloudPublishableKey || !cloudVaultKey) {
      return false;
    }
    try {
      const outgoing = records.filter(
        record => Number(record.rev || 0) > cloudPushRev
      );
      const outgoingMax = outgoing.reduce(
        (maximum, record) => Math.max(maximum, Number(record.rev || 0)),
        cloudPushRev
      );
      const response = await fetch(cloudSyncUrl, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${cloudPublishableKey}`,
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: JSON.stringify({
          p_vault_key: cloudVaultKey,
          p_since: cloudCursor,
          p_records: outgoing,
        }),
      });
      if (!response.ok) return false;
      const payload = await response.json();
      const incoming = Array.isArray(payload)
        ? payload
        : Array.isArray(payload.records)
          ? payload.records
          : [];
      if (!Array.isArray(incoming)) return false;
      if (outgoingMax > cloudPushRev) {
        cloudPushRev = outgoingMax;
      }
      const nextCursor = Number(payload?.cursor || cloudCursor);
      if (Number.isFinite(nextCursor) && nextCursor >= cloudCursor) {
        cloudCursor = nextCursor;
      }
      saveCloudProgress();
      records = mergeRecords(records, incoming);
      persist();
      render();
      return true;
    } catch {
      return false;
    }
  }

  function deriveHttpUrl() {
    try {
      const url = new URL(syncUrl);
      const token = url.pathname.split("/").filter(Boolean).pop();
      if (!token) return "";
      return `${url.protocol === "wss:" ? "https:" : "http:"}//${url.host}/t/${token}/api/sync`;
    } catch {
      return bootstrap.syncHttpUrl || "";
    }
  }

  async function syncViaHttp() {
    const target = deriveHttpUrl();
    if (!target) return false;
    try {
      const response = await fetch(target, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ records }),
      });
      const payload = await response.json();
      if (!response.ok || !Array.isArray(payload.records)) return false;
      records = mergeRecords(records, payload.records);
      persist();
      render();
      return true;
    } catch {
      return false;
    }
  }

  async function syncNow() {
    if (nativeBridge) {
      setConnectionStatus(true);
      setTimeout(syncNow, 5000);
      return;
    }
    if (syncing) return;
    syncing = true;
    let online = false;
    try {
      online = await syncViaCloud();
      if (!online) online = await syncViaWebSocket();
      if (!online) online = await syncViaHttp();
    } finally {
      syncing = false;
      setConnectionStatus(online);
      setTimeout(syncNow, online ? 300000 : 600000);
    }
  }

  statusEl.style.cursor = "pointer";
  statusEl.title = "点击输入云同步码";
  statusEl.addEventListener("click", () => {
    if (nativeBridge) {
      try {
        const info = JSON.parse(nativeBridge.getDeviceInfo() || "{}");
        nativeBridge.showToast(`电脑请连接 ${info.ip}:${info.port}`);
      } catch {
        nativeBridge.showToast("同步服务正在启动");
      }
      return;
    }
    syncCodeInput.value = cloudVaultKey;
    syncOverlay.classList.add("show");
    setTimeout(() => syncCodeInput.focus(), 80);
  });
  document.getElementById("syncCancelBtn").addEventListener("click", () => {
    syncOverlay.classList.remove("show");
  });
  document.getElementById("syncSaveBtn").addEventListener("click", () => {
    const normalized = normalizeVaultKey(syncCodeInput.value);
    if (normalized.length >= 20) {
      const changed = switchCloudVault(normalized);
      if (changed) {
        loadRecords();
        render();
      }
      syncOverlay.classList.remove("show");
      showToast("同步码已保存");
      syncNow();
    } else {
      showToast("同步码格式不正确");
    }
  });
  syncOverlay.addEventListener("click", event => {
    if (event.target === syncOverlay) {
      syncOverlay.classList.remove("show");
    }
  });
  syncBtn.addEventListener("click", () => {
    if (nativeBridge) {
      try {
        const info = JSON.parse(nativeBridge.getDeviceInfo() || "{}");
        syncGuideAddress.textContent = `${info.ip}:${info.port}`;
        syncGuideCode.textContent = info.pairing_code || "正在生成";
      } catch {
        syncGuideAddress.textContent = "同步服务正在启动";
        syncGuideCode.textContent = "正在生成";
      }
      nativeBridge.requestSync?.();
      syncTutorialOverlay.classList.add("show");
      return;
    }
    showToast("正在同步…");
    syncNow();
  });
  document.getElementById("syncTutorialClose").addEventListener("click", () => {
    syncTutorialOverlay.classList.remove("show");
  });
  syncTutorialOverlay.addEventListener("click", event => {
    if (event.target === syncTutorialOverlay) {
      syncTutorialOverlay.classList.remove("show");
    }
  });
  historyBtn.addEventListener("click", openHistory);
  document.getElementById("historyCloseBtn").addEventListener("click", () => {
    historyOverlay.classList.remove("show");
  });
  historyOverlay.addEventListener("click", event => {
    if (event.target === historyOverlay) historyOverlay.classList.remove("show");
  });
  weekBtn.addEventListener("click", openWeekView);
  document.getElementById("weekPrevBtn").addEventListener("click", () => shiftWeek(-3));
  document.getElementById("weekNextBtn").addEventListener("click", () => shiftWeek(3));
  document.getElementById("weekTodayBtn").addEventListener("click", () => {
    weekStart = dayStartOf(new Date());
    drawWeekView();
  });
  document.getElementById("weekCloseBtn").addEventListener("click", closeWeekView);
  weekOverlay.addEventListener("click", event => {
    if (event.target === weekOverlay) closeWeekView();
  });
  versionBtn.addEventListener("click", openChangelog);
  document.getElementById("changelogCloseBtn").addEventListener("click", () => {
    changelogOverlay.classList.remove("show");
  });
  changelogOverlay.addEventListener("click", event => {
    if (event.target === changelogOverlay) changelogOverlay.classList.remove("show");
  });
  document.getElementById("imageViewerCloseBtn").addEventListener("click", () => {
    imageViewerOverlay.classList.remove("show");
  });
  imageViewerOverlay.addEventListener("click", event => {
    if (event.target === imageViewerOverlay) imageViewerOverlay.classList.remove("show");
  });
  window.addEventListener("resize", () => {
    if (weekOverlay.classList.contains("show")) {
      drawWeekView();
    }
  });

  document.getElementById("addBtn").addEventListener("click", () => {
    if (activePage === "groups") {
      openGroupEditor();
    } else {
      openEditor();
    }
  });
  memosTabBtn.addEventListener("click", () => setPage("memos"));
  groupsTabBtn.addEventListener("click", () => setPage("groups"));
  newGroupBtn.addEventListener("click", () => openGroupEditor());
  groupCancelBtn.addEventListener("click", closeGroupEditor);
  groupOverlay.addEventListener("click", event => {
    if (event.target === groupOverlay) closeGroupEditor();
  });
  groupDetailCloseBtn.addEventListener("click", closeGroupDetail);
  groupDetailOverlay.addEventListener("click", event => {
    if (event.target === groupDetailOverlay) closeGroupDetail();
  });
  document.getElementById("cancelBtn").addEventListener("click", closeEditor);
  overlay.addEventListener("click", event => {
    if (event.target === overlay) closeEditor();
  });
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
      syncNow();
      checkLatestVersionStatus();
    }
  });

  function compareVersions(left, right) {
    const parse = value =>
      String(value).replace(/^v/i, "").split(".").map(Number);
    const a = parse(left);
    const b = parse(right);
    const length = Math.max(a.length, b.length);
    for (let index = 0; index < length; index += 1) {
      const difference = (a[index] || 0) - (b[index] || 0);
      if (difference) return difference;
    }
    return 0;
  }

  function normalizeVersion(value) {
    const match = String(value || "").match(/v?(\d+\.\d+\.\d+)/i);
    return match ? match[1] : "";
  }

  function extractPlatformVersion(html) {
    const source = String(html || "");
    const releaseMatch = source.match(
      /class=["'][^"']*\brelease-version\b[^"']*["'][^>]*>\s*v?(\d+\.\d+\.\d+)/i
    );
    if (releaseMatch) return releaseMatch[1];
    const currentMatch = source.match(
      /当前版本[\s\S]{0,1600}?v?(\d+\.\d+\.\d+)/i
    );
    return currentMatch ? currentMatch[1] : "";
  }

  function applyLiveUpdateButtonState() {
    if (!checkUpdateBtn) return;
    const updateOperationActive = Boolean(updateDownloadVersion);
    checkUpdateBtn.disabled = updateOperationActive;
    checkUpdateBtn.classList.toggle("update-available", liveUpdateAvailable);
    checkUpdateBtn.classList.toggle(
      "is-latest",
      updateCheckState === "latest"
    );
    checkUpdateBtn.classList.toggle(
      "check-failed",
      updateCheckState === "failed"
    );
    checkUpdateBtn.classList.toggle(
      "login-required",
      updateCheckState === "login"
    );
    checkUpdateBtn.classList.toggle(
      "checking",
      updateCheckState === "checking"
    );
    checkUpdateBtn.textContent = updateOperationActive
      ? updateInstallWaiting
        ? "等待安装"
        : `下载更新 ${updateDownloadPercent}%`
      : liveUpdateAvailable
        ? "可以更新"
      : updateCheckState === "latest"
        ? "已是最新版"
        : updateCheckState === "failed"
          ? "检查失败"
          : updateCheckState === "login"
            ? "需登录检查"
          : updateCheckState === "offline"
            ? "等待联网"
            : "正在检查";
    checkUpdateBtn.setAttribute(
      "aria-label",
      updateOperationActive
        ? updateInstallWaiting
          ? "更新包已下载，等待打开系统安装器"
          : `正在下载更新 ${updateDownloadPercent}%`
        : liveUpdateAvailable
        ? `发现新版本 ${latestRemoteVersion}，点击获取更新`
        : updateCheckState === "latest"
          ? `当前已是最新版 ${CURRENT_MOBILE_VERSION}`
          : updateCheckState === "failed"
            ? "版本检查失败，点击重试或打开国内平台"
            : updateCheckState === "login"
              ? "请先登录国内平台，登录后自动检查最新版本"
            : updateCheckState === "offline"
              ? "当前离线，联网后将自动检查版本"
              : "正在检查最新版本"
    );
  }

  function requestNativeLatestVersion() {
    if (!nativeBridge?.checkLatestVersion) {
      return Promise.resolve(null);
    }
    return new Promise(resolve => {
      if (nativeUpdateResolution) {
        nativeUpdateResolution(null);
      }
      nativeUpdateResolution = resolve;
      clearTimeout(nativeUpdateTimer);
      nativeUpdateTimer = setTimeout(() => {
        if (nativeUpdateResolution === resolve) {
          nativeUpdateResolution = null;
          resolve(null);
        }
      }, 14000);
      try {
        nativeBridge.checkLatestVersion();
      } catch {
        clearTimeout(nativeUpdateTimer);
        nativeUpdateResolution = null;
        resolve(null);
      }
    });
  }

  window.BUAANativeUpdateResult = payload => {
    if (!nativeUpdateResolution) return;
    let result = null;
    try {
      result =
        typeof payload === "string" ? JSON.parse(payload) : payload || null;
    } catch {
      result = null;
    }
    const resolve = nativeUpdateResolution;
    nativeUpdateResolution = null;
    clearTimeout(nativeUpdateTimer);
    resolve(result);
  };

  async function readPlatformVersion() {
    const response = await fetch(
      `${UPDATE_PORTAL_URL}?version_check=${Date.now()}`,
      { cache: "no-store", credentials: "omit" }
    );
    if (!response.ok) return "";
    return extractPlatformVersion(await response.text());
  }

  async function readManifestVersion(manifestUrl) {
    const response = await fetch(
      `${manifestUrl}${manifestUrl.includes("?") ? "&" : "?"}t=${Date.now()}`,
      { cache: "no-store" }
    );
    if (!response.ok) return "";
    let manifest = await response.json();
    if (manifest.content && manifest.encoding === "base64") {
      const binary = atob(manifest.content.replace(/\s/g, ""));
      const bytes = Uint8Array.from(binary, character =>
        character.charCodeAt(0)
      );
      manifest = JSON.parse(new TextDecoder().decode(bytes));
    }
    return normalizeVersion(manifest.version);
  }

  async function performLatestVersionCheck() {
    let remoteVersion = "";
    const nativeResult = await requestNativeLatestVersion();
    if (nativeResult?.ok) {
      remoteVersion = normalizeVersion(nativeResult.version);
    }
    if (nativeResult?.auth_required) {
      liveUpdateAvailable = false;
      updateCheckState = "login";
      applyLiveUpdateButtonState();
      return false;
    }
    if (!remoteVersion) {
      try {
        remoteVersion = await readPlatformVersion();
      } catch {}
    }
    for (const manifestUrl of LIVE_UPDATE_MANIFEST_URLS) {
      if (remoteVersion) break;
      try {
        remoteVersion = await readManifestVersion(manifestUrl);
      } catch {}
    }
    if (!remoteVersion) {
      liveUpdateAvailable = false;
      updateCheckState = "failed";
      applyLiveUpdateButtonState();
      return false;
    }
    latestRemoteVersion = remoteVersion;
    liveUpdateAvailable =
      compareVersions(latestRemoteVersion, CURRENT_MOBILE_VERSION) > 0;
    updateCheckState = liveUpdateAvailable ? "available" : "latest";
    applyLiveUpdateButtonState();
    return liveUpdateAvailable;
  }

  async function checkLatestVersionStatus() {
    if (!checkUpdateBtn) return false;
    if (!navigator.onLine) {
      liveUpdateAvailable = false;
      updateCheckState = "offline";
      applyLiveUpdateButtonState();
      return false;
    }
    if (versionCheckPromise) return versionCheckPromise;
    liveUpdateAvailable = false;
    updateCheckState = "checking";
    applyLiveUpdateButtonState();
    versionCheckPromise = performLatestVersionCheck();
    try {
      return await versionCheckPromise;
    } finally {
      versionCheckPromise = null;
    }
  }

  function startLiveUpdateMonitor() {
    checkLatestVersionStatus();
    if (liveUpdateTimer) clearInterval(liveUpdateTimer);
    liveUpdateTimer = setInterval(() => {
      if (!document.hidden && navigator.onLine) checkLatestVersionStatus();
    }, 60000);
  }

  function desktopDownloadMessage() {
    return (
      "BUAA浮光电脑版下载\n\n" +
      `下载页面：${UPDATE_PORTAL_URL}\n` +
      `Windows 安装包：${DESKTOP_DOWNLOAD_URL}\n\n` +
      "在电脑浏览器打开链接并登录平台，然后在“版本下载”中选择 Windows 版。"
    );
  }

  async function copyText(text) {
    if (navigator.clipboard?.writeText) {
      try {
        await navigator.clipboard.writeText(text);
        return true;
      } catch {}
    }
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    document.body.appendChild(textarea);
    textarea.select();
    let copied = false;
    try {
      copied = document.execCommand("copy");
    } catch {}
    textarea.remove();
    return copied;
  }

  async function copyDesktopDownloadLink() {
    const copied = await copyText(desktopDownloadMessage());
    showToast(
      copied
        ? "电脑版下载链接已复制，可发送到电脑"
        : "复制失败，请长按下载页面地址手动复制"
    );
  }

  async function shareDesktopDownloadLink() {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "BUAA浮光电脑版",
          text: desktopDownloadMessage(),
          url: UPDATE_PORTAL_URL,
        });
        return;
      } catch (error) {
        if (error?.name === "AbortError") return;
      }
    }
    await copyDesktopDownloadLink();
  }

  window.BUAANativeUpdateDownloadStarted = () => {
    if (!updateDownloadVersion) {
      updateDownloadVersion = latestRemoteVersion;
    }
    updateDownloadPercent = 0;
    updateInstallWaiting = false;
    applyLiveUpdateButtonState();
    showToast(`开始下载 v${updateDownloadVersion}，完成后将自动打开安装器`);
  };

  window.BUAANativeUpdateDownloadProgress = (version, percent) => {
    updateDownloadVersion = normalizeVersion(version) || updateDownloadVersion;
    updateDownloadPercent = Math.max(
      0,
      Math.min(100, Math.round(Number(percent) || 0))
    );
    updateInstallWaiting = false;
    applyLiveUpdateButtonState();
  };

  window.BUAANativeUpdateDownloaded = version => {
    updateDownloadVersion = normalizeVersion(version) || updateDownloadVersion;
    updateDownloadPercent = 100;
    updateInstallWaiting = true;
    applyLiveUpdateButtonState();
    showToast("更新包下载完成，正在准备安装");
  };

  window.BUAANativeUpdatePermissionRequired = () => {
    updateInstallWaiting = true;
    applyLiveUpdateButtonState();
    showToast("请允许 BUAA浮光安装应用，返回 App 后会自动继续");
  };

  window.BUAANativeUpdateInstallerReady = () => {
    updateInstallWaiting = true;
    applyLiveUpdateButtonState();
    showToast("已打开系统安装器，请点击“安装”完成更新");
  };

  window.BUAANativeUpdateDownloadFailed = message => {
    const detail = String(message || "更新下载失败，请稍后重试");
    updateDownloadVersion = "";
    updateDownloadPercent = 0;
    updateInstallWaiting = false;
    if (detail.includes("已是最新版")) {
      liveUpdateAvailable = false;
      updateCheckState = "latest";
    } else {
      liveUpdateAvailable = Boolean(latestRemoteVersion);
      updateCheckState = liveUpdateAvailable ? "available" : "failed";
    }
    applyLiveUpdateButtonState();
    showToast(detail);
  };

  async function checkMobileUpdate() {
    if (!checkUpdateBtn) return;
    if (updateCheckState === "checking") {
      showToast("正在读取国内平台版本，请稍候");
      return;
    }
    if (updateCheckState === "login" && nativeBridge?.openUpdateLogin) {
      nativeBridge.openUpdateLogin();
      return;
    }
    if (updateCheckState === "failed" || updateCheckState === "offline") {
      await checkLatestVersionStatus();
    }
    if (updateCheckState === "login" && nativeBridge?.openUpdateLogin) {
      nativeBridge.openUpdateLogin();
      return;
    }
    if (
      liveUpdateAvailable &&
      nativeBridge?.downloadAndInstallUpdate
    ) {
      updateDownloadVersion = latestRemoteVersion;
      updateDownloadPercent = 0;
      updateInstallWaiting = false;
      applyLiveUpdateButtonState();
      try {
        nativeBridge.downloadAndInstallUpdate();
      } catch {
        window.BUAANativeUpdateDownloadFailed(
          "无法启动更新下载，请稍后重试"
        );
      }
      return;
    }
    const updateHint = liveUpdateAvailable
      ? `已检测到新版本 v${latestRemoteVersion}。\n\n`
      : updateCheckState === "latest"
        ? `当前已是最新版 v${CURRENT_MOBILE_VERSION}。\n\n`
        : "暂时无法确认最新版本，也可以直接打开国内平台手动检查。\n\n";
    const proceed = confirm(
      `${updateHint}更新由“学业支持中心开源平台”提供。\n\n` +
        "未登录时会先跳转到平台登录页；登录后在项目页面的“版本下载”中下载最新版。\n\n" +
        "是否打开更新页面？"
    );
    if (!proceed) return;
    if (nativeBridge?.openUrl) {
      nativeBridge.openUrl(UPDATE_PORTAL_URL);
    } else {
      window.open(UPDATE_PORTAL_URL, "_blank", "noopener,noreferrer");
    }
    showToast("请先登录平台，然后在“版本下载”中安装最新版");
  }

  checkUpdateBtn?.addEventListener("click", checkMobileUpdate);
  copyDesktopLinkBtn?.addEventListener("click", copyDesktopDownloadLink);
  shareDesktopLinkBtn?.addEventListener("click", shareDesktopDownloadLink);
  desktopDownloadBtn?.addEventListener("click", () => {
    desktopDownloadOverlay?.classList.add("show");
  });
  desktopDownloadCloseBtn?.addEventListener("click", () => {
    desktopDownloadOverlay?.classList.remove("show");
  });
  desktopDownloadOverlay?.addEventListener("click", event => {
    if (event.target === desktopDownloadOverlay) {
      desktopDownloadOverlay.classList.remove("show");
    }
  });
  if (desktopDownloadPageLink) {
    desktopDownloadPageLink.href = UPDATE_PORTAL_URL;
  }
  if (directDesktopDownload) {
    directDesktopDownload.href = DESKTOP_DOWNLOAD_URL;
  }
  window.addEventListener("online", () => checkLatestVersionStatus());
  window.addEventListener("offline", () => {
    liveUpdateAvailable = false;
    updateCheckState = "offline";
    applyLiveUpdateButtonState();
  });
  window.BUAARetryUpdateCheck = () => checkLatestVersionStatus();
  applyLiveUpdateButtonState();
  startLiveUpdateMonitor();
  rescheduleAllReminders();
  initLayoutSettings();

  window.BUAAReloadRecords = () => {
    loadRecords();
    render();
  };
  window.BUAACloseTopOverlay = () => {
    if (weekOverlay.classList.contains("show")) {
      closeWeekView();
      return true;
    }
    for (const element of [
      historyOverlay,
      layoutSettingsOverlay,
      groupDetailOverlay,
      groupOverlay,
      desktopDownloadOverlay,
      changelogOverlay,
      imageViewerOverlay,
      syncTutorialOverlay,
      syncOverlay,
      overlay
    ]) {
      if (element.classList.contains("show")) {
        if (element === overlay) {
          closeEditor();
        } else {
          element.classList.remove("show");
        }
        return true;
      }
    }
    return false;
  };

  if (bootstrap.mobileVersion) {
    versionBtn.textContent = `v${bootstrap.mobileVersion}`;
  }
  loadRecords();
  render();
  setPage("memos");
  setConnectionStatus(false);
  setInterval(updateCountdowns, 1000);
  window.addEventListener("storage", event => {
    if (
      event.key === recordsStorageKey ||
      event.key === LAYOUT_SETTINGS_KEY
    ) {
      loadRecords();
      render();
    }
  });
  syncNow();
})();
