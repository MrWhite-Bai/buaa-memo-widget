param(
    [Parameter(Mandatory = $true)][string]$Source,
    [Parameter(Mandatory = $true)][string]$Destination,
    [int]$MaxWidth = 900,
    [int]$MaxHeight = 600
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

$image = $null
$bitmap = $null
$graphics = $null

try {
    $image = [System.Drawing.Image]::FromFile($Source)

    # Apply the EXIF orientation before calculating the preview size.
    if ($image.PropertyIdList -contains 0x0112) {
        $orientation = [int]$image.GetPropertyItem(0x0112).Value[0]
        switch ($orientation) {
            3 { $image.RotateFlip([System.Drawing.RotateFlipType]::Rotate180FlipNone) }
            6 { $image.RotateFlip([System.Drawing.RotateFlipType]::Rotate90FlipNone) }
            8 { $image.RotateFlip([System.Drawing.RotateFlipType]::Rotate270FlipNone) }
        }
    }

    $ratio = [Math]::Min(1.0, [Math]::Min($MaxWidth / $image.Width, $MaxHeight / $image.Height))
    $width = [Math]::Max(1, [int][Math]::Round($image.Width * $ratio))
    $height = [Math]::Max(1, [int][Math]::Round($image.Height * $ratio))

    $bitmap = New-Object System.Drawing.Bitmap(
        $width,
        $height,
        [System.Drawing.Imaging.PixelFormat]::Format32bppArgb
    )
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
    $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $graphics.Clear([System.Drawing.Color]::White)
    $graphics.DrawImage($image, 0, 0, $width, $height)

    $bitmap.Save($Destination, [System.Drawing.Imaging.ImageFormat]::Png)
}
finally {
    if ($graphics) { $graphics.Dispose() }
    if ($bitmap) { $bitmap.Dispose() }
    if ($image) { $image.Dispose() }
}
