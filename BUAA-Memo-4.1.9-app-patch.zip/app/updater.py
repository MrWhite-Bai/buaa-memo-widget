from __future__ import annotations

import hashlib
import base64
import json
import os
import shutil
import ssl
import subprocess
import sys
import time
import urllib.request
import zipfile
from pathlib import Path


class UpdateError(Exception):
    pass


CA_BUNDLE = Path(__file__).resolve().parent / "assets" / "cacert.pem"


def _open_url(request: urllib.request.Request, timeout: float):
    context = (
        ssl.create_default_context(cafile=str(CA_BUNDLE))
        if CA_BUNDLE.is_file()
        else ssl.create_default_context()
    )
    direct = urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        urllib.request.HTTPSHandler(context=context),
    )
    try:
        return direct.open(request, timeout=timeout)
    except Exception as direct_error:
        try:
            return urllib.request.urlopen(request, timeout=timeout)
        except Exception:
            raise direct_error


def version_tuple(value: str) -> tuple[int, ...]:
    parts = []
    for part in str(value).strip().lstrip("vV").split("."):
        try:
            parts.append(int(part))
        except ValueError:
            parts.append(0)
    return tuple(parts)


def is_newer(remote_version: str, local_version: str) -> bool:
    remote = version_tuple(remote_version)
    local = version_tuple(local_version)
    size = max(len(remote), len(local))
    return remote + (0,) * (size - len(remote)) > local + (0,) * (size - len(local))


def fetch_manifest(url: str, timeout: float = 12.0) -> dict:
    separator = "&" if "?" in url else "?"
    request = urllib.request.Request(
        url + f"{separator}t={int(time.time())}",
        headers={
            "User-Agent": "BUAA浮光-Updater/4.1",
            "Cache-Control": "no-cache",
        },
    )
    try:
        with _open_url(request, timeout) as response:
            body = response.read(2_000_000)
    except Exception as exc:
        raise UpdateError(f"无法连接更新服务器：{exc}") from exc
    try:
        manifest = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise UpdateError("更新清单格式不正确。") from exc
    if not isinstance(manifest, dict) or not manifest.get("version"):
        if manifest.get("encoding") == "base64" and manifest.get("content"):
            try:
                decoded = base64.b64decode(manifest["content"])
                manifest = json.loads(decoded.decode("utf-8"))
            except Exception as exc:
                raise UpdateError("更新清单解码失败。") from exc
    if not isinstance(manifest, dict) or not manifest.get("version"):
        raise UpdateError("更新清单缺少版本信息。")
    return manifest


def fetch_text_url(
    url: str,
    timeout: float = 12.0,
    limit: int = 2_000_000,
) -> str:
    separator = "&" if "?" in url else "?"
    request = urllib.request.Request(
        url + f"{separator}t={int(time.time())}",
        headers={
            "User-Agent": "BUAA浮光-Updater/4.1",
            "Cache-Control": "no-cache",
            "Accept": "text/html,application/json;q=0.9,*/*;q=0.8",
        },
    )
    try:
        with _open_url(request, timeout) as response:
            body = response.read(limit)
    except Exception as exc:
        raise UpdateError(f"无法连接更新服务器：{exc}") from exc
    try:
        return body.decode("utf-8")
    except UnicodeDecodeError:
        return body.decode("utf-8", errors="replace")


def download_verified(
    url: str,
    destination: Path,
    expected_sha256: str,
    timeout: float = 90.0,
) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "BUAA浮光-Updater/4.1",
            "Accept": "application/vnd.github.raw",
        },
    )
    digest = hashlib.sha256()
    try:
        with _open_url(request, timeout) as response:
            total = 0
            with destination.open("wb") as handle:
                while True:
                    chunk = response.read(128 * 1024)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > 100 * 1024 * 1024:
                        raise UpdateError("更新包大小异常。")
                    digest.update(chunk)
                    handle.write(chunk)
    except UpdateError:
        destination.unlink(missing_ok=True)
        raise
    except Exception as exc:
        destination.unlink(missing_ok=True)
        raise UpdateError(f"下载更新失败：{exc}") from exc

    actual = digest.hexdigest().lower()
    expected = str(expected_sha256).strip().lower()
    if not expected or actual != expected:
        destination.unlink(missing_ok=True)
        raise UpdateError("更新包校验失败，文件可能不完整。")
    return destination


def _safe_extract(archive: zipfile.ZipFile, destination: Path) -> None:
    destination = destination.resolve()
    for member in archive.infolist():
        target = (destination / member.filename).resolve()
        if destination not in target.parents and target != destination:
            raise UpdateError("更新包包含无效路径。")
        archive.extract(member, destination)


def _updatable_files(app_dir: Path):
    for path in app_dir.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(app_dir)
        if relative.parts and relative.parts[0] == "data":
            continue
        if "__pycache__" in relative.parts:
            continue
        yield path, relative


def apply_patch(patch_path: Path, app_dir: Path) -> int:
    app_dir = app_dir.resolve()
    extract_dir = app_dir / "data" / f".update-extract-{int(time.time() * 1000)}"
    extract_dir.mkdir(parents=True, exist_ok=False)
    backup_path = app_dir / "data" / f"app-backup-{int(time.time())}.zip"
    backup_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with zipfile.ZipFile(patch_path) as archive:
            _safe_extract(archive, extract_dir)
        source_root = extract_dir / "app"
        if not source_root.is_dir():
            candidates = [
                path
                for path in extract_dir.iterdir()
                if path.is_dir() and (path / "app").is_dir()
            ]
            if not candidates:
                raise UpdateError("更新包缺少 app 文件夹。")
            source_root = candidates[0] / "app"

        with zipfile.ZipFile(
            backup_path,
            "w",
            compression=zipfile.ZIP_DEFLATED,
        ) as backup:
            for path, relative in _updatable_files(app_dir):
                backup.write(path, relative.as_posix())

        copied = 0
        for source in source_root.rglob("*"):
            if not source.is_file():
                continue
            relative = source.relative_to(source_root)
            if relative.parts and relative.parts[0] == "data":
                continue
            if "__pycache__" in relative.parts:
                continue
            destination = app_dir / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            copied += 1
        return copied
    except Exception:
        if backup_path.is_file():
            try:
                with zipfile.ZipFile(backup_path) as backup:
                    _safe_extract(backup, app_dir)
            except Exception:
                pass
        raise
    finally:
        shutil.rmtree(extract_dir, ignore_errors=True)


def _powershell_quote(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def schedule_restart(app_dir: Path) -> None:
    app_dir = app_dir.resolve()
    launcher = app_dir.parent / "BUAA浮光.exe"
    if not launcher.is_file():
        launcher = app_dir.parent / "BUAA备忘.exe"
    powershell = shutil.which("powershell.exe") or shutil.which("powershell")
    if powershell is None:
        raise UpdateError("找不到 Windows PowerShell，无法自动重启。")

    if launcher.is_file():
        command = (
            "Start-Sleep -Milliseconds 1800; "
            f"Start-Process -FilePath {_powershell_quote(str(launcher))} "
            f"-WorkingDirectory {_powershell_quote(str(launcher.parent))}"
        )
    else:
        script = app_dir / "BUAA备忘录.py"
        command = (
            "Start-Sleep -Milliseconds 1800; "
            f"Start-Process -FilePath {_powershell_quote(sys.executable)} "
            f"-ArgumentList {_powershell_quote(chr(34) + str(script) + chr(34))} "
            f"-WorkingDirectory {_powershell_quote(str(app_dir))}"
        )
    subprocess.Popen(
        [
            powershell,
            "-NoProfile",
            "-WindowStyle",
            "Hidden",
            "-Command",
            command,
        ],
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        close_fds=True,
    )
