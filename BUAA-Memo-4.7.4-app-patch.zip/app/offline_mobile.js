(() => {
  "use strict";

  const bootstrap = window.BUAA_BOOTSTRAP || {};
  const STORAGE_KEY = "buaa_memo_records_v2";
  const BLOCKED_RECORD_IDS = new Set(
    (Array.isArray(bootstrap.blockedRecordIds)
      ? bootstrap.blockedRecordIds
      : []
    ).map(value => String(value))
  );
  const SYNC_URL_KEY = "buaa_memo_sync_url_v2";
  const CLOUD_VAULT_KEY = "buaa_memo_cloud_vault_v1";
  const CLOUD_CURSOR_KEY = "buaa_memo_cloud_cursor_v1";
  const CLOUD_PUSH_REV_KEY = "buaa_memo_cloud_push_rev_v1";
  const HISTORY_GRACE_MS = 24 * 60 * 60 * 1000;
  const UPDATE_PORTAL_URL =
    "https://cysyforum.muzermat.online/cy-platform/projects/5";
  const DESKTOP_DOWNLOAD_URL =
    bootstrap.desktopDownloadUrl ||
    "https://github.com/MrWhite-Bai/buaa-memo-widget/releases/download/" +
      "v4.1.0/BUAA-Memo-Windows-v4.1.0.zip";
  const CURRENT_MOBILE_VERSION = bootstrap.mobileVersion || "0.0.0";
  const LIVE_UPDATE_MANIFEST_URLS = [
    "https://raw.githubusercontent.com/MrWhite-Bai/" +
      "buaa-memo-widget/main/update-manifest.json",
    "https://cdn.jsdelivr.net/gh/MrWhite-Bai/" +
      "buaa-memo-widget@main/update-manifest.json",
  ].filter(Boolean);

  const listEl = document.getElementById("list");
  const countEl = document.getElementById("count");
  const statusEl = document.getElementById("status");
  const statusText = document.getElementById("statusText");
  const overlay = document.getElementById("overlay");
  const memosPage = document.getElementById("memosPage");
  const notesPage = document.getElementById("notesPage");
  const groupsPage = document.getElementById("groupsPage");
  const friendsPage = document.getElementById("friendsPage");
  const memosTabBtn = document.getElementById("memosTabBtn");
  const notesTabBtn = document.getElementById("notesTabBtn");
  const groupsTabBtn = document.getElementById("groupsTabBtn");
  const friendsTabBtn = document.getElementById("friendsTabBtn");
  const noteCount = document.getElementById("noteCount");
  const notesList = document.getElementById("notesList");
  const noteFilter = document.getElementById("noteFilter");
  const newNoteBtn = document.getElementById("newNoteBtn");
  const noteEditorOverlay = document.getElementById("noteEditorOverlay");
  const noteForm = document.getElementById("noteForm");
  const noteFormTitle = document.getElementById("noteFormTitle");
  const diaryTypeBtn = document.getElementById("diaryTypeBtn");
  const noteTypeBtn = document.getElementById("noteTypeBtn");
  const noteEntryTitle = document.getElementById("noteEntryTitle");
  const noteEntryIntro = document.getElementById("noteEntryIntro");
  const noteEntryDate = document.getElementById("noteEntryDate");
  const noteGroup = document.getElementById("noteGroup");
  const noteEntryBody = document.getElementById("noteEntryBody");
  const noteWritingOverlay = document.getElementById(
    "noteWritingOverlay"
  );
  const noteWritingPage = document.querySelector(
    ".note-writing-page"
  );
  const notePasteBtn = document.getElementById("notePasteBtn");
  const noteWritingTitle = document.getElementById("noteWritingTitle");
  const noteWritingMeta = document.getElementById("noteWritingMeta");
  const noteWritingBackBtn = document.getElementById(
    "noteWritingBackBtn"
  );
  const noteWritingSaveBtn = document.getElementById("noteWritingSaveBtn");
  const noteWritingStatus = document.getElementById("noteWritingStatus");
  const noteContentCount = document.getElementById("noteContentCount");
  const noteViewOverlay = document.getElementById("noteViewOverlay");
  const noteViewCloseBtn = document.getElementById("noteViewCloseBtn");
  const noteViewEditBtn = document.getElementById("noteViewEditBtn");
  const noteViewTitle = document.getElementById("noteViewTitle");
  const noteViewMeta = document.getElementById("noteViewMeta");
  const noteViewGroup = document.getElementById("noteViewGroup");
  const noteViewIntro = document.getElementById("noteViewIntro");
  const noteViewBody = document.getElementById("noteViewBody");
  const noteFontBtn = document.getElementById("noteFontBtn");
  const noteFontToolbar = document.getElementById("noteFontToolbar");
  const noteFontColor = document.getElementById("noteFontColor");
  const noteMathBtn = document.getElementById("noteMathBtn");
  const noteMathOverlay = document.getElementById("noteMathOverlay");
  const noteMathCloseBtn = document.getElementById("noteMathCloseBtn");
  const noteMathSymbolsTab = document.getElementById("noteMathSymbolsTab");
  const noteLatexTab = document.getElementById("noteLatexTab");
  const noteMathSymbolsPanel = document.getElementById(
    "noteMathSymbolsPanel"
  );
  const noteLatexPanel = document.getElementById("noteLatexPanel");
  const noteMathCategories = document.getElementById(
    "noteMathCategories"
  );
  const noteMathSymbolGrid = document.getElementById(
    "noteMathSymbolGrid"
  );
  const noteMathStatus = document.getElementById("noteMathStatus");
  const noteLatexInput = document.getElementById("noteLatexInput");
  const noteLatexDisplayMode = document.getElementById(
    "noteLatexDisplayMode"
  );
  const noteLatexPreview = document.getElementById("noteLatexPreview");
  const noteLatexQuickbar = document.getElementById("noteLatexQuickbar");
  const noteLatexTemplates = document.getElementById(
    "noteLatexTemplates"
  );
  const noteLatexStatus = document.getElementById("noteLatexStatus");
  const noteLatexInsertBtn = document.getElementById(
    "noteLatexInsertBtn"
  );
  const notePasteOverlay = document.getElementById("notePasteOverlay");
  const notePastePreview = document.getElementById("notePastePreview");
  const notePasteFallbackInput = document.getElementById(
    "notePasteFallbackInput"
  );
  const notePasteStatus = document.getElementById("notePasteStatus");
  const notePasteCancelTopBtn = document.getElementById(
    "notePasteCancelTopBtn"
  );
  const notePasteCancelBtn = document.getElementById("notePasteCancelBtn");
  const notePastePlainBtn = document.getElementById("notePastePlainBtn");
  const notePasteSmartBtn = document.getElementById("notePasteSmartBtn");
  const groupCount = document.getElementById("groupCount");
  const groupList = document.getElementById("groupList");
  const newGroupBtn = document.getElementById("newGroupBtn");
  const groupOverlay = document.getElementById("groupOverlay");
  const groupForm = document.getElementById("groupForm");
  const groupFormTitle = document.getElementById("groupFormTitle");
  const groupNameInput = document.getElementById("groupName");
  const groupIntroInput = document.getElementById("groupIntro");
  const groupMemoChoices = document.getElementById("groupMemoChoices");
  const groupCancelBtn = document.getElementById("groupCancelBtn");
  const groupDetailOverlay = document.getElementById("groupDetailOverlay");
  const groupDetailTitle = document.getElementById("groupDetailTitle");
  const groupDetailIntro = document.getElementById("groupDetailIntro");
  const groupDetailList = document.getElementById("groupDetailList");
  const groupDetailCloseBtn = document.getElementById("groupDetailCloseBtn");
  const friendCount = document.getElementById("friendCount");
  const friendRequestCount = document.getElementById("friendRequestCount");
  const friendList = document.getElementById("friendList");
  const friendRequestList = document.getElementById("friendRequestList");
  const friendDiscoveryStatus = document.getElementById(
    "friendDiscoveryStatus"
  );
  const friendsCenterBtn = document.getElementById("friendsCenterBtn");
  const friendsCenterOverlay = document.getElementById(
    "friendsCenterOverlay"
  );
  const friendsCenterCloseBtn = document.getElementById(
    "friendsCenterCloseBtn"
  );
  const myFriendCode = document.getElementById("myFriendCode");
  const addFriendBtn = document.getElementById("addFriendBtn");
  const refreshFriendsBtn = document.getElementById("refreshFriendsBtn");
  const addFriendOverlay = document.getElementById("addFriendOverlay");
  const addFriendCloseBtn = document.getElementById("addFriendCloseBtn");
  const addFriendCancelBtn = document.getElementById("addFriendCancelBtn");
  const addFriendSubmitBtn = document.getElementById("addFriendSubmitBtn");
  const friendCodeInput = document.getElementById("friendCodeInput");
  const friendAddressInput = document.getElementById("friendAddressInput");
  const addFriendStatus = document.getElementById("addFriendStatus");
  const friendChatOverlay = document.getElementById("friendChatOverlay");
  const friendChatTitle = document.getElementById("friendChatTitle");
  const friendChatCloseBtn = document.getElementById("friendChatCloseBtn");
  const friendChatGiftBtn = document.getElementById("friendChatGiftBtn");
  const friendChatList = document.getElementById("friendChatList");
  const friendChatForm = document.getElementById("friendChatForm");
  const friendChatInput = document.getElementById("friendChatInput");
  const friendChatStatus = document.getElementById("friendChatStatus");
  const friendGiftOverlay = document.getElementById("friendGiftOverlay");
  const friendGiftFriendTitle = document.getElementById(
    "friendGiftFriendTitle"
  );
  const friendGiftType = document.getElementById("friendGiftType");
  const friendGiftMessage = document.getElementById("friendGiftMessage");
  const friendGiftStatus = document.getElementById("friendGiftStatus");
  const friendGiftSendBtn = document.getElementById("friendGiftSendBtn");
  const shareMemoOverlay = document.getElementById("shareMemoOverlay");
  const shareMemoCloseBtn = document.getElementById("shareMemoCloseBtn");
  const shareMemoFriendList = document.getElementById("shareMemoFriendList");
  const shareMemoStatus = document.getElementById("shareMemoStatus");
  const accountNickname = document.getElementById("accountNickname");
  const profileAvatar = document.getElementById("profileAvatar");
  const profileRoleLabel = document.getElementById("profileRoleLabel");
  const glowWallet = document.getElementById("glowWallet");
  const glowBalance = document.getElementById("glowBalance");
  const glowPeriodLabel = document.getElementById("glowPeriodLabel");
  const experienceCard = document.getElementById("experienceCard");
  const experienceLevelValue = document.getElementById(
    "experienceLevelValue"
  );
  const experienceLevelLabel = document.getElementById(
    "experienceLevelLabel"
  );
  const experienceTrack = document.getElementById("experienceTrack");
  const experienceFill = document.getElementById("experienceFill");
  const experienceNumbers = document.getElementById("experienceNumbers");
  const experienceHint = document.getElementById("experienceHint");
  const experienceInfoBtn = document.getElementById("experienceInfoBtn");
  const experienceInfoOverlay = document.getElementById(
    "experienceInfoOverlay"
  );
  const experienceLevelTableBody = document.getElementById(
    "experienceLevelTableBody"
  );
  const editNicknameBtn = document.getElementById("editNicknameBtn");
  const nicknameOverlay = document.getElementById("nicknameOverlay");
  const nicknameInput = document.getElementById("nicknameInput");
  const nicknameCloseBtn = document.getElementById("nicknameCloseBtn");
  const nicknameCancelBtn = document.getElementById("nicknameCancelBtn");
  const nicknameSaveBtn = document.getElementById("nicknameSaveBtn");
  const redemptionBtn = document.getElementById("redemptionBtn");
  const redemptionOverlay = document.getElementById("redemptionOverlay");
  const redemptionCodeInput = document.getElementById(
    "redemptionCodeInput"
  );
  const redemptionStatus = document.getElementById("redemptionStatus");
  const redemptionSubmitBtn = document.getElementById(
    "redemptionSubmitBtn"
  );
  const syncOverlay = document.getElementById("syncOverlay");
  const syncCodeInput = document.getElementById("syncCodeInput");
  const syncAddressInput = document.getElementById("syncAddressInput");
  const syncDiscoverBtn = document.getElementById("syncDiscoverBtn");
  const syncPairingStatus = document.getElementById("syncPairingStatus");
  const rememberPhonePair = document.getElementById("rememberPhonePair");
  const desktopPeerAddressInput = document.getElementById("desktopPeerAddressInput");
  const desktopPeerCodeInput = document.getElementById("desktopPeerCodeInput");
  const mobilePullDesktopBtn = document.getElementById("mobilePullDesktopBtn");
  const mobilePullDesktopStatus = document.getElementById("mobilePullDesktopStatus");
  const rememberDesktopPair = document.getElementById("rememberDesktopPair");
  const desktopHostInfo = document.getElementById("desktopHostInfo");
  const desktopHostAddress = document.getElementById("desktopHostAddress");
  const desktopHostCode = document.getElementById("desktopHostCode");
  const syncPreviewOverlay = document.getElementById("syncPreviewOverlay");
  const syncChangeList = document.getElementById("syncChangeList");
  const syncChangeSummary = document.getElementById("syncChangeSummary");
  const syncBtn = document.getElementById("syncBtn");
  const syncTutorialOverlay = document.getElementById("syncTutorialOverlay");
  const syncGuideAddress = document.getElementById("syncGuideAddress");
  const syncGuideCode = document.getElementById("syncGuideCode");
  const nativeDeviceGuide = document.getElementById("nativeDeviceGuide");
  const historyBtn = document.getElementById("historyBtn");
  const taskBtn = document.getElementById("taskBtn");
  const taskOverlay = document.getElementById("taskOverlay");
  const taskSummary = document.getElementById("taskSummary");
  const taskList = document.getElementById("taskList");
  const dailyTaskTab = document.getElementById("dailyTaskTab");
  const weeklyTaskTab = document.getElementById("weeklyTaskTab");
  const achievementTaskTab = document.getElementById(
    "achievementTaskTab"
  );
  const mailBtn = document.getElementById("mailBtn");
  const mailOverlay = document.getElementById("mailOverlay");
  const mailList = document.getElementById("mailList");
  const backpackBtn = document.getElementById("backpackBtn");
  const backpackOverlay = document.getElementById("backpackOverlay");
  const backpackCount = document.getElementById("backpackCount");
  const backpackGrid = document.getElementById("backpackGrid");
  const backpackEmptyNote = document.getElementById("backpackEmptyNote");
  const monthBtn = document.getElementById("monthBtn");
  const versionBtn = document.getElementById("versionBtn");
  const historyOverlay = document.getElementById("historyOverlay");
  const historyList = document.getElementById("historyList");
  const historyGroupOverlay = document.getElementById(
    "historyGroupOverlay"
  );
  const historyGroupMemoTitle = document.getElementById(
    "historyGroupMemoTitle"
  );
  const historyGroupSelect = document.getElementById("historyGroupSelect");
  const historyGroupSaveBtn = document.getElementById(
    "historyGroupSaveBtn"
  );
  const monthOverlay = document.getElementById("monthOverlay");
  const monthTitle = document.getElementById("monthTitle");
  const monthGrid = document.getElementById("monthGrid");
  const checkinBtn = document.getElementById("checkinBtn");
  const checkinStreak = document.getElementById("checkinStreak");
  const checkinStatus = document.getElementById("checkinStatus");
  const monthDayOverlay = document.getElementById("monthDayOverlay");
  const monthDayTitle = document.getElementById("monthDayTitle");
  const monthDaySummary = document.getElementById("monthDaySummary");
  const monthDayList = document.getElementById("monthDayList");
  const changelogOverlay = document.getElementById("changelogOverlay");
  const changelogList = document.getElementById("changelogList");
  const imageViewerOverlay = document.getElementById("imageViewerOverlay");
  const imageViewerImage = document.getElementById("imageViewerImage");
  const imageInput = document.getElementById("imageInput");
  const imagePreview = document.getElementById("imagePreview");
  const removeImageBtn = document.getElementById("removeImageBtn");
  const form = document.getElementById("memoForm");
  const formTitle = document.getElementById("formTitle");
  const titleInput = document.getElementById("title");
  const memoGroup = document.getElementById("memoGroup");
  const dateInput = document.getElementById("date");
  const timeInput = document.getElementById("time");
  const startDateInput = document.getElementById("startDate");
  const startTimeInput = document.getElementById("startTime");
  const endDateInput = document.getElementById("endDate");
  const endTimeInput = document.getElementById("endTime");
  const taskFields = document.getElementById("taskFields");
  const eventFields = document.getElementById("eventFields");
  const taskTypeBtn = document.getElementById("taskTypeBtn");
  const eventTypeBtn = document.getElementById("eventTypeBtn");
  const reminderEnabled = document.getElementById("reminderEnabled");
  const reminderOptions = document.getElementById("reminderOptions");
  const reminderAmount = document.getElementById("reminderAmount");
  const reminderUnit = document.getElementById("reminderUnit");
  const reminderNotify = document.getElementById("reminderNotify");
  const reminderSound = document.getElementById("reminderSound");
  const reminderVibrate = document.getElementById("reminderVibrate");
  const useDefaultReminder = document.getElementById("useDefaultReminder");
  const defaultReminderSummaryBox = document.getElementById(
    "defaultReminderSummaryBox"
  );
  const defaultReminderSummary = document.getElementById(
    "defaultReminderSummary"
  );
  const editDefaultReminderBtn = document.getElementById(
    "editDefaultReminderBtn"
  );
  const defaultReminderOverlay = document.getElementById(
    "defaultReminderOverlay"
  );
  const defaultReminderCloseBtn = document.getElementById(
    "defaultReminderCloseBtn"
  );
  const defaultReminderCancelBtn = document.getElementById(
    "defaultReminderCancelBtn"
  );
  const defaultReminderSaveBtn = document.getElementById(
    "defaultReminderSaveBtn"
  );
  const defaultReminderAmount = document.getElementById(
    "defaultReminderAmount"
  );
  const defaultReminderUnit = document.getElementById("defaultReminderUnit");
  const defaultReminderNotify = document.getElementById(
    "defaultReminderNotify"
  );
  const defaultReminderSound = document.getElementById(
    "defaultReminderSound"
  );
  const defaultReminderVibrate = document.getElementById(
    "defaultReminderVibrate"
  );
  const defaultReminderStatus = document.getElementById(
    "defaultReminderStatus"
  );
  const reminderVolume = document.getElementById("reminderVolume");
  const reminderVolumeValue = document.getElementById("reminderVolumeValue");
  const testReminderBtn = document.getElementById("testReminderBtn");
  const noteInput = document.getElementById("note");
  const locationInput = document.getElementById("location");
  const memoPinned = document.getElementById("memoPinned");
  const toastEl = document.getElementById("toast");
  const checkUpdateBtn = document.getElementById("checkUpdateBtn");
  const layoutSettingsBtn = document.getElementById("layoutSettingsBtn");
  const layoutSettingsOverlay = document.getElementById(
    "layoutSettingsOverlay"
  );
  const layoutSettingsCloseBtn = document.getElementById(
    "layoutSettingsCloseBtn"
  );
  const layoutSettingsDoneBtn = document.getElementById(
    "layoutSettingsDoneBtn"
  );
  const layoutResetBtn = document.getElementById("layoutResetBtn");
  const layoutSafeTop = document.getElementById("layoutSafeTop");
  const layoutSafeBottom = document.getElementById("layoutSafeBottom");
  const layoutTopExtra = document.getElementById("layoutTopExtra");
  const layoutBottomExtra = document.getElementById("layoutBottomExtra");
  const layoutTopExtraValue = document.getElementById(
    "layoutTopExtraValue"
  );
  const layoutBottomExtraValue = document.getElementById(
    "layoutBottomExtraValue"
  );
  const layoutNavMode = document.getElementById("layoutNavMode");
  const layoutFabMode = document.getElementById("layoutFabMode");
  const noteLayoutFontFamily = document.getElementById(
    "noteLayoutFontFamily"
  );
  const noteLayoutFontSize = document.getElementById("noteLayoutFontSize");
  const noteLayoutFontSizeValue = document.getElementById(
    "noteLayoutFontSizeValue"
  );
  const noteLayoutLineHeight = document.getElementById(
    "noteLayoutLineHeight"
  );
  const noteLayoutLineHeightValue = document.getElementById(
    "noteLayoutLineHeightValue"
  );
  const noteLayoutPadding = document.getElementById(
    "noteLayoutPadding"
  );
  const noteLayoutPaddingValue = document.getElementById(
    "noteLayoutPaddingValue"
  );
  const noteLayoutAlign = document.getElementById("noteLayoutAlign");
  const noteEditorUiScale = document.getElementById(
    "noteEditorUiScale"
  );
  const noteEditorUiScaleValue = document.getElementById(
    "noteEditorUiScaleValue"
  );
  const noteHeaderMode = document.getElementById("noteHeaderMode");
  const noteHeaderOffset = document.getElementById("noteHeaderOffset");
  const noteHeaderOffsetValue = document.getElementById(
    "noteHeaderOffsetValue"
  );
  const layoutSystemInfo = document.getElementById("layoutSystemInfo");
  const iosInstallHint = document.getElementById("iosInstallHint");
  const iosInstallDismiss = document.getElementById("iosInstallDismiss");
  const desktopDownloadPageLink = document.getElementById(
    "desktopDownloadPageLink"
  );
  const directDesktopDownload = document.getElementById("directDesktopDownload");
  const copyDesktopLinkBtn = document.getElementById("copyDesktopLinkBtn");
  const shareDesktopLinkBtn = document.getElementById("shareDesktopLinkBtn");
  const desktopDownloadBtn = document.getElementById("desktopDownloadBtn");
  const desktopDownloadOverlay = document.getElementById(
    "desktopDownloadOverlay"
  );
  const desktopDownloadCloseBtn = document.getElementById(
    "desktopDownloadCloseBtn"
  );
  const mobileDownloadBtn = document.getElementById("mobileDownloadBtn");
  const mobileDownloadOverlay = document.getElementById(
    "mobileDownloadOverlay"
  );
  const mobileDownloadCloseBtn = document.getElementById(
    "mobileDownloadCloseBtn"
  );
  const mobileDownloadQrSaveBtn = document.getElementById(
    "mobileDownloadQrSaveBtn"
  );
  const mobileDownloadQrStatus = document.getElementById(
    "mobileDownloadQrStatus"
  );
  const nativeBridge = window.AndroidMemo || null;
  const isDesktopSurface =
    document.body.dataset.desktopSurface === "true";
  const isIOSDevice =
    /iPad|iPhone|iPod/i.test(navigator.userAgent) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const isMobileSyncSurface =
    Boolean(nativeBridge) ||
    isIOSDevice ||
    (!isDesktopSurface && /Android|Mobile/i.test(navigator.userAgent));
  // Production iOS PWAs are served over HTTPS. Safari blocks mixed-content
  // HTTP requests to an Android LAN endpoint, so relay mode must stay off
  // until a WebRTC transport is available.
  const isPwaRelayClient = false;
  const friendBridge =
    nativeBridge || (isPwaRelayClient ? createPwaFriendBridge() : null);

  const BETA_SESSION_KEY = "buaa_beta_access_v1";
  const BETA_ATTEMPTS_KEY = "buaa_beta_attempts_v1";
  const USER_ROLE_KEY = "buaa_user_role_v1";
  const REDEMPTION_ATTEMPTS_KEY = "buaa_redemption_attempts_v1";
  const FRIEND_LIMIT = 20;
  const REDEMPTION_CODES = Object.freeze([
    {
      role: "开发者",
      sha256:
        "3f0c8f808c66aae2c4fd14aa9dfb2834857a544ea06192b53fa3c36d01c0ab62",
      fallback: "5f4c42df75f337e2",
    },
  ]);
  const BETA_ALLOWED_SHA256 = new Set([
    "a0542cedc6f6724b4555b678ed1882ccf89c0dd9c6484bed81de4d60a4a9f2a4",
    "2ae5877ac6a2bb3754943d2e2620d94c2345b0a6f7a8c73380a8b7d6e4b3e195",
    "b1f14a7e9ea8d8bc8eb0ae28862d0f85045aa0a54397e5a3439a3b0e3365d347",
    "cb2d82830b16cdd2889f712879f65345b97417b420840df035c0860d98675285",
    "87889ef5f86b9179ec28d608f6e94cdbe877a336c6d9670ce1b80e551da53c18",
    "8fc9d70674bd5e6cd4f789feb9e732e55cd5dbdc65e721a7bdcb4295fa523e3f",
    "07d5936faac72f63309337a8d2d99d1ed52712da985941efe76a2561cd63a25f",
    "b9ae77bc3a16ca7956d173ab4204feecb09097d40e239aad770d3a7611c1574b",
    "c015f49e45c6747e9f60357f36e43b407386b3df8ff35336b8b8c194ffc44cb8",
    "04b530d72dddda4b14fd0c95b96e80de64e2a00c7c7074be731377059ca09489",
  ]);
  const BETA_ALLOWED_FALLBACK = new Set([
    "2a879a1df459adc3",
    "719fe6c7630f40dc",
    "4ee333f2c4000d3d",
    "05e7d70ae895e4ad",
    "554995e5d7bbe7f2",
    "d373503f1b7ad877",
    "56675d80e90cda90",
    "1288aad28c5b4810",
    "a73e8c3497a4fabe",
    "95108ce8b984631a",
  ]);
  const betaGate = document.getElementById("betaGate");
  const betaLoginForm = document.getElementById("betaLoginForm");
  const betaKeyInput = document.getElementById("betaKeyInput");
  const betaLoginBtn = document.getElementById("betaLoginBtn");
  const betaLoginStatus = document.getElementById("betaLoginStatus");
  const betaBadge = document.getElementById("betaBadge");

  function normalizeBetaKey(value) {
    return String(value || "")
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, "");
  }

  function fallbackBetaHash(value) {
    const text = `BUAA-BETA-V1|${value}`;
    let first = 0x811c9dc5;
    let second = 0x9e3779b9;
    for (let index = 0; index < text.length; index += 1) {
      const code = text.charCodeAt(index);
      first = Math.imul(first ^ code, 0x01000193) >>> 0;
      second = Math.imul(second ^ (code + index * 131), 0x85ebca6b) >>> 0;
      second ^= second >>> 13;
      second = Math.imul(second, 0xc2b2ae35) >>> 0;
    }
    first = Math.imul(first ^ (second >>> 16), 0x85ebca6b) >>> 0;
    second = Math.imul(second ^ (first >>> 13), 0xc2b2ae35) >>> 0;
    return `${first.toString(16).padStart(8, "0")}${second
      .toString(16)
      .padStart(8, "0")}`;
  }

  async function hashBetaKey(value) {
    const normalized = normalizeBetaKey(value);
    try {
      if (window.crypto?.subtle && window.TextEncoder) {
        const bytes = new TextEncoder().encode(normalized);
        const digest = await window.crypto.subtle.digest("SHA-256", bytes);
        return {
          kind: "sha256",
          hash: Array.from(new Uint8Array(digest))
            .map(byte => byte.toString(16).padStart(2, "0"))
            .join(""),
        };
      }
    } catch {
      // Older local WebViews may not expose Web Crypto in file contexts.
    }
    return { kind: "fallback", hash: fallbackBetaHash(normalized) };
  }

  function readBetaSession() {
    try {
      const session = JSON.parse(
        localStorage.getItem(BETA_SESSION_KEY) || "null"
      );
      if (!session || session.role !== "内测用户") return "";
      if (
        session.kind === "sha256" &&
        BETA_ALLOWED_SHA256.has(String(session.hash || ""))
      ) {
        return String(session.hash);
      }
      if (
        session.kind === "fallback" &&
        BETA_ALLOWED_FALLBACK.has(String(session.hash || ""))
      ) {
        return String(session.hash);
      }
    } catch {}
    return "";
  }

  function currentUserRole() {
    try {
      return localStorage.getItem(USER_ROLE_KEY) === "开发者"
        ? "开发者"
        : "内测用户";
    } catch {
      return "内测用户";
    }
  }

  function isDeveloperUser() {
    return currentUserRole() === "开发者";
  }

  function applyUserIdentity() {
    const developer = isDeveloperUser();
    if (betaBadge) {
      betaBadge.textContent = developer ? "开发者" : "内测用户";
      betaBadge.classList.toggle("developer-identity", developer);
    }
    if (profileAvatar) {
      profileAvatar.textContent = developer ? "✦" : "B";
      profileAvatar.classList.toggle("developer-avatar", developer);
    }
    if (profileRoleLabel) {
      profileRoleLabel.textContent = developer
        ? "开发者 · 好友数量无上限"
        : "内测用户 · 本地保存";
      profileRoleLabel.classList.toggle("developer-role-label", developer);
    }
  }

  function syncDeveloperModeToNative() {
    try {
      nativeBridge?.setDeveloperMode?.(isDeveloperUser());
    } catch {}
  }

  function betaAttemptState() {
    try {
      const state = JSON.parse(
        localStorage.getItem(BETA_ATTEMPTS_KEY) || "{}"
      );
      return state && typeof state === "object" ? state : {};
    } catch {
      return {};
    }
  }

  function saveBetaAttemptState(state) {
    try {
      localStorage.setItem(BETA_ATTEMPTS_KEY, JSON.stringify(state));
    } catch {}
  }

  function setupBetaGate() {
    document.body.classList.add("beta-locked");
    if (betaGate) betaGate.hidden = false;
    if (betaBadge) betaBadge.hidden = true;
    const state = betaAttemptState();
    const blockedUntil = Number(state.blockedUntil || 0);
    const blockSeconds = Math.ceil((blockedUntil - Date.now()) / 1000);
    if (blockSeconds > 0 && betaLoginStatus) {
      betaLoginStatus.textContent = `尝试次数过多，请 ${blockSeconds} 秒后再试。`;
      if (betaLoginBtn) betaLoginBtn.disabled = true;
      window.setTimeout(() => {
        if (betaLoginBtn) betaLoginBtn.disabled = false;
        if (betaLoginStatus) betaLoginStatus.textContent = "";
      }, blockSeconds * 1000);
    }
    window.setTimeout(() => betaKeyInput?.focus(), 80);

    betaLoginForm?.addEventListener("submit", async event => {
      event.preventDefault();
      const stateNow = betaAttemptState();
      if (Number(stateNow.blockedUntil || 0) > Date.now()) {
        if (betaLoginStatus) {
          betaLoginStatus.textContent = "尝试次数过多，请稍后再试。";
        }
        return;
      }
      const rawKey = String(betaKeyInput?.value || "").trim();
      const normalized = normalizeBetaKey(rawKey);
      if (normalized.length < 16) {
        if (betaLoginStatus) {
          betaLoginStatus.textContent = "请输入完整的内测密钥。";
        }
        betaKeyInput?.focus();
        return;
      }
      if (betaLoginBtn) {
        betaLoginBtn.disabled = true;
        betaLoginBtn.textContent = "正在验证…";
      }
      if (betaLoginStatus) betaLoginStatus.textContent = "";
      const result = await hashBetaKey(normalized);
      const accepted =
        result.kind === "sha256"
          ? BETA_ALLOWED_SHA256.has(result.hash)
          : BETA_ALLOWED_FALLBACK.has(result.hash);
      if (!accepted) {
        const failures = Number(stateNow.failures || 0) + 1;
        const nextState = {
          failures,
          blockedUntil:
            failures >= 5 ? Date.now() + 60 * 1000 : Number(stateNow.blockedUntil || 0),
        };
        saveBetaAttemptState(
          failures >= 5 ? { failures: 0, blockedUntil: nextState.blockedUntil } : nextState
        );
        if (betaLoginStatus) {
          betaLoginStatus.textContent =
            failures >= 5
              ? "密钥无效，尝试次数过多，请 60 秒后再试。"
              : "密钥无效，请检查后重试。";
        }
        if (betaLoginBtn) {
          betaLoginBtn.disabled = false;
          betaLoginBtn.textContent = "验证并进入";
        }
        betaKeyInput?.select();
        return;
      }
      try {
        localStorage.setItem(
          BETA_SESSION_KEY,
          JSON.stringify({
            role: "内测用户",
            kind: result.kind,
            hash: result.hash,
            activatedAt: new Date().toISOString(),
          })
        );
        localStorage.removeItem(BETA_ATTEMPTS_KEY);
      } catch {
        if (betaLoginStatus) {
          betaLoginStatus.textContent = "浏览器未允许保存登录状态，请检查本地存储权限。";
        }
        if (betaLoginBtn) {
          betaLoginBtn.disabled = false;
          betaLoginBtn.textContent = "验证并进入";
        }
        return;
      }
      if (betaLoginStatus) {
        betaLoginStatus.style.color = "#176b4d";
        betaLoginStatus.textContent = "密钥验证成功，已激活内测用户身份。";
      }
      window.setTimeout(() => window.location.reload(), 650);
    });
  }

  if (!readBetaSession()) {
    setupBetaGate();
    return;
  }
  document.body.classList.remove("beta-locked");
  if (betaBadge) betaBadge.hidden = false;
  applyUserIdentity();
  syncDeveloperModeToNative();

  document.querySelector(".offline-box")?.remove();

  let records = [];
  let editingId = null;
  let editingGroupId = null;
  let activeGroupDetailId = null;
  let activePage = "memos";
  let activeFriendId = "";
  let activeGiftFriendId = "";
  let activeTaskTab = "daily";
  let cachedClaimableTaskCount = 0;
  let taskBadgeRefreshTimer = 0;
  let lastCountdownStatusCheck = 0;
  let pendingSharedMemoId = "";
  let friendRuntime = {
    friend_code: "",
    device_id: "",
    device_name: "",
    ip: "",
    port: 0,
    incoming: [],
    outgoing: [],
    friends: [],
    inbox: [],
  };
  let friendPeers = new Map();
  let friendPollRunning = false;
  let friendPollTimer = null;
  let friendDiscoveryTimer = null;
  let friendPeerDiscoveryPromise = null;
  let friendPeerDiscoveryTimer = 0;
  let friendPeerDiscoveryRequestId = 0;
  let noteEditorType = "diary";
  let noteFilterType = "all";
  let editingNoteId = null;
  let activeViewedNoteId = "";
  let noteDraftBody = "";
  let noteDraftHtml = "";
  let noteFontColorValue = "#385365";
  let noteFontWeightValue = "normal";
  let noteFontDecorationValue = "none";
  let noteFontFamilyValue = "system";
  let noteBaseFontColor = "#385365";
  let noteBaseFontWeight = "normal";
  let noteBaseFontDecoration = "none";
  let noteBaseFontFamily = "system";
  let savedNoteSelectionRange = null;
  let activeMathTab = "symbols";
  let activeMathCategory = "analysis";
  let editingMathNode = null;
  let insertedMathSymbolCount = 0;
  let pendingPastePayload = { text: "", html: "" };
  let noteTapSequence = { count: 0, time: 0, x: 0, y: 0 };
  let noteViewportRefreshTimer = 0;
  let editorType = "task";
  let syncing = false;
  let toastTimer = null;
  let editingImageData = null;
  let monthCursor = new Date(
    new Date().getFullYear(),
    new Date().getMonth(),
    1
  );
  let changelogEntries = null;
  let renderedHistoryCount = 0;
  let historyGroupMemoId = "";
  let latestRemoteVersion = "";
  let liveUpdateAvailable = false;
  let updateCheckState = "checking";
  let updateDownloadVersion = "";
  let updateDownloadPercent = 0;
  let updateInstallWaiting = false;
  let liveUpdateTimer = null;
  let versionCheckPromise = null;
  let nativeUpdateResolution = null;
  let nativeUpdateTimer = null;
  let desktopPersistTimer = null;
  let desktopRefreshRunning = false;
  const LAYOUT_SETTINGS_KEY = "buaa_mobile_layout_v1";
  const PHONE_SYNC_ADDRESS_KEY = "buaa_phone_sync_address_v1";
  const PHONE_SYNC_TOKEN_KEY = "buaa_phone_sync_token_v1";
  const PHONE_SYNC_DEVICE_KEY = "buaa_phone_sync_device_v1";
  const PHONE_SYNC_CLIENT_KEY = "buaa_phone_sync_client_v1";
  const DESKTOP_PEER_ADDRESS_KEY = "buaa_desktop_peer_address_v1";
  const DESKTOP_PEER_TOKEN_KEY = "buaa_desktop_peer_token_v1";
  const DEFAULT_REMINDER_KEY = "buaa_default_reminder_v1";
  const FRIEND_IDENTITY_KEY = "buaa_friend_e2ee_identity_v1";
  const FRIEND_CHAT_KEY = "buaa_friend_chats_v1";
  const FRIEND_PENDING_KEY = "buaa_friend_pending_v1";
  const MAIL_STORAGE_KEY = "buaa_mail_v1";
  const BACKPACK_STORAGE_KEY = "buaa_backpack_items_v1";
  const GLOW_SPOTS_STORAGE_KEY = "buaa_glow_spots_v1";
  const EXPERIENCE_STORAGE_KEY = "buaa_experience_v1";
  const TASK_STATE_STORAGE_KEY = "buaa_task_state_v1";
  const CHECKIN_STORAGE_KEY = "buaa_checkins_v1";
  const EXPERIENCE_MAX_LEVEL = 50;
  const ACCOUNT_NICKNAME_KEY = "buaa_account_nickname_v1";
  const FRIEND_ACTIVE_POLL_INTERVAL = 3000;
  const FRIEND_IDLE_POLL_INTERVAL = 15000;
  const FRIEND_DISCOVERY_INTERVAL = 45000;
  const FRIEND_OFFLINE_RELAY_RETRY = 60000;
  const DEFAULT_LAYOUT_SETTINGS = Object.freeze({
    safeTop: true,
    safeBottom: true,
    topExtra: 0,
    bottomExtra: 0,
    navMode: "fixed",
    fabMode: "compact",
    noteFontFamily: "system",
    noteFontSize: 16,
    noteLineHeight: 1.8,
    notePadding: 18,
    noteAlign: "left",
    noteUiScale: 100,
    noteHeaderMode: "auto",
    noteHeaderOffset: 8,
  });
  const DEFAULT_REMINDER_SETTINGS = Object.freeze({
    minutes: 15,
    modes: ["notification"],
  });

  function installMobilePerformanceMode() {
    const body = document.body;
    const memory = Number(navigator.deviceMemory || 0);
    const cores = Number(navigator.hardwareConcurrency || 0);
    if (
      (memory > 0 && memory <= 4) ||
      (cores > 0 && cores <= 4)
    ) {
      body.dataset.performance = "lite";
    }

    let motionResumeTimer = 0;
    const pauseBackgroundMotion = () => {
      body.classList.add("is-interacting");
      window.clearTimeout(motionResumeTimer);
      motionResumeTimer = window.setTimeout(() => {
        body.classList.remove("is-interacting");
      }, 180);
    };
    window.addEventListener("scroll", pauseBackgroundMotion, {
      passive: true,
    });
    document.addEventListener("touchmove", pauseBackgroundMotion, {
      passive: true,
    });

    if (
      body.dataset.performance === "lite" ||
      window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches
    ) {
      return;
    }
    window.setTimeout(() => {
      if (document.hidden) return;
      let start = 0;
      let frames = 0;
      const sample = now => {
        if (document.hidden) return;
        if (!start) start = now;
        frames += 1;
        if (now - start < 1200) {
          window.requestAnimationFrame(sample);
          return;
        }
        const fps = ((frames - 1) * 1000) / Math.max(1, now - start);
        if (fps < 45 || (fps < 52 && memory > 0 && memory <= 6)) {
          body.dataset.performance = "lite";
        }
      };
      window.requestAnimationFrame(sample);
    }, 1600);
  }

  let layoutSettings = { ...DEFAULT_LAYOUT_SETTINGS };
  let defaultReminderSettings = { ...DEFAULT_REMINDER_SETTINGS };
  let nativeSystemInsets = {
    top: null,
    bottom: null,
    left: null,
    right: null,
  };
  let syncUrl =
    localStorage.getItem(SYNC_URL_KEY) || bootstrap.syncWsUrl || "";
  if (bootstrap.syncWsUrl && !localStorage.getItem(SYNC_URL_KEY)) {
    localStorage.setItem(SYNC_URL_KEY, bootstrap.syncWsUrl);
  }
  const cloudSyncUrl = bootstrap.cloudSyncUrl || "";
  const cloudPublishableKey = bootstrap.cloudPublishableKey || "";
  let cloudVaultKey =
    localStorage.getItem(CLOUD_VAULT_KEY) || bootstrap.cloudVaultKey || "";
  let recordsStorageKey = cloudVaultKey
    ? `${STORAGE_KEY}:${cloudVaultKey}`
    : STORAGE_KEY;
  let cloudCursor = 0;
  let cloudPushRev = 0;
  let phoneSyncAddress =
    localStorage.getItem(PHONE_SYNC_ADDRESS_KEY) || "";
  let phoneSyncToken =
    localStorage.getItem(PHONE_SYNC_TOKEN_KEY) || "";
  let phoneSyncDevice =
    localStorage.getItem(PHONE_SYNC_DEVICE_KEY) || "";
  let phoneSyncClient =
    localStorage.getItem(PHONE_SYNC_CLIENT_KEY) || "";
  let desktopPeerAddress =
    localStorage.getItem(DESKTOP_PEER_ADDRESS_KEY) || "";
  let desktopPeerToken =
    localStorage.getItem(DESKTOP_PEER_TOKEN_KEY) || "";
  let pendingSyncChanges = [];
  let activeSyncPeer = null;
  if (!phoneSyncClient) {
    phoneSyncClient =
      globalThis.crypto?.randomUUID?.() ||
      `desktop-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    localStorage.setItem(PHONE_SYNC_CLIENT_KEY, phoneSyncClient);
  }

  function cloudCursorKey() {
    return cloudVaultKey
      ? `${CLOUD_CURSOR_KEY}:${cloudVaultKey}`
      : CLOUD_CURSOR_KEY;
  }

  function cloudPushKey() {
    return cloudVaultKey
      ? `${CLOUD_PUSH_REV_KEY}:${cloudVaultKey}`
      : CLOUD_PUSH_REV_KEY;
  }

  function loadCloudProgress() {
    cloudCursor = Number(localStorage.getItem(cloudCursorKey()) || 0) || 0;
    cloudPushRev =
      Number(localStorage.getItem(cloudPushKey()) || 0) || 0;
  }

  function saveCloudProgress() {
    localStorage.setItem(cloudCursorKey(), String(cloudCursor));
    localStorage.setItem(cloudPushKey(), String(cloudPushRev));
  }

  function resetCloudProgress() {
    cloudCursor = 0;
    cloudPushRev = 0;
    saveCloudProgress();
  }

  function normalizeVaultKey(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    const match = raw.match(/[?&#]vault=([A-Za-z0-9_-]{20,})/);
    return match ? match[1] : raw;
  }

  function switchCloudVault(nextVault) {
    const normalized = normalizeVaultKey(nextVault);
    if (!normalized || normalized === cloudVaultKey) {
      return false;
    }
    const previousVault = cloudVaultKey;
    const unpairedRecords = previousVault
      ? ""
      : localStorage.getItem(STORAGE_KEY) || "";
    cloudVaultKey = normalized;
    recordsStorageKey = `${STORAGE_KEY}:${cloudVaultKey}`;
    if (unpairedRecords && !localStorage.getItem(recordsStorageKey)) {
      localStorage.setItem(recordsStorageKey, unpairedRecords);
    }
    if (previousVault) {
      records = [];
    }
    localStorage.setItem(CLOUD_VAULT_KEY, cloudVaultKey);
    resetCloudProgress();
    return true;
  }

  const hashParams = new URLSearchParams(location.hash.replace(/^#/, ""));
  const searchParams = new URLSearchParams(location.search);
  const searchVault = normalizeVaultKey(searchParams.get("vault"));
  const hashVault = normalizeVaultKey(hashParams.get("vault"));
  const linkedVault = hashVault || searchVault;
  if (linkedVault) {
    switchCloudVault(linkedVault);
    try {
      history.replaceState(null, "", location.pathname);
    } catch {}
  }
  loadCloudProgress();

  function nextRevision(record = null) {
    return Math.max(Date.now(), Number(record?.rev || 0) + 1);
  }

  function isBlockedRecord(record) {
    return Boolean(
      record &&
      record.id &&
      BLOCKED_RECORD_IDS.has(String(record.id))
    );
  }

  function mergeRecords(...groups) {
    const byId = new Map();
    for (const group of groups) {
      for (const record of Array.isArray(group) ? group : []) {
        if (!record || !record.id || isBlockedRecord(record)) continue;
        const normalized = {
          ...record,
          id: String(record.id),
          rev: Number(record.rev || 0),
          deleted: Boolean(record.deleted),
        };
        const existing = byId.get(normalized.id);
        if (!existing || normalized.rev >= Number(existing.rev || 0)) {
          byId.set(normalized.id, normalized);
        }
      }
    }
    return [...byId.values()];
  }

  function mondayOf(value) {
    const result = new Date(value);
    result.setHours(0, 0, 0, 0);
    const offset = (result.getDay() + 6) % 7;
    result.setDate(result.getDate() - offset);
    return result;
  }

  function dayStartOf(value) {
    const result = new Date(value);
    result.setHours(0, 0, 0, 0);
    return result;
  }

  function isGroupRecord(record) {
    return record?.record_kind === "group";
  }

  function isNoteRecord(record) {
    return record?.record_kind === "note";
  }

  function groupRecords() {
    return records
      .filter(record => !record.deleted && isGroupRecord(record))
      .sort((left, right) =>
        String(left.title || "").localeCompare(String(right.title || ""), "zh-CN")
      );
  }

  function memoRecords() {
    return records.filter(
      record =>
        !record.deleted &&
        !isGroupRecord(record) &&
        !isNoteRecord(record)
    );
  }

  function noteRecords() {
    return records
      .filter(record => !record.deleted && isNoteRecord(record))
      .sort((left, right) => {
        const dateCompare = String(right.note_date || "").localeCompare(
          String(left.note_date || "")
        );
        if (dateCompare) return dateCompare;
        return (
          new Date(right.updated_at || 0).getTime() -
          new Date(left.updated_at || 0).getTime()
        );
      });
  }

  function groupById(groupId) {
    return records.find(
      record =>
        record.id === groupId &&
        !record.deleted &&
        isGroupRecord(record)
    );
  }

  function isHistorical(record) {
    if (isGroupRecord(record)) return false;
    if (isNoteRecord(record)) return false;
    if (isCompleted(record)) return true;
    const deadline = new Date(record.deadline).getTime();
    return (
      Number.isFinite(deadline) &&
      deadline + HISTORY_GRACE_MS <= Date.now()
    );
  }

  function scheduleDesktopPersist() {
    if (!isDesktopSurface) return;
    clearTimeout(desktopPersistTimer);
    desktopPersistTimer = setTimeout(async () => {
      try {
        await fetch("api/records", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ records }),
          cache: "no-store",
        });
      } catch {}
    }, 220);
  }

  async function refreshDesktopRecords() {
    if (!isDesktopSurface || desktopRefreshRunning) return;
    desktopRefreshRunning = true;
    try {
      const response = await fetch("api/records", {
        headers: { "Accept": "application/json" },
        cache: "no-store",
      });
      const payload = await response.json();
      if (!response.ok || !Array.isArray(payload.records)) return;
      const before = JSON.stringify(records);
      records = mergeRecords(records, payload.records);
      if (JSON.stringify(records) !== before) {
        localStorage.setItem(recordsStorageKey, JSON.stringify(records));
        render();
      }
    } catch {
      // Keep local records available while the desktop backend is busy.
    } finally {
      desktopRefreshRunning = false;
    }
  }

  function persist(syncDesktop = true) {
    try {
      if (nativeBridge) {
        const saved = nativeBridge.writeRecords(JSON.stringify(records));
        if (!saved) {
          showToast("Android 本地保存失败");
        }
        if (saved) queueReminderReschedule();
        return saved;
      }
      localStorage.setItem(recordsStorageKey, JSON.stringify(records));
      if (syncDesktop) scheduleDesktopPersist();
      queueReminderReschedule();
      return true;
    } catch {
      showToast("浏览器未允许本地保存，请更换浏览器打开");
      return false;
    }
  }

  function loadRecords() {
    if (nativeBridge) {
      try {
        const raw = nativeBridge.readRecords();
        const loaded = raw ? JSON.parse(raw) : [];
        records = Array.isArray(loaded)
          ? loaded.filter(record => !isBlockedRecord(record))
          : [];
      } catch {
        records = [];
      }
      migrateLegacyNoteLayoutSnapshots();
      return;
    }
    let localRecords = [];
    try {
      const raw = localStorage.getItem(recordsStorageKey);
      localRecords = raw ? JSON.parse(raw) : [];
      if (!Array.isArray(localRecords)) localRecords = [];
      localRecords = localRecords.filter(record => !isBlockedRecord(record));
    } catch {
      localRecords = [];
    }
    records = mergeRecords(localRecords, bootstrap.seedRecords || []);
    migrateLegacyNoteLayoutSnapshots();
  }

  function activeRecords() {
    return records.filter(
      record =>
        !record.deleted &&
        !isGroupRecord(record) &&
        !isNoteRecord(record) &&
        !isHistorical(record)
    );
  }

  function historyRecords() {
    return records
      .filter(
        record =>
          !record.deleted &&
          !isGroupRecord(record) &&
          !isNoteRecord(record) &&
          isHistorical(record)
      )
      .sort((left, right) => {
        const leftTime = new Date(left.completed_at || left.deadline || 0).getTime();
        const rightTime = new Date(right.completed_at || right.deadline || 0).getTime();
        return rightTime - leftTime;
      });
  }

  function historyRecordCount() {
    let count = 0;
    for (const record of records) {
      if (
        !record.deleted &&
        !isGroupRecord(record) &&
        !isNoteRecord(record) &&
        isHistorical(record)
      ) {
        count += 1;
      }
    }
    return count;
  }

  function localDateValue(date) {
    const pad = value => String(value).padStart(2, "0");
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  }

  function defaultDeadline() {
    const value = new Date(Date.now() + 24 * 60 * 60 * 1000);
    value.setHours(18, 0, 0, 0);
    dateInput.value = localDateValue(value);
    timeInput.value = "18:00";
  }

  function defaultEventTimes() {
    const start = new Date(Date.now() + 60 * 60 * 1000);
    start.setSeconds(0, 0);
    const end = new Date(start.getTime() + 2 * 60 * 60 * 1000);
    startDateInput.value = localDateValue(start);
    startTimeInput.value = `${String(start.getHours()).padStart(2, "0")}:${String(start.getMinutes()).padStart(2, "0")}`;
    endDateInput.value = localDateValue(end);
    endTimeInput.value = `${String(end.getHours()).padStart(2, "0")}:${String(end.getMinutes()).padStart(2, "0")}`;
  }

  function setEditingImage(dataUrl) {
    editingImageData = dataUrl || null;
    if (editingImageData) {
      imagePreview.src = editingImageData;
      imagePreview.style.display = "block";
      removeImageBtn.style.display = "inline-block";
    } else {
      imagePreview.removeAttribute("src");
      imagePreview.style.display = "none";
      removeImageBtn.style.display = "none";
      imageInput.value = "";
    }
  }

  async function compressImageFile(file) {
    if (file.size > 20 * 1024 * 1024) {
      throw new Error("图片超过 20 MB，请先压缩后再添加");
    }
    const source = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
    const image = await new Promise((resolve, reject) => {
      const element = new Image();
      element.onload = () => resolve(element);
      element.onerror = reject;
      element.src = source;
    });
    const maxWidth = 720;
    const maxHeight = 480;
    const scale = Math.min(
      1,
      maxWidth / image.naturalWidth,
      maxHeight / image.naturalHeight
    );
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
    const webp = canvas.toDataURL("image/webp", 0.72);
    return webp.startsWith("data:image/webp")
      ? webp
      : canvas.toDataURL("image/jpeg", 0.76);
  }

  function isEvent(memo) {
    return memo?.item_type === "event";
  }

  function isCompleted(memo) {
    return Boolean(memo?.completed || memo?.completed_at);
  }

  function formatRemaining(deadlineText) {
    const deadline = new Date(deadlineText).getTime();
    const seconds = Math.floor((deadline - Date.now()) / 1000);
    if (!Number.isFinite(seconds)) return "时间无效";
    if (seconds <= 0) {
      const archiveSeconds = Math.floor(
        (deadline + HISTORY_GRACE_MS - Date.now()) / 1000
      );
      if (archiveSeconds <= 0) return "已归档";
      const archiveHours = Math.floor(archiveSeconds / 3600);
      const archiveMinutes = Math.floor((archiveSeconds % 3600) / 60);
      const archiveSecondsPart = archiveSeconds % 60;
      const pad = value => String(value).padStart(2, "0");
      return `已到期 · ${pad(archiveHours)}:${pad(archiveMinutes)}:${pad(archiveSecondsPart)} 后归档`;
    }
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    const pad = value => String(value).padStart(2, "0");
    return days > 0
      ? `${String(days).padStart(2, "0")} 天 ${pad(hours)}:${pad(minutes)}:${pad(secs)}`
      : `${pad(hours)}:${pad(minutes)}:${pad(secs)}`;
  }

  function statusOf(memo) {
    const seconds = (new Date(memo.deadline).getTime() - Date.now()) / 1000;
    if (seconds <= 0) return ["expired", isEvent(memo) ? "已结束" : "已到期"];
    if (isEvent(memo)) {
      const start = new Date(memo.start_at).getTime();
      if (Number.isFinite(start) && Date.now() < start) {
        return ["pending", "待开始"];
      }
    }
    if (seconds <= 86400) return ["urgent", "进行中"];
    return ["", "进行中"];
  }

  function setEditorType(type) {
    editorType = type === "event" ? "event" : "task";
    const isTask = editorType === "task";
    taskFields.classList.toggle("hidden", !isTask);
    eventFields.classList.toggle("hidden", isTask);
    taskTypeBtn.classList.toggle("active", isTask);
    eventTypeBtn.classList.toggle("active", !isTask);
  }

  function reminderMinutesValue() {
    const amount = Math.max(1, Number(reminderAmount.value) || 1);
    const multiplier = {
      minutes: 1,
      hours: 60,
      days: 1440,
    }[reminderUnit.value] || 1;
    return Math.round(amount * multiplier);
  }

  function reminderModesValue() {
    return [
      reminderNotify.checked ? "notification" : null,
      reminderSound.checked ? "sound" : null,
      reminderVibrate.checked ? "vibration" : null,
    ].filter(Boolean);
  }

  function reminderVolumePercent() {
    return Math.max(
      10,
      Math.min(100, Math.round(Number(reminderVolume.value) || 100))
    );
  }

  function updateReminderVolumeLabel() {
    reminderVolumeValue.textContent = `${reminderVolumePercent()}%`;
  }

  function normalizeDefaultReminder(value = {}) {
    const allowed = new Set(["notification", "sound", "vibration"]);
    const modes = Array.isArray(value.modes)
      ? value.modes.map(String).filter(mode => allowed.has(mode))
      : [];
    return {
      minutes: Math.max(1, Math.min(1_438_560, Number(value.minutes) || 15)),
      modes: modes.length ? Array.from(new Set(modes)) : ["notification"],
    };
  }

  function loadDefaultReminderSettings() {
    try {
      const stored = JSON.parse(
        localStorage.getItem(DEFAULT_REMINDER_KEY) || "null"
      );
      defaultReminderSettings = normalizeDefaultReminder(stored || {});
    } catch {
      defaultReminderSettings = { ...DEFAULT_REMINDER_SETTINGS };
    }
  }

  function saveDefaultReminderSettings() {
    try {
      localStorage.setItem(
        DEFAULT_REMINDER_KEY,
        JSON.stringify(defaultReminderSettings)
      );
    } catch {}
  }

  function formatReminderDelay(minutes) {
    if (minutes % 1440 === 0) return `${minutes / 1440} 天`;
    if (minutes % 60 === 0) return `${minutes / 60} 小时`;
    return `${minutes} 分钟`;
  }

  function formatReminderModes(modes) {
    const labels = {
      notification: "通知栏",
      sound: "响铃",
      vibration: "振动",
    };
    return modes.map(mode => labels[mode]).filter(Boolean).join(" + ");
  }

  function updateDefaultReminderSummary() {
    defaultReminderSettings = normalizeDefaultReminder(
      defaultReminderSettings
    );
    if (defaultReminderSummary) {
      defaultReminderSummary.textContent =
        `${formatReminderDelay(defaultReminderSettings.minutes)} · ` +
        formatReminderModes(defaultReminderSettings.modes);
    }
  }

  function applyDefaultReminderToEditor() {
    const minutes = defaultReminderSettings.minutes;
    reminderEnabled.checked = true;
    if (minutes % 1440 === 0) {
      reminderAmount.value = minutes / 1440;
      reminderUnit.value = "days";
    } else if (minutes % 60 === 0) {
      reminderAmount.value = minutes / 60;
      reminderUnit.value = "hours";
    } else {
      reminderAmount.value = minutes;
      reminderUnit.value = "minutes";
    }
    reminderNotify.checked = defaultReminderSettings.modes.includes(
      "notification"
    );
    reminderSound.checked = defaultReminderSettings.modes.includes("sound");
    reminderVibrate.checked =
      defaultReminderSettings.modes.includes("vibration");
  }

  function syncDefaultReminderControls() {
    const minutes = defaultReminderSettings.minutes;
    if (minutes % 1440 === 0) {
      defaultReminderAmount.value = minutes / 1440;
      defaultReminderUnit.value = "days";
    } else if (minutes % 60 === 0) {
      defaultReminderAmount.value = minutes / 60;
      defaultReminderUnit.value = "hours";
    } else {
      defaultReminderAmount.value = minutes;
      defaultReminderUnit.value = "minutes";
    }
    defaultReminderNotify.checked =
      defaultReminderSettings.modes.includes("notification");
    defaultReminderSound.checked =
      defaultReminderSettings.modes.includes("sound");
    defaultReminderVibrate.checked =
      defaultReminderSettings.modes.includes("vibration");
    defaultReminderStatus.textContent = "";
  }

  function updateReminderOptionsVisibility() {
    const usingDefault = Boolean(useDefaultReminder?.checked);
    if (defaultReminderSummaryBox) {
      defaultReminderSummaryBox.hidden = !usingDefault;
    }
    if (reminderEnabled) {
      reminderEnabled.disabled = usingDefault;
      if (usingDefault) reminderEnabled.checked = true;
    }
    reminderOptions.classList.toggle(
      "hidden",
      usingDefault || !reminderEnabled.checked
    );
  }

  function cancelMemoReminder(memo) {
    nativeBridge?.cancelReminder?.(memo.id);
  }

  function scheduleMemoReminder(memo) {
    if (!memo || !nativeBridge?.scheduleReminder) return;
    if (
      isGroupRecord(memo) ||
      !memo.reminder_enabled ||
      memo.deleted ||
      isCompleted(memo) ||
      isHistorical(memo)
    ) {
      cancelMemoReminder(memo);
      return;
    }
    const anchor = new Date(isEvent(memo) ? memo.start_at : memo.deadline);
    const reminderAt = new Date(
      anchor.getTime() - Number(memo.reminder_minutes || 0) * 60000
    );
    if (
      !Number.isFinite(reminderAt.getTime()) ||
      reminderAt.getTime() <= Date.now()
    ) {
      cancelMemoReminder(memo);
      return;
    }
    const modes = Array.isArray(memo.reminder_modes)
      ? memo.reminder_modes
      : [];
    if (!modes.length) {
      cancelMemoReminder(memo);
      return;
    }
    nativeBridge.scheduleReminder(
      memo.id,
      reminderAt.getTime(),
      memo.title || "BUAA浮光提醒",
      memo.note || (isEvent(memo) ? "事件即将开始" : "任务即将截止"),
      modes.includes("notification"),
      modes.includes("sound"),
      modes.includes("vibration"),
      Math.max(0.1, Math.min(1, Number(memo.reminder_volume || 100) / 100))
    );
  }

  function rescheduleAllReminders() {
    for (const memo of records) scheduleMemoReminder(memo);
  }

  function queueReminderReschedule() {
    clearTimeout(queueReminderReschedule.timer);
    queueReminderReschedule.timer = setTimeout(
      rescheduleAllReminders,
      350
    );
  }

  function formatDeadline(deadlineText) {
    const value = new Date(deadlineText);
    const pad = number => String(number).padStart(2, "0");
    return `${value.getFullYear()}-${pad(value.getMonth() + 1)}-${pad(value.getDate())}  ${pad(value.getHours())}:${pad(value.getMinutes())}`;
  }

  function showToast(message) {
    toastEl.textContent = message;
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("show"), 2300);
  }

  function clampLayoutNumber(value, minimum, maximum, fallback = 0) {
    const number = Number(value);
    if (!Number.isFinite(number)) return fallback;
    return Math.max(minimum, Math.min(maximum, Math.round(number)));
  }

  function clampLayoutDecimal(value, minimum, maximum, fallback = 0) {
    const number = Number(value);
    if (!Number.isFinite(number)) return fallback;
    return Math.max(
      minimum,
      Math.min(maximum, Math.round(number * 10) / 10)
    );
  }

  function normalizeLayoutSettings(value) {
    const source = value && typeof value === "object" ? value : {};
    return {
      safeTop: source.safeTop !== false,
      safeBottom: source.safeBottom !== false,
      topExtra: clampLayoutNumber(source.topExtra, 0, 48, 0),
      bottomExtra: clampLayoutNumber(source.bottomExtra, 0, 64, 0),
      navMode: source.navMode === "flow" ? "flow" : "fixed",
      fabMode: ["large", "inline", "compact"].includes(source.fabMode)
        ? source.fabMode
        : "compact",
      noteFontFamily: ["system", "serif", "kai", "sans"].includes(
        source.noteFontFamily
      )
        ? source.noteFontFamily
        : "system",
      noteFontSize: clampLayoutNumber(source.noteFontSize, 14, 24, 16),
      noteLineHeight: clampLayoutDecimal(
        source.noteLineHeight,
        1.4,
        2.6,
        1.8
      ),
      notePadding: clampLayoutNumber(source.notePadding, 10, 32, 18),
      noteAlign: source.noteAlign === "justify" ? "justify" : "left",
      noteUiScale: clampLayoutNumber(source.noteUiScale, 85, 120, 100),
      noteHeaderMode: ["single", "stacked"].includes(source.noteHeaderMode)
        ? source.noteHeaderMode
        : "auto",
      noteHeaderOffset: clampLayoutNumber(
        source.noteHeaderOffset,
        0,
        64,
        8
      ),
    };
  }

  function loadLayoutSettings() {
    try {
      layoutSettings = normalizeLayoutSettings(
        JSON.parse(localStorage.getItem(LAYOUT_SETTINGS_KEY) || "{}")
      );
    } catch {
      layoutSettings = { ...DEFAULT_LAYOUT_SETTINGS };
    }
  }

  function saveLayoutSettings() {
    localStorage.setItem(
      LAYOUT_SETTINGS_KEY,
      JSON.stringify(layoutSettings)
    );
  }

  function syncLayoutControls() {
    if (!layoutSafeTop) return;
    layoutSafeTop.checked = layoutSettings.safeTop;
    layoutSafeBottom.checked = layoutSettings.safeBottom;
    layoutTopExtra.value = String(layoutSettings.topExtra);
    layoutBottomExtra.value = String(layoutSettings.bottomExtra);
    layoutTopExtraValue.textContent = `${layoutSettings.topExtra} px`;
    layoutBottomExtraValue.textContent = `${layoutSettings.bottomExtra} px`;
    layoutNavMode.value = layoutSettings.navMode;
    layoutFabMode.value = layoutSettings.fabMode;
    noteLayoutFontFamily.value = layoutSettings.noteFontFamily;
    noteLayoutFontSize.value = String(layoutSettings.noteFontSize);
    noteLayoutFontSizeValue.textContent = `${layoutSettings.noteFontSize} px`;
    noteLayoutLineHeight.value = String(layoutSettings.noteLineHeight);
    noteLayoutLineHeightValue.textContent = Number(
      layoutSettings.noteLineHeight
    ).toFixed(1);
    noteLayoutPadding.value = String(layoutSettings.notePadding);
    noteLayoutPaddingValue.textContent = `${layoutSettings.notePadding} px`;
    noteLayoutAlign.value = layoutSettings.noteAlign;
    noteEditorUiScale.value = String(layoutSettings.noteUiScale);
    noteEditorUiScaleValue.textContent = `${layoutSettings.noteUiScale}%`;
    noteHeaderMode.value = layoutSettings.noteHeaderMode;
    noteHeaderOffset.value = String(layoutSettings.noteHeaderOffset);
    noteHeaderOffsetValue.textContent =
      `${layoutSettings.noteHeaderOffset} px`;
  }

  function applyLayoutSettings() {
    const root = document.documentElement;
    if (nativeSystemInsets.top !== null) {
      root.style.setProperty(
        "--native-safe-top",
        `${nativeSystemInsets.top}px`
      );
    }
    if (nativeSystemInsets.bottom !== null) {
      root.style.setProperty(
        "--native-safe-bottom",
        `${nativeSystemInsets.bottom}px`
      );
    }
    if (nativeSystemInsets.left !== null) {
      root.style.setProperty(
        "--native-safe-left",
        `${nativeSystemInsets.left}px`
      );
    }
    if (nativeSystemInsets.right !== null) {
      root.style.setProperty(
        "--native-safe-right",
        `${nativeSystemInsets.right}px`
      );
    }
    root.style.setProperty(
      "--layout-top-extra",
      `${layoutSettings.topExtra}px`
    );
    root.style.setProperty(
      "--layout-bottom-extra",
      `${layoutSettings.bottomExtra}px`
    );
    document.body.classList.toggle(
      "safe-top-off",
      !layoutSettings.safeTop
    );
    document.body.classList.toggle(
      "safe-bottom-off",
      !layoutSettings.safeBottom
    );
    document.body.dataset.navMode = layoutSettings.navMode;
    document.body.dataset.fabMode = layoutSettings.fabMode;
    const noteFontFamilies = {
      system:
        '-apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei UI", sans-serif',
      serif: 'Georgia, "SimSun", "Songti SC", serif',
      kai: '"KaiTi", "STKaiti", "Kaiti SC", serif',
      sans: '"Microsoft YaHei UI", "PingFang SC", Arial, sans-serif',
    };
    root.style.setProperty(
      "--note-editor-font-family",
      noteFontFamilies[layoutSettings.noteFontFamily] ||
        noteFontFamilies.system
    );
    root.style.setProperty(
      "--note-editor-font-size",
      `${layoutSettings.noteFontSize}px`
    );
    root.style.setProperty(
      "--note-editor-line-height",
      String(layoutSettings.noteLineHeight)
    );
    root.style.setProperty(
      "--note-editor-padding",
      `${layoutSettings.notePadding}px`
    );
    root.style.setProperty(
      "--note-editor-text-align",
      layoutSettings.noteAlign
    );
    const noteScale = layoutSettings.noteUiScale / 100;
    root.style.setProperty(
      "--note-editor-control-font-size",
      `${Math.round(11 * noteScale * 10) / 10}px`
    );
    root.style.setProperty(
      "--note-editor-toolbar-font-size",
      `${Math.round(10 * noteScale * 10) / 10}px`
    );
    root.style.setProperty(
      "--note-editor-control-padding-y",
      `${Math.round(8 * noteScale * 10) / 10}px`
    );
    root.style.setProperty(
      "--note-editor-control-padding-x",
      `${Math.round(11 * noteScale * 10) / 10}px`
    );
    const noteSafeTop =
      Math.max(42, Number(nativeSystemInsets.top) || 0) +
      layoutSettings.noteHeaderOffset;
    root.style.setProperty(
      "--note-editor-safe-top",
      `${noteSafeTop}px`
    );
    root.style.setProperty(
      "--note-editor-safe-bottom",
      `${Math.max(12, Number(nativeSystemInsets.bottom) || 0)}px`
    );
    document.querySelector(".note-writing-page")?.setAttribute(
      "data-header-mode",
      layoutSettings.noteHeaderMode
    );
    document.getElementById("addBtn")?.setAttribute(
      "aria-label",
      activePage === "notes"
        ? "新建札记"
        : activePage === "groups"
          ? "新建分组"
          : activePage === "friends"
            ? "添加好友"
            : "新建事项"
    );
    if (layoutSystemInfo) {
      const topText =
        nativeSystemInsets.top === null
          ? "浏览器自动值"
          : `${nativeSystemInsets.top} px`;
      const bottomText =
        nativeSystemInsets.bottom === null
          ? "浏览器自动值"
          : `${nativeSystemInsets.bottom} px`;
      layoutSystemInfo.textContent =
        `检测到顶部安全区：${topText}；底部安全区：${bottomText}。` +
        `自动避让${layoutSettings.safeTop ? "已开启" : "已关闭"}（顶部）、` +
        `${layoutSettings.safeBottom ? "已开启" : "已关闭"}（底部）。`;
    }
    renderNoteLayoutPreview();
    syncLayoutControls();
  }

  function renderNoteLayoutPreview() {
    const sample = noteRecords()[0];
    const color = sample?.font_color || "#385365";
    const weight = sample?.font_weight === "bold" ? "700" : "400";
    const decoration = sample?.font_decoration || "none";
    const root = document.documentElement;
    root.style.setProperty("--note-layout-preview-color", color);
    root.style.setProperty("--note-layout-preview-weight", weight);
    root.style.setProperty(
      "--note-layout-preview-decoration-line",
      decoration === "none" ? "none" : "underline"
    );
    root.style.setProperty(
      "--note-layout-preview-decoration-style",
      decoration === "wavy" ? "wavy" : "solid"
    );
  }

  function updateLayoutSettingsFromControls() {
    layoutSettings = normalizeLayoutSettings({
      safeTop: layoutSafeTop.checked,
      safeBottom: layoutSafeBottom.checked,
      topExtra: layoutTopExtra.value,
      bottomExtra: layoutBottomExtra.value,
      navMode: layoutNavMode.value,
      fabMode: layoutFabMode.value,
      noteFontFamily: noteLayoutFontFamily.value,
      noteFontSize: noteLayoutFontSize.value,
      noteLineHeight: noteLayoutLineHeight.value,
      notePadding: noteLayoutPadding.value,
      noteAlign: noteLayoutAlign.value,
      noteUiScale: noteEditorUiScale.value,
      noteHeaderMode: noteHeaderMode.value,
      noteHeaderOffset: noteHeaderOffset.value,
    });
    saveLayoutSettings();
    applyLayoutSettings();
  }

  function initLayoutSettings() {
    loadLayoutSettings();
    layoutSettingsBtn?.removeAttribute("hidden");
    layoutSettingsOverlay?.removeAttribute("hidden");
    applyLayoutSettings();
    layoutSettingsBtn?.addEventListener("click", () => {
      syncLayoutControls();
      renderNoteLayoutPreview();
      layoutSettingsOverlay.classList.add("show");
    });
    const close = () => layoutSettingsOverlay.classList.remove("show");
    layoutSettingsCloseBtn?.addEventListener("click", close);
    layoutSettingsDoneBtn?.addEventListener("click", close);
    layoutSettingsOverlay?.addEventListener("click", event => {
      if (event.target === layoutSettingsOverlay) close();
    });
    layoutResetBtn?.addEventListener("click", () => {
      layoutSettings = { ...DEFAULT_LAYOUT_SETTINGS };
      saveLayoutSettings();
      applyLayoutSettings();
      showToast("手机排版已恢复默认");
    });
    for (const control of [
      layoutSafeTop,
      layoutSafeBottom,
      layoutTopExtra,
      layoutBottomExtra,
      layoutNavMode,
      layoutFabMode,
      noteLayoutFontFamily,
      noteLayoutFontSize,
      noteLayoutLineHeight,
      noteLayoutPadding,
      noteLayoutAlign,
      noteEditorUiScale,
      noteHeaderMode,
      noteHeaderOffset,
    ]) {
      control?.addEventListener("input", updateLayoutSettingsFromControls);
      control?.addEventListener("change", updateLayoutSettingsFromControls);
    }
  }

  function initIosInstallHint() {
    const isIos =
      /iphone|ipad|ipod/i.test(navigator.userAgent) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    const standalone =
      window.navigator.standalone === true ||
      window.matchMedia?.("(display-mode: standalone)")?.matches;
    const dismissed =
      localStorage.getItem("buaa_pwa_install_dismissed_v1") === "1";
    if (!iosInstallHint || !isIos || standalone || dismissed) return;
    iosInstallHint.hidden = false;
    iosInstallDismiss?.addEventListener("click", () => {
      iosInstallHint.hidden = true;
      localStorage.setItem("buaa_pwa_install_dismissed_v1", "1");
    });
  }

  window.BUAASetSystemInsets = (top, bottom, left, right) => {
    nativeSystemInsets = {
      top: Math.max(0, Number(top) || 0),
      bottom: Math.max(0, Number(bottom) || 0),
      left: Math.max(0, Number(left) || 0),
      right: Math.max(0, Number(right) || 0),
    };
    applyLayoutSettings();
  };

  function setConnectionStatus(online) {
    if (nativeBridge) {
      statusEl.classList.remove("offline");
      statusText.textContent = "手机同步已开启";
      return;
    }
    statusEl.classList.toggle("offline", !online);
    if (phoneSyncToken) {
      statusText.textContent = online
        ? "手机已同步 · 数据已更新"
        : "手机已配对 · 等待下次同步";
      return;
    }
    statusText.textContent = cloudVaultKey
      ? "离线模式 · 数据已保存在本机"
      : "未连接手机 · 点击配对";
  }

  function render() {
    if (activePage === "notes") renderNotes();
    if (activePage === "groups") renderGroups();
    if (
      activeGroupDetailId &&
      groupDetailOverlay.classList.contains("show")
    ) {
      renderGroupDetail();
    }
    const memos = activeRecords();
    memos.sort((left, right) => {
      const leftPinned = left.pinned ? 0 : 1;
      const rightPinned = right.pinned ? 0 : 1;
      const leftTime = new Date(left.deadline).getTime();
      const rightTime = new Date(right.deadline).getTime();
      const now = Date.now();
      const leftActive = leftTime > now ? 0 : 1;
      const rightActive = rightTime > now ? 0 : 1;
      return (
        leftPinned - rightPinned ||
        leftActive - rightActive ||
        leftTime - rightTime
      );
    });

    countEl.textContent = `${memos.length} 项`;
    renderedHistoryCount = historyRecordCount();
    historyBtn.textContent = `历史 ${renderedHistoryCount}`;
    listEl.replaceChildren();

    if (!memos.length) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.innerHTML =
        '<div class="empty-clock">◷</div>还没有事项<br>现在可以先离线记录，联网后自动同步';
      listEl.appendChild(empty);
      return;
    }

    for (const memo of memos) {
      const [stateClass, badgeText] = statusOf(memo);
      const card = document.createElement("article");
      card.className =
        `card ${stateClass}${memo.pinned ? " pinned" : ""}`.trim();
      card.dataset.id = memo.id;

      const head = document.createElement("div");
      head.className = "card-head";
      const title = document.createElement("h2");
      title.className = "card-title";
      title.textContent = memo.title || "未命名事项";
      const badge = document.createElement("span");
      badge.className = "badge";
      badge.textContent = `${isEvent(memo) ? "事件" : "任务"} · ${badgeText}`;
      head.appendChild(title);
      if (memo.pinned) {
        const pinChip = document.createElement("span");
        pinChip.className = "pin-chip";
        pinChip.textContent = "置顶";
        head.appendChild(pinChip);
      }
      head.appendChild(badge);
      card.appendChild(head);

      if (memo.note) {
        const note = document.createElement("div");
        note.className = "note";
        note.textContent = memo.note;
        card.appendChild(note);
      }

      const memoGroupRecord = groupById(memo.group_id);
      if (memoGroupRecord) {
        const groupChip = document.createElement("span");
        groupChip.className = "memo-group-chip";
        groupChip.textContent = `分组 · ${memoGroupRecord.title}`;
        card.appendChild(groupChip);
      }
      if (memo.location) {
        const locationChip = document.createElement("span");
        locationChip.className = "memo-location-chip";
        locationChip.textContent = `地点 · ${memo.location}`;
        card.appendChild(locationChip);
      }

      if (memo.image_data) {
        const image = document.createElement("img");
        image.className = "card-image";
        image.src = memo.image_data;
        image.loading = "lazy";
        image.decoding = "async";
        image.alt = memo.title || "事项图片";
        image.addEventListener("click", () => {
          imageViewerImage.src = memo.image_data;
          imageViewerOverlay.classList.add("show");
        });
        card.appendChild(image);
      }

      const meta = document.createElement("div");
      meta.className = "meta";
      const remainingLabel = document.createElement("span");
      remainingLabel.className = "meta-label";
      remainingLabel.textContent = "剩余时间";
      const remaining = document.createElement("span");
      remaining.className = "remaining";
      remaining.dataset.deadline = memo.deadline;
      remaining.textContent = formatRemaining(memo.deadline);
      let startLabel = null;
      let startValue = null;
      if (isEvent(memo)) {
        startLabel = document.createElement("span");
        startLabel.className = "meta-label";
        startLabel.textContent = "开始时间";
        startValue = document.createElement("span");
        startValue.className = "deadline";
        startValue.textContent = formatDeadline(memo.start_at);
      }
      const deadlineLabel = document.createElement("span");
      deadlineLabel.className = "meta-label";
      deadlineLabel.textContent = isEvent(memo) ? "结束时间" : "终止时间";
      const deadline = document.createElement("span");
      deadline.className = "deadline";
      deadline.textContent = formatDeadline(memo.deadline);
      meta.append(remainingLabel, remaining);
      if (startLabel && startValue) meta.append(startLabel, startValue);
      meta.append(deadlineLabel, deadline);
      card.appendChild(meta);

      const actions = document.createElement("div");
      actions.className = "actions";
      const pinButton = document.createElement("button");
      pinButton.className = "action-btn pin";
      pinButton.textContent = memo.pinned ? "取消置顶" : "置顶";
      pinButton.addEventListener("click", () => toggleMemoPin(memo.id));
      actions.append(pinButton);
      const editButton = document.createElement("button");
      editButton.className = "action-btn";
      editButton.textContent = "编辑";
      editButton.addEventListener("click", () => openEditor(memo.id));
      actions.append(editButton);
      if (!isEvent(memo)) {
        const completeButton = document.createElement("button");
        completeButton.className = "action-btn complete";
        completeButton.textContent = "✓ 完成";
        completeButton.addEventListener("click", () => completeMemo(memo.id));
        actions.append(completeButton);
      }
      if (friendFeatureAvailable()) {
        const shareButton = document.createElement("button");
        shareButton.className = "action-btn";
        shareButton.textContent = "分享";
        shareButton.addEventListener("click", () => openShareMemo(memo.id));
        actions.append(shareButton);
      }
      const deleteButton = document.createElement("button");
      deleteButton.className = "action-btn delete";
      deleteButton.textContent = "删除";
      deleteButton.addEventListener("click", () => deleteMemo(memo.id));
      actions.append(deleteButton);
      card.appendChild(actions);
      listEl.appendChild(card);
    }
  }

  function refreshMemoGroupOptions(selectedId = "") {
    const current = selectedId || memoGroup.value;
    memoGroup.replaceChildren();
    const none = document.createElement("option");
    none.value = "";
    none.textContent = "不分组";
    memoGroup.appendChild(none);
    for (const group of groupRecords()) {
      const option = document.createElement("option");
      option.value = group.id;
      option.textContent = group.title;
      memoGroup.appendChild(option);
    }
    memoGroup.value = groupById(current) ? current : "";
  }

  function setPage(page) {
    activePage =
      page === "groups"
        ? "groups"
        : page === "friends"
          ? "friends"
          : page === "notes"
            ? "notes"
            : "memos";
    memosPage.classList.toggle("active", activePage === "memos");
    notesPage.classList.toggle("active", activePage === "notes");
    groupsPage.classList.toggle("active", activePage === "groups");
    friendsPage.classList.toggle("active", activePage === "friends");
    memosTabBtn.classList.toggle("active", activePage === "memos");
    notesTabBtn.classList.toggle("active", activePage === "notes");
    groupsTabBtn.classList.toggle("active", activePage === "groups");
    friendsTabBtn.classList.toggle("active", activePage === "friends");
    const addButton = document.getElementById("addBtn");
    addButton.textContent =
      activePage === "notes"
        ? "＋ 新建札记"
        : activePage === "groups"
        ? "＋ 新建分组"
        : activePage === "friends"
          ? "＋ 添加好友"
          : "＋ 新建事项";
    addButton.setAttribute(
      "aria-label",
      activePage === "notes"
        ? "新建札记"
        : activePage === "groups"
        ? "新建分组"
        : activePage === "friends"
          ? "添加好友"
          : "新建事项"
    );
    if (activePage === "notes") renderNotes();
    if (activePage === "groups") renderGroups();
    if (activePage === "friends") {
      renderFriends();
      scheduleFriendPoll(0);
      scheduleFriendDiscovery(0);
    } else if (friendDiscoveryTimer) {
      window.clearTimeout(friendDiscoveryTimer);
      friendDiscoveryTimer = null;
    }
  }

  function setNoteEditorType(type) {
    noteEditorType = type === "note" ? "note" : "diary";
    diaryTypeBtn.classList.toggle("active", noteEditorType === "diary");
    noteTypeBtn.classList.toggle("active", noteEditorType === "note");
  }

  function noteDisplayTitle(note) {
    if (String(note.title || "").trim()) return note.title.trim();
    const date = new Date(`${note.note_date}T12:00:00`);
    const dateText = Number.isFinite(date.getTime())
      ? `${date.getMonth() + 1} 月 ${date.getDate()} 日`
      : "未标日期";
    return `${dateText} · ${note.note_type === "note" ? "笔记" : "日记"}`;
  }

  const NOTE_MATH_SYMBOLS = Object.freeze({
    analysis: {
      label: "数学分析",
      symbols: [
        "∞", "∂", "∇", "∫", "∬", "∭", "∮", "∑", "∏", "∐",
        "Δ", "δ", "ε", "η", "λ", "μ", "ξ", "π", "ρ", "σ",
        "τ", "φ", "χ", "ψ", "ω", "≤", "≥", "≠", "≈", "≃",
        "∼", "≅", "≪", "≫", "∝", "→", "←", "↔", "↑", "↓",
        "↦", "⟶", "⟵", "′", "″", "⁰", "¹", "²", "³", "⁴",
        "⁵", "⁶", "⁷", "⁸", "⁹", "⁻", "⁺", "ⁿ", "ⁱ", "ʲ",
        "ᵏ", "ˡ", "ᵐ", "₀", "₁", "₂", "₃", "₄", "₅", "₆",
        "₇", "₈", "₉", "₊", "₋", "₌", "₍", "₎", "ₐ", "ₑ",
        "ₕ", "ᵢ", "ⱼ", "ₖ", "ₗ", "ₘ", "ₙ", "ₒ", "ₚ", "ᵣ",
        "ₛ", "ₜ", "ᵤ", "ᵥ", "ₓ",
      ],
    },
    linear: {
      label: "线性代数",
      symbols: [
        "ℝ", "ℂ", "ℕ", "ℤ", "ℚ", "𝔽", "ℓ", "𝐀", "𝐁", "𝐂",
        "𝐈", "𝐌", "𝐍", "𝐏", "𝐐", "𝐑", "𝐒", "𝐓", "𝐔", "𝐕",
        "𝐖", "𝐱", "𝐲", "𝐳", "𝐛", "𝐮", "𝐯", "𝐰", "𝟎", "𝟏",
        "ᵀ", "ᵢ", "ⱼ", "ₙ", "⊕", "⊗", "⊙", "·", "×", "⋉",
        "⋊", "⟨", "⟩", "‖", "∥", "⊥", "∠", "⊤", "†", "‡",
      ],
    },
    sets: {
      label: "集合与映射",
      symbols: [
        "∈", "∉", "∋", "∌", "⊆", "⊂", "⊇", "⊃", "⊊", "⊋",
        "∪", "∩", "∅", "∖", "△", "∁", "℘", "𝒫", "→", "←",
        "↔", "↦", "⟶", "⟵", "⟷", "∘", "×", "⊔", "⊓", "⊑",
        "⊒", "≔", "≡", "≜",
      ],
    },
    logic: {
      label: "逻辑",
      symbols: [
        "∀", "∃", "∄", "∧", "∨", "¬", "⊤", "⊥", "⇒", "⇐",
        "⇔", "→", "↔", "∴", "∵", "⊢", "⊨", "□", "◇", "⊕",
        "≡", "≢", "∥", "↑", "↓",
      ],
    },
    greek: {
      label: "希腊字母",
      symbols: [
        "α", "β", "γ", "δ", "ε", "ζ", "η", "θ", "ι", "κ",
        "λ", "μ", "ν", "ξ", "ο", "π", "ρ", "ς", "σ", "τ",
        "υ", "φ", "χ", "ψ", "ω", "Γ", "Δ", "Θ", "Λ", "Ξ",
        "Π", "Σ", "Υ", "Φ", "Ψ", "Ω", "ϑ", "ϕ", "ϱ", "ϵ",
      ],
    },
    operators: {
      label: "运算与几何",
      symbols: [
        "±", "∓", "×", "÷", "√", "∛", "∜", "∘", "∗", "⋆",
        "∑", "∏", "∫", "∞", "ℵ", "ℶ", "ℷ", "ℸ", "∠", "∟",
        "⊥", "∥", "≅", "∼", "≈", "△", "□", "◇", "○", "⊙",
        "⊕", "⊗", "⊖", "⊘", "⊛", "⋄", "◊",
      ],
    },
    arrows: {
      label: "箭头",
      symbols: [
        "→", "←", "↔", "↕", "↖", "↗", "↘", "↙", "⇐", "⇒",
        "⇔", "⇑", "⇓", "⇕", "↦", "⟼", "⟶", "⟵", "⟷", "⟹",
        "⟸", "⟺", "↪", "↩", "↬", "↭", "↠", "↣", "↦", "⇀",
        "⇁", "⇌", "⇋", "↑", "↓", "↮", "↯", "⇝", "⇜",
      ],
    },
    relations: {
      label: "关系与比较",
      symbols: [
        "=", "≠", "≈", "≉", "≡", "≢", "≅", "≇", "∼", "≁",
        "∽", "∝", "≤", "≥", "<", ">", "≪", "≫", "≦", "≧",
        "≺", "≻", "⪯", "⪰", "⊂", "⊃", "⊆", "⊇", "⊊", "⊋",
        "⊏", "⊐", "⊑", "⊒", "≔", "≕", "≜", "≝", "≞", "≟",
        "≡", "⟂", "∥", "⊥",
      ],
    },
  });

  const NOTE_LATEX_TEMPLATES = Object.freeze([
    { label: "分式", latex: "\\frac{a}{b}" },
    { label: "根式", latex: "\\sqrt[n]{x}" },
    { label: "下标", latex: "x_{i}" },
    { label: "上标", latex: "x^{2}" },
    { label: "上下标", latex: "x_{i}^{2}" },
    { label: "定积分", latex: "\\int_{a}^{b} f(x)\\,dx" },
    { label: "二重积分", latex: "\\iint_{D} f(x,y)\\,dx\\,dy" },
    { label: "三重积分", latex: "\\iiint_{\\Omega} f\\,dV" },
    { label: "曲线积分", latex: "\\oint_{C} \\mathbf{F}\\cdot d\\mathbf{r}" },
    { label: "求和上下限", latex: "\\sum_{k=1}^{n} a_k" },
    { label: "累乘上下限", latex: "\\prod_{k=1}^{n} a_k" },
    { label: "并集上下限", latex: "\\bigcup_{k=1}^{n} A_k" },
    { label: "交集上下限", latex: "\\bigcap_{k=1}^{n} A_k" },
    { label: "极限", latex: "\\lim_{x\\to x_0} f(x)" },
    { label: "上极限", latex: "\\limsup_{n\\to\\infty} a_n" },
    { label: "下极限", latex: "\\liminf_{n\\to\\infty} a_n" },
    { label: "上确界", latex: "\\sup_{x\\in A} f(x)" },
    { label: "下确界", latex: "\\inf_{x\\in A} f(x)" },
    { label: "最大最小值", latex: "\\max_{x\\in A} f(x),\\quad \\min_{x\\in A} f(x)" },
    { label: "导数", latex: "\\frac{dy}{dx}" },
    { label: "偏导", latex: "\\frac{\\partial f}{\\partial x}" },
    { label: "高阶偏导", latex: "\\frac{\\partial^2 f}{\\partial x\\,\\partial y}" },
    { label: "梯度", latex: "\\nabla f=\\left(\\frac{\\partial f}{\\partial x_1},\\ldots,\\frac{\\partial f}{\\partial x_n}\\right)" },
    { label: "泰勒展开", latex: "f(x)=\\sum_{n=0}^{\\infty}\\frac{f^{(n)}(a)}{n!}(x-a)^n" },
    { label: "傅里叶变换", latex: "\\widehat{f}(\\xi)=\\int_{-\\infty}^{\\infty} f(x)e^{-2\\pi i x\\xi}\\,dx" },
    { label: "向量", latex: "\\mathbf{v}=\\begin{pmatrix}x\\\\y\\\\z\\end{pmatrix}" },
    { label: "范数与内积", latex: "\\lVert x\\rVert_2,\\quad \\langle x,y\\rangle" },
    { label: "转置与逆", latex: "A^{\\mathsf T},\\quad A^{-1}" },
    { label: "迹与秩", latex: "\\operatorname{tr}(A),\\quad \\operatorname{rank}(A)" },
    { label: "矩阵", latex: "\\begin{pmatrix}a&b\\\\c&d\\end{pmatrix}" },
    { label: "增广矩阵", latex: "\\left(\\begin{array}{cc|c}a&b&u\\\\c&d&v\\end{array}\\right)" },
    { label: "线性方程组", latex: "\\left\\{\\begin{aligned}a_{11}x_1+a_{12}x_2&=b_1\\\\a_{21}x_1+a_{22}x_2&=b_2\\end{aligned}\\right." },
    { label: "行列式", latex: "\\det A=\\begin{vmatrix}a&b\\\\c&d\\end{vmatrix}" },
    { label: "分段函数", latex: "f(x)=\\begin{cases}x^2,&x\\ge0\\\\-x,&x<0\\end{cases}" },
    { label: "集合", latex: "A=\\{x\\in\\mathbb{R}\\mid x>0\\}" },
    { label: "映射", latex: "f:A\\to B,\\quad a\\mapsto f(a)" },
    { label: "特征值", latex: "A\\mathbf{v}=\\lambda\\mathbf{v}" },
    { label: "相似与合同", latex: "A\\sim B,\\quad A\\simeq B" },
    { label: "矩阵指数", latex: "e^{A}=\\sum_{n=0}^{\\infty}\\frac{A^n}{n!}" },
  ]);

  function normalizeNoteLatex(latex) {
    let value = String(latex || "").replace(/\r\n/g, "\n").trim();
    if (!value) return "";
    value = value.replace(
      /\\begin\s*\{((?:[pbBvV]?matrix|cases|aligned|gathered|array))\}\s*([\s\S]*?)\\end\s*\{\1\}/g,
      (_match, environment, body) => {
        let normalizedBody = body;
        normalizedBody = normalizedBody.replace(
          /(^|[^\\])\\([ \t]+)/g,
          "$1\\\\\\\\$2"
        );
        normalizedBody = normalizedBody.replace(
          /(^|[^\\])\n+/g,
          "$1\\\\\\\\\n"
        );
        return `\\begin{${environment}}${normalizedBody}\\end{${environment}}`;
      }
    );
    return value;
  }

  function hydrateNoteMath(root) {
    if (!root) return;
    const formulas = root.matches?.("[data-note-math]")
      ? [root, ...root.querySelectorAll("[data-note-math]")]
      : [...root.querySelectorAll("[data-note-math]")];
    for (const formula of formulas) {
      const latex = normalizeNoteLatex(
        formula.getAttribute("data-note-math") || ""
      );
      if (!latex) continue;
      const display =
        formula.getAttribute("data-display") === "block";
      formula.classList.add("note-math");
      formula.setAttribute("data-note-math", latex);
      formula.setAttribute("data-display", display ? "block" : "inline");
      formula.setAttribute("contenteditable", "false");
      formula.title = `LaTeX：${latex}（长按或右键编辑）`;
      if (window.katex?.render) {
        try {
          window.katex.render(latex, formula, {
            displayMode: display,
            throwOnError: false,
            strict: "ignore",
          });
        } catch {
          formula.textContent = latex;
        }
      } else {
        formula.textContent = latex;
      }
    }
  }

  function serializeNoteEditorHtml() {
    if (!noteEntryBody) return "";
    const clone = noteEntryBody.cloneNode(true);
    for (const formula of clone.querySelectorAll("[data-note-math]")) {
      const latex = String(
        formula.getAttribute("data-note-math") || ""
      ).trim();
      const placeholder = document.createElement("span");
      placeholder.setAttribute("data-note-math", latex);
      placeholder.setAttribute(
        "data-display",
        formula.getAttribute("data-display") === "block"
          ? "block"
          : "inline"
      );
      placeholder.textContent = latex;
      formula.replaceWith(placeholder);
    }
    return sanitizeNoteHtml(clone.innerHTML);
  }

  function sanitizeNoteHtml(rawHtml) {
    const source = String(rawHtml || "").slice(0, 300000);
    if (!source) return "";
    const template = document.createElement("template");
    template.innerHTML = source;
    for (const element of template.content.querySelectorAll(
      "script,style,iframe,object,embed,link,meta"
    )) {
      element.remove();
    }
    const allowedTags = new Set([
      "DIV",
      "P",
      "BR",
      "SPAN",
      "B",
      "STRONG",
      "I",
      "EM",
      "U",
      "S",
      "STRIKE",
    ]);
    const allowedStyles = [
      "color",
      "font-family",
      "font-size",
      "font-weight",
      "font-style",
      "text-decoration",
      "text-decoration-line",
      "text-decoration-style",
      "text-decoration-color",
    ];
    for (let element of [...template.content.querySelectorAll("*")]) {
      if (!element.parentNode) continue;
      if (element.hasAttribute("data-note-math")) {
        const latex = String(
          element.getAttribute("data-note-math") || ""
        )
          .slice(0, 8000)
          .trim();
        const placeholder = document.createElement("span");
        placeholder.setAttribute("data-note-math", latex);
        placeholder.setAttribute(
          "data-display",
          element.getAttribute("data-display") === "block"
            ? "block"
            : "inline"
        );
        placeholder.textContent = latex;
        element.replaceWith(placeholder);
        continue;
      }
      if (element.tagName === "FONT") {
        const span = document.createElement("span");
        if (element.getAttribute("face")) {
          span.style.fontFamily = String(
            element.getAttribute("face")
          ).slice(0, 160);
        }
        if (element.getAttribute("color")) {
          span.style.color = String(
            element.getAttribute("color")
          ).slice(0, 80);
        }
        span.append(...element.childNodes);
        element.replaceWith(span);
        element = span;
      }
      if (element.tagName === "SCRIPT") {
        element.remove();
        continue;
      }
      if (!allowedTags.has(element.tagName)) {
        element.replaceWith(
          document.createTextNode(element.textContent || "")
        );
        continue;
      }
      const safeStyles = [];
      for (const property of allowedStyles) {
        const value = element.style.getPropertyValue(property);
        if (!value || /url\s*\(|expression\s*\(|@import/i.test(value)) {
          continue;
        }
        safeStyles.push(`${property}:${value}`);
      }
      for (const attribute of [...element.attributes]) {
        element.removeAttribute(attribute.name);
      }
      if (safeStyles.length) {
        element.setAttribute("style", safeStyles.join(";"));
      }
    }
    return template.innerHTML;
  }

  function renderNoteBody(element, note) {
    if (!element) return;
    const richHtml = sanitizeNoteHtml(note?.body_html);
    if (richHtml) {
      element.innerHTML = richHtml;
      hydrateNoteMath(element);
    } else {
      element.textContent = note?.body || "";
    }
  }

  function noteEditorPlainText() {
    const text = [];
    const collect = node => {
      if (!node) return;
      if (node.nodeType === Node.TEXT_NODE) {
        text.push(node.nodeValue || "");
        return;
      }
      if (node.nodeType !== Node.ELEMENT_NODE) return;
      if (node.hasAttribute?.("data-note-math")) {
        text.push(
          ` \\(${String(node.getAttribute("data-note-math") || "")}\\) `
        );
        return;
      }
      if (node.tagName === "BR") {
        text.push("\n");
        return;
      }
      for (const child of node.childNodes) collect(child);
      if (["DIV", "P"].includes(node.tagName)) text.push("\n");
    };
    for (const child of noteEntryBody?.childNodes || []) {
      collect(child);
    }
    return String(text.join(""))
      .replace(/\u200b/g, "")
      .replace(/\u00a0/g, " ")
      .replace(/\r\n/g, "\n");
  }

  function setNoteEditorContent(html, fallbackText = "") {
    const safeHtml = sanitizeNoteHtml(html);
    if (safeHtml) {
      noteEntryBody.innerHTML = safeHtml;
      hydrateNoteMath(noteEntryBody);
    } else {
      noteEntryBody.textContent = fallbackText || "";
    }
    savedNoteSelectionRange = null;
  }

  function currentNoteSelectionRange() {
    const selection = window.getSelection();
    if (!selection || !selection.rangeCount) return null;
    const range = selection.getRangeAt(0);
    const container = range.commonAncestorContainer;
    if (
      container === noteEntryBody ||
      noteEntryBody.contains(container)
    ) {
      return range;
    }
    return null;
  }

  function rememberNoteSelection() {
    const range = currentNoteSelectionRange();
    if (!range) return;
    savedNoteSelectionRange = range.cloneRange();
  }

  function restoreNoteSelection() {
    noteEntryBody.focus({ preventScroll: true });
    if (!savedNoteSelectionRange) return;
    const selection = window.getSelection();
    if (!selection) return;
    try {
      selection.removeAllRanges();
      selection.addRange(savedNoteSelectionRange);
    } catch {
      savedNoteSelectionRange = null;
    }
  }

  function executeNoteEditorCommand(command, value = null) {
    restoreNoteSelection();
    document.execCommand("styleWithCSS", false, true);
    const applied = document.execCommand(command, false, value);
    rememberNoteSelection();
    return applied;
  }

  function currentNoteCaretRect() {
    let range = currentNoteSelectionRange();
    if (!range && savedNoteSelectionRange) {
      try {
        if (
          !savedNoteSelectionRange.startContainer.isConnected ||
          !savedNoteSelectionRange.endContainer.isConnected
        ) {
          return null;
        }
        range = savedNoteSelectionRange;
      } catch {
        return null;
      }
    }
    if (!range) return null;
    let rect = range.getBoundingClientRect();
    if (!rect || (!rect.height && !rect.width)) {
      const rects = range.getClientRects();
      rect = rects[rects.length - 1];
    }
    if (!rect || (!rect.height && !rect.width)) {
      const element =
        range.startContainer.nodeType === Node.ELEMENT_NODE
          ? range.startContainer
          : range.startContainer.parentElement;
      rect = element?.getBoundingClientRect();
    }
    return rect || null;
  }

  function syncNoteEditorViewport() {
    if (!noteWritingPage || !noteWritingOverlay.classList.contains("show")) {
      return;
    }
    const viewport = window.visualViewport;
    const height =
      viewport && Number.isFinite(viewport.height)
        ? viewport.height
        : window.innerHeight;
    const top =
      viewport && Number.isFinite(viewport.offsetTop)
        ? viewport.offsetTop
        : 0;
    const safeHeight = Math.max(260, Math.round(height));
    noteWritingPage.style.height = `${safeHeight}px`;
    noteWritingPage.style.minHeight = `${safeHeight}px`;
    noteWritingPage.style.top = `${Math.max(0, Math.round(top))}px`;
  }

  function scrollNoteCaretIntoView() {
    if (!noteWritingOverlay.classList.contains("show")) return;
    const caret = currentNoteCaretRect();
    if (!caret) return;
    const editorRect = noteEntryBody.getBoundingClientRect();
    const viewport = window.visualViewport;
    const visibleBottom =
      (viewport?.offsetTop || 0) + (viewport?.height || innerHeight);
    const safeTop = Math.max(editorRect.top, 0) + 18;
    const safeBottom = Math.min(editorRect.bottom, visibleBottom) - 30;
    if (caret.bottom > safeBottom) {
      noteEntryBody.scrollTop += caret.bottom - safeBottom + 12;
    } else if (caret.top < safeTop) {
      noteEntryBody.scrollTop -= safeTop - caret.top + 12;
    }
  }

  function scheduleNoteCaretVisibility() {
    clearTimeout(noteViewportRefreshTimer);
    noteViewportRefreshTimer = window.setTimeout(() => {
      syncNoteEditorViewport();
      requestAnimationFrame(() => {
        scrollNoteCaretIntoView();
        window.setTimeout(scrollNoteCaretIntoView, 220);
      });
    }, 60);
  }

  function dismissNoteEditorKeyboard() {
    if (document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }
    noteEntryBody.blur();
  }

  function noteFontCommandName(family) {
    return {
      system: "system-ui",
      serif: "Georgia",
      kai: "KaiTi",
      sans: "Microsoft YaHei UI",
    }[family] || "system-ui";
  }

  function applyWavyDecorationToSelection() {
    const range = currentNoteSelectionRange();
    if (!range || range.collapsed) {
      executeNoteEditorCommand("underline");
      return;
    }
    const span = document.createElement("span");
    span.style.textDecorationLine = "underline";
    span.style.textDecorationStyle = "wavy";
    span.appendChild(range.extractContents());
    range.insertNode(span);
    const selection = window.getSelection();
    if (selection) {
      const nextRange = document.createRange();
      nextRange.selectNodeContents(span);
      nextRange.collapse(false);
      selection.removeAllRanges();
      selection.addRange(nextRange);
      savedNoteSelectionRange = nextRange.cloneRange();
    }
  }

  function applyStoredNoteFontStyles(element, note) {
    element.style.color = note.font_color || "";
    element.style.fontWeight = note.font_weight === "bold" ? "700" : "";
    element.style.textDecorationLine =
      note.font_decoration && note.font_decoration !== "none"
        ? "underline"
        : "";
    element.style.textDecorationStyle =
      note.font_decoration === "wavy" ? "wavy" : "";
  }

  function noteFontFamilyCss(family) {
    return {
      system:
        '-apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei UI", sans-serif',
      serif: 'Georgia, "SimSun", "Songti SC", serif',
      kai: '"KaiTi", "STKaiti", "Kaiti SC", serif',
      sans: '"Microsoft YaHei UI", "PingFang SC", Arial, sans-serif',
    }[family] || '-apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei UI", sans-serif';
  }

  function resolvedNoteLayout(note = null) {
    const source = note && typeof note === "object" ? note : {};
    const family = ["system", "serif", "kai", "sans"].includes(
      source.font_family
    )
      ? source.font_family
      : layoutSettings.noteFontFamily;
    const size = clampLayoutNumber(
      source.font_size,
      14,
      24,
      layoutSettings.noteFontSize
    );
    const lineHeight = clampLayoutDecimal(
      source.line_height,
      1.4,
      2.6,
      layoutSettings.noteLineHeight
    );
    const padding = clampLayoutNumber(
      source.text_padding,
      10,
      32,
      layoutSettings.notePadding
    );
    const align = ["left", "justify"].includes(source.text_align)
      ? source.text_align
      : layoutSettings.noteAlign;
    return {
      font_family: family,
      font_size: size,
      line_height: lineHeight,
      text_padding: padding,
      text_align: align,
    };
  }

  function applyStoredNoteLayoutStyles(
    element,
    note,
    options = {}
  ) {
    if (!element) return;
    const layout = resolvedNoteLayout(note);
    element.style.fontFamily = noteFontFamilyCss(layout.font_family);
    element.style.fontSize = `${layout.font_size}px`;
    element.style.lineHeight = String(layout.line_height);
    element.style.textAlign = layout.text_align;
    if (options.includePadding) {
      element.style.padding = `${layout.text_padding}px`;
    }
  }

  function clearNoteLayoutInlineStyles(element) {
    if (!element) return;
    element.style.removeProperty("font-family");
    element.style.removeProperty("font-size");
    element.style.removeProperty("line-height");
    element.style.removeProperty("text-align");
    element.style.removeProperty("padding");
  }

  function ensureNoteLayoutSnapshot(note) {
    if (!note || typeof note !== "object") return false;
    const layout = resolvedNoteLayout(note);
    let changed = false;
    for (const [key, value] of Object.entries(layout)) {
      if (note[key] !== value) {
        note[key] = value;
        changed = true;
      }
    }
    return changed;
  }

  function assignCurrentNoteLayoutSnapshot(note) {
    Object.assign(note, resolvedNoteLayout(null));
  }

  function migrateLegacyNoteLayoutSnapshots() {
    const migrated = records.filter(
      note =>
        isNoteRecord(note) &&
        !note.deleted &&
        ensureNoteLayoutSnapshot(note)
    );
    if (!migrated.length) return;
    const revision = Date.now();
    for (const note of migrated) {
      note.rev = Math.max(revision, Number(note.rev || 0) + 1);
    }
    persist();
  }

  function renderNotes() {
    if (!notesList) return;
    migrateLegacyNoteLayoutSnapshots();
    let notes = noteRecords();
    noteCount.textContent = `${notes.length} 篇`;
    for (const button of noteFilter.querySelectorAll("button")) {
      button.classList.toggle(
        "active",
        button.dataset.noteFilter === noteFilterType
      );
    }
    if (noteFilterType !== "all") {
      notes = notes.filter(note => note.note_type === noteFilterType);
    }
    notesList.replaceChildren();
    if (!notes.length) {
      const empty = document.createElement("div");
      empty.className = "notes-empty";
      empty.textContent =
        noteFilterType === "all"
          ? "还没有札记。写下第一篇日记或笔记吧。"
          : `还没有${noteFilterType === "diary" ? "日记" : "笔记"}。`;
      notesList.appendChild(empty);
      return;
    }
    for (const note of notes) {
      const card = document.createElement("article");
      card.className = `note-card ${note.note_type === "note" ? "note" : "diary"}`;
      const head = document.createElement("div");
      head.className = "note-card-head";
      const title = document.createElement("h2");
      title.textContent = noteDisplayTitle(note);
      applyStoredNoteFontStyles(title, note);
      const badge = document.createElement("span");
      badge.className = "note-type-badge";
      badge.textContent = note.note_type === "note" ? "笔记" : "日记";
      head.append(title, badge);
      const date = document.createElement("div");
      date.className = "note-date";
      const noteDate = new Date(`${note.note_date}T12:00:00`);
      date.textContent = Number.isFinite(noteDate.getTime())
        ? noteDate.toLocaleDateString("zh-CN", {
            year: "numeric",
            month: "long",
            day: "numeric",
            weekday: "long",
          })
        : "日期未知";
      const intro = document.createElement("div");
      intro.className = "note-intro";
      intro.textContent = note.intro || "";
      applyStoredNoteFontStyles(intro, note);
      applyStoredNoteLayoutStyles(intro, note);
      if (!note.intro) intro.hidden = true;
      const noteGroupRecord = groupById(note.group_id);
      const groupChip = document.createElement("span");
      groupChip.className = "memo-group-chip";
      groupChip.textContent = noteGroupRecord
        ? `分组 · ${noteGroupRecord.title || "未命名分组"}`
        : "";
      groupChip.hidden = !noteGroupRecord;
      const body = document.createElement("div");
      body.className = "note-body";
      renderNoteBody(body, note);
      applyStoredNoteFontStyles(body, note);
      applyStoredNoteLayoutStyles(body, note);
      const actions = document.createElement("div");
      actions.className = "actions";
      const view = document.createElement("button");
      view.className = "action-btn view";
      view.textContent = "查看";
      view.addEventListener("click", () => openNoteView(note.id));
      const edit = document.createElement("button");
      edit.className = "action-btn edit-note";
      edit.textContent = "编辑";
      edit.addEventListener("click", () => openNoteEditor(note.id));
      const remove = document.createElement("button");
      remove.className = "action-btn delete";
      remove.textContent = "删除";
      remove.addEventListener("click", () => deleteNote(note.id));
      actions.append(view, edit, remove);
      card.append(head, date, intro, groupChip, body, actions);
      notesList.appendChild(card);
    }
  }

  function closeNoteView() {
    noteViewOverlay?.classList.remove("show");
    activeViewedNoteId = "";
  }

  function openNoteView(noteId) {
    const note = records.find(
      record =>
        record.id === noteId &&
        !record.deleted &&
        isNoteRecord(record)
    );
    if (!note || !noteViewOverlay) {
      showToast("札记不存在或已删除");
      return;
    }
    activeViewedNoteId = note.id;
    noteViewTitle.textContent = noteDisplayTitle(note);
    noteViewMeta.textContent =
      `${note.note_type === "note" ? "笔记" : "日记"} · ${note.note_date || "日期未知"}`;
    const noteGroupRecord = groupById(note.group_id);
    noteViewGroup.textContent = noteGroupRecord
      ? `分组 · ${noteGroupRecord.title || "未命名分组"}`
      : "";
    noteViewGroup.hidden = !noteGroupRecord;
    noteViewIntro.textContent = note.intro || "";
    noteViewIntro.hidden = !note.intro;
    renderNoteBody(noteViewBody, note);
    applyStoredNoteFontStyles(noteViewIntro, note);
    applyStoredNoteFontStyles(noteViewBody, note);
    applyStoredNoteLayoutStyles(noteViewIntro, note);
    applyStoredNoteLayoutStyles(noteViewBody, note, {
      includePadding: true,
    });
    noteViewOverlay.classList.add("show");
  }

  function editViewedNote() {
    const noteId = activeViewedNoteId;
    if (!noteId) return;
    closeNoteView();
    openNoteEditor(noteId, { openContent: true });
  }

  function refreshNoteGroupOptions(selectedId = "") {
    noteGroup.replaceChildren();
    const none = document.createElement("option");
    none.value = "";
    none.textContent = "不分组";
    noteGroup.appendChild(none);
    for (const group of groupRecords()) {
      const option = document.createElement("option");
      option.value = group.id;
      option.textContent = group.title || "未命名分组";
      noteGroup.appendChild(option);
    }
    noteGroup.value = groupById(selectedId) ? selectedId : "";
  }

  function setNoteFontColor(color, options = {}) {
    noteFontColorValue = /^#[0-9a-f]{6}$/i.test(String(color || ""))
      ? String(color)
      : "#385365";
    noteFontColor.value = noteFontColorValue;
    for (const swatch of document.querySelectorAll(
      ".note-color-swatch[data-note-color]"
    )) {
      swatch.classList.toggle(
        "active",
        swatch.dataset.noteColor.toLowerCase() ===
          noteFontColorValue.toLowerCase()
      );
    }
    if (options.apply) {
      executeNoteEditorCommand("foreColor", noteFontColorValue);
    }
  }

  function setNoteFontFamily(family, options = {}) {
    noteFontFamilyValue = ["system", "serif", "kai", "sans"].includes(
      family
    )
      ? family
      : "system";
    for (const option of document.querySelectorAll(
      ".note-font-option[data-note-family]"
    )) {
      option.classList.toggle(
        "active",
        option.dataset.noteFamily === noteFontFamilyValue
      );
    }
    if (options.apply) {
      executeNoteEditorCommand(
        "fontName",
        noteFontCommandName(noteFontFamilyValue)
      );
    }
  }

  function setNoteFontWeight(weight, options = {}) {
    noteFontWeightValue = weight === "bold" ? "bold" : "normal";
    applyNoteFontControls();
    if (!options.apply) return;
    restoreNoteSelection();
    const bold = Boolean(document.queryCommandState("bold"));
    if ((noteFontWeightValue === "bold") !== bold) {
      executeNoteEditorCommand("bold");
    }
  }

  function setNoteFontDecoration(decoration, options = {}) {
    noteFontDecorationValue = ["underline", "wavy"].includes(decoration)
      ? decoration
      : "none";
    applyNoteFontControls();
    if (!options.apply) return;
    restoreNoteSelection();
    if (noteFontDecorationValue === "wavy") {
      applyWavyDecorationToSelection();
      return;
    }
    const underlined = Boolean(
      document.queryCommandState("underline")
    );
    if (
      (noteFontDecorationValue === "underline") !== underlined
    ) {
      executeNoteEditorCommand("underline");
    }
  }

  function applyNoteFontControls() {
    for (const option of document.querySelectorAll(
      ".note-font-option[data-note-family]"
    )) {
      option.classList.toggle(
        "active",
        option.dataset.noteFamily === noteFontFamilyValue
      );
    }
    for (const option of document.querySelectorAll(
      ".note-font-option[data-note-weight]"
    )) {
      option.classList.toggle(
        "active",
        option.dataset.noteWeight === noteFontWeightValue
      );
    }
    for (const option of document.querySelectorAll(
      ".note-font-option[data-note-decoration]"
    )) {
      option.classList.toggle(
        "active",
        option.dataset.noteDecoration === noteFontDecorationValue
      );
    }
  }

  function setNoteMathTab(tab) {
    activeMathTab = tab === "latex" ? "latex" : "symbols";
    const symbolsActive = activeMathTab === "symbols";
    noteMathSymbolsTab.classList.toggle("active", symbolsActive);
    noteLatexTab.classList.toggle("active", !symbolsActive);
    noteMathSymbolsTab.setAttribute(
      "aria-selected",
      symbolsActive ? "true" : "false"
    );
    noteLatexTab.setAttribute(
      "aria-selected",
      symbolsActive ? "false" : "true"
    );
    noteMathSymbolsPanel.hidden = !symbolsActive;
    noteLatexPanel.hidden = symbolsActive;
    if (!symbolsActive) {
      window.setTimeout(() => noteLatexInput.focus(), 40);
    }
  }

  function renderNoteMathSymbols() {
    noteMathCategories.replaceChildren();
    for (const [key, category] of Object.entries(NOTE_MATH_SYMBOLS)) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "note-math-category";
      button.classList.toggle("active", key === activeMathCategory);
      button.textContent = category.label;
      button.addEventListener("click", () => {
        activeMathCategory = key;
        renderNoteMathSymbols();
      });
      noteMathCategories.appendChild(button);
    }
    noteMathSymbolGrid.replaceChildren();
    const symbols =
      NOTE_MATH_SYMBOLS[activeMathCategory]?.symbols ||
      NOTE_MATH_SYMBOLS.analysis.symbols;
    for (const symbol of symbols) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "note-math-symbol";
      button.textContent = symbol;
      button.title = `插入 ${symbol}`;
      button.setAttribute("aria-label", `插入 ${symbol}`);
      button.addEventListener("click", () =>
        insertUnicodeMathSymbol(symbol)
      );
      noteMathSymbolGrid.appendChild(button);
    }
  }

  function renderNoteLatexTemplates() {
    noteLatexTemplates.replaceChildren();
    for (const template of NOTE_LATEX_TEMPLATES) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "note-latex-template";
      button.textContent = template.label;
      button.title = template.latex;
      button.addEventListener("click", () => {
        noteLatexInput.value = template.latex;
        noteLatexInput.focus();
        noteLatexInput.setSelectionRange(
          template.latex.length,
          template.latex.length
        );
        renderNoteLatexPreview();
      });
      noteLatexTemplates.appendChild(button);
    }
  }

  function insertLatexQuickSnippet(snippet, caretBeforeEnd = 0) {
    const source = String(snippet || "");
    if (!source) return;
    const start = noteLatexInput.selectionStart ?? noteLatexInput.value.length;
    const end = noteLatexInput.selectionEnd ?? start;
    noteLatexInput.setRangeText(source, start, end, "end");
    const caret = Math.max(
      start,
      start + source.length - Math.max(0, Number(caretBeforeEnd) || 0)
    );
    noteLatexInput.focus();
    noteLatexInput.setSelectionRange(caret, caret);
    renderNoteLatexPreview();
  }

  function normalizedLatexDraft() {
    let latex = String(noteLatexInput.value || "").trim();
    let forceDisplay = false;
    if (/^\$\$[\s\S]*\$\$$/.test(latex)) {
      latex = latex.slice(2, -2).trim();
      forceDisplay = true;
    } else if (/^\$[\s\S]*\$$/.test(latex)) {
      latex = latex.slice(1, -1).trim();
    }
    return { latex: normalizeNoteLatex(latex), forceDisplay };
  }

  function renderNoteLatexPreview() {
    const { latex, forceDisplay } = normalizedLatexDraft();
    noteLatexPreview.replaceChildren();
    if (!latex) {
      noteLatexStatus.textContent = "";
      return;
    }
    if (!window.katex?.render) {
      noteLatexPreview.textContent =
        "公式渲染组件未加载，请重新打开浮光。";
      noteLatexStatus.textContent = "渲染组件不可用";
      return;
    }
    try {
      window.katex.render(latex, noteLatexPreview, {
        displayMode: noteLatexDisplayMode.checked || forceDisplay,
        throwOnError: false,
        strict: "ignore",
      });
      noteLatexStatus.textContent = "";
    } catch (error) {
      noteLatexPreview.textContent = latex;
      noteLatexStatus.textContent =
        error instanceof Error ? error.message : "LaTeX 语法错误";
    }
  }

  function openNoteMathDialog(options = {}) {
    dismissNoteEditorKeyboard();
    editingMathNode = options.node || null;
    insertedMathSymbolCount = 0;
    const latex = String(options.latex || "");
    noteLatexInput.value = latex;
    noteLatexDisplayMode.checked =
      options.display === true ||
      editingMathNode?.getAttribute("data-display") === "block";
    noteMathStatus.textContent =
      "点击符号即可插入当前光标位置，面板会保持打开。";
    noteLatexStatus.textContent = "";
    renderNoteMathSymbols();
    renderNoteLatexTemplates();
    renderNoteLatexPreview();
    setNoteMathTab(editingMathNode || latex ? "latex" : "symbols");
    noteMathOverlay.classList.add("show");
  }

  function closeNoteMathDialog() {
    noteMathOverlay?.classList.remove("show");
    editingMathNode = null;
  }

  function ensureNoteSelectionAtEnd() {
    if (savedNoteSelectionRange) {
      restoreNoteSelection();
      return;
    }
    noteEntryBody.focus({ preventScroll: true });
    const range = document.createRange();
    range.selectNodeContents(noteEntryBody);
    range.collapse(false);
    const selection = window.getSelection();
    selection?.removeAllRanges();
    selection?.addRange(range);
    savedNoteSelectionRange = range.cloneRange();
  }

  function insertUnicodeMathSymbol(symbol) {
    rememberNoteSelection();
    ensureNoteSelectionAtEnd();
    const value = String(symbol || "");
    if (!value) return;
    document.execCommand("insertText", false, value);
    rememberNoteSelection();
    insertedMathSymbolCount += 1;
    noteMathStatus.textContent =
      `已插入 ${insertedMathSymbolCount} 个符号：${value}。继续点击可连续插入。`;
    noteDraftBody = noteEditorPlainText();
    noteDraftHtml = serializeNoteEditorHtml();
    noteContentCount.textContent = `${noteDraftBody.length} / 10000`;
  }

  function createNoteMathElement(latex, displayMode) {
    const normalized = normalizeNoteLatex(latex);
    const formula = document.createElement("span");
    formula.className = "note-math";
    formula.setAttribute("data-note-math", normalized);
    formula.setAttribute(
      "data-display",
      displayMode ? "block" : "inline"
    );
    formula.setAttribute("contenteditable", "false");
    formula.title = `LaTeX：${normalized}（长按或右键编辑）`;
    hydrateNoteMath(formula);
    return formula;
  }

  const NOTE_BARE_TEX_COMMANDS = new Set([
    "alpha", "beta", "gamma", "delta", "epsilon", "varepsilon", "zeta",
    "eta", "theta", "vartheta", "iota", "kappa", "lambda", "mu", "nu",
    "xi", "pi", "rho", "sigma", "tau", "upsilon", "phi", "varphi", "chi",
    "psi", "omega", "Gamma", "Delta", "Theta", "Lambda", "Xi", "Pi",
    "Sigma", "Upsilon", "Phi", "Psi", "Omega", "in", "notin", "ni",
    "subset", "subseteq", "supset", "supseteq", "cup", "cap", "setminus",
    "emptyset", "mathbb", "mathcal", "mathbf", "boldsymbol", "mathrm",
    "mathsf", "operatorname", "text", "frac", "dfrac", "tfrac", "sqrt",
    "sum", "prod", "coprod", "int", "iint", "iiint", "oint", "lim",
    "limsup", "liminf", "sup", "inf", "max", "min", "partial", "nabla",
    "infty", "to", "mapsto", "rightarrow", "leftarrow", "leftrightarrow",
    "Rightarrow", "Leftarrow", "Leftrightarrow", "le", "leq", "ge", "geq",
    "ne", "neq", "approx", "sim", "simeq", "cong", "equiv", "propto",
    "pm", "mp", "times", "cdot", "ast", "star", "circ", "oplus", "otimes",
    "parallel", "perp", "langle", "rangle", "lVert", "rVert", "lvert",
    "rvert", "forall", "exists", "nexists", "land", "lor", "neg",
    "quad", "qquad", "ldots", "cdots", "dots", "vdots", "ddots", "adots",
    "left", "right", "bigcup", "bigcap", "begin", "end",
  ]);

  function appendLatexRecognizedText(parent, text) {
    const source = String(text || "");
    if (!source) return 0;
    const delimiterPattern =
      /\\\[([\s\S]+?)\\\]|\\\(([\s\S]+?)\\\)|\$\$([\s\S]+?)\$\$|\$([^$\n]+?)\$/g;
    let cursor = 0;
    let match;
    let converted = 0;
    while ((match = delimiterPattern.exec(source))) {
      appendBareLatexText(parent, source.slice(cursor, match.index));
      const latex = String(
        match[1] || match[2] || match[3] || match[4] || ""
      ).trim();
      if (latex) {
        parent.appendChild(
          createNoteMathElement(latex, Boolean(match[1] || match[3]))
        );
        converted += 1;
      }
      cursor = delimiterPattern.lastIndex;
    }
    appendBareLatexText(parent, source.slice(cursor));
    return converted;
  }

  function cleanBareLatexCandidate(candidate) {
    let value = String(candidate || "").trim();
    const openCount = (value.match(/\{/g) || []).length;
    const closeCount = (value.match(/\}/g) || []).length;
    if (value.startsWith("{") && openCount > closeCount) {
      value = value.slice(1).trimStart();
    }
    const nextOpen = (value.match(/\{/g) || []).length;
    const nextClose = (value.match(/\}/g) || []).length;
    if (value.endsWith("}") && nextClose > nextOpen) {
      value = value.slice(0, -1).trimEnd();
    }
    return normalizeNoteLatex(value);
  }

  function splitBareLatexSystem(candidate) {
    const value = String(candidate || "").trim();
    if (
      (value.match(/=/g) || []).length < 2 ||
      /\\begin\s*\{/.test(value)
    ) {
      return [value];
    }
    const startsExpression =
      /\s+(?=(?:\{?[A-Za-z]_?(?:\{[A-Za-z0-9]+\}|[A-Za-z0-9]+)[A-Za-z]?_?(?:\{[A-Za-z0-9]+\}|[A-Za-z0-9]+))|(?:\d+[A-Za-z]))/g;
    const parts = [];
    let cursor = 0;
    let match;
    while ((match = startsExpression.exec(value))) {
      const previous = value[match.index - 1] || "";
      if (/[=+\-*/<>,]/.test(previous)) continue;
      const left = value.slice(cursor, match.index).trim();
      if (left.includes("=")) {
        parts.push(left);
        cursor = match.index;
      }
    }
    if (!parts.length) return [value];
    const tail = value.slice(cursor).trim();
    if (tail) parts.push(tail);
    return parts;
  }

  function appendBareLatexText(parent, text) {
    const source = String(text || "");
    if (!source) return;
    const isMathCharacter = character =>
      Boolean(
        character &&
          /[A-Za-z0-9\\{}_^()\[\]+\-*\/=<>|&.,:;!?'" \t\u2212]/.test(
            character
          )
      );
    const hasKnownCommand = candidate => {
      const commands = candidate.matchAll(/\\([A-Za-z]+)/g);
      for (const command of commands) {
        if (NOTE_BARE_TEX_COMMANDS.has(command[1])) return true;
      }
      return false;
    };
    const hasSubOrSuperscript = candidate =>
      /[A-Za-z0-9})]\s*[_^]\s*(?:\{|[A-Za-z0-9])/.test(candidate);
    let cursor = 0;
    let index = 0;
    while (index < source.length) {
      let anchored = false;
      if (source[index] === "\\") {
        anchored = /[A-Za-z]+/.test(source.slice(index + 1));
      } else if (
        /[A-Za-z0-9})]/.test(source[index]) &&
        /[_^]/.test(source[index + 1] || "")
      ) {
        anchored = true;
      }
      if (!anchored) {
        index += 1;
        continue;
      }
      let start = index;
      while (start > 0 && isMathCharacter(source[start - 1])) {
        start -= 1;
      }
      let end = index + 1;
      while (end < source.length && isMathCharacter(source[end])) {
        end += 1;
      }
      let candidate = source.slice(start, end).trim();
      if (
        candidate.length >= 2 &&
        (hasKnownCommand(candidate) ||
          hasSubOrSuperscript(candidate))
      ) {
        parent.appendChild(document.createTextNode(source.slice(cursor, start)));
        const formulas = splitBareLatexSystem(candidate)
          .map(cleanBareLatexCandidate)
          .filter(Boolean);
        for (const formula of formulas) {
          const displayMode =
            formula.length > 16 &&
            (/=/.test(formula) || /\\begin\s*\{/.test(formula));
          parent.appendChild(
            createNoteMathElement(formula, displayMode)
          );
        }
        cursor = end;
        index = end;
      } else {
        index += 1;
      }
    }
    parent.appendChild(document.createTextNode(source.slice(cursor)));
  }

  function clipboardHtmlTextAndFormulas(html) {
    if (!html) return { text: "", formulas: [] };
    const template = document.createElement("template");
    template.innerHTML = String(html).slice(0, 600000);
    for (const br of template.content.querySelectorAll("br")) {
      br.replaceWith(document.createTextNode("\n"));
    }
    for (const item of template.content.querySelectorAll("li")) {
      const ordered = item.parentElement?.tagName === "OL";
      const index = ordered
        ? [...item.parentElement.children].indexOf(item) + 1
        : 0;
      item.insertBefore(
        document.createTextNode(ordered ? `${index}. ` : "• "),
        item.firstChild
      );
    }
    for (const block of template.content.querySelectorAll(
      "p,div,li,tr,blockquote,pre"
    )) {
      block.appendChild(document.createTextNode("\n"));
    }
    const formulas = [];
    for (const node of template.content.querySelectorAll(".katex,math")) {
      if (node.parentElement?.closest(".katex,math")) continue;
      const annotation =
        node.querySelector('annotation[encoding*="tex"]') ||
        node.querySelector("annotation");
      const latex = String(annotation?.textContent || "").trim();
      if (!latex) continue;
      const marker = `\uE000${formulas.length}\uE001`;
      formulas.push(latex);
      node.replaceWith(document.createTextNode(marker));
    }
    return {
      text: template.content.textContent || "",
      formulas,
    };
  }

  function pastedNoteFragment(plainText, htmlText) {
    const htmlData = clipboardHtmlTextAndFormulas(htmlText);
    const source = htmlData.text || String(plainText || "");
    const fragment = document.createDocumentFragment();
    let formulaCount = 0;
    const markerPattern = /\uE000(\d+)\uE001/g;
    let cursor = 0;
    let match;
    while ((match = markerPattern.exec(source))) {
      formulaCount += appendLatexRecognizedText(
        fragment,
        source.slice(cursor, match.index)
      );
      const latex = htmlData.formulas[Number(match[1])];
      if (latex) {
        fragment.appendChild(createNoteMathElement(latex, false));
        formulaCount += 1;
      }
      cursor = markerPattern.lastIndex;
    }
    formulaCount += appendLatexRecognizedText(
      fragment,
      source.slice(cursor)
    );
    return { fragment, formulaCount };
  }

  async function readSystemClipboardPayload() {
    let text = "";
    let html = "";
    if (nativeBridge?.readClipboardText) {
      try {
        text = String(nativeBridge.readClipboardText() || "");
        html = nativeBridge.readClipboardHtml
          ? String(nativeBridge.readClipboardHtml() || "")
          : "";
        return { text, html, available: Boolean(text || html) };
      } catch {}
    }
    try {
      if (navigator.clipboard?.read) {
        const items = await navigator.clipboard.read();
        for (const item of items) {
          if (!text && item.types.includes("text/plain")) {
            text = await (await item.getType("text/plain")).text();
          }
          if (!html && item.types.includes("text/html")) {
            html = await (await item.getType("text/html")).text();
          }
        }
      }
    } catch {}
    if (!text && !html) {
      try {
        text = await navigator.clipboard?.readText?.() || "";
      } catch {}
    }
    return { text, html, available: Boolean(text || html) };
  }

  function updateNotePastePayload(payload, options = {}) {
    pendingPastePayload = {
      text: String(payload.text || ""),
      html: String(payload.html || ""),
    };
    const htmlText = clipboardHtmlTextAndFormulas(
      pendingPastePayload.html
    ).text;
    const preview = (
      pendingPastePayload.text ||
      htmlText ||
      ""
    ).trim();
    notePastePreview.textContent = preview.slice(0, 1400);
    notePastePreview.classList.toggle("empty", !preview);
    const unavailable = !preview && !pendingPastePayload.html;
    notePasteFallbackInput.hidden = !unavailable;
    notePastePlainBtn.disabled = unavailable;
    notePasteSmartBtn.disabled = unavailable;
    if (unavailable && !options.probing) {
      notePasteStatus.textContent =
        "浏览器未允许直接读取剪贴板。请长按下方输入框粘贴，再选择粘贴方式。";
      window.setTimeout(() => notePasteFallbackInput.focus(), 40);
    } else if (options.probing) {
      notePasteStatus.textContent = "正在读取剪贴板…";
    } else if (preview) {
      notePasteStatus.textContent =
        "请选择“智能粘贴公式”或“只粘贴文字”。";
    }
  }

  async function openNotePasteDialog() {
    rememberNoteSelection();
    dismissNoteEditorKeyboard();
    pendingPastePayload = { text: "", html: "" };
    notePastePreview.textContent = "";
    notePastePreview.classList.add("empty");
    notePasteFallbackInput.value = "";
    notePasteFallbackInput.hidden = true;
    notePastePlainBtn.disabled = true;
    notePasteSmartBtn.disabled = true;
    notePasteStatus.textContent = "正在读取剪贴板…";
    notePasteOverlay.classList.add("show");
    const payload = await readSystemClipboardPayload();
    if (!notePasteOverlay.classList.contains("show")) return;
    updateNotePastePayload(payload);
  }

  function closeNotePasteDialog() {
    notePasteOverlay?.classList.remove("show");
    pendingPastePayload = { text: "", html: "" };
  }

  function setNoteCaretFromPoint(x, y) {
    const caret = document.caretRangeFromPoint?.(x, y);
    if (
      caret &&
      (caret.startContainer === noteEntryBody ||
        noteEntryBody.contains(caret.startContainer))
    ) {
      caret.collapse(true);
      const selection = window.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(caret);
      savedNoteSelectionRange = caret.cloneRange();
      return;
    }
    rememberNoteSelection();
  }

  function insertPastedNoteContent(text, html, smartPaste) {
    const result = smartPaste
      ? pastedNoteFragment(text, html)
      : {
          fragment: (() => {
            const fragment = document.createDocumentFragment();
            fragment.appendChild(document.createTextNode(text || ""));
            return fragment;
          })(),
          formulaCount: 0,
        };
    ensureNoteSelectionAtEnd();
    const range = currentNoteSelectionRange();
    if (!range || !result.fragment.childNodes.length) return 0;
    const pastedNodes = [...result.fragment.childNodes];
    range.deleteContents();
    range.insertNode(result.fragment);
    const last = pastedNodes[pastedNodes.length - 1];
    if (last) {
      if (last.nodeType === Node.TEXT_NODE) {
        range.setStart(last, last.nodeValue.length);
      } else {
        range.setStartAfter(last);
      }
      range.collapse(true);
      const selection = window.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
      savedNoteSelectionRange = range.cloneRange();
    }
    noteDraftBody = noteEditorPlainText();
    noteDraftHtml = serializeNoteEditorHtml();
    noteContentCount.textContent = `${noteDraftBody.length} / 10000`;
    if (noteDraftBody.trim()) {
      noteWritingStatus.textContent = "内容不能为空";
      noteWritingStatus.classList.remove("error");
    }
    return result.formulaCount;
  }

  function convertDollarLatexInEditor() {
    if (!noteEntryBody) return 0;
    const textNodes = [];
    const walker = document.createTreeWalker(
      noteEntryBody,
      NodeFilter.SHOW_TEXT
    );
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (
        node.nodeValue?.includes("$") &&
        !node.parentElement?.closest("[data-note-math]")
      ) {
        textNodes.push(node);
      }
    }
    let converted = 0;
    for (const node of textNodes) {
      const source = node.nodeValue || "";
      const pattern =
        /\\\[([\s\S]+?)\\\]|\\\(([\s\S]+?)\\\)|\$\$([\s\S]+?)\$\$|\$([^$\n]+?)\$/g;
      let match;
      let cursor = 0;
      let fragment = null;
      while ((match = pattern.exec(source))) {
        const latex = String(
          match[1] || match[2] || match[3] || match[4] || ""
        ).trim();
        if (!latex) continue;
        if (!fragment) fragment = document.createDocumentFragment();
        if (match.index > cursor) {
          fragment.appendChild(
            document.createTextNode(source.slice(cursor, match.index))
          );
        }
        fragment.appendChild(
          createNoteMathElement(latex, Boolean(match[1] || match[3]))
        );
        cursor = pattern.lastIndex;
        converted += 1;
      }
      if (!fragment) continue;
      if (cursor < source.length) {
        fragment.appendChild(
          document.createTextNode(source.slice(cursor))
        );
      }
      node.replaceWith(fragment);
    }
    return converted;
  }

  function insertLatexFormula() {
    const { latex, forceDisplay } = normalizedLatexDraft();
    if (!latex) {
      noteLatexStatus.textContent = "请先输入 LaTeX 公式";
      noteLatexInput.focus();
      return;
    }
    if (editingMathNode?.parentNode) {
      editingMathNode.setAttribute("data-note-math", latex);
      editingMathNode.setAttribute(
        "data-display",
        noteLatexDisplayMode.checked || forceDisplay ? "block" : "inline"
      );
      hydrateNoteMath(editingMathNode);
      const range = document.createRange();
      range.setStartAfter(editingMathNode);
      range.collapse(true);
      const selection = window.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
      savedNoteSelectionRange = range.cloneRange();
    } else {
      ensureNoteSelectionAtEnd();
      const range = currentNoteSelectionRange();
      if (!range) {
        noteLatexStatus.textContent = "无法定位札记光标，请关闭后重试";
        return;
      }
      range.deleteContents();
      const formula = createNoteMathElement(
        latex,
        noteLatexDisplayMode.checked || forceDisplay
      );
      range.insertNode(formula);
      const caret = document.createTextNode("\u200b");
      formula.after(caret);
      const nextRange = document.createRange();
      nextRange.setStart(caret, 1);
      nextRange.collapse(true);
      const selection = window.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(nextRange);
      savedNoteSelectionRange = nextRange.cloneRange();
    }
    noteDraftBody = noteEditorPlainText();
    noteDraftHtml = serializeNoteEditorHtml();
    noteContentCount.textContent = `${noteDraftBody.length} / 10000`;
    closeNoteMathDialog();
    noteEntryBody.focus({ preventScroll: true });
  }

  function openNoteEditor(noteId = null, options = {}) {
    const note = noteId
      ? records.find(
          record =>
            record.id === noteId &&
            !record.deleted &&
            isNoteRecord(record)
        )
      : null;
    editingNoteId = note?.id || null;
    noteFormTitle.textContent = note ? "编辑札记" : "新建札记";
    setNoteEditorType(note?.note_type === "note" ? "note" : "diary");
    noteEntryTitle.value = note?.title || "";
    noteEntryIntro.value = note?.intro || "";
    noteEntryDate.value = note?.note_date || localDateValue(new Date());
    refreshNoteGroupOptions(note?.group_id || "");
    noteDraftBody = note?.body || "";
    noteDraftHtml = note?.body_html || "";
    noteBaseFontColor = note?.font_color || "#385365";
    noteBaseFontWeight =
      note?.font_weight === "bold" ? "bold" : "normal";
    noteBaseFontDecoration = ["underline", "wavy"].includes(
      note?.font_decoration
    )
      ? note.font_decoration
      : "none";
    noteBaseFontFamily = ["system", "serif", "kai", "sans"].includes(
      note?.font_family
    )
      ? note.font_family
      : layoutSettings.noteFontFamily;
    setNoteFontColor(noteBaseFontColor);
    setNoteFontFamily(noteBaseFontFamily);
    noteFontWeightValue = noteBaseFontWeight;
    noteFontDecorationValue = noteBaseFontDecoration;
    applyNoteFontControls();
    setNoteEditorContent("", "");
    applyStoredNoteFontStyles(noteEntryBody, {
      font_color: noteBaseFontColor,
      font_weight: noteBaseFontWeight,
      font_decoration: noteBaseFontDecoration,
    });
    if (note) {
      applyStoredNoteLayoutStyles(noteEntryBody, note, {
        includePadding: true,
      });
    } else {
      clearNoteLayoutInlineStyles(noteEntryBody);
    }
    noteFontToolbar.hidden = true;
    noteContentCount.textContent = `${noteDraftBody.length} / 10000`;
    noteWritingStatus.textContent = "内容不能为空";
    noteWritingStatus.classList.remove("error");
    noteEditorOverlay.classList.add("show");
    if (note && options.openContent) {
      beginNoteWriting();
      return;
    }
    window.setTimeout(() => {
      (noteEntryTitle.value ? noteEntryBody : noteEntryTitle).focus();
    }, 80);
  }

  function closeNoteEditor() {
    closeNoteMathDialog();
    closeNotePasteDialog();
    noteWritingOverlay.classList.remove("show");
    noteWritingPage?.style.removeProperty("height");
    noteWritingPage?.style.removeProperty("min-height");
    noteWritingPage?.style.removeProperty("top");
    noteFontToolbar.hidden = true;
    noteEditorOverlay.classList.remove("show");
    editingNoteId = null;
    noteDraftBody = "";
    noteDraftHtml = "";
    setNoteEditorContent("", "");
    clearNoteLayoutInlineStyles(noteEntryBody);
  }

  function deleteNote(noteId) {
    const note = records.find(
      record =>
        record.id === noteId &&
        !record.deleted &&
        isNoteRecord(record)
    );
    if (!note || !confirm(`确定删除「${noteDisplayTitle(note)}」吗？`)) {
      return;
    }
    note.deleted = true;
    note.rev = nextRevision(note);
    note.updated_at = new Date().toISOString();
    persist();
    renderNotes();
    showToast("札记已删除，联网后自动同步");
    syncNow(false);
  }

  function beginNoteWriting() {
    if (!noteEntryDate.value) {
      showToast("请选择札记日期");
      noteEntryDate.focus();
      return;
    }
    noteWritingTitle.textContent =
      noteEntryTitle.value.trim() || "未命名札记";
    noteWritingMeta.textContent =
      `${noteEditorType === "note" ? "笔记" : "日记"} · ${
        noteEntryDate.value
      }`;
    setNoteEditorContent(noteDraftHtml, noteDraftBody);
    noteDraftBody = noteEditorPlainText();
    noteDraftHtml = serializeNoteEditorHtml();
    applyNoteFontControls();
    noteContentCount.textContent =
      `${noteDraftBody.length} / 10000`;
    noteFontToolbar.hidden = true;
    noteWritingOverlay.classList.add("show");
    scheduleNoteCaretVisibility();
    window.setTimeout(() => noteEntryBody.focus(), 80);
  }

  function saveNoteEntry() {
    convertDollarLatexInEditor();
    const body = noteEditorPlainText().trim();
    if (!body) {
      noteWritingStatus.textContent = "内容不能为空，请先输入札记内容";
      noteWritingStatus.classList.add("error");
      noteEntryBody.focus();
      showToast("札记内容不能为空");
      return;
    }
    const noteDate = noteEntryDate.value;
    if (!noteDate) {
      noteWritingStatus.textContent = "请返回确认札记日期";
      noteWritingStatus.classList.add("error");
      return;
    }
    const title = noteEntryTitle.value.trim();
    const intro = noteEntryIntro.value.trim();
    const selectedGroupId = groupById(noteGroup.value)
      ? noteGroup.value
      : null;
    const bodyHtml = serializeNoteEditorHtml();
    const now = new Date().toISOString();
    let note = editingNoteId
      ? records.find(
          record =>
            record.id === editingNoteId &&
            !record.deleted &&
            isNoteRecord(record)
        )
      : null;
    const createdNewNote = !note;
    if (note) {
      note.title = title;
      note.intro = intro;
      note.body = body;
      note.body_html = bodyHtml;
      note.note_type = noteEditorType;
      note.note_date = noteDate;
      note.group_id = selectedGroupId;
      ensureNoteLayoutSnapshot(note);
      note.updated_at = now;
      note.rev = nextRevision(note);
    } else {
      note = {
        id:
          crypto.randomUUID?.() ||
          `note-${Date.now()}-${Math.random().toString(16).slice(2)}`,
        record_kind: "note",
        note_type: noteEditorType,
        title,
        intro,
        body,
        body_html: bodyHtml,
        note_date: noteDate,
        group_id: selectedGroupId,
        font_color: noteBaseFontColor,
        font_weight: noteBaseFontWeight,
        font_decoration: noteBaseFontDecoration,
        created_at: now,
        updated_at: now,
        rev: nextRevision(),
        deleted: false,
      };
      assignCurrentNoteLayoutSnapshot(note);
      records.push(note);
    }
    noteDraftBody = body;
    noteDraftHtml = bodyHtml;
    persist();
    recordDailyAction(
      createdNewNote ? "note_created" : "note_edited"
    );
    closeNoteEditor();
    renderNotes();
    showToast("札记已保存，联网后自动同步");
    syncNow(false);
  }

  function renderGroups() {
    const groups = groupRecords();
    groupCount.textContent = `${groups.length} 组`;
    groupList.replaceChildren();
    if (!groups.length) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.innerHTML =
        '<div class="empty-clock">▦</div>还没有分组<br>新建分组后，可把已有事项加入其中';
      groupList.appendChild(empty);
      return;
    }
    for (const group of groups) {
      const memoItems = memoRecords()
        .filter(memo => memo.group_id === group.id)
        .sort((left, right) => {
          const leftPinned = left.pinned ? 0 : 1;
          const rightPinned = right.pinned ? 0 : 1;
          const leftTime = new Date(left.deadline || 0).getTime();
          const rightTime = new Date(right.deadline || 0).getTime();
          return leftPinned - rightPinned || leftTime - rightTime;
        });
      const noteItems = noteRecords().filter(
        note => note.group_id === group.id
      );
      const items = [...memoItems, ...noteItems].sort((left, right) => {
        const leftTime = isNoteRecord(left)
          ? new Date(`${left.note_date}T12:00:00`).getTime()
          : new Date(left.deadline || 0).getTime();
        const rightTime = isNoteRecord(right)
          ? new Date(`${right.note_date}T12:00:00`).getTime()
          : new Date(right.deadline || 0).getTime();
        return rightTime - leftTime;
      });
      const card = document.createElement("article");
      card.className = "group-card";

      const head = document.createElement("div");
      head.className = "group-card-head";
      const title = document.createElement("h2");
      title.textContent = group.title || "未命名分组";
      const count = document.createElement("span");
      count.className = "group-count";
      count.textContent = `${items.length} 项`;
      head.append(title, count);
      card.appendChild(head);

      if (group.note) {
        const intro = document.createElement("p");
        intro.className = "group-description";
        intro.textContent = group.note;
        card.appendChild(intro);
      }

      const itemBox = document.createElement("div");
      itemBox.className = "group-items";
      if (!items.length) {
        const text = document.createElement("div");
        text.className = "group-empty-items";
        text.textContent = "暂无内容，可在编辑分组时添加事项或札记。";
        itemBox.appendChild(text);
      } else {
        for (const memo of items.slice(0, 6)) {
          const line = document.createElement("div");
          line.className = "group-item-line";
          const typeText = isNoteRecord(memo)
            ? memo.note_type === "note"
              ? "笔记"
              : "日记"
            : isEvent(memo)
              ? "事件"
              : isCompleted(memo)
                ? "已完成"
                : isHistorical(memo)
                  ? "历史"
                  : "任务";
          const title = isNoteRecord(memo)
            ? noteDisplayTitle(memo)
            : memo.title || "未命名事项";
          line.textContent = `${title} · ${typeText}`;
          itemBox.appendChild(line);
        }
        if (items.length > 6) {
          const more = document.createElement("div");
          more.className = "group-empty-items";
          more.textContent = `还有 ${items.length - 6} 项`;
          itemBox.appendChild(more);
        }
      }
      card.appendChild(itemBox);

      const actions = document.createElement("div");
      actions.className = "actions";
      const view = document.createElement("button");
      view.className = "action-btn";
      view.textContent = "查看内容";
      view.addEventListener("click", () => openGroupDetail(group.id));
      const edit = document.createElement("button");
      edit.className = "action-btn";
      edit.textContent = "编辑分组";
      edit.addEventListener("click", () => openGroupEditor(group.id));
      const remove = document.createElement("button");
      remove.className = "action-btn delete";
      remove.textContent = "删除分组";
      remove.addEventListener("click", () => deleteGroup(group.id));
      actions.append(view, edit, remove);
      card.appendChild(actions);
      groupList.appendChild(card);
    }
  }

  function openGroupEditor(groupId = null) {
    editingGroupId = groupId;
    const group = groupId
      ? records.find(
          record =>
            record.id === groupId &&
            !record.deleted &&
            isGroupRecord(record)
        )
      : null;
    groupFormTitle.textContent = group ? "编辑分组" : "新建分组";
    groupNameInput.value = group ? group.title : "";
    groupIntroInput.value = group ? (group.note || "") : "";
    groupMemoChoices.replaceChildren();
    const memos = memoRecords()
      .filter(memo => !isHistorical(memo))
      .sort((left, right) =>
        String(left.title || "").localeCompare(
          String(right.title || ""),
          "zh-CN"
        )
      );
    const choices = [...memos, ...noteRecords()];
    if (!choices.length) {
      const empty = document.createElement("div");
      empty.className = "group-empty-items";
      empty.textContent =
        "目前没有可添加的当前事项或札记；历史事项请在“历史事项”中加入分组";
      groupMemoChoices.appendChild(empty);
    } else {
      for (const memo of choices) {
        const label = document.createElement("label");
        label.className = "group-choice";
        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.value = memo.id;
        checkbox.checked = Boolean(group && memo.group_id === group.id);
        const text = document.createElement("span");
        text.textContent = isNoteRecord(memo)
          ? noteDisplayTitle(memo)
          : memo.title || "未命名事项";
        const meta = document.createElement("span");
        meta.className = "group-choice-meta";
        meta.textContent = isNoteRecord(memo)
          ? memo.note_type === "note"
            ? "笔记"
            : "日记"
          : isCompleted(memo)
          ? "已完成"
          : isHistorical(memo)
            ? "历史"
            : isEvent(memo)
              ? "事件"
              : "任务";
        label.append(checkbox, text, meta);
        groupMemoChoices.appendChild(label);
      }
    }
    groupOverlay.classList.add("show");
    setTimeout(() => groupNameInput.focus(), 80);
  }

  function closeGroupEditor() {
    groupOverlay.classList.remove("show");
    editingGroupId = null;
  }

  function deleteGroup(groupId) {
    const group = records.find(
      record =>
        record.id === groupId &&
        !record.deleted &&
        isGroupRecord(record)
    );
    if (
      !group ||
      !confirm(
        `确定删除分组「${group.title}」吗？组内事项和札记不会被删除，只会变成未分组。`
      )
    ) {
      return;
    }
    const now = new Date().toISOString();
    group.deleted = true;
    group.rev = nextRevision(group);
    group.updated_at = now;
    for (const memo of memoRecords()) {
      if (memo.group_id !== groupId) continue;
      memo.group_id = null;
      memo.rev = nextRevision(memo);
      memo.updated_at = now;
    }
    for (const note of noteRecords()) {
      if (note.group_id !== groupId) continue;
      note.group_id = null;
      note.rev = nextRevision(note);
      note.updated_at = now;
    }
    persist();
    render();
    renderGroups();
    showToast("分组已删除，组内事项和札记已保留");
    syncNow(false);
  }

  function groupItemState(memo) {
    if (isCompleted(memo)) return ["已完成", "completed"];
    const deadline = new Date(memo.deadline).getTime();
    if (!Number.isFinite(deadline)) return ["时间无效", "expired"];
    if (deadline <= Date.now()) {
      if (deadline + HISTORY_GRACE_MS > Date.now()) {
        return [
          isEvent(memo) ? "已结束 · 待归档" : "已到期 · 待归档",
          "expired",
        ];
      }
      return ["已归档", "expired"];
    }
    if (isEvent(memo)) {
      const start = new Date(memo.start_at).getTime();
      if (Number.isFinite(start) && Date.now() < start) {
        return ["待开始", ""];
      }
    }
    if (deadline - Date.now() <= 86400000) {
      return ["24 小时内", ""];
    }
    return ["进行中", ""];
  }

  function renderGroupDetail() {
    if (!activeGroupDetailId) return;
    const group = groupById(activeGroupDetailId);
    if (!group) {
      closeGroupDetail();
      return;
    }
    const memoItems = memoRecords()
      .filter(memo => memo.group_id === group.id)
      .sort((left, right) => {
        const leftPinned = left.pinned ? 0 : 1;
        const rightPinned = right.pinned ? 0 : 1;
        const leftHistorical = isHistorical(left) ? 1 : 0;
        const rightHistorical = isHistorical(right) ? 1 : 0;
        return (
          leftPinned - rightPinned ||
          leftHistorical - rightHistorical ||
          new Date(left.deadline || 0).getTime() -
            new Date(right.deadline || 0).getTime()
        );
      });
    const noteItems = noteRecords().filter(
      note => note.group_id === group.id
    );
    const items = [...memoItems, ...noteItems];
    const activeCount = items.filter(
      memo => isNoteRecord(memo) || !isHistorical(memo)
    ).length;
    groupDetailTitle.textContent = group.title || "分组内容";
    groupDetailIntro.textContent =
      `${group.note ? `${group.note}\n` : ""}` +
      `共 ${items.length} 项 · ${activeCount} 项未结束`;
    groupDetailList.replaceChildren();
    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.innerHTML =
        '<div class="empty-clock">◷</div>这个分组还没有内容<br>当前事项和札记可在编辑分组时添加，历史事项请在“历史事项”中加入';
      groupDetailList.appendChild(empty);
      return;
    }
    for (const memo of items) {
      if (isNoteRecord(memo)) {
        const card = document.createElement("article");
        card.className = "group-detail-card";
        const head = document.createElement("div");
        head.className = "group-detail-head";
        const title = document.createElement("h3");
        title.textContent = noteDisplayTitle(memo);
        applyStoredNoteFontStyles(title, memo);
        const state = document.createElement("span");
        state.className = "group-detail-state";
        state.textContent = memo.note_type === "note" ? "笔记" : "日记";
        head.append(title, state);
        card.appendChild(head);
        const meta = document.createElement("div");
        meta.className = "group-detail-meta";
        const dateKey = document.createElement("span");
        dateKey.textContent = "札记日期";
        const dateValue = document.createElement("span");
        const noteDate = new Date(`${memo.note_date}T12:00:00`);
        dateValue.textContent = Number.isFinite(noteDate.getTime())
          ? noteDate.toLocaleDateString("zh-CN")
          : "未知";
        meta.append(dateKey, dateValue);
        card.appendChild(meta);
        if (memo.intro) {
          const intro = document.createElement("div");
          intro.className = "group-detail-note";
          intro.textContent = memo.intro;
          applyStoredNoteFontStyles(intro, memo);
          applyStoredNoteLayoutStyles(intro, memo);
          card.appendChild(intro);
        }
        const body = document.createElement("div");
        body.className = "group-detail-note";
        renderNoteBody(body, memo);
        applyStoredNoteFontStyles(body, memo);
        applyStoredNoteLayoutStyles(body, memo);
        card.appendChild(body);
        const actions = document.createElement("div");
        actions.className = "group-detail-actions";
        const view = document.createElement("button");
        view.className = "action-btn view";
        view.textContent = "查看札记";
        view.addEventListener("click", () => {
          closeGroupDetail();
          openNoteView(memo.id);
        });
        actions.appendChild(view);
        card.appendChild(actions);
        groupDetailList.appendChild(card);
        continue;
      }
      const [stateText, stateClass] = groupItemState(memo);
      const card = document.createElement("article");
      card.className = "group-detail-card";
      const head = document.createElement("div");
      head.className = "group-detail-head";
      const title = document.createElement("h3");
      title.textContent = memo.title || "未命名事项";
      const state = document.createElement("span");
      state.className = `group-detail-state ${stateClass}`.trim();
      state.textContent = stateText;
      head.append(title, state);
      card.appendChild(head);
      if (memo.note) {
        const note = document.createElement("div");
        note.className = "group-detail-note";
        note.textContent = memo.note;
        card.appendChild(note);
      }
      const meta = document.createElement("div");
      meta.className = "group-detail-meta";
      const addMeta = (label, value) => {
        const key = document.createElement("span");
        key.textContent = label;
        const content = document.createElement("span");
        content.textContent = value;
        meta.append(key, content);
      };
      addMeta("事项类型", isEvent(memo) ? "事件型" : "任务型");
      addMeta("当前状态", stateText);
      if (memo.pinned) addMeta("置顶", "是");
      if (memo.location) addMeta("地点", memo.location);
      if (!isHistorical(memo)) {
        const remaining = document.createElement("span");
        remaining.className = "remaining";
        remaining.dataset.deadline = memo.deadline;
        remaining.textContent = formatRemaining(memo.deadline);
        const remainingLabel = document.createElement("span");
        remainingLabel.textContent = "剩余时间";
        meta.append(remainingLabel, remaining);
      }
      if (isEvent(memo)) {
        addMeta("开始时间", formatDeadline(memo.start_at));
      }
      addMeta(isEvent(memo) ? "结束时间" : "终止时间", formatDeadline(memo.deadline));
      if (memo.completed_at) {
        addMeta("完成时间", formatDeadline(memo.completed_at));
      }
      card.appendChild(meta);
      if (memo.image_data) {
        const image = document.createElement("img");
        image.className = "group-detail-image";
        image.src = memo.image_data;
        image.alt = memo.title || "事项图片";
        image.addEventListener("click", () => {
          imageViewerImage.src = memo.image_data;
          imageViewerOverlay.classList.add("show");
        });
        card.appendChild(image);
      }
      const actions = document.createElement("div");
      actions.className = "group-detail-actions";
      if (!isHistorical(memo)) {
        const pin = document.createElement("button");
        pin.className = "action-btn";
        pin.textContent = memo.pinned ? "取消置顶" : "置顶";
        pin.addEventListener("click", () => toggleMemoPin(memo.id));
        actions.appendChild(pin);
        const edit = document.createElement("button");
        edit.className = "action-btn";
        edit.textContent = "编辑事项";
        edit.addEventListener("click", () => {
          closeGroupDetail();
          openEditor(memo.id);
        });
        actions.appendChild(edit);
      }
      if (actions.childElementCount) card.appendChild(actions);
      groupDetailList.appendChild(card);
    }
  }

  function openGroupDetail(groupId) {
    activeGroupDetailId = groupId;
    groupDetailOverlay.classList.add("show");
    renderGroupDetail();
  }

  function closeGroupDetail() {
    groupDetailOverlay.classList.remove("show");
    activeGroupDetailId = null;
  }

  function updateCountdowns() {
    if (document.hidden) return;
    const now = Date.now();
    document.querySelectorAll(".remaining[data-deadline]").forEach(element => {
      const text = formatRemaining(element.dataset.deadline);
      if (element.textContent !== text) element.textContent = text;
    });
    if (now - lastCountdownStatusCheck < 15000) return;
    lastCountdownStatusCheck = now;
    const recordById = new Map();
    for (const record of records) {
      if (record?.id) recordById.set(record.id, record);
    }
    document.querySelectorAll(".card").forEach(card => {
      const memo = recordById.get(card.dataset.id);
      if (!memo) return;
      const [stateClass, badgeText] = statusOf(memo);
      card.classList.remove("urgent", "expired");
      card.classList.remove("pending");
      if (stateClass) card.classList.add(stateClass);
      const badge = card.querySelector(".badge");
      if (badge) {
        const text = `${isEvent(memo) ? "事件" : "任务"} · ${badgeText}`;
        if (badge.textContent !== text) badge.textContent = text;
      }
    });
    if (historyRecordCount() !== renderedHistoryCount) {
      render();
    }
  }

  function openEditor(memoId = null) {
    editingId = memoId;
    const memo = memoId
      ? records.find(record => record.id === memoId && !record.deleted)
      : null;
    const isNewMemo = !memo;
    formTitle.textContent = memo ? "编辑事项" : "新建事项";
    titleInput.value = memo ? memo.title : "";
    noteInput.value = memo ? (memo.note || "") : "";
    locationInput.value = memo ? (memo.location || "") : "";
    memoPinned.checked = Boolean(memo?.pinned);
    useDefaultReminder.checked = isNewMemo;
    refreshMemoGroupOptions(memo?.group_id || "");
    setEditingImage(memo ? memo.image_data : null);
    setEditorType(memo && isEvent(memo) ? "event" : "task");
    const reminderMinutes = Math.max(
      1,
      Number(memo?.reminder_minutes || 15)
    );
    reminderEnabled.checked = isNewMemo
      ? true
      : Boolean(memo?.reminder_enabled);
    if (reminderMinutes % 1440 === 0) {
      reminderAmount.value = reminderMinutes / 1440;
      reminderUnit.value = "days";
    } else if (reminderMinutes % 60 === 0) {
      reminderAmount.value = reminderMinutes / 60;
      reminderUnit.value = "hours";
    } else {
      reminderAmount.value = reminderMinutes;
      reminderUnit.value = "minutes";
    }
    const modes = Array.isArray(memo?.reminder_modes)
      ? memo.reminder_modes
      : ["notification"];
    reminderNotify.checked = modes.includes("notification");
    reminderSound.checked = modes.includes("sound");
    reminderVibrate.checked = modes.includes("vibration");
    reminderVolume.value = String(
      Math.max(10, Math.min(100, Number(memo?.reminder_volume || 100)))
    );
    if (isNewMemo) {
      applyDefaultReminderToEditor();
    }
    updateReminderVolumeLabel();
    updateReminderOptionsVisibility();
    if (memo) {
      const value = new Date(memo.deadline);
      if (isEvent(memo)) {
        const start = new Date(memo.start_at);
        startDateInput.value = localDateValue(start);
        startTimeInput.value = `${String(start.getHours()).padStart(2, "0")}:${String(start.getMinutes()).padStart(2, "0")}`;
        endDateInput.value = localDateValue(value);
        endTimeInput.value = `${String(value.getHours()).padStart(2, "0")}:${String(value.getMinutes()).padStart(2, "0")}`;
      } else {
        dateInput.value = localDateValue(value);
        timeInput.value = `${String(value.getHours()).padStart(2, "0")}:${String(value.getMinutes()).padStart(2, "0")}`;
      }
    } else {
      defaultDeadline();
      defaultEventTimes();
    }
    overlay.classList.add("show");
    setTimeout(() => titleInput.focus(), 80);
  }

  function closeEditor() {
    overlay.classList.remove("show");
    editingId = null;
    setEditingImage(null);
  }

  function deleteMemo(memoId) {
    const memo = records.find(record => record.id === memoId);
    if (!memo || !confirm(`确定删除「${memo.title}」吗？`)) return;
    memo.deleted = true;
    memo.rev = nextRevision(memo);
    memo.updated_at = new Date().toISOString();
    persist();
    render();
    showToast("已删除，联网后同步");
    syncNow(false);
  }

  function toggleMemoPin(memoId) {
    const memo = records.find(record => record.id === memoId && !record.deleted);
    if (!memo || isGroupRecord(memo)) return;
    memo.pinned = !memo.pinned;
    memo.rev = nextRevision(memo);
    memo.updated_at = new Date().toISOString();
    persist();
    render();
    recordDailyAction("memo_pin_changed");
    showToast(memo.pinned ? "事项已置顶" : "已取消置顶");
    syncNow(false);
  }

  let waterAudioContext = null;

  function playWaterSinkSound() {
    try {
      const AudioContextClass =
        window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return;
      if (!waterAudioContext) {
        waterAudioContext = new AudioContextClass();
      }
      const context = waterAudioContext;
      if (context.state === "suspended") {
        context.resume().catch(() => {});
      }
      const now = context.currentTime + 0.015;

      const drop = context.createOscillator();
      const dropGain = context.createGain();
      drop.type = "sine";
      drop.frequency.setValueAtTime(520, now);
      drop.frequency.exponentialRampToValueAtTime(165, now + 0.28);
      dropGain.gain.setValueAtTime(0.0001, now);
      dropGain.gain.exponentialRampToValueAtTime(0.16, now + 0.018);
      dropGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.42);
      drop.connect(dropGain).connect(context.destination);
      drop.start(now);
      drop.stop(now + 0.44);

      const bubble = context.createOscillator();
      const bubbleGain = context.createGain();
      bubble.type = "sine";
      bubble.frequency.setValueAtTime(760, now + 0.12);
      bubble.frequency.exponentialRampToValueAtTime(330, now + 0.34);
      bubbleGain.gain.setValueAtTime(0.0001, now + 0.12);
      bubbleGain.gain.exponentialRampToValueAtTime(0.045, now + 0.15);
      bubbleGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.42);
      bubble.connect(bubbleGain).connect(context.destination);
      bubble.start(now + 0.12);
      bubble.stop(now + 0.44);

      const noiseLength = Math.round(context.sampleRate * 0.38);
      const noiseBuffer = context.createBuffer(
        1,
        noiseLength,
        context.sampleRate
      );
      const noiseData = noiseBuffer.getChannelData(0);
      for (let index = 0; index < noiseLength; index += 1) {
        noiseData[index] = (Math.random() * 2 - 1) * 0.32;
      }
      const noise = context.createBufferSource();
      const filter = context.createBiquadFilter();
      const noiseGain = context.createGain();
      noise.buffer = noiseBuffer;
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(920, now);
      filter.frequency.exponentialRampToValueAtTime(240, now + 0.36);
      noiseGain.gain.setValueAtTime(0.032, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.38);
      noise.connect(filter).connect(noiseGain).connect(context.destination);
      noise.start(now);
    } catch {
      // Sound is optional; completion still works when audio is unavailable.
    }
  }

  function animateMemoSink(card) {
    if (!card) return;
    const rect = card.getBoundingClientRect();
    const ghost = card.cloneNode(true);
    ghost.classList.add("sinking-ghost");
    ghost.removeAttribute("id");
    ghost.setAttribute("aria-hidden", "true");
    ghost.inert = true;
    Object.assign(ghost.style, {
      left: `${rect.left}px`,
      top: `${rect.top}px`,
      width: `${rect.width}px`,
      height: `${rect.height}px`,
    });
    document.body.appendChild(ghost);
    requestAnimationFrame(() => ghost.classList.add("sinking"));
    setTimeout(() => ghost.remove(), 1050);
  }

  function completeMemo(memoId) {
    const memo = records.find(record => record.id === memoId);
    if (
      !memo ||
      isEvent(memo) ||
      isCompleted(memo) ||
      memo.__completing
    ) {
      return;
    }
    if (!confirm(`将「${memo.title}」标记为已完成？`)) return;
    memo.__completing = true;
    const card = Array.from(listEl.querySelectorAll(".card")).find(
      item => item.dataset.id === memoId
    );
    try {
      animateMemoSink(card);
    } catch {
      // Completion must never depend on the visual effect.
    }
    playWaterSinkSound();

    const now = new Date().toISOString();
    memo.completed = true;
    memo.completed_at = now;
    memo.updated_at = now;
    memo.rev = nextRevision(memo);
    delete memo.__completing;
    persist();
    render();
    recordDailyAction("task_completed");
    showToast("任务已完成，如浮光沉入水面");
    syncNow(false);
  }

  function renderHistory() {
    historyList.replaceChildren();
    const items = historyRecords();
    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.textContent = "暂无历史事项";
      historyList.appendChild(empty);
      return;
    }
    for (const memo of items) {
      const row = document.createElement("article");
      row.className = "history-row";
      const title = document.createElement("h3");
      title.textContent = memo.title || "未命名事项";
      row.appendChild(title);
      const meta = document.createElement("div");
      meta.className = "history-meta";
      if (isEvent(memo)) {
        meta.textContent =
          `事件 · 开始 ${formatDeadline(memo.start_at)} · 结束 ${formatDeadline(memo.deadline)}`;
      } else if (isCompleted(memo)) {
        meta.textContent =
          `任务 · 已完成于 ${memo.completed_at ? formatDeadline(memo.completed_at) : "未知"}\n截止 ${formatDeadline(memo.deadline)}`;
      } else {
        meta.textContent = `任务 · 已过期 ${formatDeadline(memo.deadline)}`;
      }
      if (memo.location) {
        meta.textContent += `\n地点：${memo.location}`;
      }
      const assignedGroup = memo.group_id
        ? groupById(memo.group_id)
        : null;
      if (assignedGroup) {
        meta.textContent += `\n分组：${assignedGroup.title || "未命名分组"}`;
      }
      row.appendChild(meta);
      if (memo.image_data) {
        const image = document.createElement("img");
        image.className = "card-image";
        image.src = memo.image_data;
        row.appendChild(image);
      }
      const actions = document.createElement("div");
      actions.className = "history-actions";
      const groupButton = document.createElement("button");
      groupButton.className = "action-btn";
      groupButton.textContent = assignedGroup ? "更改分组" : "加入分组";
      groupButton.addEventListener("click", () =>
        openHistoryGroupPicker(memo.id)
      );
      const remove = document.createElement("button");
      remove.className = "action-btn delete";
      remove.textContent = "删除";
      remove.addEventListener("click", () => {
        deleteMemo(memo.id);
        renderHistory();
      });
      actions.append(groupButton, remove);
      row.appendChild(actions);
      historyList.appendChild(row);
    }
  }

  function openHistoryGroupPicker(memoId) {
    const memo = records.find(
      record =>
        record.id === memoId &&
        !record.deleted &&
        !isGroupRecord(record) &&
        isHistorical(record)
    );
    const groups = groupRecords();
    if (!memo) {
      showToast("该历史事项已不存在");
      return;
    }
    if (!groups.length) {
      showToast("请先在“分组”页面新建一个分组");
      return;
    }
    historyGroupMemoId = memo.id;
    historyGroupMemoTitle.textContent = memo.title || "未命名事项";
    historyGroupSelect.replaceChildren();
    const none = document.createElement("option");
    none.value = "";
    none.textContent = "不加入分组";
    historyGroupSelect.appendChild(none);
    for (const group of groups) {
      const option = document.createElement("option");
      option.value = group.id;
      option.textContent = group.title || "未命名分组";
      historyGroupSelect.appendChild(option);
    }
    historyGroupSelect.value = groupById(memo.group_id)
      ? memo.group_id
      : "";
    historyGroupOverlay?.classList.add("show");
  }

  function closeHistoryGroupPicker() {
    historyGroupOverlay?.classList.remove("show");
    historyGroupMemoId = "";
  }

  function saveHistoryGroupAssignment() {
    const memo = records.find(
      record =>
        record.id === historyGroupMemoId &&
        !record.deleted &&
        !isGroupRecord(record) &&
        isHistorical(record)
    );
    if (!memo) {
      closeHistoryGroupPicker();
      showToast("该历史事项已不存在");
      return;
    }
    const selectedGroupId = groupById(historyGroupSelect?.value)
      ? historyGroupSelect.value
      : null;
    const now = new Date().toISOString();
    memo.group_id = selectedGroupId;
    memo.rev = nextRevision(memo);
    memo.updated_at = now;
    persist();
    render();
    renderGroups();
    renderHistory();
    if (
      activeGroupDetailId &&
      groupDetailOverlay.classList.contains("show")
    ) {
      renderGroupDetail();
    }
    closeHistoryGroupPicker();
    showToast(
      selectedGroupId
        ? "历史事项已加入分组"
        : "历史事项已移出分组"
    );
    syncNow(false);
  }

  function openHistory() {
    renderHistory();
    historyOverlay.classList.add("show");
    recordDailyAction("history_opened");
  }

  function loadCheckins() {
    const parsed = parseJsonValue(
      localStorage.getItem(CHECKIN_STORAGE_KEY),
      {}
    );
    return parsed && typeof parsed === "object" && !Array.isArray(parsed)
      ? parsed
      : {};
  }

  function saveCheckins(checkins) {
    try {
      localStorage.setItem(
        CHECKIN_STORAGE_KEY,
        JSON.stringify(checkins)
      );
      return true;
    } catch {
      showToast("签到记录保存失败");
      return false;
    }
  }

  const SOLAR_TERM_NAMES = [
    "小寒", "大寒", "立春", "雨水", "惊蛰", "春分",
    "清明", "谷雨", "立夏", "小满", "芒种", "夏至",
    "小暑", "大暑", "立秋", "处暑", "白露", "秋分",
    "寒露", "霜降", "立冬", "小雪", "大雪", "冬至",
  ];
  const SOLAR_TERM_MINUTES = [
    0, 21208, 42467, 63836, 85337, 107014,
    128867, 150921, 173149, 195551, 218072, 240693,
    263343, 285989, 308563, 331033, 353350, 375494,
    397447, 419210, 440795, 462224, 483532, 504758,
  ];
  const SOLAR_TERM_COLORS = {
    小寒: "#5687a2", 大寒: "#3f6d91",
    立春: "#699d45", 雨水: "#4b9489",
    惊蛰: "#5b9444", 春分: "#2f9464",
    清明: "#267f60", 谷雨: "#478f5c",
    立夏: "#178b55", 小满: "#3b9347",
    芒种: "#a47d16", 夏至: "#db7f28",
    小暑: "#d36e28", 大暑: "#ce5029",
    立秋: "#a97124", 处暑: "#976921",
    白露: "#688899", 秋分: "#b88424",
    寒露: "#ab6525", 霜降: "#75684a",
    立冬: "#527a98", 小雪: "#648ba3",
    大雪: "#456f96", 冬至: "#315d8f",
  };
  const LUNAR_FESTIVALS = {
    "1-1": ["春节", "#c9342e"],
    "1-15": ["元宵节", "#e06a32"],
    "2-2": ["龙抬头", "#4b8841"],
    "3-3": ["上巳节", "#438f83"],
    "5-5": ["端午节", "#21784c"],
    "7-7": ["七夕节", "#d35c98"],
    "7-15": ["中元节", "#68589b"],
    "8-15": ["中秋节", "#c68712"],
    "9-9": ["重阳节", "#d1712b"],
    "10-1": ["寒衣节", "#687797"],
    "10-15": ["下元节", "#3b7c99"],
    "12-8": ["腊八节", "#a65a30"],
    "12-23": ["小年", "#c24c3b"],
  };
  const solarTermCache = new Map();
  let lunarDateFormatter = null;
  try {
    lunarDateFormatter = new Intl.DateTimeFormat(
      "zh-CN-u-ca-chinese",
      { month: "numeric", day: "numeric" }
    );
  } catch {}

  function solarTermsForYear(year) {
    if (solarTermCache.has(year)) return solarTermCache.get(year);
    const terms = new Map();
    const base = Date.UTC(1900, 0, 6, 2, 5);
    const tropicalYearMs = 31556925974.7;
    for (let index = 0; index < 24; index += 1) {
      const term = new Date(
        base +
          tropicalYearMs * (year - 1900) +
          SOLAR_TERM_MINUTES[index] * 60000
      );
      const month = Math.floor(index / 2) + 1;
      const day = term.getUTCDate();
      const key = `${year}-${String(month).padStart(2, "0")}-${String(
        day
      ).padStart(2, "0")}`;
      terms.set(key, {
        name: SOLAR_TERM_NAMES[index],
        color: SOLAR_TERM_COLORS[SOLAR_TERM_NAMES[index]],
      });
    }
    solarTermCache.set(year, terms);
    return terms;
  }

  function lunarDateParts(date) {
    if (!lunarDateFormatter) return null;
    try {
      const values = {};
      for (const part of lunarDateFormatter.formatToParts(date)) {
        if (part.type === "month" || part.type === "day") {
          values[part.type] = part.value;
        }
      }
      if (
        !/^\d+$/.test(values.month || "") ||
        !/^\d+$/.test(values.day || "")
      ) {
        return null;
      }
      return {
        month: Number(values.month),
        day: Number(values.day),
      };
    } catch {
      return null;
    }
  }

  function calendarLabelsForDate(date) {
    const key = localDateValue(date);
    const labels = [];
    const solar = solarTermsForYear(date.getFullYear()).get(key);
    if (solar) labels.push(solar);
    const lunar = lunarDateParts(date);
    if (!lunar) return labels;
    let festival = LUNAR_FESTIVALS[`${lunar.month}-${lunar.day}`];
    if (!festival) {
      const tomorrow = new Date(
        date.getFullYear(),
        date.getMonth(),
        date.getDate() + 1
      );
      const nextLunar = lunarDateParts(tomorrow);
      if (
        lunar.month === 12 &&
        nextLunar?.month === 1 &&
        nextLunar?.day === 1
      ) {
        festival = ["除夕", "#b62d2d"];
      }
    }
    if (festival) {
      labels.push({ name: festival[0], color: festival[1] });
    }
    return labels;
  }

  function checkinStreakCount(checkins = loadCheckins()) {
    const cursor = new Date();
    cursor.setHours(12, 0, 0, 0);
    if (!checkins[localDateValue(cursor)]) {
      cursor.setDate(cursor.getDate() - 1);
    }
    let streak = 0;
    while (checkins[localDateValue(cursor)]) {
      streak += 1;
      cursor.setDate(cursor.getDate() - 1);
    }
    return streak;
  }

  function monthItemCounts(monthStart, monthEnd) {
    const counts = new Map();
    const dayMs = 24 * 60 * 60 * 1000;
    const addDate = date => {
      if (date < monthStart || date >= monthEnd) return;
      const key = localDateValue(date);
      counts.set(key, Number(counts.get(key) || 0) + 1);
    };
    for (const record of records) {
      if (
        record.deleted ||
        isGroupRecord(record) ||
        isNoteRecord(record)
      ) {
        continue;
      }
      const end = new Date(record.deadline);
      if (!Number.isFinite(end.getTime())) continue;
      let start = end;
      if (isEvent(record)) {
        const eventStart = new Date(record.start_at);
        if (Number.isFinite(eventStart.getTime())) start = eventStart;
      }
      start = new Date(
        start.getFullYear(),
        start.getMonth(),
        start.getDate()
      );
      const last = new Date(
        end.getFullYear(),
        end.getMonth(),
        end.getDate()
      );
      if (start > last) continue;
      if (start < monthStart) start = new Date(monthStart);
      for (
        let cursor = start;
        cursor <= last && cursor < monthEnd;
        cursor = new Date(cursor.getTime() + dayMs)
      ) {
        addDate(new Date(cursor));
      }
    }
    return counts;
  }

  function renderMonthView() {
    if (!monthGrid || !monthTitle) return;
    const year = monthCursor.getFullYear();
    const month = monthCursor.getMonth();
    const monthStart = new Date(year, month, 1);
    const monthEnd = new Date(year, month + 1, 1);
    const leadingDays = (monthStart.getDay() + 6) % 7;
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const totalCells =
      Math.ceil((leadingDays + daysInMonth) / 7) * 7;
    const gridStart = new Date(
      year,
      month,
      1 - leadingDays
    );
    const gridEnd = new Date(
      gridStart.getFullYear(),
      gridStart.getMonth(),
      gridStart.getDate() + totalCells
    );
    const todayKey = localDateValue(new Date());
    const checkins = loadCheckins();
    const counts = monthItemCounts(gridStart, gridEnd);
    monthTitle.textContent = `${year} 年 ${month + 1} 月`;
    monthGrid.replaceChildren();
    for (let index = 0; index < totalCells; index += 1) {
      const date = new Date(
        gridStart.getFullYear(),
        gridStart.getMonth(),
        gridStart.getDate() + index
      );
      const key = localDateValue(date);
      const signed = Boolean(checkins[key]);
      const outside = date.getMonth() !== month;
      const cell = document.createElement("button");
      cell.type = "button";
      cell.className = `month-day${outside ? " outside-month" : ""}${
        key === todayKey ? " today" : ""
      }${signed ? " signed" : ""}`;
      cell.setAttribute(
        "aria-label",
        `${key}${counts.get(key) ? `，${counts.get(key)} 个事项` : ""}${
          signed ? "，已签到" : ""
        }`
      );
      const number = document.createElement("span");
      number.className = "month-date-number";
      number.textContent = String(date.getDate());
      cell.appendChild(number);
      const calendarLabels = calendarLabelsForDate(date);
      if (calendarLabels.length) {
        const labelBox = document.createElement("span");
        labelBox.className = "month-event-labels";
        for (const label of calendarLabels) {
          const labelElement = document.createElement("span");
          labelElement.className = "month-event-label";
          labelElement.textContent = label.name;
          labelElement.style.color = label.color;
          labelBox.appendChild(labelElement);
        }
        cell.appendChild(labelBox);
      }
      const itemCount = Number(counts.get(key) || 0);
      if (itemCount) {
        const badge = document.createElement("span");
        badge.className = "month-item-count";
        badge.textContent = String(itemCount);
        badge.title = `${itemCount} 个事项`;
        cell.appendChild(badge);
      }
      if (signed) {
        const mark = document.createElement("span");
        mark.className = "month-signed-mark";
        mark.textContent = "✓";
        mark.setAttribute("aria-hidden", "true");
        cell.appendChild(mark);
      }
      cell.addEventListener("click", () => {
        if (outside) {
          monthCursor = new Date(
            date.getFullYear(),
            date.getMonth(),
            1
          );
          renderMonthView();
        }
        openMonthDayDetail(key);
      });
      monthGrid.appendChild(cell);
    }
    const checkedToday = Boolean(checkins[todayKey]);
    if (checkinBtn) {
      checkinBtn.disabled = checkedToday;
      checkinBtn.textContent = checkedToday ? "今日已签到" : "今日签到";
    }
    if (checkinStreak) {
      checkinStreak.textContent =
        `连续签到 ${checkinStreakCount(checkins)} 天`;
    }
    if (checkinStatus) {
      checkinStatus.textContent = checkedToday
        ? "今日已签到，获得 5 光斑和 20 经验。"
        : "今日尚未签到。";
    }
  }

  function openMonthView() {
    monthCursor = new Date(
      new Date().getFullYear(),
      new Date().getMonth(),
      1
    );
    monthOverlay.classList.add("show");
    recordDailyAction("month_view_opened");
    renderMonthView();
  }

  function shiftMonth(offset) {
    monthCursor = new Date(
      monthCursor.getFullYear(),
      monthCursor.getMonth() + offset,
      1
    );
    renderMonthView();
  }

  function closeMonthView() {
    monthOverlay.classList.remove("show");
  }

  function checkInToday() {
    const key = localDateValue(new Date());
    const checkins = loadCheckins();
    if (checkins[key]) {
      showToast("今天已经签到过了");
      renderMonthView();
      return;
    }
    checkins[key] = {
      checked_at: new Date().toISOString(),
      spots: 5,
      xp: 20,
    };
    if (!saveCheckins(checkins)) return;
    adjustGlowSpots(5, "每日签到");
    adjustExperience(20, "每日签到");
    recordDailyAction("checkin");
    renderMonthView();
    showToast("签到成功：获得 5 光斑和 20 经验");
  }

  function recordsForDate(dateKey) {
    const target = new Date(`${dateKey}T12:00:00`);
    const dayStart = new Date(
      target.getFullYear(),
      target.getMonth(),
      target.getDate()
    );
    const nextDay = new Date(
      target.getFullYear(),
      target.getMonth(),
      target.getDate() + 1
    );
    return records
      .filter(record => {
        if (
          record.deleted ||
          isGroupRecord(record) ||
          isNoteRecord(record)
        ) {
          return false;
        }
        if (!isEvent(record)) {
          return localDateValue(new Date(record.deadline)) === dateKey;
        }
        const start = new Date(record.start_at);
        const end = new Date(record.deadline);
        return (
          Number.isFinite(start.getTime()) &&
          Number.isFinite(end.getTime()) &&
          start < nextDay &&
          end > dayStart
        );
      })
      .sort((left, right) => {
        const leftPinned = left.pinned ? 0 : 1;
        const rightPinned = right.pinned ? 0 : 1;
        const leftTime = new Date(
          isEvent(left) ? left.start_at : left.deadline
        ).getTime();
        const rightTime = new Date(
          isEvent(right) ? right.start_at : right.deadline
        ).getTime();
        return (
          leftPinned - rightPinned ||
          (Number.isFinite(leftTime) ? leftTime : 0) -
            (Number.isFinite(rightTime) ? rightTime : 0)
        );
      });
  }

  function closeMonthDayDetail() {
    monthDayOverlay?.classList.remove("show");
  }

  function openMonthDayDetail(dateKey) {
    if (!monthDayOverlay || !monthDayList) return;
    const target = new Date(`${dateKey}T12:00:00`);
    const items = recordsForDate(dateKey);
    monthDayTitle.textContent = target.toLocaleDateString("zh-CN", {
      year: "numeric",
      month: "long",
      day: "numeric",
      weekday: "long",
    });
    monthDaySummary.textContent = items.length
      ? `当天共有 ${items.length} 个事项`
      : "当天没有事项";
    monthDayList.replaceChildren();
    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "month-day-empty";
      empty.textContent = "这一天还没有记录事项。";
      monthDayList.appendChild(empty);
    } else {
      for (const memo of items) {
        const [stateText] = groupItemState(memo);
        const card = document.createElement("article");
        card.className = "month-day-item";
        const head = document.createElement("div");
        head.className = "month-day-item-head";
        const title = document.createElement("strong");
        title.textContent = memo.title || "未命名事项";
        const type = document.createElement("span");
        type.className = `month-day-item-type${
          isEvent(memo) ? " event" : ""
        }`;
        type.textContent = `${isEvent(memo) ? "事件" : "任务"} · ${stateText}`;
        head.append(title, type);
        const meta = document.createElement("div");
        meta.className = "month-day-item-meta";
        meta.textContent = isEvent(memo)
          ? `开始：${formatDeadline(memo.start_at)}\n结束：${formatDeadline(memo.deadline)}`
          : `截止：${formatDeadline(memo.deadline)}${
              memo.completed_at
                ? `\n完成：${formatDeadline(memo.completed_at)}`
                : ""
            }`;
        if (memo.location) {
          meta.textContent += `\n地点：${memo.location}`;
        }
        card.append(head, meta);
        if (memo.note) {
          const note = document.createElement("div");
          note.className = "month-day-item-note";
          note.textContent = memo.note;
          card.appendChild(note);
        }
        if (memo.image_data) {
          const image = document.createElement("img");
          image.className = "month-day-item-image";
          image.src = memo.image_data;
          image.loading = "lazy";
          image.decoding = "async";
          image.alt = memo.title || "事项图片";
          card.appendChild(image);
        }
        monthDayList.appendChild(card);
      }
    }
    monthDayOverlay.classList.add("show");
  }

  async function openChangelog() {
    if (!changelogEntries && bootstrap.changelog) {
      changelogEntries = bootstrap.changelog;
    }
    if (!changelogEntries) {
      try {
        const response = await fetch("./changelog.json", { cache: "no-store" });
        if (response.ok) {
          changelogEntries = await response.json();
        }
      } catch {}
    }
    if (!changelogEntries) {
      changelogEntries = {
        current_version: bootstrap.mobileVersion || "3.1.0",
        entries: [],
      };
    }
    versionBtn.textContent =
      document.body.dataset.desktopSurface === "true"
        ? "更新日志"
        : `v${changelogEntries.current_version || "3.1.0"}`;
    changelogList.replaceChildren();
    for (const entry of changelogEntries.entries || []) {
      const card = document.createElement("article");
      card.className = "version-history-entry";
      const head = document.createElement("div");
      head.className = "version-entry-head";
      const title = document.createElement("h3");
      title.textContent = `v${entry.version} · ${entry.title || "版本更新"}`;
      const time = document.createElement("time");
      time.textContent = entry.date || "";
      head.append(title, time);
      const list = document.createElement("ul");
      for (const change of entry.changes || []) {
        const item = document.createElement("li");
        if (String(change).startsWith("green:")) {
          item.textContent = String(change).slice(6);
          item.classList.add("changelog-highlight");
        } else {
          item.textContent = change;
        }
        list.appendChild(item);
      }
      card.append(head, list);
      changelogList.appendChild(card);
    }
    changelogOverlay.classList.add("show");
  }

  startDateInput.addEventListener("change", () => {
    if (startDateInput.value) {
      endDateInput.value = startDateInput.value;
    }
  });

  function openDefaultReminderEditor() {
    syncDefaultReminderControls();
    defaultReminderOverlay?.classList.add("show");
  }

  function closeDefaultReminderEditor() {
    defaultReminderOverlay?.classList.remove("show");
  }

  editDefaultReminderBtn?.addEventListener("click", openDefaultReminderEditor);
  defaultReminderCloseBtn?.addEventListener("click", closeDefaultReminderEditor);
  defaultReminderCancelBtn?.addEventListener("click", closeDefaultReminderEditor);
  defaultReminderOverlay?.addEventListener("click", event => {
    if (event.target === defaultReminderOverlay) closeDefaultReminderEditor();
  });
  useDefaultReminder?.addEventListener("change", () => {
    if (useDefaultReminder.checked) {
      applyDefaultReminderToEditor();
    } else {
      reminderEnabled.checked = false;
    }
    updateReminderOptionsVisibility();
  });
  reminderEnabled?.addEventListener("change", updateReminderOptionsVisibility);
  defaultReminderSaveBtn?.addEventListener("click", () => {
    const amount = Math.max(1, Number(defaultReminderAmount.value) || 1);
    const multiplier = {
      minutes: 1,
      hours: 60,
      days: 1440,
    }[defaultReminderUnit.value] || 1;
    const modes = [
      defaultReminderNotify.checked ? "notification" : null,
      defaultReminderSound.checked ? "sound" : null,
      defaultReminderVibrate.checked ? "vibration" : null,
    ].filter(Boolean);
    if (!modes.length) {
      defaultReminderStatus.textContent = "请至少选择一种提醒方式。";
      return;
    }
    defaultReminderSettings = normalizeDefaultReminder({
      minutes: Math.round(amount * multiplier),
      modes,
    });
    saveDefaultReminderSettings();
    updateDefaultReminderSummary();
    if (useDefaultReminder.checked) {
      applyDefaultReminderToEditor();
    }
    updateReminderOptionsVisibility();
    closeDefaultReminderEditor();
    recordDailyAction("reminder_saved");
    showToast("默认提醒搭配已保存");
  });

  loadDefaultReminderSettings();
  updateDefaultReminderSummary();
  updateReminderOptionsVisibility();

  form.addEventListener("submit", event => {
    event.preventDefault();
    const title = titleInput.value.trim();
    if (!title) {
      showToast("请填写事项名称");
      return;
    }
    if (
      editorType === "event"
        ? (!startDateInput.value || !startTimeInput.value || !endDateInput.value || !endTimeInput.value)
        : (!dateInput.value || !timeInput.value)
    ) {
      showToast(editorType === "event" ? "请选择事件开始和结束时间" : "请选择截止时间");
      return;
    }
    const deadline = editorType === "event"
      ? `${endDateInput.value}T${endTimeInput.value}:00`
      : `${dateInput.value}T${timeInput.value}:00`;
    const startAt = editorType === "event"
      ? `${startDateInput.value}T${startTimeInput.value}:00`
      : null;
    if (new Date(deadline).getTime() <= Date.now()) {
      showToast("结束时间需要晚于现在");
      return;
    }
    if (
      editorType === "event" &&
      new Date(startAt).getTime() >= new Date(deadline).getTime()
    ) {
      showToast("事件开始时间需要早于结束时间");
      return;
    }
    const reminderMinutes = reminderMinutesValue();
    const reminderModes = reminderModesValue();
    if (reminderEnabled.checked) {
      nativeBridge?.requestReminderSystemPermissions?.();
    }
    const reminderVolumePercentValue = reminderVolumePercent();
    if (reminderEnabled.checked && !reminderModes.length) {
      showToast("请至少选择一种提醒方式");
      return;
    }
    const reminderAnchor = new Date(
      editorType === "event" ? startAt : deadline
    );
    const reminderAt = new Date(
      reminderAnchor.getTime() - reminderMinutes * 60000
    );
    if (
      reminderEnabled.checked &&
      reminderAt.getTime() <= Date.now()
    ) {
      showToast("提前通知时间已经过去，请缩短提前时间");
      return;
    }
    const selectedGroupId = groupById(memoGroup.value)
      ? memoGroup.value
      : null;

    const now = new Date().toISOString();
    let memo = editingId
      ? records.find(record => record.id === editingId)
      : null;
    const createdNewMemo = !memo;
    if (memo) {
      memo.title = title;
      memo.note = noteInput.value.trim();
      memo.location = locationInput.value.trim();
      memo.pinned = memoPinned.checked;
      memo.item_type = editorType;
      memo.start_at = startAt;
      memo.deadline = deadline;
      memo.group_id = selectedGroupId;
      memo.reminder_enabled = reminderEnabled.checked;
      memo.reminder_minutes = reminderMinutes;
      memo.reminder_modes = reminderModes;
      memo.reminder_volume = reminderVolumePercentValue;
      memo.reminder_at = reminderEnabled.checked
        ? reminderAt.toISOString()
        : null;
      memo.image_data = editingImageData;
      if (editorType === "event") {
        memo.completed = false;
        memo.completed_at = null;
      }
      memo.deleted = false;
      memo.rev = nextRevision(memo);
      memo.updated_at = now;
    } else {
      memo = {
        id:
          crypto.randomUUID?.() ||
          `m-${Date.now()}-${Math.random().toString(16).slice(2)}`,
        title,
        note: noteInput.value.trim(),
        location: locationInput.value.trim(),
        pinned: memoPinned.checked,
        item_type: editorType,
        start_at: startAt,
        deadline,
        group_id: selectedGroupId,
        completed: false,
        completed_at: null,
        reminder_enabled: reminderEnabled.checked,
        reminder_minutes: reminderMinutes,
        reminder_modes: reminderModes,
        reminder_volume: reminderVolumePercentValue,
        reminder_at: reminderEnabled.checked ? reminderAt.toISOString() : null,
        image_data: editingImageData,
        created_at: now,
        updated_at: now,
        rev: nextRevision(),
        deleted: false,
        image: null,
      };
      records.push(memo);
    }
    persist();
    if (createdNewMemo) {
      recordDailyAction("memo_created");
    } else {
      recordDailyAction("memo_edited");
    }
    closeEditor();
    render();
    showToast("已保存到手机，联网后自动同步");
    syncNow(false);
  });

  groupForm.addEventListener("submit", event => {
    event.preventDefault();
    const name = groupNameInput.value.trim();
    const intro = groupIntroInput.value.trim();
    if (!name) {
      showToast("请填写分组名称");
      return;
    }
    const duplicate = groupRecords().find(
      group =>
        group.id !== editingGroupId &&
        String(group.title || "").trim().toLocaleLowerCase("zh-CN") ===
          name.toLocaleLowerCase("zh-CN")
    );
    if (duplicate) {
      showToast("已经有同名分组，请换一个名称");
      return;
    }

    const now = new Date().toISOString();
    let group = editingGroupId
      ? records.find(
          record =>
            record.id === editingGroupId &&
            !record.deleted &&
            isGroupRecord(record)
        )
      : null;
    if (group) {
      group.title = name;
      group.note = intro;
      group.rev = nextRevision(group);
      group.updated_at = now;
    } else {
      group = {
        id:
          crypto.randomUUID?.() ||
          `g-${Date.now()}-${Math.random().toString(16).slice(2)}`,
        record_kind: "group",
        title: name,
        note: intro,
        created_at: now,
        updated_at: now,
        rev: nextRevision(),
        deleted: false,
      };
      records.push(group);
    }

    const selectedIds = new Set(
      [...groupMemoChoices.querySelectorAll('input[type="checkbox"]:checked')]
        .map(input => input.value)
    );
    for (const memo of memoRecords()) {
      // Historical items are managed from the History screen. Editing a
      // group's active-item list must not silently remove their assignment.
      if (isHistorical(memo)) continue;
      const shouldBelongToGroup = selectedIds.has(memo.id);
      if (shouldBelongToGroup && memo.group_id !== group.id) {
        memo.group_id = group.id;
        memo.rev = nextRevision(memo);
        memo.updated_at = now;
      } else if (!shouldBelongToGroup && memo.group_id === group.id) {
        memo.group_id = null;
        memo.rev = nextRevision(memo);
        memo.updated_at = now;
      }
    }
    for (const note of noteRecords()) {
      const shouldBelongToGroup = selectedIds.has(note.id);
      if (shouldBelongToGroup && note.group_id !== group.id) {
        note.group_id = group.id;
        note.rev = nextRevision(note);
        note.updated_at = now;
      } else if (!shouldBelongToGroup && note.group_id === group.id) {
        note.group_id = null;
        note.rev = nextRevision(note);
        note.updated_at = now;
      }
    }
    persist();
    closeGroupEditor();
    render();
    setPage("groups");
    renderGroups();
    recordDailyAction("group_saved");
    showToast("分组已保存，联网后自动同步");
    syncNow(false);
  });

  noteForm.addEventListener("submit", event => {
    event.preventDefault();
    beginNoteWriting();
  });

  taskTypeBtn.addEventListener("click", () => setEditorType("task"));
  eventTypeBtn.addEventListener("click", () => setEditorType("event"));
  reminderEnabled.addEventListener("change", updateReminderOptionsVisibility);
  reminderVolume.addEventListener("input", updateReminderVolumeLabel);
  testReminderBtn.addEventListener("click", () => {
    const modes = reminderModesValue();
    if (!modes.length) {
      showToast("请至少选择一种提醒方式");
      return;
    }
    if (!nativeBridge?.testReminder) {
      showToast("测试提醒功能需要在 Android App 中使用");
      return;
    }
    if (modes.includes("notification")) {
      nativeBridge?.requestReminderSystemPermissions?.();
    }
    nativeBridge.testReminder(
      modes.includes("notification"),
      modes.includes("sound"),
      modes.includes("vibration"),
      reminderVolumePercent() / 100
    );
    showToast("测试提醒将在 3 秒后触发");
  });
  imageInput.addEventListener("change", async () => {
    const file = imageInput.files?.[0];
    if (!file) {
      setEditingImage(null);
      return;
    }
    try {
      setEditingImage(await compressImageFile(file));
    } catch (error) {
      showToast(error?.message || "图片读取失败");
      setEditingImage(null);
    }
  });
  removeImageBtn.addEventListener("click", () => setEditingImage(null));

  function normalizePhoneAddress(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    try {
      const parsed = new URL(
        /^https?:\/\//i.test(raw) ? raw : `http://${raw}`
      );
      if (parsed.protocol !== "http:" || !parsed.hostname) return "";
      const port = Number(parsed.port || 8790);
      if (!Number.isInteger(port) || port < 1 || port > 65535) return "";
      return `${parsed.hostname}:${port}`;
    } catch {
      return "";
    }
  }

  function savePhonePairing(address, token, deviceId = "", remember = true) {
    phoneSyncAddress = normalizePhoneAddress(address);
    phoneSyncToken = String(token || "").trim();
    phoneSyncDevice = String(deviceId || "").trim();
    if (remember && phoneSyncAddress) {
      localStorage.setItem(PHONE_SYNC_ADDRESS_KEY, phoneSyncAddress);
    } else {
      localStorage.removeItem(PHONE_SYNC_ADDRESS_KEY);
    }
    if (remember && phoneSyncToken) {
      localStorage.setItem(PHONE_SYNC_TOKEN_KEY, phoneSyncToken);
    } else {
      localStorage.removeItem(PHONE_SYNC_TOKEN_KEY);
    }
    if (remember && phoneSyncDevice) {
      localStorage.setItem(PHONE_SYNC_DEVICE_KEY, phoneSyncDevice);
    } else {
      localStorage.removeItem(PHONE_SYNC_DEVICE_KEY);
    }
  }

  async function discoverPhoneFromDesktop() {
    if (!isDesktopSurface) {
      throw new Error("自动发现仅在电脑版可用，请填写手机显示的地址");
    }
    const response = await fetch("api/phone/discover", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "{}",
      cache: "no-store",
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || !payload.ok) {
      throw new Error(payload.error || "无法自动发现手机");
    }
    const devices = Array.isArray(payload.devices) ? payload.devices : [];
    if (!devices.length) {
      throw new Error("没有发现手机，请确认双方连接同一 Wi-Fi 并打开手机同步");
    }
    return devices;
  }

  async function pairPhone(address, code, remember = true) {
    const normalized = normalizePhoneAddress(address);
    if (!normalized) {
      throw new Error("手机地址格式不正确");
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    let payload = {};
    try {
      const response = await fetch(`http://${normalized}/pair`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: JSON.stringify({
          code: String(code || "").trim(),
          client_id: phoneSyncClient,
        }),
        cache: "no-store",
        signal: controller.signal,
      });
      payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.token) {
        throw new Error(payload.error || "配对失败，请检查配对码");
      }
    } catch (error) {
      if (error?.name === "AbortError") {
        throw new Error("连接手机超时，请检查 Wi-Fi 和手机地址");
      }
      throw error;
    } finally {
      clearTimeout(timer);
    }
    savePhonePairing(
      normalized,
      payload.token,
      payload.device_id || payload.device_name || "",
      remember
    );
    return normalized;
  }

  async function pairDesktopPeer(address, code, remember = true) {
    const normalized = normalizePhoneAddress(address);
    if (!normalized) {
      throw new Error("电脑地址格式不正确");
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    let payload = {};
    try {
      const response = await fetch(`http://${normalized}/pair`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: JSON.stringify({
          code: String(code || "").trim(),
          client_id: phoneSyncClient,
        }),
        cache: "no-store",
        signal: controller.signal,
      });
      payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.token) {
        throw new Error(payload.error || "电脑配对失败");
      }
    } catch (error) {
      if (error?.name === "AbortError") {
        throw new Error("连接电脑超时，请检查 Wi-Fi、热点和电脑地址");
      }
      throw error;
    } finally {
      clearTimeout(timer);
    }
    desktopPeerAddress = normalized;
    desktopPeerToken = String(payload.token);
    if (remember) {
      localStorage.setItem(DESKTOP_PEER_ADDRESS_KEY, desktopPeerAddress);
      localStorage.setItem(DESKTOP_PEER_TOKEN_KEY, desktopPeerToken);
    } else {
      localStorage.removeItem(DESKTOP_PEER_ADDRESS_KEY);
      localStorage.removeItem(DESKTOP_PEER_TOKEN_KEY);
    }
    return normalized;
  }

  async function fetchPeerRecords(peer) {
    const target = normalizePhoneAddress(peer?.address);
    const token = String(peer?.token || "");
    if (!target || !token) {
      throw new Error("设备尚未配对");
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    try {
      const peerPath =
        peer.kind === "desktop"
          ? `/d/${encodeURIComponent(token)}`
          : "";
      const response = await fetch(`http://${target}${peerPath}/records`, {
        method: "GET",
        headers: {
          "Accept": "application/json",
          "X-Buaa-Token": token,
        },
        cache: "no-store",
        signal: controller.signal,
      });
      if (response.status === 401) {
        if (peer.kind === "phone") {
          savePhonePairing(target, "", phoneSyncDevice);
        }
        throw new Error("设备配对已失效，请重新输入 12 位配对码");
      }
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !Array.isArray(payload.records)) {
        throw new Error(payload.error || "无法读取另一端事项");
      }
      if (peer.kind === "phone") {
        savePhonePairing(target, token, phoneSyncDevice);
      }
      return payload.records;
    } catch (error) {
      if (error?.name === "AbortError") {
        throw new Error("连接手机超时，请检查 Wi-Fi、热点和手机地址");
      }
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  async function postPeerChanges(outgoing, peer) {
    const target = normalizePhoneAddress(peer?.address);
    const token = String(peer?.token || "");
    if (!target || !token) {
      throw new Error("设备尚未配对");
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15000);
    try {
      const peerPath =
        peer.kind === "desktop"
          ? `/d/${encodeURIComponent(token)}`
          : "";
      const response = await fetch(`http://${target}${peerPath}/sync`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "X-Buaa-Token": token,
        },
        body: JSON.stringify({ records: outgoing }),
        cache: "no-store",
        signal: controller.signal,
      });
      if (response.status === 401) {
        if (peer.kind === "phone") {
          savePhonePairing(target, "", phoneSyncDevice);
        }
        throw new Error("设备配对已失效，请重新输入 12 位配对码");
      }
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !Array.isArray(payload.records)) {
        throw new Error(payload.error || "另一端同步写入失败");
      }
      if (peer.kind === "phone") {
        savePhonePairing(target, token, phoneSyncDevice);
      }
      return payload.records;
    } catch (error) {
      if (error?.name === "AbortError") {
        throw new Error("同步写入超时，请检查局域网连接");
      }
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  function recordMap(source) {
    const map = new Map();
    for (const record of Array.isArray(source) ? source : []) {
      if (!record?.id) continue;
      const copy = {
        ...record,
        id: String(record.id),
        rev: Number(record.rev || 0),
        deleted: Boolean(record.deleted),
      };
      const previous = map.get(copy.id);
      if (!previous || copy.rev >= previous.rev) map.set(copy.id, copy);
    }
    return map;
  }

  function listSyncChanges(localSource, remoteSource) {
    const localMap = recordMap(localSource);
    const remoteMap = recordMap(remoteSource);
    const ids = new Set([...localMap.keys(), ...remoteMap.keys()]);
    const changes = [];
    for (const id of ids) {
      const local = localMap.get(id);
      const remote = remoteMap.get(id);
      const localRev = Number(local?.rev || 0);
      const remoteRev = Number(remote?.rev || 0);
      if (localRev === remoteRev) continue;
      const direction = localRev > remoteRev ? "local" : "phone";
      const changed = direction === "local" ? local : remote;
      const previous = direction === "local" ? remote : local;
      if (!changed || isBlockedRecord(changed)) continue;
      let kind = "修改";
      if (!previous) {
        kind = "新增";
      } else if (changed.deleted) {
        kind = "删除";
      } else if (previous.deleted) {
        kind = "恢复";
      } else if (changed.completed_at && !previous.completed_at) {
        kind = "完成";
      }
      changes.push({
        id,
        direction,
        kind,
        historical:
          (!changed.deleted && isHistorical(changed)) ||
          Boolean(previous && !previous.deleted && isHistorical(previous)),
        title:
          String(changed.title || previous?.title || "").trim() ||
          "未命名事项",
        record: changed,
      });
    }
    changes.sort((left, right) => {
      if (left.direction !== right.direction) {
        return left.direction === "local" ? -1 : 1;
      }
      return left.title.localeCompare(right.title, "zh-CN");
    });
    return changes;
  }

  function renderSyncChanges() {
    if (!syncChangeList) return;
    syncChangeList.replaceChildren();
    pendingSyncChanges.forEach((change, index) => {
      const label = document.createElement("label");
      label.className = "group-choice-row";
      label.style.display = "flex";
      label.style.alignItems = "center";
      label.style.gap = "9px";
      label.style.padding = "9px 4px";
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = true;
      checkbox.dataset.changeIndex = String(index);
      const text = document.createElement("span");
      const peerIsDesktop = activeSyncPeer?.kind === "desktop";
      const from = peerIsDesktop
        ? change.direction === "local"
          ? "手机 → 电脑"
          : "电脑 → 手机"
        : change.direction === "local"
          ? isDesktopSurface
            ? "电脑 → 手机"
            : "本机 → 手机"
          : isDesktopSurface
            ? "手机 → 电脑"
            : "手机 → 本机";
      text.textContent =
        `${from} · ${change.historical ? "历史事项" : "当前事项"} · ` +
        `${change.kind} · ${change.title}`;
      label.append(checkbox, text);
      syncChangeList.appendChild(label);
    });
    if (syncChangeSummary) {
      const localCount = pendingSyncChanges.filter(
        change => change.direction === "local"
      ).length;
      const phoneCount = pendingSyncChanges.length - localCount;
      const historyCount = pendingSyncChanges.filter(
        change => change.historical
      ).length;
      syncChangeSummary.textContent =
        `本机待发送 ${localCount} 项，手机待接收 ${phoneCount} 项，` +
        `其中历史事项 ${historyCount} 项。`;
    }
  }

  async function openSyncPreview(peer = null) {
    const targetPeer = peer || {
      kind: "phone",
      address: phoneSyncAddress,
      token: phoneSyncToken,
    };
    if (!targetPeer.address || !targetPeer.token) {
      openPhoneSyncOverlay();
      return false;
    }
    showToast("正在检查两端的变更…");
    try {
      const remoteRecords = await fetchPeerRecords(targetPeer);
      activeSyncPeer = targetPeer;
      pendingSyncChanges = listSyncChanges(records, remoteRecords);
      if (!pendingSyncChanges.length) {
        showToast("两端事项已经一致");
        setConnectionStatus(true);
        return true;
      }
      renderSyncChanges();
      syncPreviewOverlay?.classList.add("show");
      return true;
    } catch (error) {
      showToast(error?.message || "无法获取手机变更");
      if (!phoneSyncToken) openPhoneSyncOverlay();
      return false;
    }
  }

  async function applySyncChanges(selectAll = false) {
    const selectedIds = new Set(
      Array.from(syncChangeList?.querySelectorAll('input[type="checkbox"]') || [])
        .filter(input => selectAll || input.checked)
        .map(input => Number(input.dataset.changeIndex))
    );
    const selected = pendingSyncChanges.filter((_change, index) =>
      selectedIds.has(index)
    );
    if (!selected.length) {
      showToast("请至少选择一项变更");
      return;
    }
    const outgoing = selected
      .filter(change => change.direction === "local")
      .map(change => change.record);
    const incoming = selected
      .filter(change => change.direction === "phone")
      .map(change => change.record);
    try {
      if (outgoing.length) {
        await postPeerChanges(outgoing, activeSyncPeer);
      }
      if (incoming.length) {
        records = mergeRecords(records, incoming);
        persist();
        render();
      }
      syncPreviewOverlay?.classList.remove("show");
      pendingSyncChanges = [];
      activeSyncPeer = null;
      setConnectionStatus(true);
      showToast(
        `同步完成：发送 ${outgoing.length} 项，接收 ${incoming.length} 项`
      );
    } catch (error) {
      showToast(error?.message || "同步失败");
    }
  }

  function openPhoneSyncOverlay() {
    if (syncCodeInput) syncCodeInput.value = "";
    if (syncAddressInput) {
      syncAddressInput.value = phoneSyncAddress || "";
    }
    if (syncPairingStatus) {
      syncPairingStatus.textContent = phoneSyncToken
        ? `已配对：${phoneSyncAddress}`
        : "手机和电脑需要连接同一 Wi-Fi 或手机热点。";
    }
    if (desktopHostInfo) {
      const address = String(bootstrap.desktopLanAddress || "");
      const code = String(bootstrap.desktopPairingCode || "");
      desktopHostInfo.style.display =
        isDesktopSurface && address && code ? "block" : "none";
      if (desktopHostAddress) desktopHostAddress.textContent = address || "—";
      if (desktopHostCode) desktopHostCode.textContent = code || "—";
    }
    syncOverlay?.classList.add("show");
    setTimeout(() => syncCodeInput?.focus(), 80);
  }

  function syncViaWebSocket() {
    return new Promise(resolve => {
      if (!syncUrl) {
        resolve(false);
        return;
      }
      let settled = false;
      let socket;
      let timer;
      const finish = ok => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        try {
          socket?.close();
        } catch {}
        resolve(ok);
      };
      try {
        socket = new WebSocket(syncUrl);
      } catch {
        resolve(false);
        return;
      }
      timer = setTimeout(() => finish(false), 4500);
      socket.onopen = () => {
        socket.send(JSON.stringify({ type: "sync", records }));
      };
      socket.onmessage = event => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type !== "synced" || !Array.isArray(payload.records)) {
            finish(false);
            return;
          }
          records = mergeRecords(records, payload.records);
          persist();
          render();
          finish(true);
        } catch {
          finish(false);
        }
      };
      socket.onerror = () => finish(false);
      socket.onclose = () => finish(false);
    });
  }

  async function syncViaCloud() {
    if (!cloudSyncUrl || !cloudPublishableKey || !cloudVaultKey) {
      return false;
    }
    try {
      const outgoing = records.filter(
        record => Number(record.rev || 0) > cloudPushRev
      );
      const outgoingMax = outgoing.reduce(
        (maximum, record) => Math.max(maximum, Number(record.rev || 0)),
        cloudPushRev
      );
      const response = await fetch(cloudSyncUrl, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${cloudPublishableKey}`,
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: JSON.stringify({
          p_vault_key: cloudVaultKey,
          p_since: cloudCursor,
          p_records: outgoing,
        }),
      });
      if (!response.ok) return false;
      const payload = await response.json();
      const incoming = Array.isArray(payload)
        ? payload
        : Array.isArray(payload.records)
          ? payload.records
          : [];
      if (!Array.isArray(incoming)) return false;
      if (outgoingMax > cloudPushRev) {
        cloudPushRev = outgoingMax;
      }
      const nextCursor = Number(payload?.cursor || cloudCursor);
      if (Number.isFinite(nextCursor) && nextCursor >= cloudCursor) {
        cloudCursor = nextCursor;
      }
      saveCloudProgress();
      records = mergeRecords(records, incoming);
      persist();
      render();
      return true;
    } catch {
      return false;
    }
  }

  function deriveHttpUrl() {
    try {
      const url = new URL(syncUrl);
      const token = url.pathname.split("/").filter(Boolean).pop();
      if (!token) return "";
      return `${url.protocol === "wss:" ? "https:" : "http:"}//${url.host}/t/${token}/api/sync`;
    } catch {
      return bootstrap.syncHttpUrl || "";
    }
  }

  async function syncViaHttp() {
    const target = deriveHttpUrl();
    if (!target) return false;
    try {
      const response = await fetch(target, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ records }),
      });
      const payload = await response.json();
      if (!response.ok || !Array.isArray(payload.records)) return false;
      records = mergeRecords(records, payload.records);
      persist();
      render();
      return true;
    } catch {
      return false;
    }
  }

  async function syncNow(interactive = true) {
    if (nativeBridge) {
      setConnectionStatus(true);
      setTimeout(syncNow, 5000);
      return true;
    }
    if (isDesktopSurface || phoneSyncToken) {
      return interactive ? openSyncPreview() : false;
    }
    if (syncing) return false;
    syncing = true;
    let online = false;
    try {
      online = await syncViaCloud();
      if (!online) online = await syncViaWebSocket();
      if (!online) online = await syncViaHttp();
    } finally {
      syncing = false;
      setConnectionStatus(online);
      setTimeout(syncNow, online ? 300000 : 600000);
    }
    return online;
  }

  statusEl.style.cursor = "pointer";
  statusEl.title = "点击配对手机或立即同步";
  statusEl.addEventListener("click", () => {
    if (nativeBridge) {
      try {
        const info = JSON.parse(nativeBridge.getDeviceInfo() || "{}");
        nativeBridge.showToast(`电脑请连接 ${info.ip}:${info.port}`);
      } catch {
        nativeBridge.showToast("同步服务正在启动");
      }
      return;
    }
    if (phoneSyncToken) {
      openSyncPreview();
      return;
    }
    openPhoneSyncOverlay();
  });
  document.getElementById("syncCancelBtn").addEventListener("click", () => {
    syncOverlay.classList.remove("show");
  });
  document.getElementById("syncSaveBtn").addEventListener("click", async () => {
    const code = String(syncCodeInput?.value || "").trim();
    if (!/^\d{12}$/.test(code)) {
      if (syncPairingStatus) {
        syncPairingStatus.textContent = "请输入手机显示的 12 位数字配对码。";
      }
      return;
    }
    let address = normalizePhoneAddress(syncAddressInput?.value || "");
    try {
      if (!address) {
        if (syncPairingStatus) {
          syncPairingStatus.textContent = "正在自动发现手机…";
        }
        const devices = await discoverPhoneFromDesktop();
        address = normalizePhoneAddress(
          `${devices[0].host}:${devices[0].port}`
        );
        if (syncAddressInput) syncAddressInput.value = address;
      }
      if (!address) throw new Error("请填写手机显示的 IP:端口");
      if (syncPairingStatus) {
        syncPairingStatus.textContent = "正在配对并同步…";
      }
      await pairPhone(address, code, rememberPhonePair?.checked !== false);
      syncOverlay.classList.remove("show");
      showToast("配对成功，正在读取两端变更");
      await openSyncPreview();
    } catch (error) {
      if (syncPairingStatus) {
        syncPairingStatus.textContent =
          error?.message || "配对失败，请稍后重试";
      }
    }
  });
  syncDiscoverBtn?.addEventListener("click", async () => {
    try {
      if (syncPairingStatus) syncPairingStatus.textContent = "正在发现手机…";
      const devices = await discoverPhoneFromDesktop();
      const address = normalizePhoneAddress(
        `${devices[0].host}:${devices[0].port}`
      );
      if (syncAddressInput) syncAddressInput.value = address;
      if (syncPairingStatus) {
        syncPairingStatus.textContent =
          devices.length > 1
            ? `发现 ${devices.length} 台设备，已选择 ${address}`
            : `已发现手机：${address}`;
      }
    } catch (error) {
      if (syncPairingStatus) {
        syncPairingStatus.textContent =
          error?.message || "没有发现手机";
      }
    }
  });
  syncOverlay.addEventListener("click", event => {
    if (event.target === syncOverlay) {
      syncOverlay.classList.remove("show");
    }
  });

  function openMobileSyncTutorial() {
    let deviceInfo = {};
    if (nativeBridge) {
      try {
        deviceInfo = JSON.parse(nativeBridge.getDeviceInfo() || "{}");
      } catch {}
    }
    if (nativeDeviceGuide) nativeDeviceGuide.hidden = !nativeBridge;
    if (syncGuideAddress) {
      syncGuideAddress.textContent =
        deviceInfo.ip && deviceInfo.port
          ? `${deviceInfo.ip}:${deviceInfo.port}`
          : "手机端无需填写；请以电脑端“同步”中显示的地址为准";
    }
    if (syncGuideCode) {
      syncGuideCode.textContent =
        deviceInfo.pairing_code ||
        "手机端无需填写；首次连接请输入电脑端显示的 12 位配对码";
    }
    if (desktopPeerAddressInput && !desktopPeerAddressInput.value) {
      desktopPeerAddressInput.value = desktopPeerAddress;
    }
    if (mobilePullDesktopStatus) {
      mobilePullDesktopStatus.textContent = desktopPeerToken
        ? `已配对电脑：${desktopPeerAddress}`
        : "请在电脑端点击“同步”，再把电脑显示的地址和 12 位配对码填到下面。";
    }
    nativeBridge?.requestSync?.();
    syncTutorialOverlay.classList.add("show");
  }

  syncBtn.addEventListener("click", async () => {
    if (isMobileSyncSurface) {
      openMobileSyncTutorial();
      return;
    }
    if (phoneSyncToken) {
      await openSyncPreview();
      return;
    }
    openPhoneSyncOverlay();
    if (isDesktopSurface) {
      try {
        const devices = await discoverPhoneFromDesktop();
        const address = normalizePhoneAddress(
          `${devices[0].host}:${devices[0].port}`
        );
        if (syncAddressInput) syncAddressInput.value = address;
        if (syncPairingStatus) {
          syncPairingStatus.textContent = `已发现手机：${address}，请输入 12 位配对码`;
        }
      } catch {
        // Manual address entry remains available.
      }
    }
  });
  document.getElementById("syncTutorialClose").addEventListener("click", () => {
    syncTutorialOverlay.classList.remove("show");
  });
  syncTutorialOverlay.addEventListener("click", event => {
    if (event.target === syncTutorialOverlay) {
      syncTutorialOverlay.classList.remove("show");
    }
  });
  mobilePullDesktopBtn?.addEventListener("click", async () => {
    const address = normalizePhoneAddress(
      desktopPeerAddressInput?.value || desktopPeerAddress
    );
    const code = String(desktopPeerCodeInput?.value || "").trim();
    if (!address || (!desktopPeerToken && !/^\d{12}$/.test(code))) {
      if (mobilePullDesktopStatus) {
        mobilePullDesktopStatus.textContent =
          "请填写电脑显示的地址；首次连接还需输入 12 位配对码。";
      }
      return;
    }
    try {
      if (code) {
        if (mobilePullDesktopStatus) {
          mobilePullDesktopStatus.textContent = "正在连接电脑…";
        }
        await pairDesktopPeer(
          address,
          code,
          rememberDesktopPair?.checked !== false
        );
      }
      if (mobilePullDesktopStatus) {
        mobilePullDesktopStatus.textContent = "已连接电脑，正在读取变更…";
      }
      await openSyncPreview({
        kind: "desktop",
        address,
        token: desktopPeerToken,
      });
    } catch (error) {
      if (mobilePullDesktopStatus) {
        mobilePullDesktopStatus.textContent =
          error?.message || "无法连接电脑";
      }
    }
  });
  document
    .getElementById("syncPreviewCloseBtn")
    ?.addEventListener("click", () => {
      syncPreviewOverlay?.classList.remove("show");
      pendingSyncChanges = [];
    });
  syncPreviewOverlay?.addEventListener("click", event => {
    if (event.target === syncPreviewOverlay) {
      syncPreviewOverlay.classList.remove("show");
      pendingSyncChanges = [];
    }
  });
  document
    .getElementById("syncPreviewSelectedBtn")
    ?.addEventListener("click", () => applySyncChanges(false));
  document
    .getElementById("syncPreviewAllBtn")
    ?.addEventListener("click", () => applySyncChanges(true));
  historyBtn.addEventListener("click", openHistory);
  experienceInfoBtn.addEventListener("click", openExperienceGuide);
  document
    .getElementById("experienceInfoCloseBtn")
    .addEventListener("click", () =>
      experienceInfoOverlay.classList.remove("show")
    );
  experienceInfoOverlay.addEventListener("click", event => {
    if (event.target === experienceInfoOverlay) {
      experienceInfoOverlay.classList.remove("show");
    }
  });
  taskBtn.addEventListener("click", openTaskSystem);
  dailyTaskTab.addEventListener("click", () => setTaskTab("daily"));
  weeklyTaskTab.addEventListener("click", () => setTaskTab("weekly"));
  achievementTaskTab.addEventListener("click", () =>
    setTaskTab("achievements")
  );
  document.getElementById("taskCloseBtn").addEventListener("click", () => {
    taskOverlay.classList.remove("show");
  });
  taskOverlay.addEventListener("click", event => {
    if (event.target === taskOverlay) {
      taskOverlay.classList.remove("show");
    }
  });
  mailBtn.addEventListener("click", openMail);
  document.getElementById("mailCloseBtn").addEventListener("click", () => {
    mailOverlay.classList.remove("show");
  });
  mailOverlay.addEventListener("click", event => {
    if (event.target === mailOverlay) {
      mailOverlay.classList.remove("show");
    }
  });
  backpackBtn.addEventListener("click", () => {
    renderBackpack();
    backpackOverlay.classList.add("show");
    recordDailyAction("backpack_opened");
  });
  document.getElementById("backpackCloseBtn").addEventListener("click", () => {
    backpackOverlay.classList.remove("show");
  });
  backpackOverlay.addEventListener("click", event => {
    if (event.target === backpackOverlay) {
      backpackOverlay.classList.remove("show");
    }
  });
  redemptionBtn.addEventListener("click", openRedemptionDialog);
  document
    .getElementById("redemptionCloseBtn")
    .addEventListener("click", () =>
      redemptionOverlay.classList.remove("show")
    );
  document
    .getElementById("redemptionCancelBtn")
    .addEventListener("click", () =>
      redemptionOverlay.classList.remove("show")
    );
  redemptionSubmitBtn.addEventListener("click", redeemCode);
  redemptionCodeInput.addEventListener("keydown", event => {
    if (event.key === "Enter") {
      event.preventDefault();
      redeemCode();
    }
  });
  redemptionOverlay.addEventListener("click", event => {
    if (event.target === redemptionOverlay) {
      redemptionOverlay.classList.remove("show");
    }
  });
  document.getElementById("historyCloseBtn").addEventListener("click", () => {
    historyOverlay.classList.remove("show");
  });
  historyOverlay.addEventListener("click", event => {
    if (event.target === historyOverlay) historyOverlay.classList.remove("show");
  });
  document
    .getElementById("historyGroupCloseBtn")
    .addEventListener("click", closeHistoryGroupPicker);
  document
    .getElementById("historyGroupCancelBtn")
    .addEventListener("click", closeHistoryGroupPicker);
  historyGroupSaveBtn.addEventListener(
    "click",
    saveHistoryGroupAssignment
  );
  historyGroupOverlay.addEventListener("click", event => {
    if (event.target === historyGroupOverlay) {
      closeHistoryGroupPicker();
    }
  });
  monthBtn.addEventListener("click", openMonthView);
  document
    .getElementById("monthPrevBtn")
    .addEventListener("click", () => shiftMonth(-1));
  document
    .getElementById("monthNextBtn")
    .addEventListener("click", () => shiftMonth(1));
  document.getElementById("monthTodayBtn").addEventListener("click", () => {
    monthCursor = new Date(
      new Date().getFullYear(),
      new Date().getMonth(),
      1
    );
    renderMonthView();
  });
  document
    .getElementById("monthCloseBtn")
    .addEventListener("click", closeMonthView);
  checkinBtn.addEventListener("click", checkInToday);
  monthOverlay.addEventListener("click", event => {
    if (event.target === monthOverlay) closeMonthView();
  });
  document
    .getElementById("monthDayCloseBtn")
    .addEventListener("click", closeMonthDayDetail);
  monthDayOverlay.addEventListener("click", event => {
    if (event.target === monthDayOverlay) closeMonthDayDetail();
  });
  versionBtn.addEventListener("click", openChangelog);
  document.getElementById("changelogCloseBtn").addEventListener("click", () => {
    changelogOverlay.classList.remove("show");
  });
  changelogOverlay.addEventListener("click", event => {
    if (event.target === changelogOverlay) changelogOverlay.classList.remove("show");
  });
  document.getElementById("imageViewerCloseBtn").addEventListener("click", () => {
    imageViewerOverlay.classList.remove("show");
  });
  imageViewerOverlay.addEventListener("click", event => {
    if (event.target === imageViewerOverlay) imageViewerOverlay.classList.remove("show");
  });
  window.addEventListener("resize", () => {
    if (monthOverlay.classList.contains("show")) {
      renderMonthView();
    }
  });

  document.getElementById("addBtn").addEventListener("click", () => {
    if (activePage === "notes") {
      openNoteEditor();
    } else if (activePage === "groups") {
      openGroupEditor();
    } else if (activePage === "friends") {
      openAddFriendDialog();
    } else {
      openEditor();
    }
  });
  const friendCryptoKeyCache = new Map();
  let friendLastDiscoveryAt = 0;
  const PWA_FRIEND_STATE_KEY = "buaa_pwa_friend_state_v1";
  let pwaFriendIdentityPromise = null;
  const friendRelayPullTimes = new Map();

  function readPwaFriendState() {
    const parsed = parseJsonValue(
      localStorage.getItem(PWA_FRIEND_STATE_KEY),
      null
    );
    const state =
      parsed && typeof parsed === "object" && !Array.isArray(parsed)
        ? parsed
        : {};
    for (const key of ["incoming", "outgoing", "friends", "inbox"]) {
      if (!Array.isArray(state[key])) state[key] = [];
    }
    return state;
  }

  function writePwaFriendState(state) {
    localStorage.setItem(PWA_FRIEND_STATE_KEY, JSON.stringify(state));
    return true;
  }

  function upsertPwaFriend(friend) {
    const state = readPwaFriendState();
    state.friends = state.friends.filter(item => item.id !== friend.id);
    state.friends.push(friend);
    writePwaFriendState(state);
  }

  function createPwaFriendBridge() {
    return {
      getFriendState() {
        return JSON.stringify(readPwaFriendState());
      },
      discoverFriendPeers() {
        return "[]";
      },
      saveFriend(value) {
        const friend = parseJsonValue(value, null);
        if (!friend?.id) return false;
        const state = readPwaFriendState();
        if (
          !isDeveloperUser() &&
          !state.friends.some(item => item.id === friend.id) &&
          state.friends.length >= FRIEND_LIMIT
        ) {
          return false;
        }
        upsertPwaFriend(friend);
        return true;
      },
      removeFriend(friendId) {
        const state = readPwaFriendState();
        state.friends = state.friends.filter(item => item.id !== friendId);
        writePwaFriendState(state);
        return true;
      },
      addOutgoingFriendRequest(value) {
        const request = parseJsonValue(value, null);
        if (!request?.request_id) return false;
        const state = readPwaFriendState();
        state.outgoing = state.outgoing.filter(
          item => item.request_id !== request.request_id
        );
        state.outgoing.push(request);
        writePwaFriendState(state);
        return true;
      },
      removeOutgoingFriendRequest(requestId) {
        const state = readPwaFriendState();
        state.outgoing = state.outgoing.filter(
          item => item.request_id !== requestId
        );
        writePwaFriendState(state);
        return true;
      },
      acknowledgeFriendRequest(requestId) {
        const state = readPwaFriendState();
        state.incoming = state.incoming.filter(
          item => item.request_id !== requestId
        );
        writePwaFriendState(state);
        return true;
      },
      acknowledgeFriendInbox(idsJson) {
        const ids = new Set(parseJsonValue(idsJson, []));
        const state = readPwaFriendState();
        state.inbox = state.inbox.filter(
          item => !ids.has(item.event_id)
        );
        writePwaFriendState(state);
        return true;
      },
    };
  }

  async function ensurePwaRelayIdentity() {
    if (!isPwaRelayClient) return;
    if (!pwaFriendIdentityPromise) {
      pwaFriendIdentityPromise = (async () => {
        const state = readPwaFriendState();
        if (!state.pairing_code || !state.friend_secret) {
          const bytes = crypto.getRandomValues(new Uint8Array(12));
          state.pairing_code = Array.from(bytes)
            .map(value => String(value % 10))
            .join("");
          state.friend_secret = randomBytesBase64(32);
          state.device_id =
            `PWA-${String(state.pairing_code).slice(-4)}`;
          state.device_name = "BUAA浮光 iOS PWA";
        }
        if (!state.friend_code) {
          const key = await crypto.subtle.importKey(
            "raw",
            new TextEncoder().encode(state.friend_secret),
            { name: "HMAC", hash: "SHA-256" },
            false,
            ["sign"]
          );
          const signature = await crypto.subtle.sign(
            "HMAC",
            key,
            new TextEncoder().encode(
              `BUAA-FRIEND-V1|${state.pairing_code}`
            )
          );
          const hex = Array.from(new Uint8Array(signature).slice(0, 6))
            .map(value => value.toString(16).padStart(2, "0").toUpperCase())
            .join("");
          state.friend_code =
            `BF-${hex.slice(0, 4)}-${hex.slice(4, 8)}-${hex.slice(8, 12)}`;
        }
        writePwaFriendState(state);
      })();
    }
    await pwaFriendIdentityPromise;
  }

  function friendFeatureAvailable() {
    return Boolean(
      (friendBridge?.getFriendState || friendBridge?.getFriendStateAsync) &&
      (friendBridge?.discoverFriendPeers ||
        friendBridge?.discoverFriendPeersAsync) &&
      friendBridge?.saveFriend &&
      friendBridge?.removeFriend
    );
  }

  function parseJsonValue(value, fallback) {
    try {
      return typeof value === "string" ? JSON.parse(value) : value;
    } catch {
      return fallback;
    }
  }

  function friendRandomId() {
    return (
      crypto.randomUUID?.() ||
      `friend-${Date.now()}-${Math.random().toString(16).slice(2)}`
    );
  }

  function accountNicknameValue() {
    return String(localStorage.getItem(ACCOUNT_NICKNAME_KEY) || "").trim();
  }

  function friendDisplayName() {
    return (
      accountNicknameValue() ||
      String(friendRuntime.device_name || "").trim() ||
      currentUserRole()
    );
  }

  function renderAccountNickname() {
    if (accountNickname) {
      accountNickname.textContent =
        accountNicknameValue() || currentUserRole();
    }
    applyUserIdentity();
  }

  function glowWalletData() {
    const parsed = parseJsonValue(
      localStorage.getItem(GLOW_SPOTS_STORAGE_KEY),
      null
    );
    const balance = Math.max(
      0,
      Math.floor(Number(parsed?.balance) || 0)
    );
    return {
      balance,
      updated_at: parsed?.updated_at || null,
      history: Array.isArray(parsed?.history)
        ? parsed.history.slice(0, 200)
        : [],
    };
  }

  function renderGlowBalance() {
    if (!glowBalance) return;
    glowBalance.textContent = glowWalletData().balance.toLocaleString(
      "zh-CN"
    );
  }

  function glowPeriodForDate(date = new Date()) {
    const hour = date.getHours();
    if (hour >= 5 && hour < 11) {
      return {
        key: "dawn",
        label: "清晨 · 橙色光点",
      };
    }
    if (hour >= 11 && hour < 16) {
      return {
        key: "noon",
        label: "正午 · 白色光点",
      };
    }
    if (hour >= 16 && hour < 20) {
      return {
        key: "dusk",
        label: "黄昏 · 粉色光点",
      };
    }
    return {
      key: "night",
      label: "夜间 · 暖黄色光点",
    };
  }

  function updateGlowPeriod() {
    const period = glowPeriodForDate(new Date());
    if (glowWallet) glowWallet.dataset.period = period.key;
    if (glowPeriodLabel) glowPeriodLabel.textContent = period.label;
  }

  function adjustGlowSpots(delta, reason = "系统调整") {
    const wallet = glowWalletData();
    const amount = Math.trunc(Number(delta) || 0);
    const previousBalance = wallet.balance;
    const nextBalance = Math.max(0, wallet.balance + amount);
    const actualDelta = nextBalance - wallet.balance;
    if (!actualDelta) return wallet.balance;
    const now = new Date().toISOString();
    wallet.balance = nextBalance;
    wallet.updated_at = now;
    wallet.history.unshift({
      delta: actualDelta,
      balance_after: nextBalance,
      reason: String(reason || "系统调整"),
      created_at: now,
    });
    wallet.history = wallet.history.slice(0, 200);
    try {
      localStorage.setItem(
        GLOW_SPOTS_STORAGE_KEY,
        JSON.stringify(wallet)
      );
    } catch {
      showToast("光斑余额保存失败");
      return previousBalance;
    }
    renderGlowBalance();
    return nextBalance;
  }

  function experienceRequiredForNextLevel(level) {
    const safeLevel = Math.max(
      1,
      Math.min(EXPERIENCE_MAX_LEVEL - 1, Math.floor(Number(level) || 1))
    );
    if (safeLevel < 10) {
      return 80 + (safeLevel - 1) * 45;
    }
    if (safeLevel < 20) {
      return 620 + (safeLevel - 10) * 180;
    }
    if (safeLevel < 30) {
      return 2600 + (safeLevel - 20) * 330;
    }
    if (safeLevel < 40) {
      return 6200 + (safeLevel - 30) * 620;
    }
    return 13000 + (safeLevel - 40) * 1100;
  }

  function experienceTotalForLevel(targetLevel) {
    let total = 0;
    for (
      let level = 1;
      level < Math.min(EXPERIENCE_MAX_LEVEL, targetLevel);
      level += 1
    ) {
      total += experienceRequiredForNextLevel(level);
    }
    return total;
  }

  function experienceLevelState(totalXp) {
    const maximum = experienceTotalForLevel(EXPERIENCE_MAX_LEVEL);
    let remaining = Math.max(
      0,
      Math.min(maximum, Math.floor(Number(totalXp) || 0))
    );
    let level = 1;
    while (level < EXPERIENCE_MAX_LEVEL) {
      const needed = experienceRequiredForNextLevel(level);
      if (remaining < needed) break;
      remaining -= needed;
      level += 1;
    }
    if (level >= EXPERIENCE_MAX_LEVEL) {
      return {
        level: EXPERIENCE_MAX_LEVEL,
        current: 0,
        needed: 0,
        totalXp: maximum,
        maximum,
        isMax: true,
      };
    }
    return {
      level,
      current: remaining,
      needed: experienceRequiredForNextLevel(level),
      totalXp: Math.max(0, Math.min(maximum, Math.floor(Number(totalXp) || 0))),
      maximum,
      isMax: false,
    };
  }

  function experienceData() {
    const parsed = parseJsonValue(
      localStorage.getItem(EXPERIENCE_STORAGE_KEY),
      null
    );
    const maximum = experienceTotalForLevel(EXPERIENCE_MAX_LEVEL);
    return {
      total_xp: Math.max(
        0,
        Math.min(maximum, Math.floor(Number(parsed?.total_xp) || 0))
      ),
      maximum,
      updated_at: parsed?.updated_at || null,
      history: Array.isArray(parsed?.history)
        ? parsed.history.slice(0, 200)
        : [],
    };
  }

  function renderExperience() {
    const data = experienceData();
    const state = experienceLevelState(data.total_xp);
    if (experienceLevelValue) {
      experienceLevelValue.textContent = String(state.level);
    }
    if (experienceLevelLabel) {
      experienceLevelLabel.textContent = `${state.level} 级`;
    }
    experienceCard?.classList.toggle("max-level", state.isMax);
    if (experienceFill) {
      experienceFill.style.width = state.isMax
        ? "100%"
        : `${Math.max(
            0,
            Math.min(100, (state.current / state.needed) * 100)
          )}%`;
    }
    if (experienceTrack) {
      experienceTrack.setAttribute(
        "aria-valuemax",
        String(state.isMax ? 100 : state.needed)
      );
      experienceTrack.setAttribute(
        "aria-valuenow",
        String(state.isMax ? 100 : state.current)
      );
    }
    if (experienceNumbers) {
      experienceNumbers.textContent = state.isMax
        ? `累计 ${state.totalXp.toLocaleString("zh-CN")} 经验 · 已满级`
        : `${state.current.toLocaleString("zh-CN")} / ${state.needed.toLocaleString("zh-CN")} 经验`;
    }
    if (experienceHint) {
      experienceHint.textContent = state.isMax
        ? "已达到 50 级上限"
        : state.level < 10
          ? "前 10 级升级较快"
          : "升级所需经验逐级增加";
    }
  }

  function renderExperienceGuide() {
    if (!experienceLevelTableBody) return;
    const state = experienceLevelState(experienceData().total_xp);
    experienceLevelTableBody.replaceChildren();
    for (
      let level = 1;
      level <= EXPERIENCE_MAX_LEVEL;
      level += 1
    ) {
      const row = document.createElement("tr");
      if (level === state.level) row.className = "current-level";
      const levelCell = document.createElement("td");
      levelCell.textContent = `${level} 级${level === state.level ? " · 当前" : ""}`;
      const nextCell = document.createElement("td");
      nextCell.textContent =
        level >= EXPERIENCE_MAX_LEVEL
          ? "已封顶"
          : `${experienceRequiredForNextLevel(level).toLocaleString("zh-CN")} 经验`;
      const totalCell = document.createElement("td");
      totalCell.textContent = experienceTotalForLevel(level).toLocaleString(
        "zh-CN"
      );
      row.append(levelCell, nextCell, totalCell);
      experienceLevelTableBody.appendChild(row);
    }
  }

  function openExperienceGuide() {
    renderExperienceGuide();
    experienceInfoOverlay?.classList.add("show");
    const currentRow = experienceLevelTableBody?.querySelector(
      ".current-level"
    );
    currentRow?.scrollIntoView({ block: "center" });
  }

  function adjustExperience(delta, reason = "系统调整") {
    const data = experienceData();
    const amount = Math.trunc(Number(delta) || 0);
    const previousTotal = data.total_xp;
    const nextTotal = Math.max(
      0,
      Math.min(data.maximum, previousTotal + amount)
    );
    const actualDelta = nextTotal - previousTotal;
    if (!actualDelta) {
      renderExperience();
      return experienceLevelState(previousTotal);
    }
    const now = new Date().toISOString();
    data.total_xp = nextTotal;
    data.updated_at = now;
    data.history.unshift({
      delta: actualDelta,
      total_after: nextTotal,
      reason: String(reason || "系统调整"),
      created_at: now,
    });
    data.history = data.history.slice(0, 200);
    try {
      localStorage.setItem(
        EXPERIENCE_STORAGE_KEY,
        JSON.stringify(data)
      );
    } catch {
      showToast("经验保存失败");
      return experienceLevelState(previousTotal);
    }
    renderExperience();
    return experienceLevelState(nextTotal);
  }

  function taskDayKey(date = new Date()) {
    const pad = value => String(value).padStart(2, "0");
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(
      date.getDate()
    )}`;
  }

  function taskWeekKey(date = new Date()) {
    const start = new Date(date);
    const mondayOffset = (start.getDay() + 6) % 7;
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - mondayOffset);
    return taskDayKey(start);
  }

  function taskState() {
    const parsed = parseJsonValue(
      localStorage.getItem(TASK_STATE_STORAGE_KEY),
      null
    );
    const today = taskDayKey();
    const thisWeek = taskWeekKey();
    const state =
      parsed && typeof parsed === "object" ? parsed : {};
    if (
      !state.daily ||
      state.daily.date !== today ||
      typeof state.daily.counters !== "object"
    ) {
      state.daily = {
        date: today,
        counters: {},
        claimed: {},
      };
    }
    if (!state.daily.claimed || typeof state.daily.claimed !== "object") {
      state.daily.claimed = {};
    }
    if (
      !state.weekly ||
      state.weekly.week_start !== thisWeek ||
      typeof state.weekly.counters !== "object"
    ) {
      state.weekly = {
        week_start: thisWeek,
        counters: {},
        claimed: {},
      };
    }
    if (!state.weekly.claimed || typeof state.weekly.claimed !== "object") {
      state.weekly.claimed = {};
    }
    if (
      !state.achievements ||
      typeof state.achievements.claimed !== "object"
    ) {
      state.achievements = { claimed: {} };
    }
    return state;
  }

  function saveTaskState(state) {
    try {
      localStorage.setItem(
        TASK_STATE_STORAGE_KEY,
        JSON.stringify(state)
      );
      return true;
    } catch {
      showToast("任务进度保存失败");
      return false;
    }
  }

  function sentGiftCount() {
    const chats = loadFriendChats();
    let count = 0;
    for (const list of Object.values(chats)) {
      if (!Array.isArray(list)) continue;
      count += list.filter(
        message =>
          message.direction === "me" && message.kind === "gift"
      ).length;
    }
    return count;
  }

  const DAILY_TASKS = Object.freeze([
    {
      id: "daily-new-memo",
      title: "写下一条新记录",
      description: "新建 1 个事项",
      target: 1,
      counter: "memo_created",
      spots: 2,
      xp: 10,
    },
    {
      id: "daily-complete-task",
      title: "完成一件事",
      description: "完成 1 个任务型事项",
      target: 1,
      counter: "task_completed",
      spots: 3,
      xp: 20,
    },
    {
      id: "daily-save-group",
      title: "整理一下",
      description: "新建或编辑 1 个分组",
      target: 1,
      counter: "group_saved",
      spots: 2,
      xp: 10,
    },
    {
      id: "daily-view-history",
      title: "回望浮光",
      description: "查看 1 次历史事项",
      target: 1,
      counter: "history_opened",
      spots: 1,
      xp: 5,
    },
    {
      id: "daily-check-storage",
      title: "整理行囊",
      description: "分别查看 1 次邮件和背包",
      target: 2,
      progress: state =>
        Number(state.daily.counters.mail_opened > 0) +
        Number(state.daily.counters.backpack_opened > 0),
      spots: 1,
      xp: 5,
    },
    {
      id: "daily-edit-memo",
      title: "完善一条记录",
      description: "编辑 1 个已有事项",
      target: 1,
      counter: "memo_edited",
      spots: 2,
      xp: 10,
    },
    {
      id: "daily-pin-memo",
      title: "聚焦重点",
      description: "置顶或取消置顶 1 个事项",
      target: 1,
      counter: "memo_pin_changed",
      spots: 2,
      xp: 10,
    },
    {
      id: "daily-reminder",
      title: "提前安排",
      description: "保存 1 次默认提前提醒设置",
      target: 1,
      counter: "reminder_saved",
      spots: 2,
      xp: 10,
    },
    {
      id: "daily-month-view",
      title: "纵览本月",
      description: "打开 1 次月视图",
      target: 1,
      counter: "month_view_opened",
      spots: 1,
      xp: 5,
    },
    {
      id: "daily-checkin",
      title: "今日签到",
      description: "完成 1 次每日签到",
      target: 1,
      counter: "checkin",
      spots: 3,
      xp: 20,
    },
    {
      id: "daily-note-create",
      title: "记下一段浮光",
      description: "新建 1 篇日记或笔记",
      target: 1,
      counter: "note_created",
      spots: 3,
      xp: 15,
    },
    {
      id: "daily-note-edit",
      title: "继续完善札记",
      description: "编辑 1 篇已有日记或笔记",
      target: 1,
      counter: "note_edited",
      spots: 2,
      xp: 10,
    },
  ]);

  const WEEKLY_TASKS = Object.freeze([
    {
      id: "weekly-create-five",
      title: "一周记录者",
      description: "本周累计新建 5 个事项",
      target: 5,
      progress: (state, counters) => Number(counters.memo_created || 0),
      spots: 12,
      xp: 100,
    },
    {
      id: "weekly-complete-five",
      title: "本周执行者",
      description: "本周累计完成 5 个任务型事项",
      target: 5,
      progress: (state, counters) => Number(counters.task_completed || 0),
      spots: 20,
      xp: 180,
    },
    {
      id: "weekly-organize-three",
      title: "整理成册",
      description: "本周累计保存 3 次分组",
      target: 3,
      progress: (state, counters) => Number(counters.group_saved || 0),
      spots: 10,
      xp: 80,
    },
    {
      id: "weekly-review-three",
      title: "温故知新",
      description: "本周累计查看 3 次历史事项",
      target: 3,
      progress: (state, counters) => Number(counters.history_opened || 0),
      spots: 8,
      xp: 60,
    },
    {
      id: "weekly-reminder-three",
      title: "时刻有数",
      description: "本周累计保存 3 次提醒设置",
      target: 3,
      progress: (state, counters) => Number(counters.reminder_saved || 0),
      spots: 10,
      xp: 80,
    },
    {
      id: "weekly-focus-three",
      title: "周度焦点",
      description: "本周累计置顶或取消置顶 3 次",
      target: 3,
      progress: (state, counters) => Number(counters.memo_pin_changed || 0),
      spots: 8,
      xp: 60,
    },
    {
      id: "weekly-gift-two",
      title: "心意双至",
      description: "本周累计寄出 2 份好友赠礼",
      target: 2,
      progress: (state, counters) => Number(counters.gift_sent || 0),
      spots: 18,
      xp: 150,
    },
    {
      id: "weekly-claim-two",
      title: "收下两份祝福",
      description: "本周累计从邮件领取 2 件物品",
      target: 2,
      progress: (state, counters) => Number(counters.mail_claimed || 0),
      spots: 12,
      xp: 100,
    },
    {
      id: "weekly-friend-one",
      title: "新的同行者",
      description: "本周新增 1 位好友",
      target: 1,
      progress: (state, counters) => Number(counters.friend_added || 0),
      spots: 15,
      xp: 120,
    },
    {
      id: "weekly-checkin-three",
      title: "本周常来",
      description: "本周累计签到 3 天",
      target: 3,
      progress: (state, counters) => Number(counters.checkin || 0),
      spots: 15,
      xp: 120,
    },
    {
      id: "weekly-note-five",
      title: "一周札记",
      description: "本周累计新建 5 篇日记或笔记",
      target: 5,
      progress: (state, counters) => Number(counters.note_created || 0),
      spots: 18,
      xp: 150,
    },
    {
      id: "weekly-note-edit-three",
      title: "反复打磨",
      description: "本周累计编辑 3 篇已有札记",
      target: 3,
      progress: (state, counters) => Number(counters.note_edited || 0),
      spots: 12,
      xp: 100,
    },
  ]);

  const ACHIEVEMENT_TASKS = Object.freeze([
    {
      id: "achievement-first-memo",
      title: "浮光初记",
      description: "创建第一个事项",
      target: 1,
      progress: () => memoRecords().length,
      spots: 5,
      xp: 25,
    },
    {
      id: "achievement-complete-five",
      title: "说到做到",
      description: "累计完成 5 个任务型事项",
      target: 5,
      progress: () =>
        memoRecords().filter(
          memo => !isEvent(memo) && isCompleted(memo)
        ).length,
      spots: 15,
      xp: 80,
    },
    {
      id: "achievement-three-groups",
      title: "井井有条",
      description: "累计创建 3 个分组",
      target: 3,
      progress: () => groupRecords().length,
      spots: 10,
      xp: 50,
    },
    {
      id: "achievement-first-pin",
      title: "放在眼前",
      description: "累计置顶 1 个事项",
      target: 1,
      progress: () =>
        records.filter(
          record =>
            !record.deleted &&
            !isGroupRecord(record) &&
            !isNoteRecord(record) &&
            record.pinned
        ).length,
      spots: 3,
      xp: 15,
    },
    {
      id: "achievement-first-friend",
      title: "同游浮光",
      description: "添加第一个好友",
      target: 1,
      progress: () => (friendRuntime.friends || []).length,
      spots: 10,
      xp: 50,
    },
    {
      id: "achievement-first-gift",
      title: "寄出心意",
      description: "累计寄出 1 份好友赠礼",
      target: 1,
      progress: sentGiftCount,
      spots: 10,
      xp: 50,
    },
    {
      id: "achievement-first-claim",
      title: "收下祝福",
      description: "累计从邮件领取 1 件物品",
      target: 1,
      progress: () =>
        loadMails().filter(mail => mail.claimed_at).length,
      spots: 8,
      xp: 40,
    },
    {
      id: "achievement-checkin-first",
      title: "第一束晨光",
      description: "累计签到 1 天",
      target: 1,
      progress: () => Object.keys(loadCheckins()).length,
      spots: 8,
      xp: 40,
    },
    {
      id: "achievement-checkin-seven",
      title: "七日不缺席",
      description: "累计签到 7 天",
      target: 7,
      progress: () => Object.keys(loadCheckins()).length,
      spots: 25,
      xp: 180,
    },
    {
      id: "achievement-note-first",
      title: "第一篇札记",
      description: "累计创建 1 篇日记或笔记",
      target: 1,
      progress: () => noteRecords().length,
      spots: 8,
      xp: 40,
    },
    {
      id: "achievement-note-ten",
      title: "十页浮光",
      description: "累计创建 10 篇日记或笔记",
      target: 10,
      progress: () => noteRecords().length,
      spots: 25,
      xp: 180,
    },
  ]);

  function allTaskDefinitions() {
    return [...DAILY_TASKS, ...WEEKLY_TASKS, ...ACHIEVEMENT_TASKS];
  }

  function taskProgress(definition, state) {
    const counters = WEEKLY_TASKS.includes(definition)
      ? state.weekly.counters
      : state.daily.counters;
    const value =
      typeof definition.progress === "function"
        ? definition.progress(state, counters)
        : Number(counters[definition.counter] || 0);
    return Math.max(0, Math.min(definition.target, Number(value) || 0));
  }

  function taskClaimed(definition, state) {
    if (DAILY_TASKS.includes(definition)) {
      return Boolean(state.daily.claimed[definition.id]);
    }
    if (WEEKLY_TASKS.includes(definition)) {
      return Boolean(state.weekly.claimed[definition.id]);
    }
    return Boolean(state.achievements.claimed[definition.id]);
  }

  function taskReady(definition, state) {
    return (
      !taskClaimed(definition, state) &&
      taskProgress(definition, state) >= definition.target
    );
  }

  function taskRewardText(definition) {
    return `+${definition.spots} 光斑 · +${definition.xp} 经验`;
  }

  function claimableTaskCount() {
    const state = taskState();
    return allTaskDefinitions().filter(definition =>
      taskReady(definition, state)
    ).length;
  }

  function renderTaskButton() {
    if (!taskBtn) return;
    taskBtn.textContent = cachedClaimableTaskCount
      ? `任务 · ${cachedClaimableTaskCount}`
      : "任务";
    taskBtn.title = cachedClaimableTaskCount
      ? `${cachedClaimableTaskCount} 项任务奖励可领取`
      : "查看每日、每周和成就任务";
  }

  function refreshTaskBadge(immediate = false) {
    if (!immediate) {
      window.clearTimeout(taskBadgeRefreshTimer);
      taskBadgeRefreshTimer = window.setTimeout(() => {
        taskBadgeRefreshTimer = 0;
        cachedClaimableTaskCount = claimableTaskCount();
        renderTaskButton();
      }, 220);
      return;
    }
    window.clearTimeout(taskBadgeRefreshTimer);
    taskBadgeRefreshTimer = 0;
    cachedClaimableTaskCount = claimableTaskCount();
    renderTaskButton();
  }

  function setTaskTab(tab) {
    activeTaskTab =
      tab === "achievements"
        ? "achievements"
        : tab === "weekly"
          ? "weekly"
          : "daily";
    dailyTaskTab.classList.toggle(
      "active",
      activeTaskTab === "daily"
    );
    weeklyTaskTab.classList.toggle(
      "active",
      activeTaskTab === "weekly"
    );
    achievementTaskTab.classList.toggle(
      "active",
      activeTaskTab === "achievements"
    );
    renderTasks();
  }

  function renderTasks() {
    if (!taskList || !taskSummary) return;
    const state = taskState();
    const definitions =
      activeTaskTab === "achievements"
        ? ACHIEVEMENT_TASKS
        : activeTaskTab === "weekly"
          ? WEEKLY_TASKS
          : DAILY_TASKS;
    const dailyCompleted = DAILY_TASKS.filter(
      definition => taskProgress(definition, state) >= definition.target
    ).length;
    const achievementCompleted = ACHIEVEMENT_TASKS.filter(
      definition => taskProgress(definition, state) >= definition.target
    ).length;
    const weeklyCompleted = WEEKLY_TASKS.filter(
      definition => taskProgress(definition, state) >= definition.target
    ).length;
    const claimable = allTaskDefinitions().filter(definition =>
      taskReady(definition, state)
    ).length;
    const summaryTitle = document.createElement("strong");
    summaryTitle.textContent =
      activeTaskTab === "achievements"
        ? "成就任务"
        : activeTaskTab === "weekly"
          ? "本周任务"
          : "今日任务";
    const summaryText = document.createElement("span");
    summaryText.textContent =
      activeTaskTab === "achievements"
        ? `${achievementCompleted} / ${ACHIEVEMENT_TASKS.length} 已完成 · ${claimable} 项可领取`
        : activeTaskTab === "weekly"
          ? `${weeklyCompleted} / ${WEEKLY_TASKS.length} 已完成 · ${claimable} 项可领取`
          : `${dailyCompleted} / ${DAILY_TASKS.length} 已完成 · ${claimable} 项可领取`;
    taskSummary.replaceChildren(summaryTitle, summaryText);
    taskList.replaceChildren();
    for (const definition of definitions) {
      const progress = taskProgress(definition, state);
      const claimed = taskClaimed(definition, state);
      const ready = taskReady(definition, state);
      const card = document.createElement("article");
      card.className = `task-card${ready ? " ready" : ""}${
        claimed ? " claimed" : ""
      }`;
      const head = document.createElement("div");
      head.className = "task-card-head";
      const title = document.createElement("strong");
      title.textContent = definition.title;
      const reward = document.createElement("span");
      reward.className = "task-reward";
      reward.textContent = taskRewardText(definition);
      head.append(title, reward);
      const description = document.createElement("div");
      description.className = "task-description";
      description.textContent = definition.description;
      const track = document.createElement("div");
      track.className = "task-progress-track";
      const fill = document.createElement("div");
      fill.className = "task-progress-fill";
      fill.style.width = `${Math.min(
        100,
        (progress / definition.target) * 100
      )}%`;
      track.appendChild(fill);
      const footer = document.createElement("div");
      footer.className = "task-card-footer";
      const progressText = document.createElement("span");
      progressText.className = "task-progress-text";
      progressText.textContent = `${progress} / ${definition.target}`;
      const claim = document.createElement("button");
      claim.type = "button";
      claim.className = "task-claim";
      claim.disabled = !ready;
      claim.textContent = claimed
        ? "已领取"
        : ready
          ? "领取奖励"
          : "未完成";
      claim.addEventListener("click", () =>
        claimTaskReward(definition.id, claim)
      );
      footer.append(progressText, claim);
      card.append(head, description, track, footer);
      taskList.appendChild(card);
    }
  }

  function openTaskSystem() {
    saveTaskState(taskState());
    refreshTaskBadge(true);
    setTaskTab(activeTaskTab);
    taskOverlay?.classList.add("show");
  }

  function recordDailyAction(counter, amount = 1) {
    if (!counter) return;
    const state = taskState();
    const increment = Math.max(1, Number(amount) || 1);
    state.daily.counters[counter] =
      Number(state.daily.counters[counter] || 0) +
      increment;
    state.weekly.counters[counter] =
      Number(state.weekly.counters[counter] || 0) +
      increment;
    saveTaskState(state);
    refreshTaskBadge();
    if (taskOverlay?.classList.contains("show")) renderTasks();
  }

  function claimTaskReward(taskId, button = null) {
    const definition = allTaskDefinitions().find(
      item => item.id === taskId
    );
    if (!definition) return;
    const state = taskState();
    if (taskClaimed(definition, state)) {
      showToast("这项奖励已经领取");
      return;
    }
    if (taskProgress(definition, state) < definition.target) {
      showToast("任务尚未完成");
      return;
    }
    if (button) button.disabled = true;
    if (DAILY_TASKS.includes(definition)) {
      state.daily.claimed[definition.id] =
        new Date().toISOString();
    } else if (WEEKLY_TASKS.includes(definition)) {
      state.weekly.claimed[definition.id] =
        new Date().toISOString();
    } else {
      state.achievements.claimed[definition.id] =
        new Date().toISOString();
    }
    saveTaskState(state);
    adjustGlowSpots(
      definition.spots,
      `任务奖励：${definition.title}`
    );
    adjustExperience(
      definition.xp,
      `任务奖励：${definition.title}`
    );
    renderTasks();
    refreshTaskBadge(true);
    showToast(
      `已领取 ${definition.spots} 光斑和 ${definition.xp} 经验`
    );
  }

  function openNicknameEditor() {
    if (!nicknameOverlay || !nicknameInput) return;
    nicknameInput.value = accountNicknameValue();
    nicknameOverlay.classList.add("show");
    window.setTimeout(() => nicknameInput.focus(), 80);
  }

  async function saveAccountNickname() {
    const nickname = String(nicknameInput?.value || "")
      .trim()
      .slice(0, 20);
    if (nickname) {
      localStorage.setItem(ACCOUNT_NICKNAME_KEY, nickname);
    } else {
      localStorage.removeItem(ACCOUNT_NICKNAME_KEY);
    }
    renderAccountNickname();
    recordDailyAction("profile_updated");
    nicknameOverlay?.classList.remove("show");
    showToast(nickname ? `昵称已设为「${nickname}」` : "已使用默认昵称");
    if (!friendRuntime.friend_code) return;
    const profileName =
      nickname || friendRuntime.device_name || currentUserRole();
    for (const friend of friendRuntime.friends || []) {
      await queueFriendEvent(friend, "profile", {
        profile_name: profileName,
      });
    }
  }

  function redemptionAttemptState() {
    return parseJsonValue(
      localStorage.getItem(REDEMPTION_ATTEMPTS_KEY),
      {}
    ) || {};
  }

  function openRedemptionDialog() {
    if (!redemptionOverlay) return;
    redemptionCodeInput.value = "";
    redemptionStatus.textContent = isDeveloperUser()
      ? "当前设备已经是开发者身份。"
      : "";
    redemptionStatus.style.color = "#58758a";
    redemptionOverlay.classList.add("show");
    window.setTimeout(() => redemptionCodeInput?.focus(), 80);
  }

  async function redeemCode() {
    const normalized = normalizeBetaKey(redemptionCodeInput?.value || "");
    if (normalized.length !== 20) {
      redemptionStatus.textContent = "请输入完整的 20 位兑换码。";
      redemptionStatus.style.color = "#a15432";
      return;
    }
    const attempts = redemptionAttemptState();
    if (Number(attempts.blockedUntil || 0) > Date.now()) {
      const seconds = Math.ceil(
        (Number(attempts.blockedUntil) - Date.now()) / 1000
      );
      redemptionStatus.textContent =
        `尝试次数过多，请 ${seconds} 秒后再试。`;
      redemptionStatus.style.color = "#a15432";
      return;
    }
    redemptionSubmitBtn.disabled = true;
    redemptionSubmitBtn.textContent = "正在兑换…";
    redemptionStatus.textContent = "";
    try {
      const result = await hashBetaKey(normalized);
      const matched = REDEMPTION_CODES.find(entry =>
        result.kind === "sha256"
          ? entry.sha256 === result.hash
          : entry.fallback === result.hash
      );
      if (!matched) {
        const failures = Number(attempts.failures || 0) + 1;
        const blockedUntil =
          failures >= 5 ? Date.now() + 60 * 1000 : 0;
        localStorage.setItem(
          REDEMPTION_ATTEMPTS_KEY,
          JSON.stringify({
            failures: blockedUntil ? 0 : failures,
            blockedUntil,
          })
        );
        redemptionStatus.textContent = blockedUntil
          ? "兑换码无效，尝试次数过多，请 60 秒后再试。"
          : "兑换码无效，请检查后再试。";
        redemptionStatus.style.color = "#a15432";
        return;
      }
      localStorage.setItem(USER_ROLE_KEY, matched.role);
      localStorage.removeItem(REDEMPTION_ATTEMPTS_KEY);
      syncDeveloperModeToNative();
      renderAccountNickname();
      renderFriends();
      redemptionStatus.textContent =
        `兑换成功，当前身份已更新为“${matched.role}”。`;
      redemptionStatus.style.color = "#176b4d";
      showToast(`兑换成功：${matched.role}`);
      window.setTimeout(() => {
        redemptionOverlay?.classList.remove("show");
      }, 900);
    } catch {
      redemptionStatus.textContent = "兑换失败，请稍后重试。";
      redemptionStatus.style.color = "#a15432";
    } finally {
      redemptionSubmitBtn.disabled = false;
      redemptionSubmitBtn.textContent = "兑换";
    }
  }

  async function applyFriendProfile(friendId, profileName) {
    const friend = friendById(friendId);
    if (!friend) return false;
    const name = String(profileName || "").trim().slice(0, 20);
    if (!name || name === friend.name) return true;
    const updated = { ...friend, name };
    friendBridge.saveFriend(JSON.stringify(updated));
    const index = friendRuntime.friends.findIndex(
      item => String(item.id || "") === String(friendId)
    );
    if (index >= 0) friendRuntime.friends[index] = updated;
    return true;
  }

  function randomBytesBase64(length = 32) {
    const bytes = crypto.getRandomValues(new Uint8Array(length));
    let binary = "";
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary)
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/g, "");
  }

  function bytesToBase64(bytes) {
    let binary = "";
    const view = new Uint8Array(bytes);
    for (const byte of view) binary += String.fromCharCode(byte);
    return btoa(binary);
  }

  function base64ToBytes(value) {
    const binary = atob(String(value || ""));
    return Uint8Array.from(binary, character => character.charCodeAt(0));
  }

  function normalizeFriendCode(value) {
    const compact = String(value || "")
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, "");
    if (!compact.startsWith("BF") || compact.length !== 14) return "";
    return `BF-${compact.slice(2, 6)}-${compact.slice(6, 10)}-${compact.slice(
      10,
      14
    )}`;
  }

  function normalizeFriendAddress(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    try {
      const parsed = new URL(
        /^https?:\/\//i.test(raw) ? raw : `http://${raw}`
      );
      if (parsed.protocol !== "http:" || !parsed.hostname) return "";
      const port = Number(parsed.port || 8790);
      if (!Number.isInteger(port) || port < 1 || port > 65535) return "";
      return `${parsed.hostname}:${port}`;
    } catch {
      return "";
    }
  }

  function friendById(friendId) {
    return (friendRuntime.friends || []).find(
      friend => String(friend.id || "") === String(friendId || "")
    );
  }

  function friendLimitReached() {
    return (
      !isDeveloperUser() &&
      (friendRuntime.friends || []).length >= FRIEND_LIMIT
    );
  }

  function loadMails() {
    const parsed = parseJsonValue(
      localStorage.getItem(MAIL_STORAGE_KEY),
      []
    );
    return Array.isArray(parsed) ? parsed : [];
  }

  function saveMails(mails) {
    try {
      localStorage.setItem(MAIL_STORAGE_KEY, JSON.stringify(mails));
      return true;
    } catch {
      return false;
    }
  }

  function loadBackpackItems() {
    const parsed = parseJsonValue(
      localStorage.getItem(BACKPACK_STORAGE_KEY),
      []
    );
    return Array.isArray(parsed) ? parsed : [];
  }

  function saveBackpackItems(items) {
    try {
      localStorage.setItem(
        BACKPACK_STORAGE_KEY,
        JSON.stringify(items)
      );
      return true;
    } catch {
      return false;
    }
  }

  function mailBadgeCounts() {
    const mails = loadMails();
    return {
      unread: mails.filter(mail => !mail.read_at).length,
      unclaimed: mails.filter(
        mail => mail.item && !mail.claimed_at
      ).length,
    };
  }

  function renderMailButton() {
    if (!mailBtn) return;
    const counts = mailBadgeCounts();
    mailBtn.textContent = counts.unread
      ? `邮件 ${counts.unread}`
      : counts.unclaimed
        ? "邮件 · 待领取"
        : "邮件";
  }

  function receiveGiftMail(friend, gift, eventId, createdAt) {
    const mails = loadMails();
    if (mails.some(mail => mail.event_id === eventId)) {
      return true;
    }
    const sourceItem =
      gift?.item && typeof gift.item === "object" ? gift.item : {};
    const item = {
      item_key: String(
        sourceItem.item_key ||
        gift?.card_type ||
        "fuguang-card"
      ),
      name: String(
        sourceItem.name ||
        gift?.name ||
        "浮光心意卡"
      ),
      description: String(
        sourceItem.description ||
        "好友通过浮光赠礼邮件寄来的心意纪念。"
      ),
    };
    const mail = {
      id:
        crypto.randomUUID?.() ||
        `mail-${Date.now()}-${Math.random().toString(16).slice(2)}`,
      event_id: String(eventId || friendRandomId()),
      from_id: String(friend?.id || ""),
      from_name: String(friend?.name || "好友"),
      subject: `${friend?.name || "好友"}寄来了一封赠礼邮件`,
      body:
        String(gift?.message || "").trim() ||
        "愿这束浮光陪你走过今天。",
      item,
      created_at: Number(createdAt || Date.now()),
      read_at: null,
      claimed_at: null,
    };
    mails.unshift(mail);
    if (!saveMails(mails)) return false;
    renderMailButton();
    if (mailOverlay?.classList.contains("show")) renderMail();
    return true;
  }

  function renderBackpack() {
    if (!backpackGrid) return;
    const items = loadBackpackItems();
    if (backpackCount) {
      backpackCount.textContent = `${items.length} 件物品`;
    }
    backpackGrid.replaceChildren();
    if (!items.length) {
      for (let index = 0; index < 6; index += 1) {
        const slot = document.createElement("div");
        slot.className = "backpack-slot";
        const mark = document.createElement("span");
        mark.textContent = "＋";
        slot.append(mark, document.createTextNode("待领取"));
        backpackGrid.appendChild(slot);
      }
      if (backpackEmptyNote) backpackEmptyNote.hidden = false;
      return;
    }
    if (backpackEmptyNote) backpackEmptyNote.hidden = true;
    for (const item of items.slice().reverse()) {
      const card = document.createElement("div");
      card.className = "backpack-slot has-item";
      const mark = document.createElement("span");
      mark.textContent = "✦";
      const name = document.createElement("strong");
      name.textContent = item.name || "未命名物品";
      const detail = document.createElement("small");
      detail.textContent = item.description || "来自好友的赠礼";
      card.append(mark, name, detail);
      backpackGrid.appendChild(card);
    }
  }

  function renderMail() {
    if (!mailList) return;
    const mails = loadMails().sort(
      (left, right) =>
        Number(right.created_at || 0) - Number(left.created_at || 0)
    );
    mailList.replaceChildren();
    if (!mails.length) {
      const empty = document.createElement("div");
      empty.className = "mail-empty";
      empty.textContent =
        "还没有邮件。好友寄来的赠礼会出现在这里。";
      mailList.appendChild(empty);
      return;
    }
    for (const mail of mails) {
      const card = document.createElement("article");
      card.className = `mail-card${mail.read_at ? "" : " unread"}`;
      const head = document.createElement("div");
      head.className = "mail-head";
      const subject = document.createElement("strong");
      subject.textContent = mail.subject || "好友赠礼";
      const time = document.createElement("time");
      time.textContent = new Date(
        mail.created_at || Date.now()
      ).toLocaleString("zh-CN");
      head.append(subject, time);
      const sender = document.createElement("div");
      sender.className = "mail-sender";
      sender.textContent = `发件人：${mail.from_name || "好友"}`;
      const body = document.createElement("div");
      body.className = "mail-body";
      body.textContent = mail.body || "愿这束浮光陪你走过今天。";
      card.append(head, sender, body);
      if (mail.item) {
        const item = document.createElement("div");
        item.className = "mail-item";
        const icon = document.createElement("div");
        icon.className = "mail-item-icon";
        icon.textContent = "✦";
        const info = document.createElement("div");
        const name = document.createElement("strong");
        name.textContent = mail.item.name || "浮光心意卡";
        const detail = document.createElement("small");
        detail.textContent =
          mail.item.description || "领取后会放入背包";
        info.append(name, detail);
        item.append(icon, info);
        card.appendChild(item);
        const actions = document.createElement("div");
        actions.className = "mail-actions";
        const claim = document.createElement("button");
        claim.type = "button";
        claim.className = "mail-claim-btn";
        claim.textContent = mail.claimed_at ? "已领取至背包" : "领取物品";
        claim.disabled = Boolean(mail.claimed_at);
        claim.addEventListener("click", () =>
          claimMailItem(mail.id, claim)
        );
        actions.appendChild(claim);
        card.appendChild(actions);
      }
      mailList.appendChild(card);
    }
  }

  function openMail() {
    const now = new Date().toISOString();
    const mails = loadMails().map(mail =>
      mail.read_at ? mail : { ...mail, read_at: now }
    );
    saveMails(mails);
    renderMailButton();
    renderMail();
    mailOverlay?.classList.add("show");
    recordDailyAction("mail_opened");
  }

  function claimMailItem(mailId, button = null) {
    const mails = loadMails();
    const mail = mails.find(item => item.id === mailId);
    if (!mail?.item) {
      showToast("这封邮件没有可领取的物品");
      return;
    }
    if (mail.claimed_at) {
      showToast("这件物品已经领取过");
      if (button) button.disabled = true;
      return;
    }
    const items = loadBackpackItems();
    if (
      !items.some(
        item => item.source_mail_id === mail.id
      )
    ) {
      items.push({
        id:
          crypto.randomUUID?.() ||
          `item-${Date.now()}-${Math.random().toString(16).slice(2)}`,
        item_key: mail.item.item_key || "fuguang-card",
        name: mail.item.name || "浮光心意卡",
        description:
          mail.item.description || "来自好友的赠礼",
        source_mail_id: mail.id,
        source_friend: mail.from_name || "好友",
        acquired_at: new Date().toISOString(),
      });
      if (!saveBackpackItems(items)) {
        showToast("领取失败，本机存储空间可能不足");
        return;
      }
    }
    mail.claimed_at = new Date().toISOString();
    if (!saveMails(mails)) {
      showToast("物品已放入背包，但邮件状态保存失败");
    }
    renderMail();
    renderBackpack();
    renderMailButton();
    recordDailyAction("mail_claimed");
    showToast("物品已领取并放入背包");
  }

  function loadFriendChats() {
    const parsed = parseJsonValue(
      localStorage.getItem(FRIEND_CHAT_KEY),
      {}
    );
    return parsed && typeof parsed === "object" && !Array.isArray(parsed)
      ? parsed
      : {};
  }

  function saveFriendChats(chats) {
    localStorage.setItem(FRIEND_CHAT_KEY, JSON.stringify(chats));
  }

  function appendFriendChat(friendId, entry) {
    const chats = loadFriendChats();
    const list = Array.isArray(chats[friendId]) ? chats[friendId] : [];
    if (
      entry.event_id &&
      list.some(item => item.event_id === entry.event_id)
    ) {
      return false;
    }
    list.push(entry);
    chats[friendId] = list.slice(-500);
    saveFriendChats(chats);
    return true;
  }

  async function ensureFriendCryptoIdentity() {
    let stored = parseJsonValue(
      localStorage.getItem(FRIEND_IDENTITY_KEY),
      null
    );
    if (stored?.privateKey && stored?.publicKey) return stored;
    if (!crypto?.subtle) {
      throw new Error("当前设备不支持好友加密");
    }
    const pair = await crypto.subtle.generateKey(
      { name: "ECDH", namedCurve: "P-256" },
      true,
      ["deriveBits"]
    );
    stored = {
      privateKey: await crypto.subtle.exportKey("jwk", pair.privateKey),
      publicKey: await crypto.subtle.exportKey("jwk", pair.publicKey),
      created_at: new Date().toISOString(),
    };
    localStorage.setItem(FRIEND_IDENTITY_KEY, JSON.stringify(stored));
    return stored;
  }

  async function deriveFriendKey(friend) {
    const cacheKey = `${friend.id}|${friend.public_key || ""}`;
    const cached = friendCryptoKeyCache.get(cacheKey);
    if (cached) return cached;
    const identity = await ensureFriendCryptoIdentity();
    const peerPublicKey = parseJsonValue(friend.public_key, null);
    if (!peerPublicKey?.kty) {
      throw new Error("好友加密身份不完整，请重新添加好友");
    }
    const ownPrivate = await crypto.subtle.importKey(
      "jwk",
      identity.privateKey,
      { name: "ECDH", namedCurve: "P-256" },
      false,
      ["deriveBits"]
    );
    const peerPublic = await crypto.subtle.importKey(
      "jwk",
      peerPublicKey,
      { name: "ECDH", namedCurve: "P-256" },
      false,
      []
    );
    const shared = await crypto.subtle.deriveBits(
      { name: "ECDH", public: peerPublic },
      ownPrivate,
      256
    );
    const material = await crypto.subtle.importKey(
      "raw",
      shared,
      "HKDF",
      false,
      ["deriveKey"]
    );
    const friendIds = [friendRuntime.friend_code, friend.id]
      .map(String)
      .sort()
      .join("|");
    const key = await crypto.subtle.deriveKey(
      {
        name: "HKDF",
        hash: "SHA-256",
        salt: new TextEncoder().encode("BUAA-FRIEND-E2EE-V1"),
        info: new TextEncoder().encode(friendIds),
      },
      material,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );
    friendCryptoKeyCache.set(cacheKey, key);
    return key;
  }

  async function encryptFriendPayload(friend, payload, eventId) {
    const key = await deriveFriendKey(friend);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encoded = new TextEncoder().encode(JSON.stringify(payload));
    const ciphertext = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      key,
      encoded
    );
    return {
      version: 1,
      algorithm: "A256GCM",
      event_id: eventId,
      iv: bytesToBase64(iv),
      ciphertext: bytesToBase64(ciphertext),
      created_at: Date.now(),
    };
  }

  async function decryptFriendPayload(friend, envelope) {
    if (
      !envelope ||
      envelope.version !== 1 ||
      !envelope.iv ||
      !envelope.ciphertext
    ) {
      throw new Error("好友消息格式不正确");
    }
    const key = await deriveFriendKey(friend);
    const plaintext = await crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv: base64ToBytes(envelope.iv),
      },
      key,
      base64ToBytes(envelope.ciphertext)
    );
    return JSON.parse(new TextDecoder().decode(plaintext));
  }

  async function postFriendJson(
    address,
    path,
    payload,
    headers = {},
    timeoutMs = 6500
  ) {
    const normalized = normalizeFriendAddress(address);
    if (!normalized) throw new Error("好友地址无效");
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(`http://${normalized}${path}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...headers,
        },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });
      const result = parseJsonValue(await response.text(), {});
      if (!response.ok || result?.ok === false) {
        throw new Error(result?.error || `好友连接失败（${response.status}）`);
      }
      return result || {};
    } finally {
      window.clearTimeout(timer);
    }
  }

  async function probeFriendAddress(friend) {
    const address = normalizeFriendAddress(friend.address);
    if (!address) return false;
    try {
      const controller = new AbortController();
      const timer = window.setTimeout(() => controller.abort(), 1400);
      try {
        const response = await fetch(`http://${address}/friend/info`, {
          signal: controller.signal,
        });
        if (!response.ok) return false;
        const info = await response.json();
        return info?.friend_code === friend.id;
      } finally {
        window.clearTimeout(timer);
      }
    } catch {
      return false;
    }
  }

  function requestFriendPeerDiscovery() {
    if (friendBridge?.discoverFriendPeersAsync) {
      return friendBridge.discoverFriendPeersAsync();
    }
    if (!friendBridge?.startFriendDiscovery) {
      return Promise.resolve(friendBridge?.discoverFriendPeers?.() || "[]");
    }
    if (friendPeerDiscoveryPromise) return friendPeerDiscoveryPromise;
    const requestId = ++friendPeerDiscoveryRequestId;
    friendPeerDiscoveryPromise = new Promise(resolve => {
      const finish = payload => {
        if (requestId !== friendPeerDiscoveryRequestId) return;
        window.clearTimeout(friendPeerDiscoveryTimer);
        friendPeerDiscoveryTimer = 0;
        friendPeerDiscoveryPromise = null;
        resolve(payload || "[]");
      };
      window.BUAANativeAndroidFriendPeersResult = finish;
      friendPeerDiscoveryTimer = window.setTimeout(
        () => finish("[]"),
        5000
      );
      try {
        friendBridge.startFriendDiscovery();
      } catch {
        finish("[]");
      }
    });
    return friendPeerDiscoveryPromise;
  }

  async function refreshFriendOnline(force = false) {
    if (!friendFeatureAvailable()) return;
    if (!force && Date.now() - friendLastDiscoveryAt < 5000) return;
    friendLastDiscoveryAt = Date.now();
    let peers = [];
    try {
      const peerPayload = await requestFriendPeerDiscovery();
      peers = parseJsonValue(peerPayload, []);
    } catch {
      peers = [];
    }
    friendPeers = new Map();
    for (const peer of Array.isArray(peers) ? peers : []) {
      const friendCode = String(peer.friend_code || "");
      if (!friendCode) continue;
      friendPeers.set(friendCode, {
        online: true,
        address: `${peer.ip}:${peer.port}`,
        device_name: peer.device_name || "",
      });
    }
    const unresolved = (friendRuntime.friends || []).filter(
      friend => !friendPeers.has(String(friend.id || ""))
    );
    await Promise.all(
      unresolved.slice(0, 12).map(async friend => {
        if (await probeFriendAddress(friend)) {
          friendPeers.set(String(friend.id), {
            online: true,
            address: normalizeFriendAddress(friend.address),
            device_name: friend.name || "",
          });
        }
      })
    );
    friendDiscoveryStatus.textContent = friendPeers.size
      ? `发现 ${friendPeers.size} 位在线好友`
      : "暂未发现在线好友";
    renderFriends();
  }

  async function pollPwaFriendRequests() {
    if (!isPwaRelayClient) return;
    const state = readPwaFriendState();
    const outgoing = Array.isArray(state.outgoing) ? state.outgoing : [];
    let changed = false;
    for (const request of outgoing) {
      if (request.transport !== "poll" || !request.address) continue;
      try {
        const result = await postFriendJson(
          request.address,
          "/friend/request-status",
          {
            request_id: request.request_id,
            from_id: state.friend_code,
            token: request.token,
          }
        );
        if (result.status !== "approved") continue;
        const friend = {
          id: request.target_id,
          name: result.device_name || request.target_name || "好友",
          token: request.token,
          public_key: result.public_key,
          address: request.address,
          transport: "poll",
          accepted_at: Date.now(),
        };
        state.friends = (state.friends || []).filter(
          item => item.id !== friend.id
        );
        state.friends.push(friend);
        state.outgoing = state.outgoing.filter(
          item => item.request_id !== request.request_id
        );
        changed = true;
      } catch {}
    }
    if (changed) writePwaFriendState(state);
  }

  async function refreshFriendState(silent = false) {
    if (isPwaRelayClient) {
      await ensurePwaRelayIdentity();
      await pollPwaFriendRequests();
    }
    if (!friendFeatureAvailable()) {
      if (myFriendCode) myFriendCode.textContent = "需 Android / iOS App";
      if (friendDiscoveryStatus) {
        friendDiscoveryStatus.textContent = "好友功能需在 Android 或 iOS App 内使用";
      }
      renderFriends();
      return;
    }
    try {
      const statePayload = friendBridge.getFriendStateAsync
        ? await friendBridge.getFriendStateAsync()
        : friendBridge.getFriendState();
      const state = parseJsonValue(statePayload, {});
      friendRuntime = {
        friend_code: String(state.friend_code || ""),
        device_id: String(state.device_id || ""),
        device_name: String(state.device_name || "BUAA浮光"),
        ip: String(state.ip || ""),
        port: Number(state.port || 0),
        incoming: Array.isArray(state.incoming) ? state.incoming : [],
        outgoing: Array.isArray(state.outgoing) ? state.outgoing : [],
        friends: Array.isArray(state.friends) ? state.friends : [],
        inbox: Array.isArray(state.inbox) ? state.inbox : [],
      };
      renderAccountNickname();
      if (myFriendCode) {
        myFriendCode.textContent = friendRuntime.friend_code || "读取失败";
      }
      await processFriendInbox();
      await pullRelayMessages();
      if (friendUiIsActive()) renderFriends();
      if (!silent) await refreshFriendOnline(true);
    } catch (error) {
      if (!silent) showToast(error?.message || "好友状态读取失败");
    }
  }

  function friendUiIsActive() {
    return (
      activePage === "friends" ||
      Boolean(friendsCenterOverlay?.classList.contains("show"))
    );
  }

  function scheduleFriendPoll(delay = null) {
    if (!friendFeatureAvailable()) return;
    if (friendPollTimer) window.clearTimeout(friendPollTimer);
    const nextDelay =
      delay === null
        ? document.hidden
          ? FRIEND_IDLE_POLL_INTERVAL
          : friendUiIsActive()
            ? FRIEND_ACTIVE_POLL_INTERVAL
            : FRIEND_IDLE_POLL_INTERVAL
        : Math.max(0, Number(delay) || 0);
    friendPollTimer = window.setTimeout(async () => {
      if (document.hidden || friendPollRunning) {
        scheduleFriendPoll();
        return;
      }
      friendPollRunning = true;
      try {
        await refreshFriendState(true);
        await flushPendingFriendMessages();
      } finally {
        friendPollRunning = false;
        scheduleFriendPoll();
      }
    }, nextDelay);
  }

  function scheduleFriendDiscovery(delay = null) {
    if (!friendFeatureAvailable()) return;
    if (friendDiscoveryTimer) window.clearTimeout(friendDiscoveryTimer);
    const nextDelay =
      delay === null
        ? FRIEND_DISCOVERY_INTERVAL
        : Math.max(0, Number(delay) || 0);
    friendDiscoveryTimer = window.setTimeout(async () => {
      friendDiscoveryTimer = null;
      if (document.hidden || !friendUiIsActive()) return;
      try {
        await refreshFriendOnline(true);
      } finally {
        if (friendUiIsActive() && !document.hidden) {
          scheduleFriendDiscovery();
        }
      }
    }, nextDelay);
  }

  async function processFriendInbox() {
    const inbox = Array.isArray(friendRuntime.inbox)
      ? friendRuntime.inbox
      : [];
    if (!inbox.length || !friendBridge?.acknowledgeFriendInbox) return;
    const acknowledged = [];
    for (const item of inbox) {
      const friend = friendById(item.sender_id);
      if (!friend) continue;
      try {
        const payload = await decryptFriendPayload(friend, item.envelope);
        if (payload.kind === "profile") {
          await applyFriendProfile(
            friend.id,
            payload.profile_name || ""
          );
          acknowledged.push(item.event_id);
          continue;
        }
        const eventId =
          item.event_id ||
          item.envelope?.event_id ||
          friendRandomId();
        const giftMail =
          payload.kind === "gift"
            ? receiveGiftMail(
                friend,
                payload.gift,
                eventId,
                payload.created_at || item.created_at
              )
            : true;
        if (!giftMail) {
          throw new Error("邮件保存失败");
        }
        const added = appendFriendChat(friend.id, {
          event_id: eventId,
          direction: "them",
          kind:
            payload.kind === "memo"
              ? "memo"
              : payload.kind === "gift"
                ? "mail"
                : "text",
          text:
            payload.kind === "gift"
              ? `收到一封赠礼邮件：${
                  payload.gift?.name || "浮光心意卡"
                }。请到“我的 → 邮件”中领取。`
              : String(payload.text || ""),
          memo: payload.memo || null,
          gift: null,
          created_at: Number(payload.created_at || item.created_at || Date.now()),
          status: "received",
        });
        if (added) {
          acknowledged.push(item.event_id);
        } else {
          acknowledged.push(item.event_id);
        }
      } catch {
        // Keep undecryptable messages so a corrected friend key can retry later.
      }
    }
    if (acknowledged.length) {
      friendBridge.acknowledgeFriendInbox(JSON.stringify(acknowledged));
      friendRuntime.inbox = inbox.filter(
        item => !acknowledged.includes(item.event_id)
      );
      renderFriendChatIfOpen();
    }
  }

  async function pullRelayMessages() {
    if (!friendFeatureAvailable()) return;
    for (const friend of friendRuntime.friends || []) {
      const address = normalizeFriendAddress(friend.address);
      if (!address) {
        continue;
      }
      const relayKey = String(friend.id || "");
      const lastPull = friendRelayPullTimes.get(relayKey) || 0;
      const isOnline =
        friendPeers.has(relayKey) || friend.transport === "poll";
      if (
        !isOnline &&
        Date.now() - lastPull < FRIEND_OFFLINE_RELAY_RETRY
      ) {
        continue;
      }
      friendRelayPullTimes.set(relayKey, Date.now());
      try {
        const result = await postFriendJson(
          address,
          "/friend/relay-pull",
          {},
          {
            "X-Friend-Id": friendRuntime.friend_code,
            "X-Friend-Token": friend.token,
          },
          1600
        );
        const messages = Array.isArray(result.messages)
          ? result.messages
          : [];
        if (!messages.length) continue;
        const acknowledged = [];
        for (const item of messages) {
          try {
            const payload = await decryptFriendPayload(
              friend,
              item.envelope
            );
            if (payload.kind === "profile") {
              await applyFriendProfile(
                friend.id,
                payload.profile_name || ""
              );
              acknowledged.push(
                item.event_id || item.envelope?.event_id
              );
              continue;
            }
            const eventId =
              item.event_id ||
              item.envelope?.event_id ||
              friendRandomId();
            const giftMail =
              payload.kind === "gift"
                ? receiveGiftMail(
                    friend,
                    payload.gift,
                    eventId,
                    payload.created_at || item.created_at
                  )
                : true;
            if (!giftMail) {
              throw new Error("邮件保存失败");
            }
            appendFriendChat(friend.id, {
              event_id: eventId,
              direction: "them",
              kind:
                payload.kind === "memo"
                  ? "memo"
                  : payload.kind === "gift"
                    ? "mail"
                    : "text",
              text:
                payload.kind === "gift"
                  ? `收到一封赠礼邮件：${
                      payload.gift?.name || "浮光心意卡"
                    }。请到“我的 → 邮件”中领取。`
                  : String(payload.text || ""),
              memo: payload.memo || null,
              gift: null,
              created_at: Number(
                payload.created_at || item.created_at || Date.now()
              ),
              status: "received",
            });
            acknowledged.push(eventId);
          } catch {}
        }
        if (acknowledged.length) {
          await postFriendJson(
            address,
            "/friend/relay-ack",
            { event_ids: acknowledged },
            {
              "X-Friend-Id": friendRuntime.friend_code,
              "X-Friend-Token": friend.token,
            },
            1600
          );
          renderFriendChatIfOpen();
        }
      } catch {}
    }
  }

  function friendButton(label, className, handler) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = label;
    if (className) button.className = className;
    button.addEventListener("click", handler);
    return button;
  }

  function renderFriends() {
    if (!friendCount || !friendRequestCount || !friendList) return;
    if (!friendFeatureAvailable()) {
      friendCount.textContent = currentUserRole();
      friendRequestCount.textContent = "0 条";
      friendRequestList.replaceChildren();
      friendList.replaceChildren();
      const empty = document.createElement("div");
      empty.className = "friend-note";
      empty.textContent = "Android 与 iOS 已接入好友协议；电脑版暂不启用好友入口。";
      friendList.appendChild(empty);
      return;
    }

    const friends = friendRuntime.friends || [];
    const incoming = friendRuntime.incoming || [];
    friendCount.textContent = isDeveloperUser()
      ? `${friends.length} 位好友 · 无上限`
      : `${friends.length} / ${FRIEND_LIMIT} 位好友`;
    const atLimit = friendLimitReached();
    addFriendBtn.disabled = atLimit;
    addFriendBtn.textContent = atLimit
      ? `好友已达 ${FRIEND_LIMIT} 人`
      : "＋ 添加好友";
    addFriendBtn.title = atLimit
      ? `普通用户最多添加 ${FRIEND_LIMIT} 位好友`
      : "";
    friendRequestCount.textContent = `${incoming.length} 条`;

    friendRequestList.replaceChildren();
    if (!incoming.length) {
      const empty = document.createElement("div");
      empty.className = "friend-note";
      empty.textContent = "暂无新的好友请求";
      friendRequestList.appendChild(empty);
    } else {
      for (const request of incoming) {
        const card = document.createElement("article");
        card.className = "friend-card friend-request-card";
        const info = document.createElement("div");
        const title = document.createElement("strong");
        title.textContent = request.from_name || "新好友";
        const detail = document.createElement("small");
        detail.textContent = `${request.from_id || ""} · ${request.address || ""}`;
        info.append(title, detail);
        const actions = document.createElement("div");
        actions.className = "friend-actions";
        actions.append(
          friendButton("拒绝", "danger", () => rejectFriendRequest(request)),
          friendButton("接受", "primary", () => acceptFriendRequest(request))
        );
        card.append(info, actions);
        friendRequestList.appendChild(card);
      }
    }

    friendList.replaceChildren();
    if (!friends.length) {
      const empty = document.createElement("div");
      empty.className = "friend-note";
      empty.textContent = "还没有好友。点击“添加好友”，输入对方好友码。";
      friendList.appendChild(empty);
    } else {
      const sorted = [...friends].sort((left, right) =>
        String(left.name || "").localeCompare(String(right.name || ""), "zh-CN")
      );
      for (const friend of sorted) {
        const peer = friendPeers.get(String(friend.id || ""));
        const card = document.createElement("article");
        card.className = "friend-card";
        const info = document.createElement("div");
        const name = document.createElement("strong");
        name.textContent = friend.name || "好友";
        const detail = document.createElement("small");
        detail.className = peer ? "friend-status-online" : "";
        detail.textContent = peer
          ? `在线 · ${peer.address}`
          : `离线 · ${friend.address || "等待下次同网"}`;
        const code = document.createElement("small");
        code.textContent = friend.id || "";
        info.append(name, detail, code);
        const actions = document.createElement("div");
        actions.className = "friend-actions";
        actions.append(
          friendButton("消息", "primary", () => openFriendChat(friend.id)),
          friendButton("赠送", "", () => openFriendGift(friend.id)),
          friendButton("清空聊天", "", () => clearFriendChat(friend.id)),
          friendButton("删除", "danger", () => deleteFriend(friend.id))
        );
        card.append(info, actions);
        friendList.appendChild(card);
      }
    }
  }

  function openAddFriendDialog() {
    if (!friendFeatureAvailable()) {
      showToast("好友功能目前需要在 Android 或 iOS App 内使用");
      return;
    }
    if (friendLimitReached()) {
      showToast(`普通用户最多添加 ${FRIEND_LIMIT} 位好友`);
      return;
    }
    addFriendStatus.textContent = "";
    friendCodeInput.value = "";
    friendAddressInput.value = "";
    addFriendOverlay.classList.add("show");
    window.setTimeout(() => friendCodeInput?.focus(), 80);
  }

  function openFriendsCenter() {
    friendsCenterOverlay?.classList.add("show");
    scheduleFriendPoll(0);
    scheduleFriendDiscovery(0);
  }

  async function addFriendByCode() {
    if (!friendFeatureAvailable()) {
      showToast("好友功能目前需要在 Android 或 iOS App 内使用");
      return;
    }
    if (friendLimitReached()) {
      addFriendStatus.textContent =
        `普通用户最多添加 ${FRIEND_LIMIT} 位好友，请先删除部分好友。`;
      return;
    }
    const friendCode = normalizeFriendCode(friendCodeInput?.value);
    if (!friendCode || friendCode === friendRuntime.friend_code) {
      addFriendStatus.textContent = "请输入有效且不同于自己的好友码。";
      return;
    }
    if (friendById(friendCode)) {
      addFriendStatus.textContent = "这个人已经是你的好友。";
      return;
    }
    addFriendSubmitBtn.disabled = true;
    addFriendStatus.textContent = "正在发现好友…";
    try {
      await refreshFriendOnline(true);
      let peer = friendPeers.get(friendCode);
      let address = normalizeFriendAddress(friendAddressInput?.value);
      if (!peer && address) {
        try {
          const controller = new AbortController();
          const timer = window.setTimeout(() => controller.abort(), 1600);
          try {
            const response = await fetch(`http://${address}/friend/info`, {
              signal: controller.signal,
            });
            const info = response.ok ? await response.json() : {};
            if (info?.friend_code === friendCode) {
              peer = { online: true, address };
            }
          } finally {
            window.clearTimeout(timer);
          }
        } catch {}
      }
      address = normalizeFriendAddress(peer?.address || address);
      if (!address) {
        throw new Error("没有发现该好友。请确认双方连接同一 Wi-Fi，或填写对方地址。");
      }
      if (
        !isPwaRelayClient &&
        (!friendRuntime.ip || !Number(friendRuntime.port))
      ) {
        throw new Error("本机同步服务尚未启动，请关闭后重新打开浮光。");
      }
      const identity = await ensureFriendCryptoIdentity();
      const requestId = friendRandomId();
      const token = randomBytesBase64(32);
      const ownAddress = isPwaRelayClient
        ? "pwa"
        : `${friendRuntime.ip}:${friendRuntime.port}`;
      const outgoing = {
        request_id: requestId,
        target_id: friendCode,
        target_name: peer?.device_name || friendCode,
        token,
        address,
        transport: isPwaRelayClient ? "poll" : "direct",
        created_at: Date.now(),
      };
      if (
        !friendBridge.addOutgoingFriendRequest(JSON.stringify(outgoing))
      ) {
        throw new Error("无法保存好友请求，请重试");
      }
      await postFriendJson(address, "/friend/request", {
        request_id: requestId,
        from_id: friendRuntime.friend_code,
        from_name: friendDisplayName(),
        token,
        public_key: JSON.stringify(identity.publicKey),
        address: ownAddress,
        transport: isPwaRelayClient ? "poll" : "direct",
        created_at: Date.now(),
      });
      addFriendOverlay.classList.remove("show");
      showToast("好友请求已发送，请等待对方确认");
      await refreshFriendState(true);
    } catch (error) {
      addFriendStatus.textContent = error?.message || "好友请求发送失败";
    } finally {
      addFriendSubmitBtn.disabled = false;
    }
  }

  async function acceptFriendRequest(request) {
    if (friendLimitReached()) {
      showToast(
        `普通用户最多添加 ${FRIEND_LIMIT} 位好友，请先删除部分好友`
      );
      return;
    }
    try {
      if (friendById(request.from_id)) {
        friendBridge.acknowledgeFriendRequest(request.request_id);
        await refreshFriendState(true);
        throw new Error("该好友码已经在好友列表中，请先核对身份");
      }
      const identity = await ensureFriendCryptoIdentity();
      if (!friendRuntime.ip || !friendRuntime.port) {
        throw new Error("本机同步服务尚未启动，请重新打开浮光");
      }
      const friend = {
        id: request.from_id,
        name: request.from_name || "好友",
        token: request.token,
        public_key: request.public_key,
        address: request.transport === "poll" ? "" : request.address,
        transport: request.transport === "poll" ? "poll" : "direct",
        accepted_at: Date.now(),
      };
      if (request.transport === "poll") {
        if (!friendBridge.approveIncomingFriendRequest) {
          throw new Error("当前设备不能接收 PWA 好友请求");
        }
        if (
          !friendBridge.approveIncomingFriendRequest(
            request.request_id,
            JSON.stringify(identity.publicKey)
          )
        ) {
          throw new Error("无法确认 PWA 好友请求");
        }
      } else {
        await postFriendJson(request.address, "/friend/approve", {
          request_id: request.request_id,
          from_id: friendRuntime.friend_code,
          from_name: friendDisplayName(),
          token: request.token,
          public_key: JSON.stringify(identity.publicKey),
          address: `${friendRuntime.ip}:${friendRuntime.port}`,
        });
      }
      if (!friendBridge.saveFriend(JSON.stringify(friend))) {
        throw new Error("好友已确认，但本机保存失败");
      }
      if (request.transport !== "poll") {
        friendBridge.acknowledgeFriendRequest(request.request_id);
      }
      showToast(`已添加 ${friend.name} 为好友`);
      await refreshFriendState(true);
      await refreshFriendOnline(true);
      recordDailyAction("friend_added");
    } catch (error) {
      showToast(error?.message || "好友确认失败，请让对方保持在线后重试");
    }
  }

  async function rejectFriendRequest(request) {
    try {
      await postFriendJson(request.address, "/friend/deny", {
        request_id: request.request_id,
        from_id: friendRuntime.friend_code,
        token: request.token,
      });
    } catch {}
    friendBridge.acknowledgeFriendRequest(request.request_id);
    await refreshFriendState(true);
    showToast("已拒绝好友请求");
  }

  function openFriendChat(friendId) {
    const friend = friendById(friendId);
    if (!friend) {
      showToast("好友不存在或已被删除");
      return;
    }
    activeFriendId = friend.id;
    friendChatTitle.textContent = friend.name || "好友消息";
    friendChatStatus.textContent = "";
    friendChatOverlay.classList.add("show");
    renderFriendChat();
    window.setTimeout(() => friendChatInput?.focus(), 80);
  }

  function openFriendGift(friendId) {
    const friend = friendById(friendId);
    if (!friend) {
      showToast("好友不存在或已被删除");
      return;
    }
    activeGiftFriendId = friend.id;
    friendGiftFriendTitle.textContent =
      `赠送给：${friend.name || "好友"}`;
    friendGiftType.value = "fuguang-card";
    friendGiftMessage.value = "";
    friendGiftStatus.textContent = friendPeers.has(String(friend.id))
      ? "好友当前在线，赠礼邮件将立即尝试投递。"
      : "好友当前离线，赠礼邮件会保存在本机待发队列。";
    friendGiftOverlay.classList.add("show");
    window.setTimeout(() => friendGiftMessage.focus(), 80);
  }

  async function sendFriendGift() {
    const friend = friendById(activeGiftFriendId);
    if (!friend) {
      friendGiftOverlay.classList.remove("show");
      showToast("好友不存在或已被删除");
      return;
    }
    const option = friendGiftType.selectedOptions?.[0];
    const message = String(friendGiftMessage.value || "")
      .trim()
      .slice(0, 200);
    friendGiftSendBtn.disabled = true;
    friendGiftSendBtn.textContent = "正在发送…";
    try {
      await queueFriendEvent(friend, "gift", {
        gift: {
          card_type: friendGiftType.value || "fuguang-card",
          name: option?.textContent || "浮光心意卡",
          message,
          item: {
            item_key: friendGiftType.value || "fuguang-card",
            name: option?.textContent || "浮光心意卡",
            description: "好友通过浮光赠礼邮件寄来的心意纪念。",
          },
          sent_at: Date.now(),
        },
      });
      recordDailyAction("gift_sent");
      friendGiftOverlay.classList.remove("show");
      activeGiftFriendId = "";
      showToast(
        friendPeers.has(String(friend.id))
          ? "赠礼邮件已发送"
          : "好友离线，赠礼邮件已保存在待发队列"
      );
    } catch (error) {
      friendGiftStatus.textContent =
        error?.message || "赠礼发送失败，请稍后重试。";
    } finally {
      friendGiftSendBtn.disabled = false;
      friendGiftSendBtn.textContent = "发送赠礼";
    }
  }

  function saveSharedMemo(memo, shareId, button) {
    if (!memo?.title || !memo?.deadline) return;
    if (
      records.some(
        record =>
          record.friend_share_id === shareId &&
          !record.deleted
      )
    ) {
      showToast("这个事项已经保存过");
      if (button) button.textContent = "已保存";
      return;
    }
    const now = new Date().toISOString();
    records.push({
      id: crypto.randomUUID?.() || `m-${Date.now()}`,
      title: memo.title,
      note: memo.note || "",
      location: memo.location || "",
      pinned: false,
      item_type: memo.item_type === "event" ? "event" : "task",
      start_at: memo.start_at || memo.deadline,
      deadline: memo.deadline,
      group_id: null,
      completed: false,
      completed_at: null,
      reminder_enabled: false,
      reminder_minutes: 15,
      reminder_modes: [],
      reminder_volume: 100,
      reminder_at: null,
      image_data: null,
      image: null,
      friend_share_id: shareId,
      created_at: now,
      updated_at: now,
      rev: nextRevision(),
      deleted: false,
    });
    persist();
    render();
    syncNow(false);
    if (button) {
      button.textContent = "已保存";
      button.disabled = true;
    }
    showToast("好友分享的事项已保存到本机");
  }

  function renderFriendChat() {
    if (!friendChatList) return;
    const friend = friendById(activeFriendId);
    friendChatList.replaceChildren();
    if (!friend) {
      const empty = document.createElement("div");
      empty.className = "friend-note";
      empty.textContent = "好友不存在或已被删除。";
      friendChatList.appendChild(empty);
      return;
    }
    friendChatTitle.textContent = friend.name || "好友消息";
    const chats = loadFriendChats();
    const messages = Array.isArray(chats[friend.id]) ? chats[friend.id] : [];
    if (!messages.length) {
      const empty = document.createElement("div");
      empty.className = "friend-note";
      empty.textContent = "还没有消息。好友离线时发送的消息会保存在本机待发队列。";
      friendChatList.appendChild(empty);
      return;
    }
    for (const message of messages) {
      if (message.kind === "profile") continue;
      const bubble = document.createElement("div");
      bubble.className = `friend-bubble${
        message.direction === "me" ? " me" : ""
      }${message.status === "pending" ? " pending" : ""}${
        message.kind === "gift" ? " gift-message-bubble" : ""
      }`;
      if (message.kind === "gift" && message.gift) {
        const giftCard = document.createElement("div");
        giftCard.className = "friend-gift-card";
        const giftTitle = document.createElement("strong");
        giftTitle.textContent =
          `${
            message.direction === "me"
              ? "赠礼邮件已寄出"
              : "赠礼邮件"
          } · ${message.gift.name || "浮光心意卡"}`;
        const giftMessage = document.createElement("p");
        giftMessage.textContent =
          message.gift.message || "愿这束浮光陪你走过今天。";
        const giftHint = document.createElement("small");
        giftHint.textContent =
          "物品会保存在收件人的“我的 → 邮件”中，领取后进入背包。";
        giftCard.append(giftTitle, giftMessage, giftHint);
        bubble.appendChild(giftCard);
      } else if (message.kind === "memo" && message.memo) {
        const memoCard = document.createElement("div");
        memoCard.className = "friend-memo-card";
        const title = document.createElement("strong");
        title.textContent = message.memo.title || "共享事项";
        const detail = document.createElement("div");
        detail.textContent = [
          message.memo.item_type === "event" ? "事件" : "任务",
          message.memo.deadline
            ? `终止 ${formatDeadline(message.memo.deadline)}`
            : "",
          message.memo.location ? `地点 ${message.memo.location}` : "",
          message.memo.note || "",
        ]
          .filter(Boolean)
          .join(" · ");
        memoCard.append(title, detail);
        if (message.direction === "them") {
          const saveButton = document.createElement("button");
          saveButton.type = "button";
          saveButton.textContent = records.some(
            record =>
              record.friend_share_id === message.event_id &&
              !record.deleted
          )
            ? "已保存"
            : "保存为我的事项";
          saveButton.disabled = saveButton.textContent === "已保存";
          saveButton.addEventListener("click", () =>
            saveSharedMemo(message.memo, message.event_id, saveButton)
          );
          memoCard.appendChild(saveButton);
        }
        bubble.appendChild(memoCard);
      } else {
        bubble.textContent = message.text || "";
      }
      const status = document.createElement("small");
      const deliveryStatus =
        message.status === "pending"
          ? " · 等待对方在线"
          : message.status === "relayed"
            ? " · 已存入 Android 中转"
            : "";
      status.textContent = `${
        message.direction === "me" ? "我" : friend.name || "好友"
      } · ${new Date(message.created_at || Date.now()).toLocaleString(
        "zh-CN"
      )}${deliveryStatus}`;
      bubble.appendChild(status);
      friendChatList.appendChild(bubble);
    }
    friendChatList.scrollTop = friendChatList.scrollHeight;
  }

  function renderFriendChatIfOpen() {
    if (friendChatOverlay?.classList.contains("show")) {
      renderFriendChat();
    }
  }

  async function flushPendingFriendMessages() {
    if (!friendFeatureAvailable()) return;
    const chats = loadFriendChats();
    let changed = false;
    for (const friend of friendRuntime.friends || []) {
      const list = Array.isArray(chats[friend.id]) ? chats[friend.id] : [];
      const peer = friendPeers.get(String(friend.id || ""));
      const address = normalizeFriendAddress(peer?.address || friend.address);
      for (const message of list) {
        if (message.direction !== "me" || message.status !== "pending") {
          continue;
        }
        try {
          const envelope = await encryptFriendPayload(
            friend,
            {
              kind: message.kind,
              text: message.text || "",
              memo: message.memo || null,
              gift: message.gift || null,
              profile_name: message.profile_name || "",
              created_at: message.created_at,
            },
            message.event_id
          );
          if (address) {
            await postFriendJson(
              address,
              "/friend/message",
              envelope,
              {
                "X-Friend-Id": friendRuntime.friend_code,
                "X-Friend-Token": friend.token,
              }
            );
            message.status = "sent";
            changed = true;
          } else {
            throw new Error("好友暂时不在线");
          }
        } catch {
          if (friendBridge.queueFriendRelay) {
            try {
              const envelope = await encryptFriendPayload(
                friend,
                {
                  kind: message.kind,
                  text: message.text || "",
                  memo: message.memo || null,
                  gift: message.gift || null,
                  profile_name: message.profile_name || "",
                  created_at: message.created_at,
                },
                message.event_id
              );
              if (
                friendBridge.queueFriendRelay(
                  friend.id,
                  JSON.stringify(envelope)
                )
              ) {
                message.status = "relayed";
                changed = true;
              }
            } catch {}
          }
        }
      }
    }
    if (changed) {
      saveFriendChats(chats);
      renderFriendChatIfOpen();
    }
  }

  async function queueFriendEvent(friend, kind, payload) {
    const eventId = friendRandomId();
    appendFriendChat(friend.id, {
      event_id: eventId,
      direction: "me",
      kind,
      text: kind === "text" ? payload.text : "",
      memo: kind === "memo" ? payload.memo : null,
      gift: kind === "gift" ? payload.gift : null,
      profile_name: kind === "profile" ? payload.profile_name || "" : "",
      created_at: Date.now(),
      status: "pending",
    });
    renderFriendChatIfOpen();
    await flushPendingFriendMessages();
    if (kind === "text" || kind === "gift") {
      friendChatStatus.textContent = "已加入发送队列";
    }
  }

  function serializeSharedMemo(memo) {
    return {
      title: memo.title || "未命名事项",
      note: memo.note || "",
      location: memo.location || "",
      item_type: memo.item_type === "event" ? "event" : "task",
      start_at: memo.start_at || memo.deadline,
      deadline: memo.deadline,
    };
  }

  function openShareMemo(memoId) {
    const memo = records.find(record => record.id === memoId && !record.deleted);
    if (!memo) return;
    if (!friendFeatureAvailable()) {
      showToast("好友功能目前需要在 Android 或 iOS App 内使用");
      return;
    }
    if (!(friendRuntime.friends || []).length) {
      showToast("请先在“我的”页面添加好友");
      return;
    }
    pendingSharedMemoId = memoId;
    shareMemoStatus.textContent = "";
    shareMemoFriendList.replaceChildren();
    for (const friend of friendRuntime.friends) {
      const card = document.createElement("article");
      card.className = "friend-card";
      const info = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = friend.name || "好友";
      const detail = document.createElement("small");
      detail.textContent = friendPeers.has(String(friend.id))
        ? "在线"
        : "离线，将保存在待发队列";
      info.append(title, detail);
      const actions = document.createElement("div");
      actions.className = "friend-actions";
      actions.appendChild(
        friendButton("分享", "primary", async () => {
          const current = records.find(
            record => record.id === pendingSharedMemoId && !record.deleted
          );
          if (!current) return;
          await queueFriendEvent(friend, "memo", {
            memo: serializeSharedMemo(current),
          });
          shareMemoStatus.textContent = friendPeers.has(String(friend.id))
            ? "事项已发送"
            : "好友离线，事项已保存在本机待发队列";
          showToast("共享事项已加入发送队列");
        })
      );
      card.append(info, actions);
      shareMemoFriendList.appendChild(card);
    }
    shareMemoOverlay.classList.add("show");
  }

  function clearFriendChat(friendId) {
    const friend = friendById(friendId);
    if (!friend) return;
    if (!confirm(`清空与「${friend.name || "好友"}」的聊天记录？`)) return;
    const chats = loadFriendChats();
    delete chats[friend.id];
    saveFriendChats(chats);
    if (activeFriendId === friend.id) renderFriendChatIfOpen();
    showToast("聊天记录已清空");
  }

  async function deleteFriend(friendId) {
    const friend = friendById(friendId);
    if (!friend) return;
    if (
      !confirm(
        `删除好友「${friend.name || "好友"}」？删除后将停止接收对方消息。`
      )
    ) {
      return;
    }
    try {
      await postFriendJson(
        friendPeers.get(String(friend.id))?.address || friend.address,
        "/friend/remove",
        {},
        {
          "X-Friend-Id": friendRuntime.friend_code,
          "X-Friend-Token": friend.token,
        }
      );
    } catch {}
    friendBridge.removeFriend(friend.id);
    const chats = loadFriendChats();
    delete chats[friend.id];
    saveFriendChats(chats);
    for (const cacheKey of [...friendCryptoKeyCache.keys()]) {
      if (cacheKey.startsWith(`${friend.id}|`)) {
        friendCryptoKeyCache.delete(cacheKey);
      }
    }
    if (activeFriendId === friend.id) {
      activeFriendId = "";
      friendChatOverlay.classList.remove("show");
    }
    await refreshFriendState(true);
    showToast("好友已删除");
  }

  addFriendBtn?.addEventListener("click", openAddFriendDialog);
  friendsCenterBtn?.addEventListener("click", openFriendsCenter);
  friendsCenterCloseBtn?.addEventListener("click", () =>
    friendsCenterOverlay?.classList.remove("show")
  );
  friendsCenterOverlay?.addEventListener("click", event => {
    if (event.target === friendsCenterOverlay) {
      friendsCenterOverlay.classList.remove("show");
    }
  });
  editNicknameBtn?.addEventListener("click", openNicknameEditor);
  nicknameCloseBtn?.addEventListener("click", () =>
    nicknameOverlay?.classList.remove("show")
  );
  nicknameCancelBtn?.addEventListener("click", () =>
    nicknameOverlay?.classList.remove("show")
  );
  nicknameSaveBtn?.addEventListener("click", saveAccountNickname);
  nicknameInput?.addEventListener("keydown", event => {
    if (event.key === "Enter") {
      event.preventDefault();
      saveAccountNickname();
    }
  });
  nicknameOverlay?.addEventListener("click", event => {
    if (event.target === nicknameOverlay) {
      nicknameOverlay.classList.remove("show");
    }
  });
  myFriendCode?.addEventListener("click", async () => {
    if (!friendRuntime.friend_code) return;
    try {
      await copyText(friendRuntime.friend_code);
      showToast("好友码已复制");
    } catch {
      showToast("好友码复制失败");
    }
  });
  refreshFriendsBtn?.addEventListener("click", async () => {
    friendDiscoveryStatus.textContent = "正在发现好友…";
    await refreshFriendState(true);
    await refreshFriendOnline(true);
    await flushPendingFriendMessages();
    scheduleFriendDiscovery();
  });
  addFriendCloseBtn?.addEventListener("click", () =>
    addFriendOverlay.classList.remove("show")
  );
  addFriendCancelBtn?.addEventListener("click", () =>
    addFriendOverlay.classList.remove("show")
  );
  addFriendSubmitBtn?.addEventListener("click", addFriendByCode);
  friendCodeInput?.addEventListener("keydown", event => {
    if (event.key === "Enter") {
      event.preventDefault();
      addFriendByCode();
    }
  });
  addFriendOverlay?.addEventListener("click", event => {
    if (event.target === addFriendOverlay) {
      addFriendOverlay.classList.remove("show");
    }
  });
  friendChatCloseBtn?.addEventListener("click", () =>
    friendChatOverlay.classList.remove("show")
  );
  friendChatGiftBtn?.addEventListener("click", () =>
    openFriendGift(activeFriendId)
  );
  friendChatOverlay?.addEventListener("click", event => {
    if (event.target === friendChatOverlay) {
      friendChatOverlay.classList.remove("show");
    }
  });
  document
    .getElementById("friendGiftCloseBtn")
    ?.addEventListener("click", () =>
      friendGiftOverlay.classList.remove("show")
    );
  document
    .getElementById("friendGiftCancelBtn")
    ?.addEventListener("click", () =>
      friendGiftOverlay.classList.remove("show")
    );
  friendGiftSendBtn?.addEventListener("click", sendFriendGift);
  friendGiftOverlay?.addEventListener("click", event => {
    if (event.target === friendGiftOverlay) {
      friendGiftOverlay.classList.remove("show");
    }
  });
  friendChatForm?.addEventListener("submit", async event => {
    event.preventDefault();
    const friend = friendById(activeFriendId);
    const text = String(friendChatInput?.value || "").trim();
    if (!friend || !text) return;
    friendChatInput.value = "";
    await queueFriendEvent(friend, "text", { text: text.slice(0, 2000) });
  });
  shareMemoCloseBtn?.addEventListener("click", () =>
    shareMemoOverlay.classList.remove("show")
  );
  shareMemoOverlay?.addEventListener("click", event => {
    if (event.target === shareMemoOverlay) {
      shareMemoOverlay.classList.remove("show");
    }
  });

  memosTabBtn.addEventListener("click", () => setPage("memos"));
  notesTabBtn.addEventListener("click", () => setPage("notes"));
  groupsTabBtn.addEventListener("click", () => setPage("groups"));
  friendsTabBtn.addEventListener("click", () => setPage("friends"));
  newGroupBtn.addEventListener("click", () => openGroupEditor());
  newNoteBtn.addEventListener("click", () => openNoteEditor());
  diaryTypeBtn.addEventListener("click", () => setNoteEditorType("diary"));
  noteTypeBtn.addEventListener("click", () => setNoteEditorType("note"));
  document
    .getElementById("noteCancelBtn")
    .addEventListener("click", closeNoteEditor);
  noteEditorOverlay.addEventListener("click", event => {
    if (event.target === noteEditorOverlay) closeNoteEditor();
  });
  noteWritingBackBtn.addEventListener("click", () => {
    convertDollarLatexInEditor();
    noteDraftBody = noteEditorPlainText();
    noteDraftHtml = serializeNoteEditorHtml();
    noteWritingOverlay.classList.remove("show");
    noteEntryTitle.focus();
  });
  noteViewCloseBtn?.addEventListener("click", closeNoteView);
  noteViewEditBtn?.addEventListener("click", editViewedNote);
  noteViewOverlay?.addEventListener("click", event => {
    if (event.target === noteViewOverlay) closeNoteView();
  });
  noteWritingSaveBtn.addEventListener("click", saveNoteEntry);
  noteEntryBody.addEventListener("input", () => {
    scheduleNoteCaretVisibility();
    noteDraftBody = noteEditorPlainText();
    noteDraftHtml = serializeNoteEditorHtml();
    noteContentCount.textContent =
      `${noteDraftBody.length} / 10000`;
    if (noteDraftBody.trim()) {
      noteWritingStatus.textContent = "内容不能为空";
      noteWritingStatus.classList.remove("error");
    }
  });
  noteEntryBody.addEventListener("paste", event => {
    event.preventDefault();
    const text = event.clipboardData?.getData("text/plain") || "";
    const html = event.clipboardData?.getData("text/html") || "";
    const formulaCount = insertPastedNoteContent(text, html, true);
    if (formulaCount) {
      showToast(`已识别并转换 ${formulaCount} 个数学公式`);
    }
  });
  noteEntryBody.addEventListener("beforeinput", event => {
    if (
      event.inputType?.startsWith("insert") &&
      noteEditorPlainText().length >= 10000
    ) {
      event.preventDefault();
      showToast("札记内容最多 10000 字");
    }
  });
  noteEntryBody.addEventListener("keydown", event => {
    if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
      event.preventDefault();
      saveNoteEntry();
    }
  });
  noteEntryBody.addEventListener("click", event => {
    scheduleNoteCaretVisibility();
    const formula = event.target.closest?.("[data-note-math]");
    if (formula && noteEntryBody.contains(formula)) {
      noteTapSequence = { count: 0, time: 0, x: 0, y: 0 };
      return;
    }
    const now = Date.now();
    const distance = Math.hypot(
      event.clientX - noteTapSequence.x,
      event.clientY - noteTapSequence.y
    );
    if (event.detail >= 3) {
      noteTapSequence.count = 3;
    } else if (
      now - noteTapSequence.time <= 720 &&
      distance <= 36
    ) {
      noteTapSequence.count += 1;
    } else {
      noteTapSequence.count = 1;
    }
    noteTapSequence.time = now;
    noteTapSequence.x = event.clientX;
    noteTapSequence.y = event.clientY;
    if (noteTapSequence.count < 3) return;
    event.preventDefault();
    noteTapSequence = { count: 0, time: 0, x: 0, y: 0 };
    setNoteCaretFromPoint(event.clientX, event.clientY);
    openNotePasteDialog();
  });
  noteEntryBody.addEventListener("contextmenu", event => {
    const formula = event.target.closest?.("[data-note-math]");
    if (!formula || !noteEntryBody.contains(formula)) return;
    event.preventDefault();
    rememberNoteSelection();
    openNoteMathDialog({
      latex: formula.getAttribute("data-note-math") || "",
      display: formula.getAttribute("data-display") === "block",
      node: formula,
    });
  });
  document.addEventListener("selectionchange", () => {
    if (noteWritingOverlay.classList.contains("show")) {
      rememberNoteSelection();
      scheduleNoteCaretVisibility();
    }
  });
  window.visualViewport?.addEventListener(
    "resize",
    scheduleNoteCaretVisibility,
    { passive: true }
  );
  window.visualViewport?.addEventListener(
    "scroll",
    scheduleNoteCaretVisibility,
    { passive: true }
  );
  window.addEventListener("resize", scheduleNoteCaretVisibility, {
    passive: true,
  });
  notePasteBtn.addEventListener("mousedown", event => {
    event.preventDefault();
    rememberNoteSelection();
  });
  notePasteBtn.addEventListener("click", openNotePasteDialog);
  noteFontBtn.addEventListener("mousedown", event =>
    event.preventDefault()
  );
  noteFontBtn.addEventListener("click", () => {
    noteFontToolbar.hidden = !noteFontToolbar.hidden;
  });
  noteMathBtn.addEventListener("mousedown", event => {
    event.preventDefault();
    rememberNoteSelection();
  });
  noteMathBtn.addEventListener("click", () => openNoteMathDialog());
  noteMathCloseBtn.addEventListener("click", closeNoteMathDialog);
  noteMathOverlay.addEventListener("click", event => {
    if (event.target === noteMathOverlay) closeNoteMathDialog();
  });
  noteMathSymbolsTab.addEventListener("click", () =>
    setNoteMathTab("symbols")
  );
  noteLatexTab.addEventListener("click", () =>
    setNoteMathTab("latex")
  );
  noteLatexQuickbar.addEventListener("click", event => {
    const button = event.target.closest("button[data-latex-snippet]");
    if (!button) return;
    insertLatexQuickSnippet(
      button.dataset.latexSnippet,
      Number(button.dataset.caretBeforeEnd || 0)
    );
  });
  noteLatexInput.addEventListener("input", renderNoteLatexPreview);
  noteLatexDisplayMode.addEventListener(
    "change",
    renderNoteLatexPreview
  );
  noteLatexInsertBtn.addEventListener("click", insertLatexFormula);
  notePasteCancelTopBtn.addEventListener("click", closeNotePasteDialog);
  notePasteCancelBtn.addEventListener("click", closeNotePasteDialog);
  notePasteOverlay.addEventListener("click", event => {
    if (event.target === notePasteOverlay) closeNotePasteDialog();
  });
  notePasteFallbackInput.addEventListener("input", () => {
    const text = notePasteFallbackInput.value;
    pendingPastePayload = { text, html: "" };
    notePastePreview.textContent = text.trim().slice(0, 1400);
    notePastePreview.classList.toggle("empty", !text.trim());
    notePastePlainBtn.disabled = !text.trim();
    notePasteSmartBtn.disabled = !text.trim();
    notePasteStatus.textContent = text.trim()
      ? "内容已读取，请选择粘贴方式。"
      : "请长按输入框并粘贴内容。";
  });
  notePastePlainBtn.addEventListener("click", () => {
    const fallback = !notePasteFallbackInput.hidden;
    const text = fallback
      ? notePasteFallbackInput.value
      : pendingPastePayload.text ||
        clipboardHtmlTextAndFormulas(pendingPastePayload.html).text;
    const html = fallback ? "" : pendingPastePayload.html;
    const count = insertPastedNoteContent(text, html, false);
    closeNotePasteDialog();
    noteEntryBody.focus({ preventScroll: true });
    if (count || text) showToast("已粘贴为纯文本");
  });
  notePasteSmartBtn.addEventListener("click", () => {
    const fallback = !notePasteFallbackInput.hidden;
    const text = fallback
      ? notePasteFallbackInput.value
      : pendingPastePayload.text;
    const html = fallback ? "" : pendingPastePayload.html;
    const count = insertPastedNoteContent(text, html, true);
    closeNotePasteDialog();
    noteEntryBody.focus({ preventScroll: true });
    showToast(
      count
        ? `已智能粘贴并识别 ${count} 个公式`
        : "已智能粘贴到札记"
    );
  });
  noteFontToolbar.addEventListener("mousedown", event => {
    rememberNoteSelection();
    if (event.target.closest("button")) {
      event.preventDefault();
    }
  });
  noteFontColor.addEventListener("pointerdown", rememberNoteSelection);
  noteFontColor.addEventListener("input", () =>
    setNoteFontColor(noteFontColor.value, { apply: true })
  );
  for (const option of document.querySelectorAll(
    ".note-font-option[data-note-family]"
  )) {
    option.addEventListener("click", () =>
      setNoteFontFamily(option.dataset.noteFamily, { apply: true })
    );
  }
  for (const swatch of document.querySelectorAll(
    ".note-color-swatch[data-note-color]"
  )) {
    swatch.addEventListener("click", () =>
      setNoteFontColor(swatch.dataset.noteColor, { apply: true })
    );
  }
  for (const option of document.querySelectorAll(
    ".note-font-option[data-note-weight]"
  )) {
    option.addEventListener("click", () =>
      setNoteFontWeight(option.dataset.noteWeight, { apply: true })
    );
  }
  for (const option of document.querySelectorAll(
    ".note-font-option[data-note-decoration]"
  )) {
    option.addEventListener("click", () =>
      setNoteFontDecoration(option.dataset.noteDecoration, {
        apply: true,
      })
    );
  }
  noteFilter.addEventListener("click", event => {
    const button = event.target.closest("button[data-note-filter]");
    if (!button) return;
    noteFilterType = button.dataset.noteFilter;
    renderNotes();
  });
  groupCancelBtn.addEventListener("click", closeGroupEditor);
  groupOverlay.addEventListener("click", event => {
    if (event.target === groupOverlay) closeGroupEditor();
  });
  groupDetailCloseBtn.addEventListener("click", closeGroupDetail);
  groupDetailOverlay.addEventListener("click", event => {
    if (event.target === groupDetailOverlay) closeGroupDetail();
  });
  document.getElementById("cancelBtn").addEventListener("click", closeEditor);
  overlay.addEventListener("click", event => {
    if (event.target === overlay) closeEditor();
  });
  document.addEventListener("visibilitychange", () => {
    document.body.classList.toggle("page-hidden", document.hidden);
    if (!document.hidden) {
      syncNow(false);
      checkLatestVersionStatus();
      updateGlowPeriod();
    }
    scheduleFriendPoll(0);
  });

  function compareVersions(left, right) {
    const parse = value =>
      String(value).replace(/^v/i, "").split(".").map(Number);
    const a = parse(left);
    const b = parse(right);
    const length = Math.max(a.length, b.length);
    for (let index = 0; index < length; index += 1) {
      const difference = (a[index] || 0) - (b[index] || 0);
      if (difference) return difference;
    }
    return 0;
  }

  function normalizeVersion(value) {
    const match = String(value || "").match(/v?(\d+\.\d+\.\d+)/i);
    return match ? match[1] : "";
  }

  function extractPlatformVersion(html) {
    const source = String(html || "");
    const releaseMatch = source.match(
      /class=["'][^"']*\brelease-version\b[^"']*["'][^>]*>\s*v?(\d+\.\d+\.\d+)/i
    );
    if (releaseMatch) return releaseMatch[1];
    const currentMatch = source.match(
      /当前版本[\s\S]{0,1600}?v?(\d+\.\d+\.\d+)/i
    );
    return currentMatch ? currentMatch[1] : "";
  }

  function applyLiveUpdateButtonState() {
    if (!checkUpdateBtn) return;
    const updateOperationActive = Boolean(updateDownloadVersion);
    checkUpdateBtn.disabled = updateOperationActive;
    checkUpdateBtn.classList.toggle("update-available", liveUpdateAvailable);
    checkUpdateBtn.classList.toggle(
      "is-latest",
      updateCheckState === "latest"
    );
    checkUpdateBtn.classList.toggle(
      "check-failed",
      updateCheckState === "failed"
    );
    checkUpdateBtn.classList.toggle(
      "login-required",
      updateCheckState === "login"
    );
    checkUpdateBtn.classList.toggle(
      "checking",
      updateCheckState === "checking"
    );
    checkUpdateBtn.textContent = updateOperationActive
      ? updateInstallWaiting
        ? "等待安装"
        : `下载更新 ${updateDownloadPercent}%`
      : liveUpdateAvailable
        ? "可以更新"
      : updateCheckState === "latest"
        ? "已是最新版"
        : updateCheckState === "failed"
          ? "检查失败"
          : updateCheckState === "login"
            ? "需登录检查"
          : updateCheckState === "offline"
            ? "等待联网"
            : "正在检查";
    checkUpdateBtn.setAttribute(
      "aria-label",
      updateOperationActive
        ? updateInstallWaiting
          ? "更新包已下载，等待打开系统安装器"
          : `正在下载更新 ${updateDownloadPercent}%`
        : liveUpdateAvailable
        ? `发现新版本 ${latestRemoteVersion}，点击获取更新`
        : updateCheckState === "latest"
          ? `当前已是最新版 ${CURRENT_MOBILE_VERSION}`
          : updateCheckState === "failed"
            ? "版本检查失败，点击重试或打开国内平台"
            : updateCheckState === "login"
              ? "请先登录国内平台，登录后自动检查最新版本"
            : updateCheckState === "offline"
              ? "当前离线，联网后将自动检查版本"
              : "正在检查最新版本"
    );
  }

  window.BUAASetPwaUpdateReady = () => {
    latestRemoteVersion = latestRemoteVersion || "新版本";
    liveUpdateAvailable = true;
    updateCheckState = "available";
    applyLiveUpdateButtonState();
  };

  function requestNativeLatestVersion() {
    if (!nativeBridge?.checkLatestVersion) {
      return Promise.resolve(null);
    }
    return new Promise(resolve => {
      if (nativeUpdateResolution) {
        nativeUpdateResolution(null);
      }
      nativeUpdateResolution = resolve;
      clearTimeout(nativeUpdateTimer);
      nativeUpdateTimer = setTimeout(() => {
        if (nativeUpdateResolution === resolve) {
          nativeUpdateResolution = null;
          resolve(null);
        }
      }, 14000);
      try {
        nativeBridge.checkLatestVersion();
      } catch {
        clearTimeout(nativeUpdateTimer);
        nativeUpdateResolution = null;
        resolve(null);
      }
    });
  }

  window.BUAANativeUpdateResult = payload => {
    if (!nativeUpdateResolution) return;
    let result = null;
    try {
      result =
        typeof payload === "string" ? JSON.parse(payload) : payload || null;
    } catch {
      result = null;
    }
    const resolve = nativeUpdateResolution;
    nativeUpdateResolution = null;
    clearTimeout(nativeUpdateTimer);
    resolve(result);
  };

  async function readPlatformVersion() {
    const response = await fetch(
      `${UPDATE_PORTAL_URL}?version_check=${Date.now()}`,
      { cache: "no-store", credentials: "omit" }
    );
    if (!response.ok) return "";
    return extractPlatformVersion(await response.text());
  }

  async function readManifestVersion(manifestUrl) {
    const response = await fetch(
      `${manifestUrl}${manifestUrl.includes("?") ? "&" : "?"}t=${Date.now()}`,
      { cache: "no-store" }
    );
    if (!response.ok) return "";
    let manifest = await response.json();
    if (manifest.content && manifest.encoding === "base64") {
      const binary = atob(manifest.content.replace(/\s/g, ""));
      const bytes = Uint8Array.from(binary, character =>
        character.charCodeAt(0)
      );
      manifest = JSON.parse(new TextDecoder().decode(bytes));
    }
    return normalizeVersion(manifest.version);
  }

  async function performLatestVersionCheck() {
    let remoteVersion = "";
    const nativeResult = await requestNativeLatestVersion();
    if (nativeResult?.ok) {
      remoteVersion = normalizeVersion(nativeResult.version);
    }
    if (nativeResult?.auth_required) {
      liveUpdateAvailable = false;
      updateCheckState = "login";
      applyLiveUpdateButtonState();
      return false;
    }
    if (!remoteVersion) {
      try {
        remoteVersion = await readPlatformVersion();
      } catch {}
    }
    for (const manifestUrl of LIVE_UPDATE_MANIFEST_URLS) {
      if (remoteVersion) break;
      try {
        remoteVersion = await readManifestVersion(manifestUrl);
      } catch {}
    }
    if (!remoteVersion) {
      liveUpdateAvailable = false;
      updateCheckState = "failed";
      applyLiveUpdateButtonState();
      return false;
    }
    latestRemoteVersion = remoteVersion;
    liveUpdateAvailable =
      compareVersions(latestRemoteVersion, CURRENT_MOBILE_VERSION) > 0;
    updateCheckState = liveUpdateAvailable ? "available" : "latest";
    applyLiveUpdateButtonState();
    return liveUpdateAvailable;
  }

  async function checkLatestVersionStatus() {
    if (!checkUpdateBtn) return false;
    if (!navigator.onLine) {
      liveUpdateAvailable = false;
      updateCheckState = "offline";
      applyLiveUpdateButtonState();
      return false;
    }
    if (versionCheckPromise) return versionCheckPromise;
    liveUpdateAvailable = false;
    updateCheckState = "checking";
    applyLiveUpdateButtonState();
    versionCheckPromise = performLatestVersionCheck();
    try {
      return await versionCheckPromise;
    } finally {
      versionCheckPromise = null;
    }
  }

  function startLiveUpdateMonitor() {
    checkLatestVersionStatus();
    if (liveUpdateTimer) clearInterval(liveUpdateTimer);
    liveUpdateTimer = setInterval(() => {
      if (!document.hidden && navigator.onLine) checkLatestVersionStatus();
    }, 60000);
  }

  function desktopDownloadMessage() {
    return (
      "BUAA浮光电脑版下载\n\n" +
      `下载页面：${UPDATE_PORTAL_URL}\n` +
      `Windows 安装包：${DESKTOP_DOWNLOAD_URL}\n\n` +
      "在电脑浏览器打开链接并登录平台，然后在“版本下载”中选择 Windows 版。"
    );
  }

  async function copyText(text) {
    if (navigator.clipboard?.writeText) {
      try {
        await navigator.clipboard.writeText(text);
        return true;
      } catch {}
    }
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    document.body.appendChild(textarea);
    textarea.select();
    let copied = false;
    try {
      copied = document.execCommand("copy");
    } catch {}
    textarea.remove();
    return copied;
  }

  async function copyDesktopDownloadLink() {
    const copied = await copyText(desktopDownloadMessage());
    showToast(
      copied
        ? "电脑版下载链接已复制，可发送到电脑"
        : "复制失败，请长按下载页面地址手动复制"
    );
  }

  async function shareDesktopDownloadLink() {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "BUAA浮光电脑版",
          text: desktopDownloadMessage(),
          url: UPDATE_PORTAL_URL,
        });
        return;
      } catch (error) {
        if (error?.name === "AbortError") return;
      }
    }
    await copyDesktopDownloadLink();
  }

  window.BUAANativeUpdateDownloadStarted = () => {
    if (!updateDownloadVersion) {
      updateDownloadVersion = latestRemoteVersion;
    }
    updateDownloadPercent = 0;
    updateInstallWaiting = false;
    applyLiveUpdateButtonState();
    showToast(`开始下载 v${updateDownloadVersion}，完成后将自动打开安装器`);
  };

  window.BUAANativeUpdateDownloadProgress = (version, percent) => {
    updateDownloadVersion = normalizeVersion(version) || updateDownloadVersion;
    updateDownloadPercent = Math.max(
      0,
      Math.min(100, Math.round(Number(percent) || 0))
    );
    updateInstallWaiting = false;
    applyLiveUpdateButtonState();
  };

  window.BUAANativeUpdateDownloaded = version => {
    updateDownloadVersion = normalizeVersion(version) || updateDownloadVersion;
    updateDownloadPercent = 100;
    updateInstallWaiting = true;
    applyLiveUpdateButtonState();
    showToast("更新包下载完成，正在准备安装");
  };

  window.BUAANativeUpdatePermissionRequired = () => {
    updateInstallWaiting = true;
    applyLiveUpdateButtonState();
    showToast("请允许 BUAA浮光安装应用，返回 App 后会自动继续");
  };

  window.BUAANativeUpdateInstallerReady = () => {
    updateInstallWaiting = true;
    applyLiveUpdateButtonState();
    showToast("已打开系统安装器，请点击“安装”完成更新");
  };

  window.BUAANativeUpdateDownloadFailed = message => {
    const detail = String(message || "更新下载失败，请稍后重试");
    updateDownloadVersion = "";
    updateDownloadPercent = 0;
    updateInstallWaiting = false;
    if (detail.includes("已是最新版")) {
      liveUpdateAvailable = false;
      updateCheckState = "latest";
    } else {
      liveUpdateAvailable = Boolean(latestRemoteVersion);
      updateCheckState = liveUpdateAvailable ? "available" : "failed";
    }
    applyLiveUpdateButtonState();
    showToast(detail);
  };

  async function checkMobileUpdate() {
    if (!checkUpdateBtn) return;
    if (updateCheckState === "checking") {
      showToast("正在读取国内平台版本，请稍候");
      return;
    }
    if (updateCheckState === "login" && nativeBridge?.openUpdateLogin) {
      nativeBridge.openUpdateLogin();
      return;
    }
    if (updateCheckState === "failed" || updateCheckState === "offline") {
      await checkLatestVersionStatus();
    }
    if (updateCheckState === "login" && nativeBridge?.openUpdateLogin) {
      nativeBridge.openUpdateLogin();
      return;
    }
    if (
      liveUpdateAvailable &&
      typeof window.BUAAApplyPwaUpdate === "function"
    ) {
      try {
        const applied = await window.BUAAApplyPwaUpdate();
        if (applied) {
          checkUpdateBtn.disabled = true;
          checkUpdateBtn.textContent = "正在应用更新";
          showToast("正在载入新版本，请稍候");
          return;
        }
      } catch {}
    }
    if (
      liveUpdateAvailable &&
      nativeBridge?.downloadAndInstallUpdate
    ) {
      updateDownloadVersion = latestRemoteVersion;
      updateDownloadPercent = 0;
      updateInstallWaiting = false;
      applyLiveUpdateButtonState();
      try {
        nativeBridge.downloadAndInstallUpdate();
      } catch {
        window.BUAANativeUpdateDownloadFailed(
          "无法启动更新下载，请稍后重试"
        );
      }
      return;
    }
    const updateHint = liveUpdateAvailable
      ? `已检测到新版本 v${latestRemoteVersion}。\n\n`
      : updateCheckState === "latest"
        ? `当前已是最新版 v${CURRENT_MOBILE_VERSION}。\n\n`
        : "暂时无法确认最新版本，也可以直接打开国内平台手动检查。\n\n";
    const proceed = confirm(
      `${updateHint}更新由“学业支持中心开源平台”提供。\n\n` +
        "未登录时会先跳转到平台登录页；登录后在项目页面的“版本下载”中下载最新版。\n\n" +
        "是否打开更新页面？"
    );
    if (!proceed) return;
    if (nativeBridge?.openUrl) {
      nativeBridge.openUrl(UPDATE_PORTAL_URL);
    } else {
      window.open(UPDATE_PORTAL_URL, "_blank", "noopener,noreferrer");
    }
    showToast("请先登录平台，然后在“版本下载”中安装最新版");
  }

  function saveMobileDownloadQr() {
    if (nativeBridge?.saveAssetImage) {
      try {
        nativeBridge.saveAssetImage(
          "assets/mobile-download-qr.png",
          "BUAA浮光手机下载二维码.png"
        );
        if (mobileDownloadQrStatus) {
          mobileDownloadQrStatus.textContent =
            "二维码已保存到相册中的 BUAA浮光 文件夹。";
        }
        return;
      } catch {}
    }
    const link = document.createElement("a");
    link.href = "assets/mobile-download-qr.png";
    link.download = "BUAA浮光手机下载二维码.png";
    document.body.appendChild(link);
    link.click();
    link.remove();
    if (mobileDownloadQrStatus) {
      mobileDownloadQrStatus.textContent =
        /iPhone|iPad|iPod/i.test(navigator.userAgent)
          ? "二维码已打开，可长按图片选择“存储到照片”。"
          : "二维码已开始保存；如果没有下载，请长按图片保存。";
    }
  }

  checkUpdateBtn?.addEventListener("click", checkMobileUpdate);
  copyDesktopLinkBtn?.addEventListener("click", copyDesktopDownloadLink);
  shareDesktopLinkBtn?.addEventListener("click", shareDesktopDownloadLink);
  desktopDownloadBtn?.addEventListener("click", () => {
    desktopDownloadOverlay?.classList.add("show");
  });
  desktopDownloadCloseBtn?.addEventListener("click", () => {
    desktopDownloadOverlay?.classList.remove("show");
  });
  desktopDownloadOverlay?.addEventListener("click", event => {
    if (event.target === desktopDownloadOverlay) {
      desktopDownloadOverlay.classList.remove("show");
    }
  });
  mobileDownloadBtn?.addEventListener("click", () => {
    mobileDownloadOverlay?.classList.add("show");
  });
  mobileDownloadCloseBtn?.addEventListener("click", () => {
    mobileDownloadOverlay?.classList.remove("show");
  });
  mobileDownloadQrSaveBtn?.addEventListener("click", saveMobileDownloadQr);
  mobileDownloadOverlay?.addEventListener("click", event => {
    if (event.target === mobileDownloadOverlay) {
      mobileDownloadOverlay.classList.remove("show");
    }
  });
  if (new URLSearchParams(window.location.search).get("download") === "1") {
    window.setTimeout(() => mobileDownloadOverlay?.classList.add("show"), 0);
  }
  if (desktopDownloadPageLink) {
    desktopDownloadPageLink.href = UPDATE_PORTAL_URL;
  }
  if (directDesktopDownload) {
    directDesktopDownload.href = DESKTOP_DOWNLOAD_URL;
  }
  window.addEventListener("online", () => checkLatestVersionStatus());
  window.addEventListener("offline", () => {
    liveUpdateAvailable = false;
    updateCheckState = "offline";
    applyLiveUpdateButtonState();
  });
  window.BUAARetryUpdateCheck = () => checkLatestVersionStatus();
  applyLiveUpdateButtonState();
  startLiveUpdateMonitor();
  rescheduleAllReminders();
  initLayoutSettings();
  initIosInstallHint();

  window.BUAAReloadRecords = () => {
    loadRecords();
    render();
  };
  window.BUAACloseTopOverlay = () => {
    if (monthDayOverlay.classList.contains("show")) {
      closeMonthDayDetail();
      return true;
    }
    if (monthOverlay.classList.contains("show")) {
      closeMonthView();
      return true;
    }
    if (noteViewOverlay?.classList.contains("show")) {
      closeNoteView();
      return true;
    }
    if (notePasteOverlay?.classList.contains("show")) {
      closeNotePasteDialog();
      return true;
    }
    if (noteMathOverlay?.classList.contains("show")) {
      closeNoteMathDialog();
      return true;
    }
    for (const element of [
      noteWritingOverlay,
      noteEditorOverlay,
      redemptionOverlay,
      experienceInfoOverlay,
      taskOverlay,
      mailOverlay,
      backpackOverlay,
      historyGroupOverlay,
      historyOverlay,
      layoutSettingsOverlay,
      defaultReminderOverlay,
      friendsCenterOverlay,
      nicknameOverlay,
      shareMemoOverlay,
      friendGiftOverlay,
      friendChatOverlay,
      addFriendOverlay,
      groupDetailOverlay,
      groupOverlay,
      desktopDownloadOverlay,
      mobileDownloadOverlay,
      changelogOverlay,
      imageViewerOverlay,
      syncTutorialOverlay,
      syncPreviewOverlay,
      syncOverlay,
      overlay
    ]) {
      if (element.classList.contains("show")) {
        if (element === overlay) {
          closeEditor();
        } else {
          element.classList.remove("show");
        }
        return true;
      }
    }
    return false;
  };

  if (bootstrap.mobileVersion) {
    versionBtn.textContent =
      document.body.dataset.desktopSurface === "true"
        ? "更新日志"
        : `v${bootstrap.mobileVersion}`;
  }
  installMobilePerformanceMode();
  renderAccountNickname();
  renderGlowBalance();
  updateGlowPeriod();
  window.setInterval(updateGlowPeriod, 60 * 1000);
  window.BUAAGlowSpots = Object.freeze({
    getBalance: () => glowWalletData().balance,
    adjust: (delta, reason) => adjustGlowSpots(delta, reason),
    getPeriod: () => glowPeriodForDate(new Date()),
  });
  renderExperience();
  window.BUAAExperience = Object.freeze({
    getState: () => experienceLevelState(experienceData().total_xp),
    getTotalExperience: () => experienceData().total_xp,
    adjust: (delta, reason) => adjustExperience(delta, reason),
    requiredForNextLevel: level =>
      experienceRequiredForNextLevel(level),
  });
  renderMailButton();
  renderBackpack();
  if (friendFeatureAvailable()) {
    window.setTimeout(() => {
      refreshFriendState(true).then(() => refreshTaskBadge());
    }, 500);
    scheduleFriendPoll();
  }
  loadRecords();
  render();
  refreshTaskBadge();
  setPage("memos");
  setConnectionStatus(false);
  if (isDesktopSurface) {
    refreshDesktopRecords();
    setInterval(refreshDesktopRecords, 3000);
  }
  setInterval(updateCountdowns, 1000);
  window.addEventListener("storage", event => {
    if (
      event.key === recordsStorageKey ||
      event.key === LAYOUT_SETTINGS_KEY
    ) {
      loadRecords();
      render();
    }
  });
})();
