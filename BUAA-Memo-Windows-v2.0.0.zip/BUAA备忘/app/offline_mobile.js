(() => {
  "use strict";

  const bootstrap = window.BUAA_BOOTSTRAP || {};
  const STORAGE_KEY = "buaa_memo_records_v2";
  const SYNC_URL_KEY = "buaa_memo_sync_url_v2";

  const listEl = document.getElementById("list");
  const countEl = document.getElementById("count");
  const statusEl = document.getElementById("status");
  const statusText = document.getElementById("statusText");
  const overlay = document.getElementById("overlay");
  const form = document.getElementById("memoForm");
  const formTitle = document.getElementById("formTitle");
  const titleInput = document.getElementById("title");
  const dateInput = document.getElementById("date");
  const timeInput = document.getElementById("time");
  const startDateInput = document.getElementById("startDate");
  const startTimeInput = document.getElementById("startTime");
  const endDateInput = document.getElementById("endDate");
  const endTimeInput = document.getElementById("endTime");
  const taskFields = document.getElementById("taskFields");
  const eventFields = document.getElementById("eventFields");
  const taskTypeBtn = document.getElementById("taskTypeBtn");
  const eventTypeBtn = document.getElementById("eventTypeBtn");
  const noteInput = document.getElementById("note");
  const toastEl = document.getElementById("toast");
  const checkUpdateBtn = document.getElementById("checkUpdateBtn");

  document.querySelector(".offline-box")?.remove();

  let records = [];
  let editingId = null;
  let editorType = "task";
  let syncing = false;
  let toastTimer = null;
  let syncUrl =
    localStorage.getItem(SYNC_URL_KEY) || bootstrap.syncWsUrl || "";
  if (bootstrap.syncWsUrl && !localStorage.getItem(SYNC_URL_KEY)) {
    localStorage.setItem(SYNC_URL_KEY, bootstrap.syncWsUrl);
  }

  function nextRevision(record = null) {
    return Math.max(Date.now(), Number(record?.rev || 0) + 1);
  }

  function mergeRecords(...groups) {
    const byId = new Map();
    for (const group of groups) {
      for (const record of Array.isArray(group) ? group : []) {
        if (!record || !record.id) continue;
        const normalized = {
          ...record,
          id: String(record.id),
          rev: Number(record.rev || 0),
          deleted: Boolean(record.deleted),
        };
        const existing = byId.get(normalized.id);
        if (!existing || normalized.rev >= Number(existing.rev || 0)) {
          byId.set(normalized.id, normalized);
        }
      }
    }
    return [...byId.values()];
  }

  function persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
      return true;
    } catch {
      showToast("浏览器未允许本地保存，请更换浏览器打开");
      return false;
    }
  }

  function loadRecords() {
    let localRecords = [];
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      localRecords = raw ? JSON.parse(raw) : [];
    } catch {
      localRecords = [];
    }
    records = mergeRecords(localRecords, bootstrap.seedRecords || []);
    persist();
  }

  function activeRecords() {
    return records.filter(record => !record.deleted && !isCompleted(record));
  }

  function localDateValue(date) {
    const pad = value => String(value).padStart(2, "0");
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  }

  function defaultDeadline() {
    const value = new Date(Date.now() + 24 * 60 * 60 * 1000);
    value.setHours(18, 0, 0, 0);
    dateInput.value = localDateValue(value);
    timeInput.value = "18:00";
  }

  function defaultEventTimes() {
    const start = new Date(Date.now() + 60 * 60 * 1000);
    start.setSeconds(0, 0);
    const end = new Date(start.getTime() + 2 * 60 * 60 * 1000);
    startDateInput.value = localDateValue(start);
    startTimeInput.value = `${String(start.getHours()).padStart(2, "0")}:${String(start.getMinutes()).padStart(2, "0")}`;
    endDateInput.value = localDateValue(end);
    endTimeInput.value = `${String(end.getHours()).padStart(2, "0")}:${String(end.getMinutes()).padStart(2, "0")}`;
  }

  function isEvent(memo) {
    return memo?.item_type === "event";
  }

  function isCompleted(memo) {
    return Boolean(memo?.completed || memo?.completed_at);
  }

  function formatRemaining(deadlineText) {
    const seconds = Math.floor(
      (new Date(deadlineText).getTime() - Date.now()) / 1000
    );
    if (!Number.isFinite(seconds)) return "时间无效";
    if (seconds <= 0) return "已到期";
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    const pad = value => String(value).padStart(2, "0");
    return days > 0
      ? `${String(days).padStart(2, "0")} 天 ${pad(hours)}:${pad(minutes)}:${pad(secs)}`
      : `${pad(hours)}:${pad(minutes)}:${pad(secs)}`;
  }

  function statusOf(memo) {
    const seconds = (new Date(memo.deadline).getTime() - Date.now()) / 1000;
    if (seconds <= 0) return ["expired", isEvent(memo) ? "已结束" : "已到期"];
    if (isEvent(memo)) {
      const start = new Date(memo.start_at).getTime();
      if (Number.isFinite(start) && Date.now() < start) {
        return ["pending", "待开始"];
      }
    }
    if (seconds <= 86400) return ["urgent", "进行中"];
    return ["", "进行中"];
  }

  function setEditorType(type) {
    editorType = type === "event" ? "event" : "task";
    const isTask = editorType === "task";
    taskFields.classList.toggle("hidden", !isTask);
    eventFields.classList.toggle("hidden", isTask);
    taskTypeBtn.classList.toggle("active", isTask);
    eventTypeBtn.classList.toggle("active", !isTask);
  }

  function formatDeadline(deadlineText) {
    const value = new Date(deadlineText);
    const pad = number => String(number).padStart(2, "0");
    return `${value.getFullYear()}-${pad(value.getMonth() + 1)}-${pad(value.getDate())}  ${pad(value.getHours())}:${pad(value.getMinutes())}`;
  }

  function showToast(message) {
    toastEl.textContent = message;
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("show"), 2300);
  }

  function setConnectionStatus(online) {
    statusEl.classList.toggle("offline", !online);
    statusText.textContent = online
      ? "已连接电脑 · 已同步"
      : "离线模式 · 数据已保存在本机";
  }

  function render() {
    const memos = activeRecords();
    memos.sort((left, right) => {
      const leftTime = new Date(left.deadline).getTime();
      const rightTime = new Date(right.deadline).getTime();
      const now = Date.now();
      const leftActive = leftTime > now ? 0 : 1;
      const rightActive = rightTime > now ? 0 : 1;
      return leftActive - rightActive || leftTime - rightTime;
    });

    countEl.textContent = `${memos.length} 项`;
    listEl.replaceChildren();

    if (!memos.length) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.innerHTML =
        '<div class="empty-clock">◷</div>还没有事项<br>现在可以先离线记录，联网后自动同步';
      listEl.appendChild(empty);
      return;
    }

    for (const memo of memos) {
      const [stateClass, badgeText] = statusOf(memo);
      const card = document.createElement("article");
      card.className = `card ${stateClass}`.trim();
      card.dataset.id = memo.id;

      const head = document.createElement("div");
      head.className = "card-head";
      const title = document.createElement("h2");
      title.className = "card-title";
      title.textContent = memo.title || "未命名事项";
      const badge = document.createElement("span");
      badge.className = "badge";
      badge.textContent = `${isEvent(memo) ? "事件" : "任务"} · ${badgeText}`;
      head.append(title, badge);
      card.appendChild(head);

      if (memo.note) {
        const note = document.createElement("div");
        note.className = "note";
        note.textContent = memo.note;
        card.appendChild(note);
      }

      const meta = document.createElement("div");
      meta.className = "meta";
      const remainingLabel = document.createElement("span");
      remainingLabel.className = "meta-label";
      remainingLabel.textContent = "剩余时间";
      const remaining = document.createElement("span");
      remaining.className = "remaining";
      remaining.dataset.deadline = memo.deadline;
      remaining.textContent = formatRemaining(memo.deadline);
      let startLabel = null;
      let startValue = null;
      if (isEvent(memo)) {
        startLabel = document.createElement("span");
        startLabel.className = "meta-label";
        startLabel.textContent = "开始时间";
        startValue = document.createElement("span");
        startValue.className = "deadline";
        startValue.textContent = formatDeadline(memo.start_at);
      }
      const deadlineLabel = document.createElement("span");
      deadlineLabel.className = "meta-label";
      deadlineLabel.textContent = isEvent(memo) ? "结束时间" : "终止时间";
      const deadline = document.createElement("span");
      deadline.className = "deadline";
      deadline.textContent = formatDeadline(memo.deadline);
      meta.append(remainingLabel, remaining);
      if (startLabel && startValue) meta.append(startLabel, startValue);
      meta.append(deadlineLabel, deadline);
      card.appendChild(meta);

      const actions = document.createElement("div");
      actions.className = "actions";
      const editButton = document.createElement("button");
      editButton.className = "action-btn";
      editButton.textContent = "编辑";
      editButton.addEventListener("click", () => openEditor(memo.id));
      actions.append(editButton);
      if (!isEvent(memo)) {
        const completeButton = document.createElement("button");
        completeButton.className = "action-btn complete";
        completeButton.textContent = "✓ 完成";
        completeButton.addEventListener("click", () => completeMemo(memo.id));
        actions.append(completeButton);
      }
      const deleteButton = document.createElement("button");
      deleteButton.className = "action-btn delete";
      deleteButton.textContent = "删除";
      deleteButton.addEventListener("click", () => deleteMemo(memo.id));
      actions.append(deleteButton);
      card.appendChild(actions);
      listEl.appendChild(card);
    }
  }

  function updateCountdowns() {
    document.querySelectorAll(".remaining[data-deadline]").forEach(element => {
      element.textContent = formatRemaining(element.dataset.deadline);
    });
    document.querySelectorAll(".card").forEach(card => {
      const memo = records.find(record => record.id === card.dataset.id);
      if (!memo) return;
      const [stateClass, badgeText] = statusOf(memo);
      card.classList.remove("urgent", "expired");
      card.classList.remove("pending");
      if (stateClass) card.classList.add(stateClass);
      const badge = card.querySelector(".badge");
      if (badge) {
        badge.textContent = `${isEvent(memo) ? "事件" : "任务"} · ${badgeText}`;
      }
    });
  }

  function openEditor(memoId = null) {
    editingId = memoId;
    const memo = memoId
      ? records.find(record => record.id === memoId && !record.deleted)
      : null;
    formTitle.textContent = memo ? "编辑事项" : "新建事项";
    titleInput.value = memo ? memo.title : "";
    noteInput.value = memo ? (memo.note || "") : "";
    setEditorType(memo && isEvent(memo) ? "event" : "task");
    if (memo) {
      const value = new Date(memo.deadline);
      if (isEvent(memo)) {
        const start = new Date(memo.start_at);
        startDateInput.value = localDateValue(start);
        startTimeInput.value = `${String(start.getHours()).padStart(2, "0")}:${String(start.getMinutes()).padStart(2, "0")}`;
        endDateInput.value = localDateValue(value);
        endTimeInput.value = `${String(value.getHours()).padStart(2, "0")}:${String(value.getMinutes()).padStart(2, "0")}`;
      } else {
        dateInput.value = localDateValue(value);
        timeInput.value = `${String(value.getHours()).padStart(2, "0")}:${String(value.getMinutes()).padStart(2, "0")}`;
      }
    } else {
      defaultDeadline();
      defaultEventTimes();
    }
    overlay.classList.add("show");
    setTimeout(() => titleInput.focus(), 80);
  }

  function closeEditor() {
    overlay.classList.remove("show");
    editingId = null;
  }

  function deleteMemo(memoId) {
    const memo = records.find(record => record.id === memoId);
    if (!memo || !confirm(`确定删除「${memo.title}」吗？`)) return;
    memo.deleted = true;
    memo.rev = nextRevision(memo);
    memo.updated_at = new Date().toISOString();
    persist();
    render();
    showToast("已删除，联网后同步");
    syncNow();
  }

  function completeMemo(memoId) {
    const memo = records.find(record => record.id === memoId);
    if (!memo || isEvent(memo) || isCompleted(memo)) return;
    if (!confirm(`将「${memo.title}」标记为已完成？`)) return;
    const now = new Date().toISOString();
    memo.completed = true;
    memo.completed_at = now;
    memo.updated_at = now;
    memo.rev = nextRevision(memo);
    persist();
    render();
    showToast("任务已完成，联网后自动同步");
    syncNow();
  }

  form.addEventListener("submit", event => {
    event.preventDefault();
    const title = titleInput.value.trim();
    if (!title) {
      showToast("请填写事项名称");
      return;
    }
    if (
      editorType === "event"
        ? (!startDateInput.value || !startTimeInput.value || !endDateInput.value || !endTimeInput.value)
        : (!dateInput.value || !timeInput.value)
    ) {
      showToast(editorType === "event" ? "请选择事件开始和结束时间" : "请选择截止时间");
      return;
    }
    const deadline = editorType === "event"
      ? `${endDateInput.value}T${endTimeInput.value}:00`
      : `${dateInput.value}T${timeInput.value}:00`;
    const startAt = editorType === "event"
      ? `${startDateInput.value}T${startTimeInput.value}:00`
      : null;
    if (new Date(deadline).getTime() <= Date.now()) {
      showToast("结束时间需要晚于现在");
      return;
    }
    if (
      editorType === "event" &&
      new Date(startAt).getTime() >= new Date(deadline).getTime()
    ) {
      showToast("事件开始时间需要早于结束时间");
      return;
    }

    const now = new Date().toISOString();
    let memo = editingId
      ? records.find(record => record.id === editingId)
      : null;
    if (memo) {
      memo.title = title;
      memo.note = noteInput.value.trim();
      memo.item_type = editorType;
      memo.start_at = startAt;
      memo.deadline = deadline;
      if (editorType === "event") {
        memo.completed = false;
        memo.completed_at = null;
      }
      memo.deleted = false;
      memo.rev = nextRevision(memo);
      memo.updated_at = now;
    } else {
      memo = {
        id:
          crypto.randomUUID?.() ||
          `m-${Date.now()}-${Math.random().toString(16).slice(2)}`,
        title,
        note: noteInput.value.trim(),
        item_type: editorType,
        start_at: startAt,
        deadline,
        completed: false,
        completed_at: null,
        created_at: now,
        updated_at: now,
        rev: nextRevision(),
        deleted: false,
        image: null,
      };
      records.push(memo);
    }
    persist();
    closeEditor();
    render();
    showToast("已保存到手机，联网后自动同步");
    syncNow();
  });

  taskTypeBtn.addEventListener("click", () => setEditorType("task"));
  eventTypeBtn.addEventListener("click", () => setEditorType("event"));

  function syncViaWebSocket() {
    return new Promise(resolve => {
      if (!syncUrl) {
        resolve(false);
        return;
      }
      let settled = false;
      let socket;
      let timer;
      const finish = ok => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        try {
          socket?.close();
        } catch {}
        resolve(ok);
      };
      try {
        socket = new WebSocket(syncUrl);
      } catch {
        resolve(false);
        return;
      }
      timer = setTimeout(() => finish(false), 4500);
      socket.onopen = () => {
        socket.send(JSON.stringify({ type: "sync", records }));
      };
      socket.onmessage = event => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type !== "synced" || !Array.isArray(payload.records)) {
            finish(false);
            return;
          }
          records = mergeRecords(records, payload.records);
          persist();
          render();
          finish(true);
        } catch {
          finish(false);
        }
      };
      socket.onerror = () => finish(false);
      socket.onclose = () => finish(false);
    });
  }

  function deriveHttpUrl() {
    try {
      const url = new URL(syncUrl);
      const token = url.pathname.split("/").filter(Boolean).pop();
      if (!token) return "";
      return `${url.protocol === "wss:" ? "https:" : "http:"}//${url.host}/t/${token}/api/sync`;
    } catch {
      return bootstrap.syncHttpUrl || "";
    }
  }

  async function syncViaHttp() {
    const target = deriveHttpUrl();
    if (!target) return false;
    try {
      const response = await fetch(target, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ records }),
      });
      const payload = await response.json();
      if (!response.ok || !Array.isArray(payload.records)) return false;
      records = mergeRecords(records, payload.records);
      persist();
      render();
      return true;
    } catch {
      return false;
    }
  }

  async function syncNow() {
    if (syncing) return;
    syncing = true;
    let online = false;
    try {
      online = await syncViaWebSocket();
      if (!online) online = await syncViaHttp();
    } finally {
      syncing = false;
      setConnectionStatus(online);
      setTimeout(syncNow, online ? 3000 : 9000);
    }
  }

  statusEl.style.cursor = "pointer";
  statusEl.title = "点击设置电脑同步地址";
  statusEl.addEventListener("click", () => {
    const value = prompt(
      "输入电脑“微信控制”窗口中显示的离线同步地址：",
      syncUrl
    );
    if (value && value.trim()) {
      syncUrl = value.trim();
      localStorage.setItem(SYNC_URL_KEY, syncUrl);
      syncNow();
    }
  });

  document.getElementById("addBtn").addEventListener("click", () => openEditor());
  document.getElementById("cancelBtn").addEventListener("click", closeEditor);
  overlay.addEventListener("click", event => {
    if (event.target === overlay) closeEditor();
  });
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) syncNow();
  });

  function compareVersions(left, right) {
    const parse = value =>
      String(value).replace(/^v/i, "").split(".").map(Number);
    const a = parse(left);
    const b = parse(right);
    const length = Math.max(a.length, b.length);
    for (let index = 0; index < length; index += 1) {
      const difference = (a[index] || 0) - (b[index] || 0);
      if (difference) return difference;
    }
    return 0;
  }

  async function checkMobileUpdate() {
    if (!checkUpdateBtn) return;
    const manifestUrl =
      bootstrap.updateManifestUrl ||
      "https://api.github.com/repos/MrWhite-Bai/buaa-memo-widget/contents/update-manifest.json?ref=main";
    const currentVersion = bootstrap.mobileVersion || "0.0.0";
    checkUpdateBtn.disabled = true;
    checkUpdateBtn.textContent = "检查中…";
    try {
      const response = await fetch(`${manifestUrl}?t=${Date.now()}`, {
        cache: "no-store",
      });
      if (!response.ok) throw new Error("无法获取版本信息");
      let manifest = await response.json();
      if (manifest.content && manifest.encoding === "base64") {
        const binary = atob(manifest.content.replace(/\s/g, ""));
        const bytes = Uint8Array.from(binary, character => character.charCodeAt(0));
        manifest = JSON.parse(new TextDecoder().decode(bytes));
      }
      if (compareVersions(manifest.version, currentVersion) <= 0) {
        showToast(`已是最新版本 v${currentVersion}`);
        return;
      }
      const notes = Array.isArray(manifest.notes)
        ? manifest.notes.map(item => `• ${item}`).join("\n")
        : "";
      const install = confirm(
        `发现新版本 v${manifest.version}\n\n${notes}\n\n` +
          "下载后将得到最新离线版 HTML。请用新文件替换旧文件并保持原文件名不变，本机事项数据会保留。"
      );
      if (!install) return;
      const mobile = manifest.mobile || {};
      if (!mobile.offline_html_url) {
        throw new Error("更新清单缺少手机版下载地址");
      }
      checkUpdateBtn.textContent = "下载中…";
      const fileResponse = await fetch(mobile.offline_html_url, {
        cache: "no-store",
        headers: { Accept: "application/vnd.github.raw" },
      });
      if (!fileResponse.ok) throw new Error("下载失败");
      const html = await fileResponse.text();
      const blob = new Blob([html], { type: "text/html;charset=utf-8" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "BUAA-Memo-Offline.html";
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(link.href), 2000);
      showToast("已下载最新离线版，请打开新文件替换旧版");
    } catch (error) {
      showToast(error.message || "检查更新失败");
    } finally {
      checkUpdateBtn.disabled = false;
      checkUpdateBtn.textContent = "检查更新";
    }
  }

  checkUpdateBtn?.addEventListener("click", checkMobileUpdate);

  loadRecords();
  render();
  setConnectionStatus(false);
  setInterval(updateCountdowns, 1000);
  syncNow();
})();
