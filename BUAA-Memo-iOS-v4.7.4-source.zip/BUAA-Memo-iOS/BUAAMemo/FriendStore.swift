import Foundation

final class FriendStore {
    static let shared = FriendStore()

    private let key = "buaa_ios_friend_state_v1"
    private let lock = NSLock()
    private let defaults = UserDefaults.standard
    private let maxRequests = 50
    private let maxMessages = 500
    private let maxFriends = 20
    private let developerModeKey = "buaa_developer_mode_v1"
    private var state: [String: Any]

    private init() {
        if let raw = defaults.string(forKey: key),
           let data = raw.data(using: .utf8),
           let object = try? JSONSerialization.jsonObject(with: data),
           let parsed = object as? [String: Any] {
            state = parsed
        } else {
            state = [:]
        }
        for name in ["incoming", "outgoing", "friends", "inbox"] {
            if state[name] as? [[String: Any]] == nil {
                state[name] = []
            }
        }
    }

    func snapshot() -> [String: Any] {
        lock.lock()
        defer { lock.unlock() }
        return [
            "incoming": array("incoming"),
            "outgoing": array("outgoing"),
            "friends": array("friends"),
            "inbox": array("inbox")
        ]
    }

    func addIncomingRequest(_ request: [String: Any]) -> [String: Any]? {
        guard let requestID = request["request_id"] as? String,
              !requestID.isEmpty else {
            return nil
        }
        lock.lock()
        defer { lock.unlock() }
        var items = array("incoming")
        if let existing = items.first(where: {
            ($0["request_id"] as? String) == requestID
        }) {
            return existing
        }
        trim(&items, max: maxRequests - 1)
        items.append(request)
        state["incoming"] = items
        save()
        return request
    }

    func removeIncomingRequest(_ requestID: String) {
        lock.lock()
        defer { lock.unlock() }
        state["incoming"] = array("incoming").filter {
            ($0["request_id"] as? String) != requestID
        }
        save()
    }

    func addOutgoingRequest(_ request: [String: Any]) -> Bool {
        guard let requestID = request["request_id"] as? String,
              !requestID.isEmpty else {
            return false
        }
        lock.lock()
        defer { lock.unlock() }
        var items = array("outgoing").filter {
            ($0["request_id"] as? String) != requestID
        }
        trim(&items, max: maxRequests - 1)
        items.append(request)
        state["outgoing"] = items
        save()
        return true
    }

    func approveOutgoing(
        requestID: String,
        friendID: String,
        token: String,
        publicKey: String,
        address: String,
        name: String
    ) -> [String: Any]? {
        lock.lock()
        defer { lock.unlock() }
        var items = array("outgoing")
        guard let index = items.firstIndex(where: {
            ($0["request_id"] as? String) == requestID &&
            ($0["target_id"] as? String) == friendID &&
            ($0["token"] as? String) == token
        }) else {
            return nil
        }
        guard !friendLimitReached(friendID) else {
            return nil
        }
        items.remove(at: index)
        state["outgoing"] = items
        let friend: [String: Any] = [
            "id": friendID,
            "name": name,
            "token": token,
            "public_key": publicKey,
            "address": address,
            "accepted_at": Int64(Date().timeIntervalSince1970 * 1000)
        ]
        upsertFriend(friend)
        save()
        return friend
    }

    func denyOutgoing(requestID: String, friendID: String, token: String) -> Bool {
        lock.lock()
        defer { lock.unlock() }
        var items = array("outgoing")
        let before = items.count
        items.removeAll {
            ($0["request_id"] as? String) == requestID &&
            ($0["target_id"] as? String) == friendID &&
            ($0["token"] as? String) == token
        }
        state["outgoing"] = items
        save()
        return items.count != before
    }

    func saveFriend(_ friend: [String: Any]) -> Bool {
        guard let friendID = friend["id"] as? String, !friendID.isEmpty else {
            return false
        }
        lock.lock()
        defer { lock.unlock() }
        guard !friendLimitReached(friendID) else {
            return false
        }
        upsertFriend(friend)
        save()
        return true
    }

    func isFriendLimitReached(_ friendID: String) -> Bool {
        lock.lock()
        defer { lock.unlock() }
        return friendLimitReached(friendID)
    }

    func removeFriend(_ friendID: String) {
        lock.lock()
        defer { lock.unlock() }
        state["friends"] = array("friends").filter {
            ($0["id"] as? String) != friendID
        }
        save()
    }

    func tokenMatches(friendID: String, token: String) -> Bool {
        lock.lock()
        defer { lock.unlock() }
        return array("friends").contains {
            ($0["id"] as? String) == friendID &&
            ($0["token"] as? String) == token
        }
    }

    func addInboxMessage(senderID: String, envelope: [String: Any]) -> Bool {
        guard let eventID = envelope["event_id"] as? String,
              !eventID.isEmpty else {
            return false
        }
        lock.lock()
        defer { lock.unlock() }
        var items = array("inbox")
        if items.contains(where: { ($0["event_id"] as? String) == eventID }) {
            return true
        }
        trim(&items, max: maxMessages - 1)
        items.append([
            "event_id": eventID,
            "sender_id": senderID,
            "envelope": envelope,
            "created_at": Int64(Date().timeIntervalSince1970 * 1000)
        ])
        state["inbox"] = items
        save()
        return true
    }

    func acknowledgeInbox(_ eventIDs: Set<String>) {
        guard !eventIDs.isEmpty else { return }
        lock.lock()
        defer { lock.unlock() }
        state["inbox"] = array("inbox").filter {
            guard let eventID = $0["event_id"] as? String else { return false }
            return !eventIDs.contains(eventID)
        }
        save()
    }

    private func upsertFriend(_ friend: [String: Any]) {
        guard let friendID = friend["id"] as? String else { return }
        var items = array("friends").filter {
            ($0["id"] as? String) != friendID
        }
        items.append(friend)
        state["friends"] = items
    }

    private func array(_ name: String) -> [[String: Any]] {
        state[name] as? [[String: Any]] ?? []
    }

    private func trim(_ items: inout [[String: Any]], max: Int) {
        if items.count > max {
            items.removeFirst(items.count - max)
        }
    }

    private func friendLimitReached(_ candidateFriendID: String) -> Bool {
        if defaults.bool(forKey: developerModeKey) {
            return false
        }
        let count = array("friends").filter {
            ($0["id"] as? String) != candidateFriendID
        }.count
        return count >= maxFriends
    }

    private func save() {
        guard let data = try? JSONSerialization.data(withJSONObject: state),
              let text = String(data: data, encoding: .utf8) else {
            return
        }
        defaults.set(text, forKey: key)
    }
}
