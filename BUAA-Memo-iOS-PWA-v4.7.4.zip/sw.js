const CACHE_NAME = "buaa-memo-cloud-20261023214249";
const ASSETS = [
  "./",
  "./index.html",
  "./manifest.json",
  "./changelog.json",
  "./assets/starry-sky-v2.jpg",
  "./assets/river-material-v3.jpg",
  "./assets/mobile-download-qr.png",
  "./assets/katex/fonts/KaTeX_AMS-Regular.woff2",
  "./assets/katex/fonts/KaTeX_Caligraphic-Bold.woff2",
  "./assets/katex/fonts/KaTeX_Caligraphic-Regular.woff2",
  "./assets/katex/fonts/KaTeX_Fraktur-Bold.woff2",
  "./assets/katex/fonts/KaTeX_Fraktur-Regular.woff2",
  "./assets/katex/fonts/KaTeX_Main-Bold.woff2",
  "./assets/katex/fonts/KaTeX_Main-BoldItalic.woff2",
  "./assets/katex/fonts/KaTeX_Main-Italic.woff2",
  "./assets/katex/fonts/KaTeX_Main-Regular.woff2",
  "./assets/katex/fonts/KaTeX_Math-BoldItalic.woff2",
  "./assets/katex/fonts/KaTeX_Math-Italic.woff2",
  "./assets/katex/fonts/KaTeX_SansSerif-Bold.woff2",
  "./assets/katex/fonts/KaTeX_SansSerif-Italic.woff2",
  "./assets/katex/fonts/KaTeX_SansSerif-Regular.woff2",
  "./assets/katex/fonts/KaTeX_Script-Regular.woff2",
  "./assets/katex/fonts/KaTeX_Size1-Regular.woff2",
  "./assets/katex/fonts/KaTeX_Size2-Regular.woff2",
  "./assets/katex/fonts/KaTeX_Size3-Regular.woff2",
  "./assets/katex/fonts/KaTeX_Size4-Regular.woff2",
  "./assets/katex/fonts/KaTeX_Typewriter-Regular.woff2",
  "./assets/katex/katex.min.css",
  "./assets/katex/katex.min.js",
  "./assets/katex/LICENSE",
  "./icon-192.png",
  "./icon-180.png",
  "./icon-512.png"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== location.origin) return;
  event.respondWith(
    fetch(event.request)
      .then(response => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
        return response;
      })
      .catch(async () => {
        const cached = await caches.match(event.request);
        return cached || caches.match("./index.html");
      })
  );
});

self.addEventListener("message", event => {
  if (event.data && event.data.type === "SKIP_WAITING") {
    self.skipWaiting();
  }
});
